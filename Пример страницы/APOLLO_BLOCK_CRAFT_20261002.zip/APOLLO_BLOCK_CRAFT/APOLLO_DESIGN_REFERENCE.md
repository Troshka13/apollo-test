# Справочник дизайна Apollo · токены, компоненты, анатомия, режимы, движок (дословно из блоков)

Часть набора `APOLLO_BLOCK_CRAFT/` (ядро — `APOLLO_BLOCK_CRAFT_GUIDE.md`). Выдержки — дословно из блоков (файл и строки указаны); «[имя]» — убранное имя человека, «…» — сокращение. Где правила дополнения (`addon/DESIGN.md`) расходятся с кодом блоков — прав код блоков.

Собрано 02.10.2026 по последним выданным блокам; пути — от корня пака передачи.
Основные образцы: `blocks/stretching-samara/DIR08-01…08_v1.1.0.html`, `blocks/cycle-samara/DIR07-02/05/06_v1.1.0.html`, `blocks/prices/PRICES-01/05_v1.2.0.html`, `blocks/home/HOME-01_v9.2.0.html`, `HOME-03_v8.2.0`, `HOME-05_v2.2.0`.

Статистика по 317 последним версиям блоков (все папки `blocks/*`, без HEAD): поверхности `dark` 147, `deep` 90, `paper` 78, `accent` 2 (PRICES-01 и ещё один). Атрибут `data-ag-surface` в CSS как селектор не используется — это маркер для людей и стенда; цвета задаются токенами корня.

---

## 1. Токены

### 1.1 Правило (addon/DESIGN.md, CODE_RULES §1)
- «Токены объявляются на собственном корне блока, например #ag-home-01. Глобальный :root из вставляемого блока не меняется. Каждый автономный файл содержит свои значения, даже если рядом есть другой блок.» (DESIGN.md)
- «токены реальными значениями или своими custom properties на корне. `var(--ag-…)` снаружи запрещён» (CODE_RULES §1).

### 1.2 Тёмная поверхность `dark` — полный набор (DIR08-01_v1.1.0, строки 94–110)
```css
#ag-dir08-01{
  --bg:#09090A;
  --panel:#111114;
  --accent:#FFC400;
  --accent-hover:#FFD44F;
  --accent-ink:#09090A;
  --text:#F4F4F5;
  --muted:#C4C4C9;
  --faint:#A2A2A9;
  --line:rgba(255,255,255,.1);
  --line-strong:rgba(255,255,255,.16);
  --fan:rgba(255,255,255,.16);          /* свой токен блока (декор «веер») */
  --f-display:"Oswald","Roboto Condensed","PT Sans Narrow","Arial Narrow","Helvetica Neue Condensed",sans-serif;
  --f-body:"Manrope","Inter",system-ui,-apple-system,"Segoe UI",Roboto,Arial,sans-serif;
  --r-pill:999px;
  --gutter:clamp(16px,4vw,48px);
  --max:1320px;
```
Сводка по всем dark-блокам выборки (значение: сколько раз): `--bg #09090A` (8; варианты #0B0B0D, #141416), `--panel/--card #111114` (+ #0E0E10, #111113, #131316), `--faint #A2A2A9` (9; в HOME-01 — #96969D), `--line rgba(255,255,255,.1)` (7; .09 — 4), `--line-strong rgba(255,255,255,.16)`. Дополнительно встречаются: `--tab-on:#18181C` (фон выбранной вкладки), `--card-open:#141418`, `--surface:#141416`, `--deep:#060607`, `--plate:#101013/#17171B` (плашка-монограмма), `--a08/--a12/--a35` = `rgba(255,196,0,.08/.12/.35)` (HOME-01: тинт и обводка плашки), `--ease:cubic-bezier(.22,.61,.36,1)`, `--r:14px`/`16px`, `--r-lg:22px`.

HOME-01_v9.2.0 (эталон G00, строки 126–153) — самый полный тёмный набор:
```css
  /* Токены: значения эталона G00, объявлены на корне блока */
  #ag-home-01{
    --bg:#09090A;
    --deep:#060607;
    --panel:#0E0E10;
    --surface:#141416;
    --accent:#FFC400;
    --accent-hover:#FFD44F;
    --accent-ink:#09090A;
    --a08:rgba(255,196,0,.08);
    --a12:rgba(255,196,0,.12);
    --a35:rgba(255,196,0,.35);
    --text:#F4F4F5;
    --muted:#C4C4C9;
    --faint:#96969D;
    --line:rgba(255,255,255,.09);
    --line-strong:rgba(255,255,255,.16);
    --f-display:…; --f-body:…;
    --ease:cubic-bezier(.22,.61,.36,1);
    --dur:.45s;
    --r:14px;
    --r-lg:22px;
    --r-pill:999px;
    --gutter:clamp(16px,4vw,48px);
    --max:1320px;
    --shot-h:clamp(440px,74vh,720px);
    --ov:clamp(40px,5vw,88px);
```

### 1.3 Глубокая `deep` (DIR08-08_v1.1.0, строки 75–90)
```css
#ag-dir08-08{
  --bg:#060607;
  --accent:#FFC400;
  --accent-hover:#FFD44F;
  --accent-ink:#09090A;
  --text:#F4F4F5;
  --muted:#C4C4C9;
  --faint:#A2A2A9;
  --line:rgba(255,255,255,.1);
  --line-strong:rgba(255,255,255,.16);
  --outline:rgba(255,255,255,.3);      /* контурное слово */
  --f-display:…; --f-body:…;
  --r-pill:999px;
  --gutter:clamp(16px,4vw,48px);
  --max:1320px;
```
В остальных deep-блоках: `--card:#111114`, `--card-open:#16161A`, `--tab-on:#17171B`, `--sheet:#0E0E11`.

### 1.4 Бумага `paper` — полный набор (DIR08-02_v1.1.0, строки 143–160)
```css
#ag-dir08-02{
  --bg:#F4F1EA;
  --sheet:#F9F7F2;
  --ink:#09090A;
  --text:#09090A;
  --muted:#3F3D39;
  --soft:#57544D;
  --kicker:#7A5C00;
  --ochre:#6B4F00;
  --rule:rgba(9,9,10,.16);
  --rule-strong:rgba(9,9,10,.34);
  --hl:#ECE3CB;
  --accent:#FFC400;
  --f-display:"Oswald","Roboto Condensed","PT Sans Narrow","Arial Narrow","Helvetica Neue Condensed",sans-serif;
  --f-body:"Manrope","Inter",system-ui,-apple-system,"Segoe UI",Roboto,Arial,sans-serif;
  --r-pill:999px;
  --gutter:clamp(16px,4vw,48px);
  --max:1320px;
```
Варианты `--sheet`: #F7F4EE (DIR07-02/06), #FFFDF8 (PRICES-05), #FBF9F4 (DIR08-06; «эмаль» ст. 150). `--rule` .16 (DIR08), .28 (DIR07-06 «штамп»).
Старое именование бумаги (HOME-05_v2.2.0, PRICES-05) — те же значения под другими именами:
```css
  #ag-home-05.ag-home-kids{
    --paper:#F4F1EA;
    --paper2:#EAE5D9;
    --ink:#09090A;
    --ink2:#3F3D39;
    --ink3:#5C5A55;
    --line:rgba(9,9,10,.12);
    --line2:rgba(9,9,10,.22);
    --accent:#FFC400;
    --accent-hi:#FFD44F;
    --kick:#7A5C00;
    --dark:#0E0E10;
    --text:#F4F4F5;
    --muted:#C4C4C9;
    --disp:"Oswald","PT Sans Narrow","Arial Narrow",Arial,sans-serif;
    --body:"Manrope","Helvetica Neue",Arial,sans-serif;
    --ease:cubic-bezier(.22,.61,.36,1);
    --row:1320px;
    --gut:clamp(16px,4vw,48px);
```
(HOME-03/04/05 используют `--disp/--body/--row/--gut`; новые DIR/PRICES — `--f-display/--f-body/--max/--gutter`. Для гайда — новое именование.)

### 1.5 Жёлтая поверхность `accent` (PRICES-01_v1.2.0, строки 127–143)
```css
  #ag-prices-01{
    --y:#FFC400;
    --y2:#FFD23F;
    --ink:#09090A;
    --ink2:rgba(9,9,10,.8);
    --ink3:rgba(9,9,10,.66);
    --card:#111113;
    --card2:#19191C;
    --text:#F4F4F5;
    --muted:#C4C4C9;
    --f-display:…; --f-body:…;
    --ease:cubic-bezier(.22,.61,.36,1);
    --spring:cubic-bezier(.3,1.9,.45,1);
    --r-pill:999px;
    --gutter:clamp(16px,4vw,48px);
    --max:1320px;
    …
    color:var(--ink);
    background:var(--y);
```
Ст. 116: «Жёлтая поверхность (`data-ag-surface="accent"`): текст — тушь #09090A сплошным, фокус — `outline:3px solid #09090A; outline-offset:3px`». На жёлтом — тёмные ценники (`--card`), кнопка тёмная с жёлтым текстом (`.ag-ph__btn{background:var(--ink)} … {color:var(--y)}`).

### 1.6 Шрифты
- Один `<link>` Google Fonts в каждом блоке: `family=Oswald:wght@500;600;700&family=Manrope:wght@400;500;600;700;800&display=swap` (+ два `preconnect`).
- Стеки (новые блоки): display `"Oswald","Roboto Condensed","PT Sans Narrow","Arial Narrow","Helvetica Neue Condensed",sans-serif`; body `"Manrope","Inter",system-ui,-apple-system,"Segoe UI",Roboto,Arial,sans-serif`. Короткий вариант display на бумаге (DIR07-02, PRICES-05): `"Oswald","Roboto Condensed","PT Sans Narrow","Arial Narrow",Arial,sans-serif`.
- Ст. 5: проверка в трёх режимах — Oswald+Manrope; Arial; широкий системный. Отсюда подгонка H1 по самому длинному слову (JS, ст. 42/43/66).
- DESIGN.md: H1 Oswald 600, 72–112px desktop / 38–52 mobile, lh 1–1.05; H2 40–64 / 30–38, lh 1.08–1.15; H3 Oswald 500 24–32 / 22–26; текст Manrope 17–19 / 16–18, lh 1.5–1.65; подпись 13–15; CTA Oswald 17–20, hit-area ≥ 44×44; цена Oswald 600 56–80 / 44–64, без переноса внутри числа и валюты. В блоках фактически H1/H2 — Oswald **700**, uppercase (см. §3).

### 1.7 Сетка и радиусы
- `--max:1320px` (DESIGN.md: «Рабочая ширина 1200–1280px; итог уточняется по текущему блоку»), `--gutter:clamp(16px,4vw,48px)`; обёртка: `width:100%;max-width:var(--max);margin:0 auto;padding:0 var(--gutter);`.
- DESIGN.md: поля 20px mobile / 32 tablet / 48–64 desktop; шкала 8/12/16/24/32/48/64/96; разрыв секций 72–112 desktop, 48–64 mobile.
- Факт в блоках: секция `padding:clamp(56px,7vw,112px) 0` (≤ 599/767 — `44px 0 40px`); первый экран `padding:clamp(20px,2.6vw,40px) 0 clamp(48px,5vw,80px)` (≤ 599 — `10px 0 32px`).
- Радиусы: `--r-pill:999px` (кнопки, плашки, чипы), рамка кадра 16px (≤ 599 — 12px), карточка/панель 16px (≤ 767 — 12px), карточка тренера 18px, полоса/плашка 14px, вкладки на телефоне 10px, ценник-карточка `0 0 12px 12px`, фокус-рамка `border-radius:4px` (8px на жёлтом/FAQ бумаги, 6px FAQ тёмный). DESIGN.md: «Для новых медиа-рамок диапазон 0–16px; у округлой CTA сохранять исходную форму. Не вводить новую форму кнопки в каждом блоке.»

### 1.8 Цвета-роли и где применяются
| Токен | Значение | Роль / где |
|---|---|---|
| `--accent` | #FFC400 | На тёмном: кикер и его черта, цифры планки фактов, заливка primary-кнопки, стрелки ссылок, точки-маркеры, подчёркивание ссылок `rgba(255,196,0,.6)`, контур фокуса (`outline:3px solid var(--accent)`), «луч» выбранной вкладки, крестик FAQ. На бумаге — **только заливкой** (карточка «выгоднее всего», маркер под тёмным текстом, точка в знаке), никогда текстом. |
| `--accent-hover` | #FFD44F | hover primary-кнопки (`--y2 #FFD23F` на жёлтой поверхности). |
| `--accent-ink` | #09090A | текст на жёлтом (primary-кнопка, жёлтая карточка). |
| `--text` | #F4F4F5 (тёмн.) / #09090A (бумага) | основной текст, H1/H2. |
| `--muted` | #C4C4C9 / #3F3D39 | лид, ответы FAQ, подписи. |
| `--faint` | #A2A2A9 (#96969D) | крошки, подписи-метки «Залы с единоборствами:», неактивные вкладки (только тёмные). |
| `--soft` | #57544D | бумага: `dt`, название пакета, «за занятие». |
| `--kicker` | #7A5C00 | бумага: кикер, его черта, подчёркивание ссылок `text-decoration-color:var(--kicker)`, hover телефона. |
| `--ochre` | #6B4F00 | бумага: стрелки ссылок (`.ag-zp__li{color:var(--ochre)}`), hover ссылки, акцентные штрихи SVG, метки полей `.ag-xp__lab`, `dt` подсвеченной строки. Заменитель жёлтого на бумаге. |
| `--ink` | #09090A | бумага: фокус, рамки «штампа», верхняя кромка карточек `border-top:3px solid var(--ink)`, кнопка `--ink`, выбранный переключатель. |
| `--sheet` | #F9F7F2 … #FFFDF8 | бумага: карточка/лист поверх фона. |
| `--rule` / `--rule-strong` | rgba(9,9,10,.16) / .34 | бумага: разделители строк / колонок. |
| `--line` / `--line-strong` | rgba(255,255,255,.1) / .16 | тёмн.: разделители, обводка карточек и вкладок (`inset 0 0 0 1px var(--line-strong)` у кадра). |
| `--hl` | #ECE3CB | бумага: подсветка строки сравнения при наведении/автопоказе (`background:var(--hl)`, `dt` → `--ochre`). |
| `--panel`/`--card` | #111114 | тёмн.: подложка рамки кадра, карточки FAQ, панели вкладок. |
| `--tab-on` | #18181C / #17171B | фон выбранной вкладки. |

### 1.9 Контраст (посчитано по WCAG из значений токенов)
- Бумага #F4F1EA: `--kicker` #7A5C00 = 5.54:1; `--ochre` #6B4F00 = 6.79; `--soft` #57544D = 6.70; `--muted` #3F3D39 = 9.61; `--ink` = 17.65. **#FFC400 на бумаге = 1.42:1 — жёлтый текст на бумаге нельзя.** `--kicker` на `--hl` #ECE3CB = 4.89 (поэтому на подсветке `dt` красится `--ochre`).
- Тёмная #09090A: `--text` 18.11; `--muted` 11.46; `--faint` #A2A2A9 7.85 (#96969D 6.77); `--accent` 12.46; #09090A на #FFC400 = 12.46.
- Правила: DESIGN.md — «Жёлтый текст не ставить на бумажную поверхность. Жёлтые CTA имеют тёмный текст. Ошибки обозначаются словом и связью с полем; цвет не единственный сигнал.»; «Border … Разделители; не использовать для важного текста». Ст. 111: «жёлтый на бумаге — плашкой со сдвигом, как вторая краска». Ст. 6: контраст от 4.5:1, axe WCAG 2.2 AA.
- Расхождение для гайда: таблица DESIGN.md (проект дополнения v1) даёт для бумаги Text #171719, Muted #55555A, Border rgba(23,23,25,.20), Focus #171719; в production-блоках — `--ink/--text #09090A`, `--muted #3F3D39`, `--rule rgba(9,9,10,.16)`, фокус `var(--ink)`. Действуют значения блоков (DESIGN.md: «Приоритет у уже принятой системы Apollo»).

---

## 2. Корень и сброс — дословно (DIR08-06_v1.1.0, бумага, строки 83–135)
```css
  #ag-dir08-06{
    --bg:#F4F1EA;
    --sheet:#FBF9F4;
    --ink:#09090A;
    --text:#09090A;
    --muted:#3F3D39;
    --soft:#57544D;
    --kicker:#7A5C00;
    --ochre:#6B4F00;
    --rule:rgba(9,9,10,.16);
    --accent:#FFC400;
    --f-display:"Oswald","Roboto Condensed","PT Sans Narrow","Arial Narrow","Helvetica Neue Condensed",sans-serif;
    --f-body:"Manrope","Inter",system-ui,-apple-system,"Segoe UI",Roboto,Arial,sans-serif;
    --gutter:clamp(16px,4vw,48px);
    --max:1320px;
    position:relative;
    display:block;
    margin:0;
    padding:0;
    overflow-x:clip;
    color:var(--text);
    background:var(--bg);
    font-family:var(--f-body);
    font-size:16px;
    font-weight:400;
    line-height:1.5;
    letter-spacing:normal;
    text-align:left;
    -webkit-font-smoothing:antialiased;
    -moz-osx-font-smoothing:grayscale;
    text-rendering:optimizeLegibility;
    -webkit-text-size-adjust:100%;
    text-size-adjust:100%;
    scroll-margin-top:96px;
  }
  #ag-dir08-06 *,
  #ag-dir08-06 *::before,
  #ag-dir08-06 *::after{box-sizing:border-box;}
  #ag-dir08-06 p,
  #ag-dir08-06 h2,
  #ag-dir08-06 table,
  #ag-dir08-06 th,
  #ag-dir08-06 td{margin:0;padding:0;}
  #ag-dir08-06 table{border-collapse:separate;border-spacing:0;}
  #ag-dir08-06 th{font-weight:inherit;text-align:inherit;}
  #ag-dir08-06 strong{font-weight:inherit;}
  #ag-dir08-06 b{font-weight:700;}
  #ag-dir08-06 svg{display:block;flex:none;overflow:visible;}
  #ag-dir08-06 .ag-nw{white-space:nowrap;}
  #ag-dir08-06 .ag-vh{position:absolute;width:1px;height:1px;margin:-1px;padding:0;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0;}
  #ag-dir08-06 .ag-zp__sprite{position:absolute;width:0;height:0;overflow:hidden;}
  #ag-dir08-06.ag-scope a{color:inherit;text-decoration:none;-webkit-tap-highlight-color:transparent;}
  #ag-dir08-06.ag-scope :is(a,button):focus-visible{outline:3px solid var(--ink);outline-offset:3px;border-radius:4px;}
```
Дополнения сброса из других блоков (берутся по составу блока):
- списки: `#ag-dir08-01 ul, #ag-dir08-01 ol{list-style:none;}`; `img{border:0;}`;
- кнопки (DIR08-02): `#ag-dir08-02 button{margin:0;font:inherit;color:inherit;background:none;border:0;-webkit-appearance:none;appearance:none;}`;
- `#ag-dir08-02 [hidden]{display:none !important;}`;
- summary в фокусе (FAQ): `#ag-dir08-07.ag-scope :is(a,button,summary):focus-visible{outline:3px solid var(--accent);outline-offset:3px;border-radius:6px;}`;
- фокус-цель skip-ссылки в H1-блоке: `.ag-zh__text:focus-visible{outline:2px solid var(--accent);outline-offset:10px;border-radius:6px;}` + `.ag-zh__text:focus:not(:focus-visible){outline:none;}`;
- primary-кнопка на тёмном меняет цвет фокуса: `.ag-btn--primary:focus-visible{outline-color:var(--text);}`.
Почему так (ст. 14, 45, 52, 3): сброс — типовыми селекторами `#id p` (1,0,1), а не `#id.ag-scope p` (1,1,1), чтобы компоненты ниже перевешивали; а вот `a{color:inherit}`, цвет кнопки-ссылки, подчёркивание и фокус — с `.ag-scope` (иначе Tilda `#allrecords a:focus-visible` перебивает). HOME-05 комментирует: «сброс на типовых селекторах (1,0,1): правила компонентов ниже их перевешивают».
`overflow-x:clip` на корне (ст. 35: `overflow:hidden` у предка ломает `position:sticky`). `scroll-margin-top:96px` — под шапку сайта.

---

## 3. Компоненты (дословно)

### 3.1 Кикер `.ag-kicker` — всегда `<p>`, текст в одном `<span>` (ст. 65; COPY_STANDARD §5)
Разметка: `<p class="ag-kicker"><span>Сколько стоит</span></p>`
Тёмная (DIR08-01):
```css
  #ag-dir08-01 .ag-kicker{
    display:flex;align-items:center;gap:10px;margin-top:4px;
    font-family:var(--f-display);font-size:13px;font-weight:600;line-height:1.2;
    letter-spacing:.14em;text-transform:uppercase;color:var(--accent);
  }
  #ag-dir08-01 .ag-kicker::before{content:"";flex:none;width:22px;height:2px;background:var(--accent);}
```
Бумага (DIR08-06): то же, `color:var(--kicker)` и `::before{…background:var(--kicker);}`.
Жёлтая (PRICES-01): `letter-spacing:.16em;… color:var(--ink);` и `::before{…width:26px;height:3px;background:var(--ink);}`.

### 3.2 H1 / H2 / лид
H1 первого экрана (DIR08-01):
```css
  #ag-dir08-01 .ag-zh__title{
    margin-top:16px;
    font-family:var(--f-display);font-size:clamp(2.6rem,5vw,4.6rem);font-weight:700;
    line-height:.96;letter-spacing:-.012em;text-transform:uppercase;color:var(--text);
  }
  /* ≤ 599 */ #ag-dir08-01 .ag-zh__title{font-size:clamp(2.05rem,10.2vw,2.7rem);margin-top:8px;line-height:.98;}
```
Другие H1: HOME-01 `clamp(2.5rem,5.2vw,5.25rem)`, lh .95, ls -.01em, `text-wrap:balance;overflow-wrap:break-word;` + `@supports (width:1cqi){ .ag-hh__text{container-type:inline-size;} .ag-hh__title{font-size:clamp(2.5rem,14.6cqi,5.25rem);} }`; PRICES-01 `clamp(2.6rem,5.2vw,4.9rem)`, `max-width:15ch`, lh .96, ls -.015em. Разметка H1: `<h1 class="ag-zh__title" id="ag-dir08-01-title">Растяжка в&nbsp;Самаре</h1>`, обёртка текста `id="ag-main" tabindex="-1"` (цель skip-ссылки шапки). JS-подгонка по самому длинному слову (canvas `measureText`, таймер 30 мс + `ResizeObserver` + `document.fonts`, без rAF), метка `data-ag-fit`.

H2 секции (DIR08-02/06/07 — одинаково):
```css
  #ag-dir08-02 .ag-zc__title{
    max-width:900px;margin-top:14px;font-family:var(--f-display);font-size:clamp(1.9rem,3.6vw,3.4rem);font-weight:700;
    line-height:1.02;letter-spacing:-.005em;text-transform:uppercase;color:var(--text);text-wrap:balance;
  }
  /* ≤ 767 (или ≤ 599) */ .ag-zc__title{margin-top:10px;font-size:clamp(1.6rem,7.6vw,2rem);}
```
H2 финального CTA (DIR08-08): `font-size:clamp(2rem,4vw,3.8rem);font-weight:700;line-height:1;letter-spacing:-.008em;` (≤ 599: `clamp(1.7rem,8.4vw,2.2rem)`).
H3 (колонка/вкладка): `font-size:clamp(1.25rem,1.7vw,1.6rem);font-weight:600;line-height:1.1;text-transform:uppercase;letter-spacing:.01em;`.

Лид:
```css
  #ag-dir08-01 .ag-zh__lead{max-width:54ch;margin-top:20px;font-size:clamp(17px,1.3vw,19px);font-weight:500;line-height:1.6;color:var(--muted);text-wrap:pretty;}
  #ag-dir08-02 .ag-zc__lead{max-width:64ch;margin-top:18px;font-size:clamp(16px,1.2vw,18px);line-height:1.6;color:var(--muted);text-wrap:pretty;}
  /* ≤ 767 */ .ag-zc__lead{margin-top:12px;font-size:15.5px;line-height:1.55;}
```
Шапка секции «заголовок слева — абзац справа» (DIR08-06): `.ag-zp__head{display:grid;grid-template-columns:minmax(0,7fr) minmax(0,5fr);gap:20px clamp(28px,4vw,72px);align-items:end;}` → < 1024 одна колонка.

### 3.3 Кнопки `.ag-btn`
Разметка (всегда внутренний `span.ag-btn__in` — для F23, иконка из спрайта):
```html
<a class="ag-btn ag-btn--primary" href="/request?direction=stretching-samara&amp;club=nofitness" data-ag-track="request_start" data-ag-params='{"from":"hero","direction":"stretching-samara"}'><span class="ag-btn__in">Записаться на растяжку<svg class="ag-btn__i" width="16" height="16" aria-hidden="true" focusable="false"><use href="#ag-dir08-01-i-arrow"/></svg></span></a>
<a class="ag-btn ag-btn--ghost" href="tel:+79171075179" data-ag-track="phone_click" data-ag-params='{"page":"DIR08","from":"cta"}'><span class="ag-btn__in"><svg class="ag-btn__t" width="18" height="18" aria-hidden="true" focusable="false"><use href="#ag-dir08-08-i-tel"/></svg><span>Позвонить <span class="ag-nw">+7&nbsp;917&nbsp;107-51-79</span></span></span></a>
```
База + варианты (DIR08-08, deep):
```css
  #ag-dir08-08 .ag-btn{
    display:inline-flex;align-items:center;justify-content:center;gap:10px;
    min-height:56px;padding:12px 24px;border:1.5px solid transparent;border-radius:var(--r-pill);
    font-family:var(--f-display);font-size:16px;font-weight:600;line-height:1.15;
    letter-spacing:.06em;text-transform:uppercase;text-align:center;cursor:pointer;
    transition:background-color .2s ease,box-shadow .2s ease,border-color .2s ease,color .2s ease;
  }
  #ag-dir08-08.ag-scope .ag-btn--primary{background:var(--accent);color:var(--accent-ink);box-shadow:0 10px 30px rgba(255,196,0,.2);}
  #ag-dir08-08.ag-scope .ag-btn--primary:focus-visible{outline-color:var(--text);}
  #ag-dir08-08.ag-scope .ag-btn--ghost{border-color:rgba(255,255,255,.28);color:var(--text);}
  #ag-dir08-08 .ag-btn__i{width:16px;height:16px;margin-right:-4px;}
  #ag-dir08-08 .ag-btn__t{color:var(--accent);}
  @media (hover:hover){
    #ag-dir08-08.ag-scope .ag-btn--primary:hover{background:var(--accent-hover);box-shadow:0 14px 36px rgba(255,196,0,.3);}
    #ag-dir08-08.ag-scope .ag-btn--ghost:hover{border-color:var(--accent);color:var(--accent);}
  }
  /* ≤ 599 */ #ag-dir08-08 .ag-btn{min-height:52px;padding:12px 18px;font-size:15px;}
```
Размеры по блокам: min-height 54 (DIR08-01, padding 12px 26px), 56 (DIR08-08), 52 (HOME-01, DIR07-06), 58 (PRICES-01 `.ag-ph__btn`, padding 14px 28px, 17px); на телефоне 48–52 и `flex:1 1 100%` / `width:100%`.
Ghost на фоне кадра (HOME-01): `.ag-btn--ghost{background:rgba(9,9,10,.4);color:var(--text);border-color:var(--line-strong);}`.
Ink — тёмная кнопка на бумаге (DIR07-06):
```css
  #ag-dir07-06 .ag-btn{ … min-height:52px;padding:12px 24px;border:1.5px solid transparent;border-radius:var(--r-pill);
    font-family:var(--f-display);font-size:15px;font-weight:600;line-height:1.15; letter-spacing:.06em;text-transform:uppercase;… transition:background-color .2s ease; }
  #ag-dir07-06.ag-scope .ag-btn--ink{background:var(--ink);color:#F4F4F5;}
  #ag-dir07-06 .ag-btn__i{width:16px;height:16px;margin-right:-4px;color:var(--accent);}
  @media (hover:hover){ #ag-dir07-06.ag-scope .ag-btn--ink:hover{background:#26262B;} }
```
Нажатие F23 (одинаковый хвост во всех v1.1.0, MOTION_ADDENDUM «Press CTA 120–160мс scale .98; возврат 220–280мс»):
```css
  /* F23 · нажатие: область кнопки неподвижна, сжимается подпись со значком */
  #ag-dir08-01 .ag-btn__in{display:inline-flex;align-items:center;justify-content:inherit;gap:inherit;flex:1 1 auto;min-width:0;
    transition:transform 260ms cubic-bezier(.34,1.56,.64,1);}
  #ag-dir08-01 .ag-btn:active .ag-btn__in{transform:scale(.98);transition-duration:140ms;transition-timing-function:cubic-bezier(.22,.61,.36,1);}
  @media (prefers-reduced-motion:reduce){
    #ag-dir08-01 .ag-btn__in{transition:none;}
    #ag-dir08-01 .ag-btn:active .ag-btn__in{transform:none;}
  }
```
+ в JS: `root.addEventListener("touchstart", function () {}, { passive: true });` («iOS включает :active только при слушателе касания (F23)»). Магнит (`data-ag-magnetic`) в проходе v1.1.0 снят с кнопок.
Правила: COPY §6 — «Глагол + объект», «Одна главная кнопка на экран. Вторичные — текстовой ссылкой со стрелкой»; CODE_RULES — `<a>` для перехода, `<button>` для действия; ст. 45 цвет ссылки-кнопки — с `.ag-scope`; ст. 51 ряд кнопок — `flex-wrap`, не лента.

### 3.4 Текстовая ссылка с подчёркиванием и стрелкой (ст. 31, 67, 79, 103, 148)
```html
<a class="ag-zp__link" href="/prices" data-ag-track="nav_click" data-ag-params='{"to":"prices","from":"dir08_prices"}'>Все цены и персональные <span class="ag-nw">занятия<svg class="ag-zp__li" width="14" height="14" aria-hidden="true" focusable="false"><use href="#ag-dir08-06-i-arrow"/></svg></span></a>
```
Бумага (DIR08-06):
```css
  #ag-dir08-06.ag-scope .ag-zp__link{
    display:inline-block;padding:10px 0;line-height:24px;font-size:16px;font-weight:600;color:var(--ink);
    text-decoration:underline;text-decoration-color:var(--kicker);text-decoration-thickness:1.5px;text-underline-offset:5px;
    transition:color .2s ease;
  }
  #ag-dir08-06 .ag-zp__li{display:inline-block;vertical-align:-2px;margin-left:6px;color:var(--ochre);}
  @media (hover:hover){ #ag-dir08-06.ag-scope .ag-zp__link:hover{color:var(--ochre);} }
```
Тёмная (DIR08-04): `color:var(--text); text-decoration-color:rgba(255,196,0,.6);text-decoration-thickness:1.5px;text-underline-offset:6px;`, стрелка `color:var(--accent)`, hover `color:var(--accent)`.
Ссылка внутри абзаца FAQ: `display:inline-block;padding:10px 0;margin:-10px 0;line-height:inherit;` (не раздувает строку, но даёт высоту попадания).
Телефон-ссылка (тёмн.): `display:inline-flex;align-items:center;min-height:44px; font-family:var(--f-display);font-size:19px;font-weight:600;letter-spacing:.02em;color:var(--text);white-space:nowrap; text-decoration:underline;text-decoration-color:rgba(255,196,0,.6);text-decoration-thickness:1px;text-underline-offset:6px;`.
Крошки: `min-height:44px;color:var(--muted);text-decoration:underline;text-decoration-color:rgba(255,255,255,.25);text-underline-offset:4px;`, разделитель `<li class="ag-zh__sep" aria-hidden="true">/</li>`, текущая — `<span aria-current="page">`.
Ст. 70: короткая текстовая ссылка — `min-width:44px`. Длинные адреса: `<span class="ag-nw">Молодогвардейская,</span> <span class="ag-nw">56<svg…></span>` (ст. 42, 61).

### 3.5 Спрайт иконок (ст. 4, 53)
```html
  <svg class="ag-zh__sprite" width="0" height="0" aria-hidden="true" focusable="false">
    <symbol id="ag-dir08-01-i-arrow" viewBox="0 0 16 16"><path d="M3 8h9.5M8.8 4.2 12.6 8l-3.8 3.8" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></symbol>
    <symbol id="ag-dir08-01-i-down" viewBox="0 0 16 16"><path d="M8 2.6v10.2M3.9 8.7 8 12.8l4.1-4.1" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></symbol>
  </svg>
```
Телефон (DIR08-08): `<symbol id="ag-dir08-08-i-tel" viewBox="0 0 24 24"><path d="M6.5 3.5h3l1.5 4-2 1.3a11 11 0 0 0 6.2 6.2l1.3-2 4 1.5v3a2 2 0 0 1-2.2 2A16.5 16.5 0 0 1 4.5 5.7a2 2 0 0 1 2-2.2Z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/></symbol>`.
Скрытие: `.ag-zh__sprite{position:absolute;width:0;height:0;overflow:hidden;}`. id символа = `<id корня>-i-<имя>` (ст. 53: приставка `-i-`). Использование: `<svg class="…" width="14" height="14" aria-hidden="true" focusable="false"><use href="#ag-dir08-01-i-arrow"/></svg>`, цвет — через `color` (stroke=currentColor). Ст. 76/134: разные цвета одного символа — custom properties на внешнем `<svg>`. HOME-01 (старый) — без спрайта, инлайн-SVG.

### 3.6 Фото-рамка и figcaption (DIR08-01; MEDIA_RULES; CODE_RULES §5)
```html
      <figure class="ag-zh__fig" data-ag-slot="DIR08-01-floor" data-ag-ratio="21:9" data-ag-brief="Группа на занятии по растяжке в зале на Молодогвардейской, 56, широкий план, ровный спокойный свет">
        …
        <span class="ag-zh__frame" data-ag-parallax-scope>
          <span class="ag-zh__imgbox"><img class="ag-zh__img" src="https://static.tildacdn.pub/tild6464-3663-4266-a161-383031663236/51-1024x683.jpg" width="1024" height="683" alt="Зал Apollo NoFitness на Молодогвардейской, 56" decoding="async" fetchpriority="high" data-ag-anim="parallax" data-ag-parallax="0.06"></span>
        </span>
        <figcaption class="ag-zh__label"><span class="ag-zh__dot" aria-hidden="true"></span><span><span class="ag-nw">Молодогвардейская,</span> 56</span></figcaption>
      </figure>
```
```css
  #ag-dir08-01 .ag-zh__frame{
    position:relative;z-index:1;display:block;aspect-ratio:3/2;overflow:hidden;border-radius:16px;background:var(--panel);
    box-shadow:0 30px 70px rgba(0,0,0,.45),inset 0 0 0 1px var(--line-strong);
  }
  #ag-dir08-01 .ag-zh__imgbox{position:absolute;inset:-5% 0;display:block;}   /* слой 110 % под parallax */
  #ag-dir08-01 .ag-zh__img{display:block;width:100%;height:100%;max-width:none;margin:0;object-fit:cover;object-position:50% 50%;}
  #ag-dir08-01 .ag-zh__label{
    display:flex;align-items:center;justify-content:flex-end;gap:10px;min-height:40px;padding-top:12px;
    font-family:var(--f-display);font-size:13px;font-weight:600;line-height:16px;letter-spacing:.1em;text-transform:uppercase;color:var(--muted);
  }
  #ag-dir08-01 .ag-zh__dot{flex:none;width:7px;height:7px;border-radius:50%;background:var(--accent);box-shadow:0 0 0 3px rgba(255,196,0,.18);}
  /* ≤ 599 */ .ag-zh__frame{border-radius:12px;box-shadow:0 18px 40px rgba(0,0,0,.4),inset 0 0 0 1px var(--line-strong);}
```
Правила: LCP-кадр — `width height fetchpriority="high"`, без `loading`, без появления, только `parallax 0.06` (ст. 40), parallax не на элементе с CSS-transform (ст. 74); обычный кадр — `loading="lazy" decoding="async"` + `srcset`; `figcaption` — прямой потомок `figure` (ст. 123); подпись/alt — по тому, что видно (ст. 38), не сверено → `alt=""` и подпись только местом; слот — атрибутами на `<figure>`: `data-ag-slot`, `data-ag-ratio`, `data-ag-brief` (+ `data-ag-consent`). Контентное фото — не CSS-фон.
Слот без кадра / нет портрета — монограмма (ст. 28; DIR07-05):
```html
<figure class="ag-xt__plate" data-ag-slot="DIR07-05-[имя]" data-ag-ratio="4:5" data-ag-brief="Портрет [имя], одинаковый фон и свет"><span class="ag-xt__ini" aria-hidden="true">[инициалы]</span></figure>
```
```css
  #ag-dir07-05 .ag-xt__plate{
    position:relative;width:100%;aspect-ratio:4/5;overflow:hidden;display:flex;align-items:center;justify-content:center;
    background:var(--plate);border:1px solid var(--line);border-radius:12px;
  }
  #ag-dir07-05 .ag-xt__plate::after{content:"";position:absolute;left:0;right:0;bottom:0;height:3px;background:var(--accent);}
  #ag-dir07-05 .ag-xt__ini{font-family:var(--f-display);font-size:clamp(34px,3.4vw,48px);font-weight:600;letter-spacing:.06em;color:var(--faint);}
```
Имя класса заглушки: CODE_RULES — `.agph`, DESIGN.md — `.ag-ph` (а `ag-ph` уже занят как префикс PRICES-01 hero) — в гайде назвать одно, `.agph`.

### 3.7 Карточки
Карточка-панель (тёмн., DIR07-05):
```css
  #ag-dir07-05 .ag-xt__lead-card{
    display:grid;grid-template-columns:clamp(150px,15vw,200px) minmax(0,1fr);gap:clamp(20px,3vw,44px);align-items:center;
    padding:clamp(18px,2.2vw,28px);border:1px solid var(--line-strong);border-radius:18px;background:var(--card);
  }
  #ag-dir07-05 .ag-xt__row{display:grid;grid-template-columns:auto minmax(0,1fr);gap:8px 28px;align-items:baseline;padding:14px clamp(18px,2.2vw,28px);border:1px solid var(--line);border-radius:14px;}
  #ag-dir07-05 .ag-xt__say{flex:1 1 360px;max-width:62ch;padding-left:14px;border-left:2px solid var(--accent);font-size:clamp(15.5px,1.15vw,17px);font-weight:600;line-height:1.55;color:var(--text);}
```
Карточка FAQ с жёлтой «бирочкой» сверху (DIR08-07): `border:1px solid var(--line-strong);border-radius:16px;background:var(--card);` + `::before{content:"";position:absolute;left:22px;top:-1px;width:44px;height:3px;border-radius:0 0 3px 3px;background:var(--accent);}`.
Бумажная карточка-ценник (DIR08-06): `border-top:3px solid var(--ink);border-radius:0 0 12px 12px;background:var(--sheet); box-shadow:inset 0 -1px 0 var(--rule),inset 1px 0 0 var(--rule),inset -1px 0 0 var(--rule);`.
Правила: DESIGN.md — «Адрес и цена не скрываются за hover, переворотом или диалогом. Карточка может иметь основную ссылку и отдельные действия, но вложенных ссылок быть не должно»; ст. 17 кнопки в карточке с растянутой ссылкой — вне ссылки и с `z-index` выше; ст. 15 колода — `grid-auto-columns:82%`; ст. 16 `padding-top` у колоды; ст. 25 равная высота — `grid` + `align-items:stretch`; ст. 131 карточка из двух частей — `subgrid`; ст. 27/55 hover-сдвиг под `stagger` — на внутреннем элементе.

### 3.8 Планка фактов (P14; DIR08-01)
```html
        <ul class="ag-zh__facts" data-ag-anim="stagger" data-ag-start="top bottom" data-ag-delay="120" data-ag-stagger="70" data-ag-distance="12">
          <li><a class="ag-zh__fact" href="/nofitness" data-ag-track="club_select" data-ag-params='{"club":"nofitness","from":"dir08_hero"}'><b>1</b><span class="ag-zh__cap"><span>зал с растяжкой: <span class="ag-nw">Молодогвардейская,</span> <span class="ag-nw">56<svg class="ag-zh__fi" width="14" height="14" aria-hidden="true" focusable="false"><use href="#ag-dir08-01-i-arrow"/></svg></span></span></span></a></li>
          <li><a class="ag-zh__fact" href="#ag-dir08-06" data-ag-track="page_jump" data-ag-params='{"to":"prices","from":"dir08_hero"}'><b>500&nbsp;₽</b><span class="ag-zh__cap"><span>за тренировку при абонементе на&nbsp;12; разовое —&nbsp;<span class="ag-nw">900&nbsp;₽<svg class="ag-zh__fi" …><use href="#ag-dir08-01-i-down"/></svg></span></span></span></a></li>
        </ul>
```
```css
  #ag-dir08-01 .ag-zh__facts{display:grid;grid-template-columns:minmax(150px,1fr) minmax(0,1.6fr);column-gap:clamp(18px,2.2vw,34px);margin-top:clamp(24px,2.6vw,34px);padding-top:18px;border-top:1px solid var(--line-strong);}
  #ag-dir08-01 .ag-zh__fact{display:grid;gap:8px;align-content:start;min-height:44px;height:100%;padding:0 0 4px;}
  #ag-dir08-01 .ag-zh__fact b{font-family:var(--f-display);font-size:clamp(30px,2.6vw,40px);font-weight:600;line-height:.95;color:var(--accent);white-space:nowrap;font-variant-numeric:tabular-nums;}
  #ag-dir08-01 .ag-zh__cap{font-size:13.5px;line-height:1.45;color:var(--muted);}
  #ag-dir08-01.ag-scope a.ag-zh__fact .ag-zh__cap>span{color:var(--text);text-decoration:underline;text-decoration-color:rgba(255,255,255,.22);text-underline-offset:4px;transition:text-decoration-color .2s ease;}
  @media (max-width:767px){
    #ag-dir08-01 .ag-zh__facts{display:grid;grid-template-columns:minmax(0,1fr);gap:0;padding-top:0;border-top:0;}
    #ag-dir08-01 .ag-zh__facts>li{border-top:1px solid var(--line);}
    #ag-dir08-01 .ag-zh__fact{grid-template-columns:86px minmax(0,1fr);align-items:center;gap:14px;padding:11px 0 10px;}
  }
```
Планка — оглавление (ссылки на места страницы). Без `count` («Планка без счётчика (стандарт 11)»: цены и однозначные числа не крутим).

### 3.9 Таблица цен (ст. 32, 75, 107, 109, 140; DESIGN: «Цена … без переноса внутри числа и валюты»)
Вариант A — таблица-карточки с явными ролями (DIR08-06):
```html
      <table class="ag-zp__table" role="table" aria-labelledby="ag-dir08-06-title">
        <thead class="ag-zp__thead" role="rowgroup">
          <tr role="row"><th role="columnheader" scope="col">Пакет</th><th role="columnheader" scope="col">Стоимость</th><th role="columnheader" scope="col">За занятие</th></tr>
        </thead>
        <tbody class="ag-zp__body" role="rowgroup" data-ag-anim="stagger" data-ag-children="tr" data-ag-from="none" data-ag-stagger="90" data-ag-dur="900">
          <tr class="ag-zp__card" role="row">
            <th class="ag-zp__pack" role="rowheader" scope="row">1 тренировка</th>
            <td class="ag-zp__sum" role="cell"><span class="ag-nw">900&nbsp;₽</span></td>
            <td class="ag-zp__per" role="cell"><span class="ag-nw">900&nbsp;₽</span><span class="ag-zp__pl" aria-hidden="true">за занятие</span></td>
          </tr>
          …
          <tr class="ag-zp__card ag-zp__card--best" role="row" data-ag-best>
            <th class="ag-zp__pack" role="rowheader" scope="row">12 тренировок</th>
            <td class="ag-zp__sum" role="cell"><strong class="ag-nw">6&nbsp;000&nbsp;₽</strong></td>
            <td class="ag-zp__per" role="cell"><strong class="ag-nw">500&nbsp;₽</strong><span class="ag-zp__pl" aria-hidden="true">за занятие</span><span class="ag-vh"> — выгоднее всего</span></td>
          </tr>
```
```css
  #ag-dir08-06 .ag-zp__table{display:block;width:100%;margin-top:clamp(28px,3.4vw,48px);font-variant-numeric:tabular-nums;}
  #ag-dir08-06 .ag-zp__thead{position:absolute;width:1px;height:1px;margin:-1px;padding:0;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0;}
  #ag-dir08-06 .ag-zp__body{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr) minmax(0,1fr) minmax(0,2fr);gap:clamp(8px,1vw,14px);}
  #ag-dir08-06 .ag-zp__sum{margin-top:clamp(18px,2.2vw,34px);font-family:var(--f-display);font-size:clamp(28px,2.7vw,40px);font-weight:600;line-height:1;letter-spacing:-.005em;color:var(--text);}
  #ag-dir08-06 .ag-zp__card--best{
    grid-template-columns:minmax(0,1fr) auto;grid-template-rows:auto 1fr;column-gap:20px;
    border-top-color:var(--ink);background:var(--accent);box-shadow:none;
  }
  #ag-dir08-06 .ag-zp__card--best .ag-zp__per{ … font-family:var(--f-display);font-size:clamp(52px,5.2vw,84px);font-weight:700;line-height:.9;letter-spacing:-.01em;text-align:right; }
  @media (max-width:1023px){ .ag-zp__body{grid-template-columns:repeat(3,minmax(0,1fr));} .ag-zp__card--best{grid-column:1 / -1;min-height:0;} }
```
Вариант B — обычная таблица в «штампе» (DIR07-06), лучший пакет — жёлтый маркер под тёмным текстом:
```css
  #ag-dir07-06 .ag-xp__table{width:100%;margin-top:10px;font-variant-numeric:tabular-nums;}
  #ag-dir07-06 .ag-xp__table thead th{
    padding:8px 12px 10px 0;border-bottom:1px solid var(--ink);
    font-family:var(--f-display);font-size:12px;font-weight:600;line-height:1.3;letter-spacing:.12em;text-transform:uppercase;color:var(--muted);
  }
  #ag-dir07-06 .ag-xp__table tbody th,
  #ag-dir07-06 .ag-xp__table tbody td{padding:12px 12px 12px 0;border-bottom:1px solid var(--rule);vertical-align:baseline;}
  #ag-dir07-06 .ag-xp__table td{font-family:var(--f-display);font-size:clamp(20px,1.8vw,26px);font-weight:600;line-height:1.1;color:var(--text);}
  #ag-dir07-06 .ag-xp__table th:nth-child(n+2),
  #ag-dir07-06 .ag-xp__table td{text-align:right;}
  #ag-dir07-06 .ag-xp__best strong{padding:1px 8px;margin-right:-8px;background:var(--accent);border-radius:3px;}
```
Общие признаки «лучшего»: `data-ag-best`, `<strong>`, скрытое `.ag-vh` «выгоднее всего». Ст. 90: неподтверждённая цена — без цифры в первом экране, прайс после оговорки, без `offers` в JSON-LD.

### 3.10 FAQ: details/summary (DESIGN «FAQ … нативных details»; ст. 99, 105, 115, 120, 148)
```html
        <details class="ag-zq__card" open>
          <summary class="ag-zq__cq"><span class="ag-zq__qt">Совсем не гнусь, возьмут в группу?</span><span class="ag-zq__ic" aria-hidden="true"></span></summary>
          <div class="ag-zq__a"><p>Да. …</p></div>
        </details>
        …
        <button class="ag-zq__all" type="button" data-ag-all aria-controls="ag-dir08-07-list" aria-expanded="false" hidden><span class="ag-zq__ain"><svg …></svg><span data-ag-all-label>Раскрыть все ответы</span></span></button>
```
```css
  #ag-dir08-07 .ag-zq__item{border-bottom:1px solid var(--line-strong);}
  #ag-dir08-07 .ag-zq__q{
    display:flex;align-items:center;justify-content:space-between;gap:18px;min-height:62px;padding:12px 4px 12px 0;cursor:pointer;list-style:none;
    font-size:clamp(16.5px,1.3vw,19px);font-weight:600;line-height:1.35;color:var(--text);transition:color .2s ease;
  }
  #ag-dir08-07 .ag-zq__item .ag-zq__a{padding:0 60px 20px 0;}
  #ag-dir08-07 .ag-zq__q::-webkit-details-marker,
  #ag-dir08-07 .ag-zq__cq::-webkit-details-marker{display:none;}
  #ag-dir08-07 .ag-zq__q::marker,
  #ag-dir08-07 .ag-zq__cq::marker{content:"";}
  #ag-dir08-07 .ag-zq__ic{position:relative;flex:none;width:30px;height:30px;border:1px solid var(--line-strong);border-radius:50%;}
  #ag-dir08-07 .ag-zq__ic::before,
  #ag-dir08-07 .ag-zq__ic::after{content:"";position:absolute;left:9px;top:13.5px;width:10px;height:2px;border-radius:1px;background:var(--accent);transition:transform .25s ease;}
  #ag-dir08-07 .ag-zq__ic::after{transform:rotate(90deg);}
  #ag-dir08-07 details[open]>summary .ag-zq__ic::after{transform:rotate(0deg);}
  #ag-dir08-07 .ag-zq__a p{max-width:70ch;font-size:clamp(15.5px,1.15vw,17px);line-height:1.6;color:var(--muted);text-wrap:pretty;}
  /* F22 · плавное раскрытие ответа (Chromium 131+); иначе — мгновенно, как было */
  @supports (interpolate-size:allow-keywords) and selector(::details-content){
    #ag-dir08-07 .ag-zq{interpolate-size:allow-keywords;}
    #ag-dir08-07 :is(.ag-zq__card,.ag-zq__item)::details-content{
      height:0;overflow:clip;overflow-clip-margin:8px;
      transition:height .32s cubic-bezier(.22,.61,.36,1),content-visibility .32s allow-discrete;
    }
    #ag-dir08-07 :is(.ag-zq__card,.ag-zq__item)[open]::details-content{height:auto;}
    #ag-dir08-07.is-bulk .ag-zq__item::details-content{transition:none;}
    @media (prefers-reduced-motion:reduce){
      #ag-dir08-07 :is(.ag-zq__card,.ag-zq__item)::details-content{transition:none;}
    }
  }
```
Бумажный вариант иконки (PRICES-05): `.ag-pq__ic{…width:36px;height:36px;border:1.5px solid rgba(9,9,10,.3);border-radius:50%;}`, открыт — `background:var(--ink);border-color:var(--ink);` и шеврон `::before` с `border-color:var(--accent);transform:rotate(-135deg)` (жёлтое на тёмном кружке, не на бумаге).
JS «Раскрыть все»: кнопка `hidden` в разметке, JS снимает `hidden`; подпись меняется через `label.firstChild.nodeValue` (ст. 34); после toggle — `ScrollTrigger.refresh()` таймером 60 мс (`ApolloMotion.ScrollTrigger || window.ScrollTrigger`); флаг `is-bulk` снимается таймером 80 мс; маркер `data-ag-faq-on`. Ответы — в HTML (FAQPage в HEAD слово в слово). DIR08-07 движка не несёт (нет `data-ag-anim`).

### 3.11 Вкладки (ст. 47, 49, 60, 86, 94, 95; DESIGN «selected/unselected/focus»; MOTION «Вкладки 320–400мс»)
Разметка (DIR08-04): tablist **первым в DOM**, `hidden` до JS; панели — `div role="group"`, JS превращает в `role="tabpanel"`:
```html
        <div class="ag-zl__tabs" role="tablist" aria-label="С какой гибкостью приходят" data-ag-tablist hidden>
          <button class="ag-zl__tab" type="button" role="tab" id="ag-dir08-04-t1" aria-controls="ag-dir08-04-p1" aria-selected="true"><span class="ag-zl__tn">Гибкости нет совсем</span></button>
          <button class="ag-zl__tab" type="button" role="tab" id="ag-dir08-04-t2" aria-controls="ag-dir08-04-p2" aria-selected="false" tabindex="-1"><span class="ag-zl__tn">После бокса или борьбы</span></button>
          …
        </div>
        <div class="ag-zl__panels">
          <div class="ag-zl__panel is-on" id="ag-dir08-04-p1" role="group" aria-labelledby="ag-dir08-04-n1">
            <h3 class="ag-zl__name" id="ag-dir08-04-n1">Гибкости нет совсем</h3>
            <p class="ag-zl__text">…</p>
          </div>
```
```css
  /* Коробка: без JS — панели столбцом; с JS — панель сверху, вкладки снизу (ПК) */
  #ag-dir08-04 .ag-zl__box{display:grid;grid-template-areas:"tabs" "panel";margin-top:clamp(28px,3.4vw,48px);}
  #ag-dir08-04 .ag-zl__panels.is-js>.ag-zl__panel{grid-area:1 / 1;visibility:hidden;}
  #ag-dir08-04 .ag-zl__panels.is-js>.ag-zl__panel.is-on{visibility:visible;}
  #ag-dir08-04 .ag-zl__tabs:not([hidden]){display:grid;grid-template-columns:repeat(4,minmax(0,1fr));}
  #ag-dir08-04 .ag-zl__tab{
    position:relative;display:flex;align-items:center;min-width:0;min-height:76px;padding:16px 22px 16px 44px;
    border:1px solid var(--line-strong);border-top:0;background:transparent;cursor:pointer;text-align:left;
    font-family:var(--f-display);font-size:clamp(15px,1.25vw,18px);font-weight:600;line-height:1.2;letter-spacing:.04em;text-transform:uppercase;
    color:var(--faint);transition:color .25s ease,background-color .25s ease;
  }
  #ag-dir08-04 .ag-zl__tab[aria-selected="true"]{color:var(--text);background:var(--tab-on);}
  #ag-dir08-04 .ag-zl__tab[aria-selected="true"]::before{background:var(--accent);border-color:var(--accent);}
  @media (min-width:1024px){
    #ag-dir08-04 .ag-zl__box.is-js{grid-template-areas:"panel" "tabs";}
  }
  /* < 1024: вкладки 2 × 2 над панелью, у выбранной — жёлтая линия сверху */
  @media (max-width:1023px){
    #ag-dir08-04 .ag-zl__tabs:not([hidden]){grid-template-columns:repeat(2,minmax(0,1fr));align-items:stretch;gap:8px;margin-bottom:12px;}
    …
  }
```
JS: клавиши ←/→/↑/↓ по кругу, Home/End, `tabindex="0"` только у выбранной (ст. 95); `aria-selected` + `tabindex` + класс `is-on`; `is-js` на коробке; F10 «плашка едет» — `::before` у списка по custom properties `--px/--py/--pw/--ph/--pbl/--pbr` (замер `offsetLeft/offsetTop`, ст. 83), `is-plate`, `is-jump` (без перехода при ресайзе); смена панели — WAAPI `opacity .001→1, translateY(6px)→none, 250ms` только не при reduce; подписи вкладок < 1024 подгоняются по самому длинному слову (ст. 61). Маркер `data-ag-tabs-on`. Бумажный вариант-переключатель (DIR08-02 < 1024): `button aria-pressed` в `role="group"`, выбранный `background:var(--ink);color:#F4F1EA;`, строки в одной ячейке `grid-area:1/1` + `visibility:hidden` (ст. 47, 54, 73).

### 3.12 Прочие повторяющиеся приёмы
- Зерно бумаги F29 (DIR08-02/06, DIR07-02/06): `@media (min-width:640px){ .ag-zp::before{content:"";position:absolute;inset:0;z-index:0;pointer-events:none;opacity:.12;background-image:url("data:image/svg+xml,…feTurbulence…");background-size:180px 180px;} .ag-zp__wrap{position:relative;z-index:1;} }` + отключение в forced-colors и print.
- Свет за кадром (тёмн.): `.ag-zh::before{content:"";position:absolute;z-index:-1;inset:0;pointer-events:none;background:radial-gradient(52% 64% at 70% 30%,rgba(255,196,0,.06),rgba(255,196,0,0) 70%);}`.
- Контурное слово (DIR08-08): `color:transparent;-webkit-text-stroke:1.5px var(--outline);` `aria-hidden`, `pointer-events:none;user-select:none;` — одно на страницу, < 1024 — неподвижный второй экземпляр.
- Бегущая строка (HOME-01): единственный разрешённый собственный `@keyframes` — не «появление»: `@keyframes ag-home-01-mq{to{transform:translate3d(-50%,0,0);}}`, пауза чекбоксом `.ag-hh__mq-stop:checked ~ … {animation-play-state:paused;}` и `:hover`; при reduce — `animation:none !important`, второй (дубль `aria-hidden`) набор скрыт, строка переносится в сетку.

---

## 4. Шапка-комментарий блока

### 4.1 Полная шапка (DIR08-06_v1.1.0.html, строки 1–30)
```html
<!-- ============================================================
     APOLLO GYM · DIR08-06 · «Цены на групповые занятия по растяжке» · v1.1.0 · 02.10.2026
     Tilda: страница «/stretching-samara», шестой блок, один T123, отступы 0 / 0.
     Ставится в запись rec4007255401 вместо старого «Сколько стоит»
     («Один абонемент на все залы», «Первая — бесплатно», «Все тарифы и
     условия»).

     P07 · бумага. «Растянутая карточка»: шапка сверху, как у владельца;
     четыре тарифа в ряд (раскладка владельца), колонки 1fr 1fr 1fr 2fr —
     пакет 12 растянут на две доли: жёлтая заливка, тёмный текст, «500 ₽ за
     занятие» крупнее, data-ag-best, <strong>, скрытое «выгоднее всего»
     (global_copy → ui.table_best). Телефон: 1 / 4 / 8 в ряд, 12 — во всю
     ширину под ними.
     Разметка — таблица с явными ролями (стандарт 75): строки — карточки,
     шапка «Пакет / Стоимость / За занятие» скрыта визуально, подпись «за
     занятие» в карточке — для глаз (aria-hidden).
     Отличие: четыре равные цифры + полоса «0 ₽» (DIR02-06), жетоны
     (CL02-06), талон (DIR03-06), раскладка (DIR04-06), отточия (DIR05-06),
     линейка (DIR06-06), штамп (DIR07-06), карточка сверху вниз (CL04-06),
     таблица с полосами (DIR01-06, CL01-06).
     Данные — prices.json → group, с 07.09.2026 (SOC-PRICE). Текст «Сбоку» —
     DIR08.md дословно. Нельзя: «30 дней», заморозка, детский тариф,
     «один абонемент на все четыре клуба».
     Автономный блок (закон 13). JS: страховка скана; последним — движок,
     копия шаблона 06_BUILD/MOTION.md.
     ============================================================ -->
<!-- v1.1.0 (проход «дизайн, движение и фишка», PROMPT_DIR08_DESIGN_MOTION_v2, 02.10.2026):
     Запись Tilda rec4007255401 — заменить v1.0.0 этим блоком целиком.
     Факт 5.1/5.13: бесплатное первое занятие по растяжке не подтверждено — обещание убрано («Условия первого занятия — при записи»).
     Первое предложение «Сбоку» заменено, остальное дословно. F29 зерно бумаги (≥ 640 px), фокус 3 px. Прайс — как есть. -->
```

### 4.2 Полная шапка первого экрана (DIR08-01_v1.1.0.html, строки 1–34)
```html
<!-- ============================================================
     APOLLO GYM · DIR08-01 · первый экран страницы «/stretching-samara» · v1.1.0 · 02.10.2026
     Tilda: страница «/stretching-samara», первый блок под шапкой, один T123, отступы 0 / 0.
     Ставится в запись rec4006241401 вместо старого hero (15.09): «Шпагат не
     обязателен…», «Понедельник и среда в 19:00», «с 14 лет», «60 минут»,
     «Записаться на пробную», «Смотреть расписание», крошка «Направления»,
     пустая рамка «РАСТЯЖКА · APOLLO GYM». Здесь единственный H1 и id="ag-main".

     Раскладка владельца «текст слева — кадр справа», цифры — в колонке
     текста под лидом, как у владельца. Язык страницы — амплитуда: за кадром
     из его нижнего левого угла (точка опоры, как таз в DIR08-03) поднимается
     веер — четыре дуги и три луча, видны над верхней кромкой кадра и в
     колонку текста не заходят. Веер прорисовывается (draw) и плывёт
     (parallax 0.1); ниже 1024 px его нет. Отличие от DIR06-01 (жёлтая
     кромка, адрес на стекле), DIR07-01 (размерная линия, выноска),
     DIR04-01 (планка под кадром).
     Текст — 03_COPY/pages/DIR08.md дословно. Планка без счётчика
     (стандарт 11): «1» → /nofitness, «0 ₽» и «500 ₽» → цены DIR08-06.
     Кадр — снимок владельца 51 «Растяжка» (HOME-03/04, CL04-04; глазами не
     сверен — подпись только адресом, стандарт 38) в родном 3:2, не шире
     620 px. Слот DIR08-01-floor (21:9) — атрибутами на <figure>. Без
     появления (LCP), parallax 0.06 на слое 110 % (стандарты 40, 74).
     Запись: /request?direction=stretching-samara&club=nofitness.
     Нельзя (DIR08.md): сроки, обещания про спину и суставы, длительность,
     возраст групп.
     Автономный блок (закон 13). JS: подгонка H1 (таймер, без rAF),
     страховка скана; последним — движок, копия шаблона 06_BUILD/MOTION.md.
     ============================================================ -->
<!-- v1.1.0 (проход «дизайн, движение и фишка», PROMPT_DIR08_DESIGN_MOTION_v2, 02.10.2026):
     Запись Tilda rec4006241401 — заменить v1.0.0 этим блоком целиком.
     Кадр 51 сверен глазами 02.10: общий вид зала (ринг, флаги); адрес — каталог владельца (тот же кадр в CL04-04),
     alt и подпись верны. Факт 5.1/5.13: бесплатное первое занятие по растяжке не подтверждено — обещание убрано («Условия первого занятия — при записи»).
     Планка — два факта: пункт «0 ₽ · первое групповое занятие» удалён (ПК — две колонки). Магнит снят, параллакс
     веера 0,1 → 0,08, F23 — нажатие кнопки записи, фокус 3 px. Остальной текст без изменений. -->
```

### 4.3 Что пишут в шапке (схема)
1. Строка-паспорт: `APOLLO GYM · <ID> · «<H2/H1 дословно>» или роль · v<X.Y.Z> · <дата>`.
2. Место в Tilda: страница, порядковый номер блока, «один T123, отступы 0 / 0»; запись `rec…` и что в ней стояло (старые фразы в кавычках) — что заменить/удалить. Для первого экрана: «Здесь единственный H1 и id="ag-main"».
3. Паттерн (P01…P15) и поверхность (бумага/тёмная/глубокая), идея композиции и «фишка»; поведение по ширинам (≥ 1024 / < 1024 / телефон).
4. «Отличие:» — чем раскладка отличается от аналогичных блоков других страниц (ID).
5. Источник текста (`03_COPY/pages/<ID>.md дословно`), данные (`prices.json → …`), стандарты по номерам, кадры и слоты (`data-ag-slot`, сверен/не сверен).
6. «Нельзя (…md): …» — запрещённые обещания/факты.
7. «Автономный блок (закон 13). JS: … ; последним — движок, копия шаблона 06_BUILD/MOTION.md.» (или «Движка нет»).
8. Второй комментарий — журнал версии: `<!-- vX.Y.Z (проход «…», PROMPT_<ID>_…_v2, дата):` запись Tilda и действие («заменить v1.0.0 этим блоком целиком»), что изменилось (F-номера фишек, факты №, «Текст без изменений»). Старые записи версий остаются ниже (PRICES-01: v1.2.0 и v1.1.0; HOME-01: v9.0/9.1 внутри шапки, v9.2 отдельным комментарием).
CODE_RULES: «Одна правка — новая полная версия файла с новым номером»; в комментариях нет ключей, персональных данных, неподтверждённых чисел (ст. 117, 123), тега `<script>` (ст. 102); [П] лишние комментарии — вырезать при сборке к публикации (8 % веса).

---

## 5. Порядок частей блока и именование

### 5.1 Порядок (все v1.1.0 DIR08/DIR07, PRICES v1.2.0)
1. `<!-- шапка -->` + `<!-- vX.Y.Z … -->`.
2. `<div class="ag-scope ag-<page>-<role>" id="ag-<page>-<nn>" data-ag-surface="dark|paper|deep|accent">` — например `<div class="ag-scope ag-dir08-prices" id="ag-dir08-06" data-ag-surface="paper">`.
3. Шрифты:
```html
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Oswald:wght@500;600;700&family=Manrope:wght@400;500;600;700;800&display=swap">
```
4. Спрайт `<svg class="ag-xx__sprite" width="0" height="0" aria-hidden="true" focusable="false">…<symbol>…</svg>` (если есть иконки; PRICES-01 ставит `<style>` раньше разметки — исключение).
5. `<section class="ag-xx" aria-labelledby="<root>-title">` → `<div class="ag-xx__wrap">` → контент.
6. `<style>` — разделы в порядке: (а) корень с токенами и базовой типографикой; (б) сброс `*` box-sizing, типовые теги, `ul/ol`, `b/strong`, `svg`, `button`, `[hidden]`, `.ag-nw`, `.ag-vh`, спрайт; (в) `.ag-scope a` и фокус `:focus-visible`; (г) секция/обёртка/сетка; (д) кикер, заголовок, лид; (е) компоненты блока с комментариями-подзаголовками `/* Текст */`, `/* Кадр 3:2 справа … */`; (ж) `@media (hover:hover)`; (з) брейкпоинты по убыванию ширины `max-width:1023px` → `767px` → `599px` → `359px`; (и) `prefers-reduced-motion`, `forced-colors`, `print`; (к) хвост версии `/* ===== v1.1.0 · дизайн, движение и фишка (02.10.2026) ===== */` — F23 нажатие, фишки F01/F10/F22/F29 со своими reduce/forced/print.
7. `<script>` своего JS: каждый модуль — IIFE с комментарием, `"use strict"`, `root = document.currentScript.closest(".ag-scope")`, маркер повторного запуска `data-ag-<что>-on` / `data-ag-fit`; затем отдельным IIFE «Страховка скана» (последней в этом `<script>`).
8. `<!-- Движок движения: копия шаблона 06_BUILD/MOTION.md → «Встраиваемый движок», логика не менялась -->` + `<script>` движка символ в символ — **последним** перед `</div>` корня. Движок только если есть `data-ag-anim`/`data-ag-magnetic` (DIR08-07 без него).

### 5.2 Именование
- Корень: `id="ag-<page>-<nn>"` (`ag-dir08-06`, `ag-home-01`, `ag-prices-05`), класс роли `ag-<page>-<role>` (`ag-dir08-hero`, `ag-dir08-tasks`, `ag-dir08-prices`, `ag-dir08-faq`, `ag-dir08-cta`, `ag-dir07-setup`, `ag-prices-check`, `ag-home-kids`). Все CSS-селекторы начинаются с `#ag-<page>-<nn>`.
- Элементы: префикс `ag-<2 буквы>` + БЭМ `__элемент` + `--модификатор`. Первая буква — страница, вторая — роль блока: DIR08 → `ag-zh` (hero), `ag-zc` (choice/tasks), `ag-zl` (level/tabs), `ag-zp` (prices), `ag-zq` (questions), `ag-zw` (word/cta); DIR07 → `ag-xh`, `ag-xs`, `ag-xp`, `ag-xt`; PRICES → `ag-ph`, `ag-pc`, `ag-pq`; HOME → `ag-hh`. Примеры: `.ag-zp__card`, `.ag-zp__card--best`, `.ag-zh__arc--far`, `.ag-zw__band--live/--still`.
- Общие (без двухбуквенного префикса): `.ag-scope`, `.ag-kicker`, `.ag-btn`, `.ag-btn--primary/--ghost/--ink`, `.ag-btn__in`, `.ag-btn__i` (стрелка), `.ag-btn__t` (иконка телефона), `.ag-nw` (nowrap), `.ag-vh` (визуально скрыто), `.ag-fitw`, `.ag-marquee__track/__item`, `.ag-deck__dot`, `.ag-split__i` (создаёт движок), `.agph`.
- id внутри: `<root>-title`, `<root>-t1`/`-p1`/`-n1` (вкладка/панель/имя), `<root>-list`, `<root>-cap`, символы `<root>-i-arrow`.
- Состояния-классы `is-*` (ставит JS): `is-on` (выбранная панель), `is-js` (JS включил раскладку), `is-plate`, `is-jump`, `is-bulk`, `is-focus`, `is-hit`, `is-off`, `is-live`, `is-fold`, `is-pick`, `is-tabs`, `is-hover`, `is-fit`, `is-clip`, `is-more`.
- Состояния атрибутами: на корне `data-hl="1…4"`, `data-row`, `data-cue` (DIR08-02); ARIA `aria-selected`, `aria-pressed`, `aria-expanded`; данные `data-ag-best`, `data-ag-club`, `data-ag-draft="N"` (ст. 149), `data-ag-slot/-ratio/-brief/-consent`; маркеры монтажа `data-ag-tabs-on`, `data-ag-faq-on`, `data-ag-fit`, `data-ag-ui-mounted` (MOTION_ADDENDUM: «собственный маркер data-ag-ui-mounted, чтобы не конфликтовать с data-ag-mounted движка»; атрибуты локальных интеракций — `data-ag-ui-*`).

---

## 6. Брейкпоинты

Частота по 317 последним блокам (блоков / всего правил):
| Запрос | Блоков | Что меняется (типично) |
|---|---|---|
| `print` | 317 | см. §7 |
| `(prefers-reduced-motion:reduce)` | 314 | см. §7 |
| `(forced-colors:active)` | 313 | см. §7 |
| `(hover:hover)` | 307 | все :hover только внутри него |
| `(max-width:599px)` | 253 | телефон: отступы секции 44/40, H2 `clamp(1.6rem,7.6vw,2rem)`, H1 `clamp(2.05rem,10.2vw,2.7rem)`, кнопки во всю ширину `flex:1 1 100%`, min-height 48–52, радиусы 16→12, мельче подписи, плотнее карточки |
| `(max-width:1023px)` | 141 | планшет: две колонки → одна, кадр под текстом во всю ширину (`max-width:760px`), декор (веер, контурное слово с parallax) убирается, вкладки 4 в ряд → 2×2 над панелью, subgrid-сравнение → переключатель, шапка 7fr/5fr → столбец, тарифы 4 → 3 + лучший во всю ширину |
| `(max-width:767px)` | 69 | планка фактов в столбик (число 86px + подпись), колонки → одна, «штамп» без боковых полей, таблица → карточки (ст. 140 — `< 768 display:block`) |
| `(max-width:959px)` | 42 | PRICES-01 и др.: hero в одну колонку |
| `(max-width:899px)` | 37 | HOME-01: канаты F01 скрыты (от 900 px — канаты, ниже — скобка) |
| `(min-width:640px)` | 22 | зерно бумаги F29 только ≥ 640 |
| `(max-width:479px)` | 20 | узкие телефоны |
| `(max-width:639.98px)` / `1023.98` / `767.98` / `599.98` | 18/18/17/8 | старые блоки — та же сетка с `.98` |
| `(max-width:359px)` | 14 | самые узкие (320): мельче кнопки переключателя (`font-size:12px;padding:8px 10px`) |
| `(max-width:374.98px)`, `379px`, `420px` | 13/7/6 | точечные |
| `(hover:hover) and (pointer:fine)` | 4 | tilt/отрыв/копирование номера только мышью (ст. 125, 145) |
| `(min-width:1024px)` | 4 | раскладки «только ПК с JS» (вкладки под панелью, автопоказ строки) |

01_SYSTEM_PROMPT: «Мобильная версия обязательна: 320–1440 (границы 599/600, 1023/1024), без прокрутки вбок, телефон не длиннее прошлой версии или рост объяснён». Стенд/axe: 1440, 1024, 390, 390 reduce; ширины 320–1920 (ст. 6). DESIGN.md: «Первый экран mobile имеет высоту по содержимому; 100vh не является целью».

Типовые мобильные раскладки (дословно):
```css
  /* < 1024: текст → планка → кнопки → кадр во всю ширину колонки; веера нет */
  @media (max-width:1023px){
    #ag-dir08-01 .ag-zh__wrap{grid-template-columns:minmax(0,1fr);gap:28px;}
    #ag-dir08-01 .ag-zh__lead{max-width:62ch;}
    #ag-dir08-01 .ag-zh__fig{justify-self:stretch;max-width:760px;padding-top:0;}
    #ag-dir08-01 .ag-zh__fan{display:none;}
    #ag-dir08-01 .ag-zh__imgbox{inset:-6% 0;}
  }
  @media (max-width:599px){
    #ag-dir08-01 .ag-zh{padding:10px 0 32px;}
    #ag-dir08-01 .ag-zh__wrap{gap:20px;}
    …
    #ag-dir08-01 .ag-btn{min-height:50px;flex:1 1 100%;padding:12px 18px;}
  }
```
Колонка-строка на телефоне (DIR08-02 ≤ 767): `.ag-zc__col{display:grid;grid-template-columns:52px minmax(0,1fr);column-gap:12px;}` + `.ag-zc__top{display:contents;}` — значок слева, имя и строки справа.
Кнопки CTA (DIR08-08): ≥ 1024 — столбик справа; < 1024 — `flex-direction:row;flex-wrap:wrap`; ≤ 599 — снова столбик `align-items:stretch`.
Ст. 39: лента на телефоне — с кнопками «предыдущий/следующий» и точками; ст. 54: справочный дубль — сворачиваемый; ст. 63: ≤ 599 кнопки карт — сетка в 2 колонки.

---

## 7. Режимы в CSS (дословно)

Типовой набор (DIR08-01_v1.1.0):
```css
  @media (prefers-reduced-motion:reduce){
    #ag-dir08-01 *,
    #ag-dir08-01 *::before,
    #ag-dir08-01 *::after{transition-duration:.01ms !important;transition-delay:0s !important;}
  }
  @media (forced-colors:active){
    #ag-dir08-01 .ag-zh__frame{border:1px solid CanvasText;}
    #ag-dir08-01 .ag-zh::before,
    #ag-dir08-01 .ag-zh__fan{display:none;}
    #ag-dir08-01 .ag-btn{border:1px solid CanvasText;}
  }
  @media print{
    #ag-dir08-01{background:none;color:#000;}
    #ag-dir08-01 *{color:#000 !important;box-shadow:none !important;}
    #ag-dir08-01 .ag-zh__fig,
    #ag-dir08-01 .ag-zh::before{display:none !important;}
  }
```
Бумага (DIR08-06):
```css
  @media (forced-colors:active){
    #ag-dir08-06 .ag-zp__card{border:1px solid CanvasText;}
    #ag-dir08-06 .ag-zp__card--best{border:3px solid Highlight;}
  }
  @media print{
    #ag-dir08-06{background:none;color:#000;}
    #ag-dir08-06 *{color:#000 !important;background:none !important;box-shadow:none !important;}
    #ag-dir08-06 .ag-zp__card{border:1px solid #000;}
  }
```
Печать до прокрутки (найдено 02.10): движок держит ещё не показанные узлы с inline `opacity:0` — в новых блоках в `@media print` добавлять `#id [data-ag-anim], #id [data-ag-anim] *{opacity:1 !important;}` и `#id [data-ag-anim]{transform:none !important;}` (есть в DIR08 v1.1.0, в более ранних блоках нет).
Интерактив (DIR08-02, DIR08-04): в forced-colors выбранное — `border:3px solid Highlight;`, штрихи SVG — `stroke:CanvasText`/`Highlight`; в print — переключатели/вкладки `display:none !important`, все панели/строки видимы: `.ag-zc__row{visibility:visible !important;grid-area:auto !important;}`, `.ag-zl__panels.is-js>.ag-zl__panel{grid-area:auto;visibility:visible;}`, у штрихов `stroke-dasharray:none !important;stroke-dashoffset:0 !important;`; FAQ — `::details-content{height:auto !important;content-visibility:visible !important;}`.
F23 и F22 несут свой reduce (см. §3.3, §3.10). HOME-01 при reduce: бегущая строка `animation:none !important`, дубль набора скрыт, ≤ 599 — сетка в 2 колонки. Ст. 144: подгоняемым замером элементам в reduce — `transition:none !important`.
MOTION_ADDENDUM: «Для reduced-motion: reveal, tilt, parallax, continuous marquee отключены; выбранные состояния переключаются мгновенно. Вкладки, форма, галерея и ссылки продолжают работать.»
`!important` в блоках встречается в reduce/print/forced и `[hidden]`; CODE_RULES формально разрешает его только по ст. 30, 97, 144 — в гайде описать как принятую практику режимов.

---

## 8. Движок (tools/engine_template.html = копия в каждом блоке)

### 8.1 Загрузка и деградация
- Корень: `var BLOCK = document.currentScript.closest(".ag-scope");` → `data-ag-mounted` (повторно не монтируется).
- `window.ApolloMotion` общий: если `ready` — сразу `scan(BLOCK)`; если есть, но не `ready` — выходит («грузится/деградировал по другому блоку — не дублируем попытку»).
- GSAP 3.13.0 + ScrollTrigger с cdnjs: `https://cdnjs.cloudflare.com/ajax/libs/gsap/3.13.0/gsap.min.js`, `…/ScrollTrigger.min.js`.
- `var BOOT_TIMEOUT = 2000;` — таймаут → `standDown("timeout")`. Также `standDown` при `prefers-reduced-motion`, ошибке загрузки, отсутствии gsap.
- `standDown`: `html.classList.remove("ag-motion"); html.setAttribute("data-ag-motion", "off"); API.ready = false;` + `console.info("[ApolloMotion] off:", reason)`.
- До загрузки: `html.classList.add("ag-motion")`; после init: `html.setAttribute("data-ag-motion", "on")`, `API.ready = true; API.gsap = gsap; API.ScrollTrigger = ST;`.
- `gsap.defaults({ ease: "power3.out", duration: 0.7 }); ST.config({ ignoreMobileResize: true });`
- Пересканирование: `ST.refresh()` на `load` и `lazyloaded`; `MutationObserver` на `childList, subtree` корня → `scan(BLOCK)` через 220 мс (поэтому свой JS не вставляет узлы — 01_SYSTEM_PROMPT).
- CODE_RULES §2 «Проверено 29.09: если запрос GSAP висит, текст виден через 2 с, но событие `load` страницы висит вместе с запросом».

### 8.2 Типы `data-ag-anim` и атрибуты (дефолты)
`trig(el)`: `start: data-ag-start || "top 86%"`, `once: data-ag-repeat === null`, `toggleActions: "play none none none"`. Неизвестный тип → `rise`.
| Тип | Что делает | Атрибуты и дефолты |
|---|---|---|
| `rise` | `fromTo(opacity 0 + сдвиг → 1, 0)`; will-change на время | `data-ag-from` up (down/left/right; любое иное, напр. `none` — без сдвига), `data-ag-distance` 32, `data-ag-dur` 700, `data-ag-delay` 0 |
| `fade` | opacity 0→1 | dur 800, delay 0 |
| `stagger` | `gsap.set(el,{opacity:1})`, дети по очереди | `data-ag-children` (селектор; иначе прямые дети), from/distance как rise, dur 650, delay 0, `data-ag-stagger` 80; нет детей → rise |
| `split` | режет текст на `span.ag-split__i` (inline-block, aria-hidden), ставит `aria-label`; `yPercent 108→0` | `data-ag-split` words/chars, dur 800, delay 0, stagger 55 (words) / 18 (chars), ease power4.out |
| `count` | счёт 0→N, пробел-разделитель тысяч | `data-ag-count-to` (иначе число из текста), `-dec` 0, `-prefix`, `-suffix`, dur 1400, start по умолчанию `"top 88%"` |
| `parallax` | `yPercent -s*50 → s*50`, scrub | `data-ag-parallax` 0.12; триггер — ближайший `[data-ag-parallax-scope]`, иначе родитель |
| `draw` | path/line: `strokeDasharray/offset` len→0 (dur 1200, power2.inOut); иное — `scaleX 0→1` от левого края (dur 900); **delay не читает** (ст. 85) |
| `scale-in` | opacity 0→1, scale 1.07→1 | dur 1000, delay 0, power2.out |
| `marquee` | только `track.style.animationDuration = speed + "s"` | `data-ag-speed` 48; трек `.ag-marquee__track` или первый ребёнок |
Отдельно: `data-ag-magnetic` (сила 0.28; при `(hover: none)` — пропуск; quickTo x/y 0.4 s); `data-ag-deck` (id ленты) + `data-ag-dots="<id>"` с `.ag-deck__dot` → `data-ag-active` на текущей точке.
Использование в 317 блоках: rise 689, draw 344, stagger 204, parallax 55, fade 16, scale-in 4, split 3, marquee 1.

### 8.3 Что движок пишет в DOM
- `<html>`: класс `ag-motion` (на время загрузки/работы), `data-ag-motion="on|off"`.
- Корень: `data-ag-mounted`.
- Каждый обработанный элемент: `data-ag-done` (повторно не анимируется).
- Inline-стили через GSAP: `opacity`, `transform` (x/y/scale/yPercent/scaleX), `will-change` (снимается после rise/split), `stroke-dasharray/-dashoffset` у `draw`; `gsap.set(el,{opacity:1})` у stagger/split/count/parallax/draw; у `split` — дочерние span и `aria-label`; у `count` — `textContent`; у `marquee` — `animation-duration` трека; у точек ленты — `data-ag-active`.
- Поэтому (ст. 56, CODE_RULES): в CSS блока нет `opacity:0` на контенте и своих @keyframes появления — скрывает только движок, и только когда он загрузился; без JS/при reduce/при таймауте всё видно. Transform узла с `data-ag-anim` принадлежит движку (ст. 27, 74; MOTION_ADDENDUM п. 4: «Reveal — на внешнем wrapper, tilt — на внутреннем media»).

### 8.4 «Страховка скана» — дословно (DIR08-01_v1.1.0, вариант с F23)
```js
  /* Страховка скана: если GSAP уже грузит блок выше (шапка), шаблон движка
     выходит без скана этого корня. Ждём готовности и просим отсканировать. */
  (function () {
    "use strict";
    var W = window, D = document;
    var root = D.currentScript && D.currentScript.closest(".ag-scope");
    if (!root) return;
    /* iOS включает :active только при слушателе касания (F23) */
    root.addEventListener("touchstart", function () {}, { passive: true });
    var tries = 0;
    (function wait() {
      var M = W.ApolloMotion;
      if (M && M.ready) {
        if (root.querySelector("[data-ag-anim]:not([data-ag-done]), [data-ag-magnetic]:not([data-ag-done])")) M.scan(root);
        return;
      }
      if (D.documentElement.getAttribute("data-ag-motion") === "off" || ++tries > 50) return;
      W.setTimeout(wait, 100);
    })();
  })();
```
Вариант без кнопок (DIR08-06) — то же без строки `touchstart`. Опрос 100 мс × 50 = до 5 с; выходит, если `data-ag-motion="off"`. Ст. 12: блок ниже первого ждёт `ApolloMotion.ready` и сам зовёт `scan(root)`; шаблон движка не меняется. ENGINE_REVIEW.md (MOTION_ADDENDUM): в архивном v8.2 найден риск пропуска корня при незавершённой загрузке — страховка закрывает его.

### 8.5 Правила движения (MOTION_ADDENDUM + стандарты)
- Время: Press CTA 120–160 мс scale .98; возврат 220–280 мс до 1.01; вкладки 320–400 мс; фильтр 180–220; смена фото 180–240 (только opacity); reveal 500–700 мс, y 16–24px; главное фото 650–800, scale 1.035–1.05→1; линия 600–800; tilt ±3°, return 360 мс, только fine pointer; parallax .05–.08 только фото. Easing `cubic-bezier(.22,.61,.36,1)`.
- Бюджет: один главный сценарий на страницу, 1–2 лёгкие интеракции на экран; ≤ 2 типов появления в блоке (ст. 20; `draw`, `count`, `parallax`, `marquee` не в счёт); каскад 6–8 элементов.
- Элементы первого экрана — `data-ag-start="top bottom"` (ст. 10); LCP-кадр без появления (ст. 40); H1 без появления при влиянии на LCP (I174) — в DIR08-01 у H1 ещё `rise`, в HOME-01 v9.1 H1 без появления.
- `count` — только на подтверждённых числах, цены не крутим (ст. 11); `split` — только один заголовок на экране (ст. 36); текст не въезжает слева (ст. 46); `data-ag-from="left"` = +x, дистанция ≤ 32 (ст. 113); `draw` — только path/line с одним `M` (ст. 89), постоянный viewBox, `preserveAspectRatio` meet (ст. 81).
- Без rAF в своём JS (таймеры + ResizeObserver), без постоянного rAF в фоне, не анимировать filter/blur/box-shadow покадрово, will-change только на время.

---

## 9. Ключевые стандарты и запреты (сжато)

Законы (01_SYSTEM_PROMPT / CODE_RULES §1): блок T123 полностью автономен (закон 13) — свои шрифты, токены, сброс, стили, JS; работает один на пустой странице Tilda; корень `div.ag-scope.ag-<page>-<role>#ag-<page>-<nn>`; один H1 на страницу в первом блоке с `id="ag-main"`; < 100 000 байт (ст. 4); движок символ в символ; каждая версия — полный файл с новым номером.

CSS:
- Запрещено: `:where(`, `:has(`, `opacity:0` на контенте, свои `@keyframes` появления, `outline:none` без замены, `!important` (кроме ст. 30, 97, 144), `var(--ag-…)` снаружи, глобальные `body/a/h1/:root`.
- Сброс типовыми селекторами (14); цвет ссылки-кнопки и подчёркивание — с `.ag-scope` (45, 52); фокус `#root.ag-scope :is(a,button,summary):focus-visible` (3), 3px, offset 3px.
- Корень `overflow-x:clip`, не hidden (35); `overflow-wrap:anywhere` на названиях/улицах запрещён — меняется раскладка (42); `max-width` подгоняемого заголовка в px (43); ссылка со стрелкой — `inline-block`/`block`, не `inline-flex` (31, 67, 79, 103, 148); панели разной длины — в одной ячейке `grid-area:1/1` + `visibility` (47, 50); ряд кнопок — `flex-wrap` (51); `th/td` со скруглением — `border-collapse:separate;border-spacing:0` (32); `th/td` не `display:flex` (114).
- Цели нажатия ≥ 44×44 (6, 70); контраст ≥ 4.5:1; axe WCAG 2.2 AA на 1440/1024/390/390-reduce.

Разметка и доступность:
- Кикер — `<p>`, не h2/h3 (COPY §5); H2 — секции, H3 — подзаголовки; `<a>` — переход, `<button>` — действие; `<article>` не бывает tabpanel (49); таблица → сетка на телефоне с явными ролями (75); вкладки: стрелки по кругу, Home/End, tabindex у выбранной (95); выбор-легенда — `aria-pressed` в `role="group"`, одна нажата всегда (73); текущая страница — не только цветом, `aria-current` (7); визуально скрытый текст — `.ag-vh`; декор `aria-hidden="true" focusable="false"`.
- Свой JS меняет текст через `nodeValue` и атрибуты, не `textContent`/`innerHTML` (34); не вставляет узлы; прокрутка к якорю — по вёрстке `offsetTop − scroll-margin-top` (48); без JS — всё раскрыто/столбцом (вкладки, переключатели, ленты).

Медиа: LCP `fetchpriority="high"`, без `loading`, без появления (40); прочие `loading="lazy" decoding="async"`, `width/height`, `srcset` tildacdn; отложенный кадр — только с настоящим запасным src (18, I172); портрета нет — кадр зала + монограмма (28); `figcaption` прямой потомок (123); карта — `iframe` с `title`, без `src`, `hidden`, src ставит IntersectionObserver (135); фон-видео `muted playsinline loop autoplay preload="metadata" poster`, ≤ 5 МБ, на телефоне и reduce — постер; длинное видео — VK/Rutube по клику; не CSS-фон для содержательного кадра; не стоки, не генерация людей и залов; с детьми — только с письменного разрешения родителей; фасады не публикуются.

Данные и ссылки: ссылки только на живые страницы 200 (2); внешняя — `target="_blank" rel="noopener"` + `outbound_click` (129); между страницами только белый список `club, direction, trainer, days, who` (44, 62); выбор в URL только по действию читателя (57), `history.replaceState`, `utm_*`/`yclid`/hash сохранять (58); формы Tilda — крючки сохраняются, блок слушает `tildaform:aftersuccess`, сам не отправляет (41).

Факты и текст (COPY_STANDARD кратко): заголовок — факт, вопрос читателя или адрес, не лозунг; кнопка — глагол + объект; одна главная кнопка на экран; восемь маркеров брака (антитеза «не X, а Y», стаккато-триада, абстрактное обещание, обещание за читателя, усилители, пустой императив, канцелярский ярлык, тире-афоризм); без «!» в заголовках, без эмодзи, капс только CSS `text-transform`, «мы» ≤ 1 раза на блок, обращение «вы» со строчной; каждое число — из facts_registry, неподтверждённое не публикуем (и в комментариях — 117); черновые фразы — `span data-ag-draft="N"` (149).

Общие запреты (CODE_RULES §10): React/Vue/библиотеки ради карточек; второй CDN, вторая копия GSAP, `document.write`; контент, скрытый до JS без страховки; ключи, токены, номер счётчика Метрики в коде; изменение шаблона движка в одном блоке; ручная правка JSON-LD-графа и страниц тренеров; ссылки на 404; имена записей «не публикуются» где угодно. Tilda: Title/Description/canonical/OG — настройки страницы, не в T123; JSON-LD не дублировать; публикация — только по поручению владельца (TILDA_ADDENDUM).

Проверки перед выдачей (CODE_RULES §9): сборка `build_block.py --ver`, `check_versions.py`, стенд страницы (группы L, A, M, G, J, S …), висящий CDN (`t_cdn_hang.js`: текст виден, движок `off` ≤ 2,5 с), линтер текста «Чисто.», `html-validate`, `wc -c` < 100 000, `code_audit.py`, снимки глазами. Без браузера (профиль Б): `tools/check_block.py`, `scan_hidden.py`, `check_claims.py`.

---

## 10. Аналитика `data-ag-track` / `data-ag-params`

Формат (на `<a>`/`<button>`/`<summary>`):
```html
<a … data-ag-track="request_start" data-ag-params='{"from":"hero","direction":"stretching-samara"}'>
<a … data-ag-track="club_select" data-ag-params='{"club":"nofitness","from":"dir08_hero"}'>
<a … data-ag-track="page_jump" data-ag-params='{"to":"prices","from":"dir08_hero"}'>
<a … data-ag-track="phone_click" data-ag-params='{"page":"DIR08","from":"cta"}'>
<a … data-ag-track="nav_click" data-ag-params='{"to":"prices","from":"dir08_prices"}'>
<a … data-ag-track="direction_select" data-ag-params='{"direction":"functional-training","from":"dir08_cta"}'>
```
- `data-ag-track` — имя цели; `data-ag-params` — JSON в одинарных кавычках атрибута, ключи в двойных. `from` — место на странице (`hero`, `cta`, `<page>_<role>`: `dir08_hero`, `dir08_faq`, `dir07_prices`).
- По 317 блокам: 1 404 `data-ag-track`, 42 имени; топ: `request_start` 229, `phone_click` 183, `direction_select` 165, `club_select` 163, `nav_click` 157, `faq_open` 148, `route_click` 72, `page_jump` 54, `trainer_open` 44, `price_view` 28, `map_select_club` 17, `schedule_filter` 15, `schedule_open` 14, `gallery_open` 11; редкие: `outbound_click`, `faq_jump`, `price_pick`, `contact_save`, `phone_copy` …
- Ключи params: `from` 1 344, `club` 287, `direction` 222, `to` 218, `page` 179, `trainer` 176, `q` 155, `map` 72, далее `n`, `goal`, `who`, `target`, `pair`, `role`, `event`, `tab`, `vs`, `intent`.
- CODE_RULES §4: обработчика нет, в Метрику сейчас не уходит ничего (I165); решение — один сайтовый трекер в HEAD (`REFERENCE/ANALYTICS_PLAN.md`), блок без него цел. Для новых блоков: имя цели — из утверждённого списка 8–12 целей; вариации — параметрами, новые имена не заводятся; в параметрах нет личных данных — только ключи белого списка, `from`, `tab`, `target`. Поля имени и телефона — `ym-disable-keys` при Вебвизоре. TILDA_ADDENDUM: «Имя, телефон и комментарий не пишутся в URL, консоль или параметры аналитики. club/direction — технический выбор без персональных данных».
- Номер счётчика Метрики — только в настройках Tilda, в документах — плейсхолдер.
