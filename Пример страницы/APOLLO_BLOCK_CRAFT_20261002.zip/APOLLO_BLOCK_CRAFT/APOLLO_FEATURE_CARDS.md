# Карточки фишек Apollo · как сделана каждая интерактивная фишка сайта

Часть набора `APOLLO_BLOCK_CRAFT/` (ядро — `APOLLO_BLOCK_CRAFT_GUIDE.md`, указатель фишек — там §10). Здесь по каждой фишке: страница и файл блока, идея и польза, механика с числами, разметка, ключевой код **дословно** (файл и строки указаны), режимы (reduce, forced-colors, печать, без JS, сенсор, телефон), грабли и поправки после проверок, что отвергли и почему.

Как пользоваться: перед своей фишкой найди похожую по механике (пружина, маятник, WAAPI по точкам, плашка, автопоказ, подсветка по наведению, текущий шаг по прокрутке) и возьми её решения для режимов и гонок. Числа здесь — проверенные в коде, в отличие от каталога F (`addon/features/`), где числа — предложения.

Оговорки: «[имя]» — убранное имя человека; «расчёт» — величина, выведенная из кода (в коде её нет числом). Пути — от корня пака передачи (`blocks/…`, `passes/…`).
В нескольких старых блоках скрипт вставляет узлы (canvas сетки клетки CL02-01, «вмятина» мешка CL03-01, временный `textarea` при копировании CL01-07, `createTextNode` в CL01-05/07, `innerHTML` результата в PRICES-02). Это наследие: движок после вставки пересканирует блок через 220 мс, вреда нет, но в новых блоках так не делать — держать узел в разметке скрытым.

## Содержание
- 1 /boxing (CL01) — четыре фишки
  - 1.1 «Канаты ринга» — ведущая фишка страницы
  - 1.2 «Мешок качается»
  - 1.3 «Кадр целиком» (F07)
  - 1.4 «Скопировать адрес» (+ карта по приближению)
- 2 /gym (CL03) — «Тяжёлый мешок» (маятник по удару)
- 3 /mma (CL02) — «Живая сетка клетки» (canvas)
- 4 /nofitness (CL04) — «Ручка программы крутится» (поворот жестом)
- 5 /prices — «Ценники на канате» (инерция прокрутки) + другие фишки PRICES
  - 5.1 Попутно на /prices (кратко)
- 6 Главная `/`
  - 6.1 F01 «Рамка ринга» — канаты из кадра (HOME-01)
  - 6.2 «Свет над рингом» — свет за курсором (HOME-01, П12)
  - 6.3 Что ещё на главной (кратко)
- 7 `/schedule`
  - 7.1 F10 «Кромка закладок» (SCHEDULE-02)
  - 7.2 «Билет-табло» (SCHEDULE-02)
  - 7.3 «Лампа отвечает вечерам» (SCHEDULE-04)
  - 7.4 Рядом на странице: «В зале включают свет» (SCHEDULE-01, было с v1.0.0)
- 8 `/boxing-samara`
  - 8.1 F14 «Живые пиктограммы» шагов (DIR01-02)
  - 8.2 F22 плавный FAQ (DIR01-08)
- 9 `/muay-thai-samara` — «Боец показывает удар» (DIR02-02)
- 10 `/kickboxing-samara` — «Разница на схеме» (DIR03-02)
- 11 «Что уже есть — что добрать» · /mma-samara
- 12 «Пройти схватку» + вертикальный профиль + F10 · /grappling-samara
- 13 «Зоны зала» (F04) · /functional-training
- 14 /cycle-samara · «Педаль по кругу», «мини-маховики», «Деталь на чертеже»
  - 14.1 «Педаль по кругу» (F30 + F14)
  - 14.2 «Мини-маховики» (тот же блок DIR07-03)
  - 14.3 «Деталь на чертеже»
- 15 /stretching-samara · «Три темпа на знаке», «Глубина наклона», соглашение `data-cue`
  - 15.1 «Три темпа на знаке» (F08 + предмет)
  - 15.2 «Глубина наклона» (шкала в DIR08-03)
  - 15.3 Соглашение `data-cue` (DIR08-02 ↔ DIR08-03)

---

## 0. Общая рамка (действует для всех фишек)

- Каждый блок — автономный T123: `<div class="ag-scope …" id="ag-dir0X-0Y">` + шрифты + разметка + `<style>` (всё через `#id`) + свой JS (IIFE) + «страховка скана» + **движок последним** (копия шаблона, байт в байт с v1.0.0 во всех блоках — это проверяется).
- Движок (GSAP 3.13 + ScrollTrigger с cdnjs, таймаут загрузки 2000 мс, при reduce — сразу `data-ag-motion="off"` на `<html>`) ищет `[data-ag-anim]` (rise, fade, stagger, split, count, parallax, draw, scale-in, marquee) и пишет **inline** `opacity`/`transform`/`stroke-dash*` (`gsap.fromTo`, `gsap.set(el,{opacity:1})` у родителя stagger). Поэтому:
  - на узлах с `data-ag-anim` и на детях stagger свой CSS/JS **не трогает `opacity`, `transform`, `d`, `stroke-dash*`** — иначе inline-значение движка перебьёт или собьёт; приглушение делают `stroke-opacity`, `stroke-width`, `color`, `background`, `fill`;
  - движок держит `MutationObserver` на `childList` корня и через 220 мс пересканирует блок — поэтому **скрипт блока не вставляет узлы**: все «бегунки», знаки, слои — заранее в HTML, скрипт меняет только атрибуты/классы/inline `transform` своих узлов (без `data-ag-anim`).
- Выдержка из движка (все блоки, например `blocks/mma-samara/DIR04-04_v1.1.0.html`):

```js
    var pending = null;
    new MutationObserver(function (muts) {
      var add = muts.some(function (m) { return m.addedNodes && m.addedNodes.length; });
      if (!add) return;
      clearTimeout(pending);
      pending = setTimeout(function () { scan(BLOCK); }, 220);
    }).observe(BLOCK, { childList: true, subtree: true });
```

- Готовность `draw` проверяют **только чтением**: вычисленный `stroke-dashoffset` ≈ 0 (или `data-ag-motion="off"` → готово сразу).

---

---

## 1. /boxing (CL01) — четыре фишки

Отчёт: `passes/boxing/RESULTS.md`, промт `passes/boxing/PROMPT_CL01_DESIGN_MOTION_v2.md` (§2 штурм, §7 ответы на ревью; §9 в этом промте нет).

### 1.1 «Канаты ринга» — ведущая фишка страницы
- **Где:** `/boxing`, блок CL01-01 (первый экран), файл `blocks/boxing/CL01-01_v1.2.0.html`.
- **Идея:** три каната ринга полосой на всю ширину между первым экраном и планкой фактов; мышь их оттягивает, касание дёргает. **Польза:** предмет именно этого зала (единственный ринг в сети на Галактионовской) — страница «ощущается как боксёрский зал»; полоса отделяет первый экран от фактов, не лежит под текстом и CTA.
- **Механика (числа из кода):**
  - Запуск: `pointermove` мыши над полосой (канат в 15 px по вертикали от курсора «прилипает»: цель прогиба = `clamp(py − b, ±13)` px); касание — `pointerup` без мыши, если сдвиг пальца ≤ 10 px: ближайшему канату импульс `v ± 6.5` (вниз, если палец над канатом).
  - Физика: пружина на кадр (нормировка к 60 fps): `a = 0.16·(target − y) − 0.13·v`; `dt = min(2, Δt/16.67)`. Расчёт: ω ≈ 0,4 рад/кадр → период ≈ 16 кадров ≈ 0,26 с; ζ ≈ 0,16 (несколько размахов). Покой: |y| и |v| ≤ 0,12 → строго 0.
  - Отрисовка: квадратичная кривая `M0 b Q cx (b+2y) w b` — вершина прогиба ровно на `y`; контрольная точка по X — место курсора, зажата в 6–94 % ширины. `viewBox` = реальные px полосы (ResizeObserver), `vector-effect:non-scaling-stroke`.
  - rAF только пока канат колеблется; вне экрана (IO) и в скрытой вкладке — `flat()` (стоп + ровные линии).
  - Полоса: высота 48 px (≤ 599 px — 44 px), `width:100vw; margin: … calc(50% - 50vw)`; горячий (верхний) канат — жёлтый `rgba(255,196,0,.85)` 2,5 px, остальные `rgba(244,244,245,.34)` 2 px.
- **Разметка:** заранее в HTML — `div.ag-bh__ropes[data-ag-ui-ropes-band][aria-hidden="true"]` > `svg` с тремя `path` и `data-y` (10/24/38 — базовая линия). Не `data-ag-anim` (полоса без появления; v2 З2: «без draw»).

```html
<!-- blocks/boxing/CL01-01_v1.2.0.html, строка 43 (фрагмент) -->
<!-- Канаты ринга: декор, реагирует на указатель и касание (скрипт ниже). Без JS — прямые линии. --> <div class="ag-bh__ropes" data-ag-ui-ropes-band aria-hidden="true"><svg class="ag-bh__rsvg" viewBox="0 0 1200 48" preserveAspectRatio="none" focusable="false"><path class="ag-bh__rope ag-bh__rope--hot" data-y="10" d="M0 10Q600 10 1200 10"/><path class="ag-bh__rope" data-y="24" d="M0 24Q600 24 1200 24"/><path class="ag-bh__rope" data-y="38" d="M0 38Q600 38 1200 38"/></svg></div>
```

```css
/* blocks/boxing/CL01-01_v1.2.0.html, строки 235–249 */
  /* «Канаты ринга»: полоса на всю ширину экрана между первым экраном и планкой фактов */
  #ag-cl01-01 .ag-bh__ropes{position:relative;z-index:1;height:48px;width:100vw;margin:clamp(14px,2vw,26px) calc(50% - 50vw) 0;touch-action:pan-y;}
  #ag-cl01-01 .ag-bh__rsvg{display:block;width:100%;height:100%;overflow:visible;}
  #ag-cl01-01 .ag-bh__rope{fill:none;stroke:rgba(244,244,245,.34);stroke-width:2;stroke-linecap:round;vector-effect:non-scaling-stroke;}
  #ag-cl01-01 .ag-bh__rope--hot{stroke:rgba(255,196,0,.85);stroke-width:2.5;}
  #ag-cl01-01 .ag-bh__ropes + .ag-bh__facts{margin-top:clamp(8px,1.2vw,16px);}
  @media (forced-colors:active){#ag-cl01-01 .ag-bh__rope,#ag-cl01-01 .ag-bh__rope--hot{stroke:CanvasText;}}
  @media print{#ag-cl01-01 .ag-bh__ropes{display:none;}}
  @media (max-width:599px){
    #ag-cl01-01 .ag-bh__ropes{height:44px;margin-top:10px;}
    #ag-cl01-01 .ag-bh__ropes + .ag-bh__facts{margin-top:6px;}
    #ag-cl01-01 .ag-bh__facts > li{padding:12px 14px 13px;}
    #ag-cl01-01 .ag-bh__facts b{font-size:28px;}
    #ag-cl01-01 .ag-bh__facts li > span{margin-top:6px;font-size:13px;line-height:1.35;}
  }
```

```js
/* blocks/boxing/CL01-01_v1.2.0.html, строки 330–406 (комментарий, состояние, физика, указатель) */
  /* «Канаты ринга» (фишка страницы, П12): три каната между первым экраном и планкой фактов.
     Мышь, проходя через канат, оттягивает его; канат отпружинивает с затуханием.
     На сенсорном экране — касание дёргает ближайший канат (сдвиг пальца > 10 px — это прокрутка, не касание).
     Цикл requestAnimationFrame идёт только пока канат колеблется; вне экрана и в скрытой вкладке — стоп.
     reduce — канаты неподвижны, слушателей нет. Без JS — три прямые линии. */
  (function () {
    "use strict";
    var W = window, D = document;
    var root = D.getElementById("ag-cl01-01");
    if (!root || root.hasAttribute("data-ag-ui-ropes")) return;
    root.setAttribute("data-ag-ui-ropes", "");
    var band = root.querySelector("[data-ag-ui-ropes-band]");
    if (!band) return;
    var svg = band.querySelector("svg");
    var paths = Array.prototype.slice.call(band.querySelectorAll("path"));
    var mqR = W.matchMedia ? W.matchMedia("(prefers-reduced-motion: reduce)") : null;
    var H = 48, w = 1, raf = 0, last = 0, visible = true, on = false;
    var ptr = { in: false, cx: 0, cy: 0 };
    var ropes = paths.map(function (p) { return { p: p, b: parseFloat(p.getAttribute("data-y")) || 24, y: 0, v: 0, x: 0.5 }; });

    function draw(r) {
      var cx = Math.max(0.06, Math.min(0.94, r.x)) * w;
      r.p.setAttribute("d", "M0 " + r.b + "Q" + cx.toFixed(1) + " " + (r.b + 2 * r.y).toFixed(2) + " " + w + " " + r.b);
    }
    function size() {
      w = Math.max(1, Math.round(band.clientWidth));
      H = Math.max(1, Math.round(band.clientHeight)) || 48;
      svg.setAttribute("viewBox", "0 0 " + w + " " + H);
      ropes.forEach(draw);
    }
    function step(ts) {
      raf = 0;
      var dt = last ? Math.min(2, (ts - last) / 16.67) : 1;
      last = ts;
      var busy = false, px = 0, py = 0;
      if (ptr.in) {
        var r0 = band.getBoundingClientRect();
        px = ptr.cx - r0.left; py = ptr.cy - r0.top;
      }
      ropes.forEach(function (r) {
        var target = 0;
        if (ptr.in) {
          var d = py - r.b;
          if (Math.abs(d) < 15) { target = Math.max(-13, Math.min(13, d)); r.x = px / w; }
        }
        var a = 0.16 * (target - r.y) - 0.13 * r.v;
        r.v += a * dt; r.y += r.v * dt;
        if (target !== 0 || Math.abs(r.y) > 0.12 || Math.abs(r.v) > 0.12) busy = true;
        else { r.y = 0; r.v = 0; }
        draw(r);
      });
      if (busy && visible && !D.hidden) raf = W.requestAnimationFrame(step);
      else last = 0;
    }
    function kick() { if (!raf && visible && !D.hidden) { last = 0; raf = W.requestAnimationFrame(step); } }
    function stop() { if (raf) { W.cancelAnimationFrame(raf); raf = 0; } last = 0; }
    function flat() { stop(); ropes.forEach(function (r) { r.y = 0; r.v = 0; draw(r); }); }

    var down = null;
    function onMove(e) {
      if (e.pointerType !== "mouse") return;
      ptr.in = true; ptr.cx = e.clientX; ptr.cy = e.clientY; kick();
    }
    function onLeave(e) { if (e.pointerType === "mouse") { ptr.in = false; kick(); } }
    function onDown(e) { if (e.pointerType !== "mouse") down = { x: e.clientX, y: e.clientY }; }
    function onUp(e) {
      if (e.pointerType === "mouse" || !down) return;
      var moved = Math.abs(e.clientX - down.x) + Math.abs(e.clientY - down.y);
      down = null;
      if (moved > 10) return;
      var r0 = band.getBoundingClientRect(), px = e.clientX - r0.left, py = e.clientY - r0.top;
      var best = ropes[0];
      ropes.forEach(function (r) { if (Math.abs(r.b - py) < Math.abs(best.b - py)) best = r; });
      best.x = px / w; best.v += (py <= best.b ? 1 : -1) * 6.5;
      kick();
    }
    function onCancel() { down = null; }
/* … строки 425–439: включение/выключение по reduce, размер, видимость */
    function apply() { if (mqR && mqR.matches) disable(); else enable(); }

    size();
    if (W.ResizeObserver) new ResizeObserver(function () { size(); }).observe(band);
    else W.addEventListener("resize", size);
    if ("IntersectionObserver" in W) {
      new IntersectionObserver(function (en) {
        visible = en.some(function (x) { return x.isIntersecting; });
        if (!visible) flat();
      }).observe(band);
    }
    D.addEventListener("visibilitychange", function () { if (D.hidden) flat(); });
    apply();
    if (mqR) { if (mqR.addEventListener) mqR.addEventListener("change", apply); else if (mqR.addListener) mqR.addListener(apply); }
  })();
```
- **Режимы:**
  - reduce: слушатели не ставятся (`apply()` → `disable()` → `flat()`), отслеживается на лету (`mqR` `change`).
  - forced-colors: `stroke:CanvasText` (канаты видны, движение остаётся — reduce не включён).
  - печать: полоса `display:none`.
  - без JS: три прямые линии (исходные `d="M0 10Q600 10 1200 10"`…).
  - сенсорный экран: `touch-action:pan-y` на полосе — вертикальный свайп прокручивает страницу; удар только касанием без сдвига (> 10 px — это прокрутка).
  - телефон: та же полоса во всю ширину, 44 px, планка фактов плотнее (12/14/13 px, цифры 28 px).
- **Грабли/поправки (RESULTS «Проверки», v2 §7):** цикл кадров в покое — 0 (проверка: подмена `requestAnimationFrame` и счётчик кадров 2 с после взаимодействия, `passes/boxing/checks_b.js` строка 9); reduce на лету — канаты замирают и оживают; на ПК страница +42 px из-за полосы.
- **Отвергнуто:** «звон» канатов при появлении страницы (ревью Б2: движение только от действия читателя); полоса «поперёк нижней кромки первого экрана» → вынесена между экраном и планкой (З2, вне текста/CTA); таймер раунда как прогресс прокрутки (фиксированный слой поверх чужих блоков, спорит с шапкой); пыль/магнезия (постоянный rAF, ничего не объясняет); «вспышка» от кнопки (F23 — область кнопки неподвижна); магнит на главной кнопке снят (F23: CTA не убегает от курсора).

### 1.2 «Мешок качается»
- **Где:** `/boxing`, CL01-02 «Ринг стоит в центре зала», `blocks/boxing/CL01-02_v1.2.0.html`.
- **Идея:** кадр «Мешки вдоль стены» висит за верхнюю кромку и раскачивается, как мешок. **Польза:** подпись кадра становится действием — читатель «трогает» предмет, о котором текст («мешки висят вдоль стены»); лёгкая фишка второго плана, не ведущая.
- **Механика:** мышь — толчок от горизонтальной скорости указателя `push((clientX − lastX)·0.006)`; касание — `pointerup` со сдвигом ≤ 10 px: ±0,45 (левая половина кадра → вправо). Скорость зажата ±0,6. Физика на кадр: `v += (−0.05·a − 0.07·v)·dt` → период ≈ 28 кадров ≈ 0,47 с, ζ ≈ 0,16. Угол — потолок ±2,4°, на упоре скорость отражается ×0,5. Покой: |a| и |v| < 0,02 → `transform:""`, класс `is-swing` снят (`will-change` только во время взмаха). Ось — `transform-origin:50% 0` (верхняя кромка).
- **Разметка:** `figure.ag-hl__media[data-ag-ui-bag-fig]` (рамка, без `data-ag-anim`); внутри `img[data-ag-anim="parallax"]` — у него transform движка, поэтому качается `figure` (v2 З5).

```html
<!-- blocks/boxing/CL01-02_v1.2.0.html, строка 29 (фрагмент) -->
<figure class="ag-hl__media" data-ag-ui-bag-fig data-ag-slot="CL01-02-ring" data-ag-ratio="4:5" data-ag-brief="Ринг крупно, канаты и угол, человек в кадре для масштаба"> <span class="ag-hl__frame"> <img class="ag-hl__img" src="https://static.tildacdn.pub/tild6431-3366-4135-a466-383164353738/Zal_5-1024x683.jpg" width="1024" height="683" alt="Мешки вдоль стены в зале Apollo Boxing Gym на Галактионовской, 81" loading="lazy" decoding="async" data-ag-anim="parallax" data-ag-parallax="0.08"> </span> <span class="ag-hl__shade" aria-hidden="true"></span> <figcaption class="ag-hl__label"><span class="ag-hl__dot" aria-hidden="true"></span>Мешки вдоль стены</figcaption> </figure>
```

```css
/* blocks/boxing/CL01-02_v1.2.0.html, строки 118–126 */
  /* ===== v1.2.0 · дизайн, движение и фишка (30.09) ===== */
  /* «Мешок качается»: точка подвеса — верхняя кромка кадра */
  #ag-cl01-02 .ag-hl__media{transform-origin:50% 0;}
  #ag-cl01-02 .ag-hl__media.is-swing{will-change:transform;}
  @media (hover:hover) and (pointer:fine){#ag-cl01-02 .ag-hl__media{cursor:grab;}}
  @media (prefers-reduced-motion:reduce){#ag-cl01-02 .ag-hl__media{transform:none !important;cursor:auto;}}
  @media (max-width:599px){
    #ag-cl01-02 .ag-hl__media{aspect-ratio:3/2;}
  }
```

```js
/* blocks/boxing/CL01-02_v1.2.0.html, строки 153–212 */
  /* «Мешок качается»: кадр «Мешки вдоль стены» висит за верхнюю кромку и раскачивается
     от движения мыши (скорость указателя) или от нажатия на кадр на сенсорном экране.
     Качается figure, у img — параллакс движка (разные узлы). До ±2,4°, затухание; rAF только
     во время взмаха. reduce — без движения и без слушателей. */
  (function () {
    "use strict";
    var W = window, D = document;
    var root = D.getElementById("ag-cl01-02");
    if (!root || root.hasAttribute("data-ag-ui-bag")) return;
    root.setAttribute("data-ag-ui-bag", "");
    var fig = root.querySelector("[data-ag-ui-bag-fig]");
    if (!fig) return;
    var mqR = W.matchMedia ? W.matchMedia("(prefers-reduced-motion: reduce)") : null;
    var a = 0, v = 0, raf = 0, last = 0, lastX = null, on = false, down = null;
    function paint() { fig.style.transform = a ? "rotate(" + a.toFixed(3) + "deg)" : ""; }
    function step(ts) {
      raf = 0;
      var dt = last ? Math.min(2, (ts - last) / 16.67) : 1; last = ts;
      v += (-0.05 * a - 0.07 * v) * dt; a += v * dt;
      if (a > 2.4) { a = 2.4; v = -Math.abs(v) * 0.5; } else if (a < -2.4) { a = -2.4; v = Math.abs(v) * 0.5; }
      if (Math.abs(a) < 0.02 && Math.abs(v) < 0.02) { a = 0; v = 0; paint(); fig.classList.remove("is-swing"); last = 0; return; }
      paint();
      if (!D.hidden) raf = W.requestAnimationFrame(step); else { a = 0; v = 0; paint(); fig.classList.remove("is-swing"); }
    }
    function push(dv) {
      v = Math.max(-0.6, Math.min(0.6, v + dv));
      fig.classList.add("is-swing");
      if (!raf) { last = 0; raf = W.requestAnimationFrame(step); }
    }
    function onMove(e) {
      if (e.pointerType !== "mouse") return;
      if (lastX !== null) push((e.clientX - lastX) * 0.006);
      lastX = e.clientX;
    }
    function onLeave() { lastX = null; }
    function onDown(e) { if (e.pointerType !== "mouse") down = { x: e.clientX, y: e.clientY }; }
    function onUp(e) {
      if (e.pointerType === "mouse" || !down) return;
      var moved = Math.abs(e.clientX - down.x) + Math.abs(e.clientY - down.y); down = null;
      if (moved > 10) return;
      var r = fig.getBoundingClientRect();
      push((e.clientX < r.left + r.width / 2 ? 1 : -1) * 0.45);
    }
    function enable() {
      if (on) return; on = true;
      fig.addEventListener("pointermove", onMove, { passive: true });
      fig.addEventListener("pointerleave", onLeave, { passive: true });
      fig.addEventListener("pointerdown", onDown, { passive: true });
      fig.addEventListener("pointerup", onUp, { passive: true });
    }
    function disable() {
      if (!on) return; on = false;
      fig.removeEventListener("pointermove", onMove); fig.removeEventListener("pointerleave", onLeave);
      fig.removeEventListener("pointerdown", onDown); fig.removeEventListener("pointerup", onUp);
      if (raf) W.cancelAnimationFrame(raf); raf = 0; a = 0; v = 0; paint(); fig.classList.remove("is-swing");
    }
    function apply() { if (mqR && mqR.matches) disable(); else enable(); }
    apply();
    if (mqR) { if (mqR.addEventListener) mqR.addEventListener("change", apply); else if (mqR.addListener) mqR.addListener(apply); }
  })();
```
- **Режимы:** reduce — CSS `transform:none !important; cursor:auto`, слушателей нет, на лету — сброс; курсор `grab` только `(hover:hover) and (pointer:fine)`; без JS — кадр неподвижен; телефон — кадр 3:2 (было 4:3), качание по касанию; скрытая вкладка — сброс. (Нет IO-стопа: взмах сам затухает за ~1–2 с.)
- **Отвергнуто/поправки:** «один взмах при появлении» на телефоне (ревью Б2 — только от действия); F04 «Зоны зала Ринг/Мешки» отложены — кадр ринга уже в первом экране, повторять кадр нельзя (Б3); наклон всех фото F05 — ≤ 1 «живой» поверхности на экран.

### 1.3 «Кадр целиком» (F07)
- **Где:** `/boxing`, CL01-05 «Как выглядит зал…», `blocks/boxing/CL01-05_v1.2.0.html`. Тот же приём потом на `/mma` (CL02-02) и `/gym` (CL03-06).
- **Идея:** каждый кадр ленты — ссылка на файл; с JS открывается окно `<dialog>` во весь экран. **Польза:** на телефоне фото зала видно целиком, а не обрезкой 4:3; без JS — просто файл.
- **Механика:** клик (без Ctrl/Meta/Shift и средней кнопки) → `preventDefault`, `showModal()`; ← → листают по кругу (только в открытом окне), Escape (нативно) закрывает; при закрытии `html.style.overflow` возвращается, фокус — на ссылку (`focus({preventScroll:true})`). Анимаций нет. Подпись «Кадр N из 3 · место» в `aria-live="polite"` (кадры не сверены — только место, alt пустой).
- **Разметка:** окно целиком в HTML (`dialog.ag-gl__dlg[aria-labelledby]`, `img[data-ag-ui-img]`, кнопки `data-ag-ui-prev/next/close` с `.ag-vh`-подписями), ссылка-оверлей `a.ag-gl__open[data-ag-ui-open][data-ag-ui-place]` поверх кадра, лупа — `svg[aria-hidden]` 40 px. Цель аналитики `gallery_open`.

```html
<!-- blocks/boxing/CL01-05_v1.2.0.html, строка 42 (ссылка первого кадра и окно) -->
<a class="ag-gl__open" href="https://static.tildacdn.pub/tild6132-3638-4232-a439-363464343036/Zal_3-1024x683.jpg" data-ag-ui-open data-ag-ui-place="Галактионовская, 81" data-ag-track="gallery_open" data-ag-params='{"from":"CL01-05","n":1}'><span class="ag-vh">Открыть кадр 1 из 3</span><svg class="ag-gl__zoom" width="20" height="20" viewBox="0 0 20 20" aria-hidden="true" focusable="false"><path d="M8.5 3.5a5 5 0 1 0 0 10 5 5 0 0 0 0-10ZM12.2 12.2 16.5 16.5M8.5 6.5v4M6.5 8.5h4" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg></a>
<dialog class="ag-gl__dlg" aria-labelledby="ag-cl01-05-dlg-t"><div class="ag-gl__dbox"><p class="ag-gl__dt" id="ag-cl01-05-dlg-t" data-ag-ui-cap aria-live="polite">Кадр 1 из 3 · Галактионовская, 81</p><img class="ag-gl__dimg" data-ag-ui-img src="https://static.tildacdn.pub/tild6132-3638-4232-a439-363464343036/Zal_3-1024x683.jpg" alt="" width="1024" height="683" loading="lazy" decoding="async"><div class="ag-gl__dnav"><button class="ag-gl__dbtn" type="button" data-ag-ui-prev><svg width="20" height="20" aria-hidden="true" focusable="false"><use href="#ag-cl01-05-i-l"/></svg><span class="ag-vh">Предыдущий кадр</span></button><button class="ag-gl__dbtn" type="button" data-ag-ui-next><svg width="20" height="20" aria-hidden="true" focusable="false"><use href="#ag-cl01-05-i-r"/></svg><span class="ag-vh">Следующий кадр</span></button></div><button class="ag-gl__dx" type="button" data-ag-ui-close><svg width="20" height="20" viewBox="0 0 20 20" aria-hidden="true" focusable="false"><path d="M5 5l10 10M15 5 5 15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg><span class="ag-vh">Закрыть</span></button></div></dialog>
```

```css
/* blocks/boxing/CL01-05_v1.2.0.html, строки 171–191 */
  /* F07 · ссылка «открыть кадр»: весь кадр, значок лупы в углу */
  #ag-cl01-05 .ag-gl__open{position:absolute;inset:0;z-index:3;display:block;border-radius:inherit;}
  #ag-cl01-05 .ag-gl__zoom{position:absolute;right:12px;top:12px;width:40px;height:40px;padding:10px;border-radius:50%;
    background:rgba(9,9,10,.62);border:1px solid rgba(255,255,255,.22);color:var(--text);
    -webkit-backdrop-filter:blur(6px);backdrop-filter:blur(6px);transition:background-color 200ms ease,color 200ms ease;}
  #ag-cl01-05.ag-scope .ag-gl__open:focus-visible{outline:3px solid var(--accent);outline-offset:-3px;}
  @media (hover:hover){#ag-cl01-05 .ag-gl__open:hover .ag-gl__zoom{background:var(--accent);color:#09090A;}}
  /* окно просмотра */
  #ag-cl01-05 .ag-gl__dlg{width:100vw;height:100vh;max-width:none;max-height:none;margin:0;padding:0;border:0;background:transparent;color:var(--text);overscroll-behavior:contain;}
  #ag-cl01-05 .ag-gl__dlg::backdrop{background:rgba(6,6,7,.92);}
  #ag-cl01-05 .ag-gl__dbox{position:relative;display:grid;grid-template-rows:auto minmax(0,1fr) auto;gap:14px;width:100%;height:100%;padding:18px clamp(16px,4vw,48px) 22px;}
  #ag-cl01-05 .ag-gl__dt{margin:0;padding-right:56px;font-family:var(--f-display,"Oswald",sans-serif);font-size:15px;font-weight:600;letter-spacing:.08em;text-transform:uppercase;color:var(--text);min-height:44px;display:flex;align-items:center;}
  #ag-cl01-05 .ag-gl__dimg{display:block;width:100%;height:100%;max-height:calc(100dvh - 150px);object-fit:contain;}
  #ag-cl01-05 .ag-gl__dnav{display:flex;justify-content:center;gap:14px;}
  #ag-cl01-05 .ag-gl__dbtn,#ag-cl01-05 .ag-gl__dx{display:inline-flex;align-items:center;justify-content:center;width:48px;height:48px;padding:0;border-radius:50%;
    border:1px solid rgba(255,255,255,.28);background:rgba(20,20,22,.9);color:var(--text);cursor:pointer;font:inherit;}
  #ag-cl01-05 .ag-gl__dx{position:absolute;top:16px;right:clamp(16px,4vw,48px);}
  #ag-cl01-05.ag-scope .ag-gl__dlg :is(button):focus-visible{outline:3px solid var(--accent);outline-offset:3px;}
  @media (hover:hover){#ag-cl01-05 .ag-gl__dbtn:hover,#ag-cl01-05 .ag-gl__dx:hover{border-color:var(--accent);color:var(--accent);}}
  @media (forced-colors:active){#ag-cl01-05 .ag-gl__zoom,#ag-cl01-05 .ag-gl__dbtn,#ag-cl01-05 .ag-gl__dx{border:1px solid CanvasText;}}
  @media print{#ag-cl01-05 .ag-gl__zoom{display:none;}}
```

```js
/* blocks/boxing/CL01-05_v1.2.0.html, строки 272–315 */
  /* F07 · кадр целиком. Ссылка на файл работает и без JS; с JS кадр открывается в <dialog>
     (showModal: фон недоступен, Escape закрывает), ← → листают, фокус возвращается на ссылку.
     Подпись — номер кадра и место (кадры не сверены, I056). */
  (function () {
    "use strict";
    var W = window, D = document;
    var root = D.getElementById("ag-cl01-05");
    if (!root || root.hasAttribute("data-ag-ui-dlg")) return;
    root.setAttribute("data-ag-ui-dlg", "");
    var dlg = root.querySelector("dialog");
    if (!dlg || typeof dlg.showModal !== "function") return;
    var links = Array.prototype.slice.call(root.querySelectorAll("[data-ag-ui-open]"));
    var img = dlg.querySelector("[data-ag-ui-img]");
    var cap = dlg.querySelector("[data-ag-ui-cap]");
    var html = D.documentElement, back = null, cur = 0, keep = "";
    function show(i) {
      cur = (i + links.length) % links.length;
      var a = links[cur];
      img.setAttribute("src", a.getAttribute("href"));
      var txt = "Кадр " + (cur + 1) + " из " + links.length + " · " + (a.getAttribute("data-ag-ui-place") || "");
      if (cap.firstChild) cap.firstChild.nodeValue = txt; else cap.appendChild(D.createTextNode(txt));
    }
    links.forEach(function (a, i) {
      a.addEventListener("click", function (e) {
        if (e.metaKey || e.ctrlKey || e.shiftKey || e.button > 0) return;
        e.preventDefault();
        back = a; show(i);
        keep = html.style.overflow; html.style.overflow = "hidden";
        dlg.showModal();
      });
    });
    dlg.querySelector("[data-ag-ui-prev]").addEventListener("click", function () { show(cur - 1); });
    dlg.querySelector("[data-ag-ui-next]").addEventListener("click", function () { show(cur + 1); });
    dlg.querySelector("[data-ag-ui-close]").addEventListener("click", function () { dlg.close(); });
    dlg.addEventListener("click", function (e) { if (e.target === dlg) dlg.close(); });
    dlg.addEventListener("keydown", function (e) {
      if (e.key === "ArrowRight") { e.preventDefault(); show(cur + 1); }
      else if (e.key === "ArrowLeft") { e.preventDefault(); show(cur - 1); }
    });
    dlg.addEventListener("close", function () {
      html.style.overflow = keep;
      if (back) { try { back.focus({ preventScroll: true }); } catch (e) { back.focus(); } }
    });
  })();
```
- **Режимы:** без JS и без `HTMLDialogElement.showModal` — ссылка открывает файл (`typeof dlg.showModal !== "function"` → выход); forced-colors — рамки `CanvasText` у лупы и кнопок; печать — лупа скрыта; телефон — кнопки окна 48 px (≥ 44), `max-height:calc(100dvh - 150px)`, `object-fit:contain`; reduce — нечего выключать.
- **Грабли (из соседних проходов, важно для гайда):**
  - `/mma` v2 §9.4: окно на всю ширину — щелчок «по фону» попадает во внутренний контейнер и окно не закрывается. Поправка: `if (e.target === dlg || e.target === box) dlg.close();` (`blocks/mma/CL02-02_v1.1.0.html` стр. 380; в `/gym` — `dbox`, CL03-06 стр. 400). В CL01-05 v1.2.0 осталось только `e.target === dlg` — у `.ag-gl__dbox` 100 % размера, так что щелчок по фону практически не закрывает (Escape и крестик работают).
  - `/gym` v2 §9.6: axe считал контраст заголовка окна по странице ПОД окном (окно прозрачное) → окно непрозрачное `rgba(6,6,7,.96)`.
  - `/gym` v2 §7 З10: если в блоке уже есть свой просмотрщик — одно состояние: стрелки окна зовут его `show()`, после закрытия он стоит на том же кадре; свайп кадр не открывает.
- **Отвергнуто:** свайп в окне (не нужен — кнопки); подписи «что на кадре» (кадры не сверены, I056).

### 1.4 «Скопировать адрес» (+ карта по приближению)
- **Где:** `/boxing`, CL01-07 «Как добраться», `blocks/boxing/CL01-07_v1.2.0.html`. Потом так же на `/mma`, `/gym`, `/nofitness`.
- **Идея:** кнопка копирует видимую строку адреса и говорит «Адрес скопирован»; «Поделиться» — только сенсорный экран. **Польза:** ПК-посетитель переносит адрес в навигатор в один клик; Web Share на ПК бесполезен.
- **Механика:** `canCopy` = `navigator.clipboard.writeText` или `execCommand("copy")`; кнопка показывается (`hidden=false`) только если можно. Успех → текст в `span[aria-live="polite"]`, через 3000 мс очищается. Отказ Clipboard API → запасной `textarea` (fixed, opacity 0) → `execCommand`; полный отказ → кнопка снова `hidden`. «Поделиться» — `navigator.share && matchMedia("(pointer: coarse)")`; отказ/отмена `share()` гасится `.catch`. Текст — из `.ag-rt__street` (видимая строка), без адреса сайта.
- **Карта:** `iframe[data-ag-ui-frame][hidden]` без `src` в разметке; IntersectionObserver с `rootMargin:"400px 0px"` ставит `src` из `data-ag-map`, `hidden` снимается по `load` (под ним видна подложка с меткой); без IO — сразу; без JS — `<noscript>` с тем же iframe. Узлы не вставляются (было в v1.1.0: iframe создавал скрипт).

```html
<!-- blocks/boxing/CL01-07_v1.2.0.html, строка 33 (кнопки и подтверждение; карта) -->
<button class="ag-btn ag-btn--quiet" type="button" data-ag-ui-copy hidden><span class="ag-btn__in"><svg class="ag-btn__i" width="16" height="16" viewBox="0 0 16 16" aria-hidden="true" focusable="false"><rect x="5.5" y="5.5" width="8" height="8.5" rx="1.6" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M10.5 3.5V3a1.5 1.5 0 0 0-1.5-1.5H4A1.5 1.5 0 0 0 2.5 3v6A1.5 1.5 0 0 0 4 10.5h.5" fill="none" stroke="currentColor" stroke-width="1.6"/></svg>Скопировать адрес</span></button> <span class="ag-rt__copied" data-ag-ui-copied aria-live="polite"></span>
<iframe class="ag-rt__frame" data-ag-ui-frame title="Apollo Boxing Gym на карте: Самара, улица Галактионовская, 81" loading="lazy" referrerpolicy="strict-origin-when-cross-origin" hidden></iframe>
```

```css
/* blocks/boxing/CL01-07_v1.2.0.html, строки 161–166 */
  #ag-cl01-07 .ag-rt__frame[hidden]{display:none;}
  #ag-cl01-07 .ag-rt__copied{flex-basis:100%;min-height:0;font-size:14px;font-weight:600;color:var(--accent);}
  #ag-cl01-07 .ag-rt__copied:empty{display:none;}
  @media (max-width:599px){
    #ag-cl01-07 .ag-rt__map{min-height:200px;}
  }
```

```js
/* blocks/boxing/CL01-07_v1.2.0.html, строки 176–252 */
  /* Адрес: «Скопировать адрес» — везде, где браузер даёт буфер обмена; «Поделиться адресом» —
     только на сенсорном экране с Web Share. Подтверждение копирования — в aria-live.
     Уходит видимая строка адреса, без адреса сайта. */
  (function () {
    "use strict";
    var W = window, D = document;
    var root = D.getElementById("ag-cl01-07");
    if (!root || root.hasAttribute("data-ag-share-on")) return;
    root.setAttribute("data-ag-share-on", "");
    /* iOS включает :active только при слушателе касания (F23) */
    root.addEventListener("touchstart", function () {}, { passive: true });
    var share = root.querySelector("[data-ag-share]");
    var copy = root.querySelector("[data-ag-ui-copy]");
    var note = root.querySelector("[data-ag-ui-copied]");
    var street = root.querySelector(".ag-rt__street");
    var text = street ? street.textContent.replace(/\s+/g, " ").trim() : "Самара, улица Галактионовская, 81";
    var coarse = W.matchMedia && W.matchMedia("(pointer: coarse)").matches;
    if (share && navigator.share && coarse) {
      share.hidden = false;
      share.addEventListener("click", function () {
        try {
          var p = navigator.share({ title: "Apollo Boxing Gym", text: "Apollo Boxing Gym, " + text + ", +7 917 107-51-79" });
          if (p && p.catch) p.catch(function () {});
        } catch (e) {}
      });
    }
    function said(msg) {
      if (!note) return;
      if (note.firstChild) note.firstChild.nodeValue = msg; else note.appendChild(D.createTextNode(msg));
      W.clearTimeout(said.t);
      said.t = W.setTimeout(function () { if (note.firstChild) note.firstChild.nodeValue = ""; }, 3000);
    }
    function fallback() {
      var ta = D.createElement("textarea");
      ta.value = text; ta.setAttribute("readonly", ""); ta.style.position = "fixed"; ta.style.opacity = "0";
      D.body.appendChild(ta); ta.select();
      var ok = false;
      try { ok = D.execCommand("copy"); } catch (e) {}
      D.body.removeChild(ta);
      return ok;
    }
    var canCopy = !!(navigator.clipboard && navigator.clipboard.writeText) || (D.queryCommandSupported && D.queryCommandSupported("copy"));
    if (copy && canCopy) {
      copy.hidden = false;
      copy.addEventListener("click", function () {
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(text).then(function () { said("Адрес скопирован"); }, function () {
            if (fallback()) said("Адрес скопирован"); else copy.hidden = true;
          });
        } else if (fallback()) said("Адрес скопирован"); else copy.hidden = true;
      });
    }
  })();

  /* Карта: src ставится iframe из разметки, когда блок подходит к экрану (I176, ст. 135) —
     Яндекс не грузится вместе со страницей; узлы не вставляются. Без JS — iframe в noscript. */
  (function () {
    "use strict";
    var W = window, D = document;
    var root = D.getElementById("ag-cl01-07");
    if (!root || root.hasAttribute("data-ag-map-on")) return;
    root.setAttribute("data-ag-map-on", "");
    var box = root.querySelector("[data-ag-map]");
    var frame = box && box.querySelector("[data-ag-ui-frame]");
    if (!box || !frame) return;
    function put() {
      if (frame.getAttribute("src")) return;
      frame.addEventListener("load", function () { frame.hidden = false; }, { once: true });
      frame.setAttribute("src", box.getAttribute("data-ag-map"));
    }
    if ("IntersectionObserver" in W) {
      var io = new IntersectionObserver(function (en) {
        if (en.some(function (e) { return e.isIntersecting; })) { io.disconnect(); put(); }
      }, { rootMargin: "400px 0px" });
      io.observe(box);
    } else put();
  })();
```
- **Режимы:** без JS — кнопок нет (`hidden`), карта в noscript; нет буфера — кнопки нет; сенсорный экран — обе кнопки; печать — карта скрыта (стр. 148); F23 на кнопках (iOS — `touchstart`-пустышка).
- **Грабли/поправки:** `/gym` v2 §9.5 — «Адрес скопирован» жёлтым на бумаге — низкий контраст → цвет `--kick` (#7A5C00); `/mma`, `/gym`, `/nofitness` — на телефоне «Скопировать» и «Поделиться» в один ряд, иначе +58 px (на стенде Chromium Web Share нет — мерить с заглушкой `navigator.share`, `passes/nofitness/checks_n.js` стр. 128); v2 З9 — «Скопировать» везде, где есть буфер (сначала планировалось только без Web Share).

---

## 2. /gym (CL03) — «Тяжёлый мешок» (маятник по удару)

- **Где:** `/gym`, CL03-01 (первый экран), `blocks/gym/CL03-01_v1.1.0.html`. Отчёт `passes/gym/RESULTS.md`, промт `passes/gym/PROMPT_CL03_DESIGN_MOTION_v2.md` (§7 ревью, §8 план, §9 поправки).
- **Идея:** кадр первого экрана уже висел в рамке-силуэте мешка (подвес, кольцо, три ремня, тень на «полу»); теперь по мешку можно ударить. **Польза:** самый прямой жест бокса, продолжает мотив страницы «мешки, лапы, пары», работает и на телефоне. Отличие от `/prices`: там качает прокрутка и тело лёгкое, здесь — только удар и тело тяжёлое.
- **Механика (числа):**
  - Удар: мышь — `pointerdown` левой кнопкой; касание — `pointerup` без `pointercancel`, сдвиг ≤ 10 px, ≤ 350 мс.
  - Маятник: ω₀ = 2π/1,6 (период 1,6 с), ζ = 0,2 (два видимых размаха, покой ≈ 3 с); интегрирование подшагами 120 Гц (`n = ceil(dt·120)`), `dt ≤ 1/30` с. Покой: |θ| < 0,05° и |ω| < 0,3 → `transform:""`.
  - Потолок угла: ПК (≥ 960) 3°, 600–959 px 2,5°, ≤ 599 px 2° (`maxDeg()` по `innerWidth` в момент кадра); на упоре скорость наружу обнуляется; скорость зажата `maxDeg·ω₀·1,25` → удары копятся до потолка.
  - Сила: `side` — смещение от центра −1…1 (минимум ±0,35, удар слева толкает вправо); «ниже — сильнее» `low = 0,6 + 0,8·(y/h)`; импульс `side·low·maxDeg·0,7·ω₀`.
  - Наведение мышью (`pointerenter`, только `(hover:hover) and (pointer:fine)`) — толчок `0,6·ω₀` (≈ 0,6°), не чаще раза в 2000 мс.
  - Точка удара: обратный поворот координат курсора вокруг кольца (`getBoundingClientRect` у повёрнутого узла — габарит, не точка).
  - «Вмятина»: радиальный градиент 150 px в точке удара, WAAPI `scale(.6)→1.4`, `opacity .9→0`, 260 мс, `cubic-bezier(.2,.7,.2,1)`.
  - Тень на полу идёт ЗА низом мешка: `translateX(−H·sin θ)`, `scaleX(1 − 0,06k)`, `opacity 1 − 0,2k` (k = |θ|/max).
  - До первого действия читателя узлы не трогаются (первый экран и LCP как в v1.0.0); rAF только во время качания; IO (вне экрана) и `visibilitychange` — `rest()`.
- **Разметка:** `figure.ag-gh__bag[data-ag-parallax-scope]` > `span.ag-gh__line` (подвес), `span.ag-gh__swing` (качается — `transform-origin:50% calc(var(--hang) * -1 + 10px)`, т. е. кольцо) > кольцо, `svg.ag-gh__straps`, `span.ag-gh__frame` (корпус) > `img[data-ag-anim="parallax"]` (transform движка — другой узел); `span.ag-gh__floor` — тень. Декор — `aria-hidden`. Метки: `data-ag-ui-bag-on` (монтирование), `data-ag-ui-bag` (фишка активна → CSS v1.0.0-наведение снимается).

```html
<!-- blocks/gym/CL03-01_v1.1.0.html, строки 79–94 -->
        <figure class="ag-gh__bag" data-ag-parallax-scope data-ag-slot="CL03-01-hall" data-ag-ratio="4:5" data-ag-brief="Зал целиком, мешки и свободная зона для пар">
          <span class="ag-gh__line" aria-hidden="true"></span>
          <span class="ag-gh__swing">
            <span class="ag-gh__ring" aria-hidden="true"></span>
            <svg class="ag-gh__straps" viewBox="0 0 100 40" preserveAspectRatio="none" aria-hidden="true" focusable="false"><path d="M50 2 12 40M50 2v38M50 2l38 38" fill="none" stroke="#C9C9CE" stroke-width="2" stroke-linecap="round" vector-effect="non-scaling-stroke"/></svg>
            <span class="ag-gh__frame">
              <span class="ag-gh__imgbox"><img class="ag-gh__img" src="https://static.tildacdn.pub/tild3462-3532-4939-a633-656637613062/1_2-1-1024x683.jpg" width="1024" height="683" alt="Зал Apollo Gym на Ново-Садовой, 106Б" decoding="async" fetchpriority="high" data-ag-anim="parallax" data-ag-parallax="0.06"></span>
              <span class="ag-gh__seam ag-gh__seam--top" aria-hidden="true"></span>
              <span class="ag-gh__seam ag-gh__seam--bottom" aria-hidden="true"></span>
              <span class="ag-gh__shade" aria-hidden="true"></span>
              <figcaption class="ag-gh__label"><span class="ag-gh__dot" aria-hidden="true"></span><span class="ag-nw">Ново-Садовая,&nbsp;106Б</span></figcaption>
            </span>
          </span>
          <span class="ag-gh__floor" aria-hidden="true"></span>
        </figure>
      </div>
```

```css
/* blocks/gym/CL03-01_v1.1.0.html, строки 216–219 (рамка-мешок) и 313–330 (v1.1.0) */
  /* Мешок: подвес → кольцо → три ремня → корпус со швами; на полу — светлый эллипс */
  #ag-cl03-01 .ag-gh__bag{position:relative;width:100%;padding-top:var(--hang);padding-bottom:28px;}
  #ag-cl03-01 .ag-gh__line{position:absolute;left:50%;bottom:calc(100% - var(--hang) + 10px);width:2px;height:100vh;margin-left:-1px;background:linear-gradient(0deg,#8B8B92,#4A4A50);pointer-events:none;}
  #ag-cl03-01 .ag-gh__swing{position:relative;display:block;transform-origin:50% calc(var(--hang) * -1 + 10px);transition:transform .6s cubic-bezier(.34,1.56,.64,1);}
/* … */
  /* «Тяжёлый мешок»: при работающей фишке мешок качает скрипт — CSS-переход и поворот по наведению сняты */
  #ag-cl03-01[data-ag-ui-bag] .ag-gh__swing{transition:none;}
  #ag-cl03-01[data-ag-ui-bag] .ag-gh__bag:hover .ag-gh__swing{transform:none;}
  #ag-cl03-01[data-ag-ui-bag] .ag-gh__frame{cursor:pointer;}
  #ag-cl03-01 .ag-gh__dent{position:absolute;left:50%;top:50%;width:150px;height:150px;margin:-75px 0 0 -75px;border-radius:50%;pointer-events:none;opacity:0;
    background:radial-gradient(closest-side,rgba(9,9,10,.34) 0,rgba(9,9,10,.18) 38%,rgba(255,226,140,.34) 56%,rgba(255,226,140,0) 72%);}
  /* Подвес на ≤ 959 px: без него кольцо висит в воздухе */
  @media (max-width:959px){
    #ag-cl03-01 .ag-gh__line{display:block;height:calc(var(--hang) + 8px);}
  }
  @media (forced-colors:active){
    #ag-cl03-01 .ag-gh__swing{transform:none !important;}
    #ag-cl03-01 .ag-gh__dent{display:none;}
  }
  @media print{
    #ag-cl03-01 .ag-gh__swing{transform:none !important;}
    #ag-cl03-01 .ag-gh__dent{display:none;}
  }
```

```js
/* blocks/gym/CL03-01_v1.1.0.html, строки 397–405 (шапка) и 420–506 (ядро) */
  /* v1.1.0 · «Тяжёлый мешок» (ведущая фишка страницы). По мешку можно ударить: щелчок мышью или касание —
     мешок уходит от удара маятником (тяжёлый: период 1,6 с, ζ ≈ 0,2, два видимых размаха ≈ 3 с), ремни и кольцо
     идут с ним, тень на «полу» — за низом мешка; в точке удара — короткая «вмятина». Сторона удара задаёт
     направление, удар ниже — сильнее, удары копятся до потолка (ПК 3°, 600–959 px 2,5°, телефон 2°).
     Наведение мышью — один лёгкий толчок (≤ 0,6°, не чаще раза в 2 с). До первого действия читателя узлы
     не трогаем (первый экран и LCP как в v1.0.0); rAF только пока мешок качается; вне экрана и в скрытой
     вкладке — стоп и покой. Касание — удар, только если жест не стал прокруткой (без pointercancel, сдвиг
     ≤ 10 px, ≤ 350 мс); слушатели пассивные, touch-action не трогаем. reduce и forced-colors — фишки нет
     (на лету — покой и CSS v1.0.0). Параллакс кадра — у img, качание — у .ag-gh__swing: разные узлы. */
    /* … */
    var W0 = 2 * Math.PI / 1.6, ZETA = 0.2;
    var th = 0, om = 0, raf = 0, last = 0, seen = true, on = false, down = null, nudgeAt = -1e9, H = 0, dent = null;
    function off() { return mqR.matches || mqF.matches; }
    function maxDeg() { var w = W.innerWidth || D.documentElement.clientWidth; return w >= 960 ? 3 : (w >= 600 ? 2.5 : 2); }
    function hang() { return parseFloat(W.getComputedStyle(root).getPropertyValue("--hang")) || 0; }
    function draw() {
      swing.style.transform = "rotate(" + th.toFixed(3) + "deg)";
      if (floor && H) {
        var k = Math.min(1, Math.abs(th) / maxDeg());
        floor.style.transform = "translateX(" + (-H * Math.sin(th * Math.PI / 180)).toFixed(1) + "px) scaleX(" + (1 - 0.06 * k).toFixed(3) + ")";
        floor.style.opacity = (1 - 0.2 * k).toFixed(3);
      }
    }
    function rest() {
      if (raf) W.cancelAnimationFrame(raf);
      raf = 0; th = 0; om = 0;
      swing.style.transform = "";
      if (floor) { floor.style.transform = ""; floor.style.opacity = ""; }
    }
    function swingFrame(now) {
      raf = 0;
      var dt = Math.min((now - last) / 1000, 1 / 30);
      last = now;
      var n = Math.max(1, Math.ceil(dt * 120)), h = dt / n;
      for (var i = 0; i < n; i++) { om += (-W0 * W0 * th - 2 * ZETA * W0 * om) * h; th += om * h; }
      var m = maxDeg();
      if (th > m) { th = m; if (om > 0) om = 0; } else if (th < -m) { th = -m; if (om < 0) om = 0; }
      if (Math.abs(th) < 0.05 && Math.abs(om) < 0.3) { rest(); return; }
      draw();
      if (seen && !D.hidden) raf = W.requestAnimationFrame(swingFrame); else rest();
    }
    function kick(v) {
      if (!seen || D.hidden) return;
      var cap = maxDeg() * W0 * 1.25;
      om = Math.max(-cap, Math.min(cap, om + v));
      H = Math.max(0, bag.clientHeight - 10);
      if (!raf) { last = W.performance.now(); raf = W.requestAnimationFrame(swingFrame); }
    }
    /* Точка на мешке: обратный поворот от оси (кольцо). getBoundingClientRect у повёрнутого узла — габарит, не точка */
    function local(e) {
      var r = bag.getBoundingClientRect();
      var px = r.left + r.width / 2, py = r.top + 10;
      var a = -th * Math.PI / 180, dx = e.clientX - px, dy = e.clientY - py;
      var ux = px + dx * Math.cos(a) - dy * Math.sin(a), uy = py + dx * Math.sin(a) + dy * Math.cos(a);
      return { x: ux - (r.left + frame.offsetLeft), y: uy - (r.top + hang() + frame.offsetTop), w: frame.offsetWidth, h: frame.offsetHeight };
    }
    function side(p) { var s = (p.x - p.w / 2) / (p.w / 2); return Math.abs(s) < 0.35 ? (s < 0 ? -0.35 : 0.35) : Math.max(-1, Math.min(1, s)); }
    function showDent(x, y) {
      if (!dent) {
        dent = D.createElement("span");
        dent.className = "ag-gh__dent";
        dent.setAttribute("aria-hidden", "true");
        var seam = frame.querySelector(".ag-gh__seam");
        frame.insertBefore(dent, seam || null);
      }
      dent.style.left = x.toFixed(1) + "px";
      dent.style.top = y.toFixed(1) + "px";
      if (dent.animate) {
        try { dent.animate([{ transform: "scale(.6)", opacity: 0.9 }, { transform: "scale(1.4)", opacity: 0 }], { duration: 260, easing: "cubic-bezier(.2,.7,.2,1)" }); } catch (err) {}
      }
    }
    function hit(e, power) {
      var p = local(e);
      if (p.x < 0 || p.y < 0 || p.x > p.w || p.y > p.h) return;
      var low = 0.6 + 0.8 * (p.y / p.h);
      kick(side(p) * low * maxDeg() * 0.7 * W0 * power);
      showDent(p.x, p.y);
    }
    function onEnter(e) {
      if (e.pointerType !== "mouse" || !fine.matches) return;
      var now = W.performance.now();
      if (now - nudgeAt < 2000) return;
      nudgeAt = now;
      var p = local(e);
      kick((p.x < p.w / 2 ? -1 : 1) * 0.6 * W0);
    }
    function onDown(e) {
      if (e.pointerType === "mouse") { if (e.button === 0) hit(e, 1); return; }
      down = { id: e.pointerId, x: e.clientX, y: e.clientY, t: W.performance.now(), ok: true };
    }
    function onUp(e) {
      if (!down || down.id !== e.pointerId) return;
      var moved = Math.abs(e.clientX - down.x) + Math.abs(e.clientY - down.y);
      if (down.ok && moved <= 10 && W.performance.now() - down.t <= 350) hit(e, 1);
      down = null;
    }
    function onCancel() { if (down) down.ok = false; down = null; }
```
- **Режимы:**
  - reduce И forced-colors — фишки нет (`off()`), на лету — `rest()` + снятие `data-ag-ui-bag` → возвращается CSS v1.0.0 (в reduce он и так `transform:none`).
  - forced-colors и печать — `transform:none !important` у `.ag-gh__swing`, «вмятина» скрыта (ревью Б1: v1.0.0-поворот по hover в forced-colors не снимался).
  - без JS — CSS v1.0.0: на ПК при наведении `rotate(-1.6deg)` переходом .6 с `cubic-bezier(.34,1.56,.64,1)`.
  - сенсорный экран — слушатели пассивные, `touch-action` не трогается: свайп от мешка прокручивает без удара.
  - телефон/планшет ≤ 959 px — над кольцом отрезок подвеса (`.ag-gh__line{display:block;height:calc(var(--hang) + 8px)}`, `--hang` 48/40 px), «чтобы кольцо не висело в воздухе». Комментарий блока говорит «18 px», план v2 — «28 px»: в коде — формула выше.
- **Грабли/поправки (v2 §7):**
  - Б1: CSS-переход с перелётом и hover-поворот конфликтовали с JS → при `[data-ag-ui-bag]` `transition:none` и hover снят.
  - Б2: «пол в противовес» — физически неверно → тень за низом мешка.
  - З3: 3–5° много (низ уходит на 33–55 px, налезает на планку) → 3/2,5/2°; период 1,6 с (у ценников ≈ 0,5 с); проверено: на максимальном угле нет наложения на текст (960 px — запас 48 px, 1024 — 41 px).
  - З4: толчок от движения мыши = копия `/prices` → наведение только одиночный импульс; главный жест — удар.
  - З5: телефон/LCP — до первого удара `swing` не трогаем; IO/`visibilitychange` — сброс.
  - F-проверки: покой через 4 с, после остановки 0 кадров; 12 ударов подряд — не выше потолка; параллакс работает после удара.
- **Отвергнуто:** курсор-перчатка над мешком (подменяет системный курсор, ломает увеличенные курсоры — только `cursor:pointer`); фон «кожа мешка» / меловая пыль (шум, мотив мешка один на страницу); качание от прокрутки как на `/prices`.

---

## 3. /mma (CL02) — «Живая сетка клетки» (canvas)

- **Где:** `/mma`, CL02-01 (первый экран), `blocks/mma/CL02-01_v1.1.0.html`. Отчёт `passes/mma/RESULTS.md`, промт `passes/mma/PROMPT_CL02_DESIGN_MOTION_v2.md`.
- **Идея:** рабица в углу кадра первого экрана отвечает на удар — круговая волна, дребезг проволоки, вспышка вокруг удара; под курсором сетка слегка «дышит». **Польза:** единственный зал сети с клеткой — предмет зала, F30 «графика из оборудования»; жест — удар о сетку (не третья «пружина» подряд после канатов и ценников).
- **Механика (числа):**
  - Canvas создаётся лениво: первое `pointerenter` (только точный указатель) или первый удар. До этого стоит SVG v1.0.0 (паттерн-ромб 36, `xMaxYMin slice`, #E9E9EC, `opacity .5`) — LCP и первый экран не меняются. Первый кадр canvas повторяет SVG, только потом `svg.style.visibility="hidden"`.
  - Геометрия: `sc = max(w/480, h/480)`, `ox = w − 480·sc` (повтор `xMaxYMin slice`); узлы ромбической решётки с шагом `18·sc`; DPR ≤ 2; пересчёт — ResizeObserver и `resize`.
  - Модель — аналитические волны от ударов (без поля узлов и без интегрирования): фронт `520·sc` px/с, длина волны `34·sc`, гауссова огибающая, затухание `exp(−3,2·age)`, радиус действия `420·sc`; дребезг в радиусе `120·sc`: `0,35·a·exp(−7·age)·sin(55·age)` поперёк радиуса; жизнь удара `LIFE = 1100` мс, одновременно ≤ 4 удара. Амплитуда: мышь 14, касание 16 (×sc).
  - Вспышка: поверх — сегменты в радиусе `(140 + 360·age)·sc` цветом `rgba(255,226,140, (1 − age/1,1)·0,9)`.
  - «Дыхание»: радиус `110·sc`, сила `5·sc·(1 − d/R)²`, гаснет за 450 мс после последнего движения.
  - Касание: удар по `pointerup`, если не было `pointercancel` и сдвиг ≤ 10 px.
  - rAF только пока жив удар/«дыхание»; вне экрана и в скрытой вкладке — стоп и `still()`.
- **Разметка:** `figure.ag-mh__band` > `span.ag-mh__frame` > `img[data-ag-anim="parallax"]` (0.06) и `span.ag-mh__mesh[aria-hidden]` (маска радиальным градиентом) > `span.ag-mh__meshi[data-ag-anim="parallax"][data-ag-parallax="0.14"]` > SVG. Canvas `.ag-mh__meshc[aria-hidden]` кладётся ВНУТРЬ `.ag-mh__meshi` — наследует параллакс и маску, transform движка не трогается. (Это вставка узла — см. «ВНИМАНИЕ» вверху.)

```html
<!-- blocks/mma/CL02-01_v1.1.0.html, строки 84–93 -->
      <figure class="ag-mh__band" data-ag-parallax-scope data-ag-slot="CL02-01-cage" data-ag-ratio="21:9" data-ag-brief="Клетка в кадре целиком, зал за ней">
        <span class="ag-mh__frame">
          <span class="ag-mh__imgbox"><img class="ag-mh__img" src="https://static.tildacdn.pub/tild3334-6462-4835-b461-663439656337/img_5464-scaled.jpeg" width="1024" height="683" alt="Клетка для ММА в зале Apollo MMA Gym на Чкалова, 72" decoding="async" fetchpriority="high" data-ag-anim="parallax" data-ag-parallax="0.06"></span>
          <!-- Сетка рабицы: ближе к зрителю, чем кадр -->
          <span class="ag-mh__mesh" aria-hidden="true"><span class="ag-mh__meshi" data-ag-anim="parallax" data-ag-parallax="0.14"><svg viewBox="0 0 480 480" preserveAspectRatio="xMaxYMin slice" focusable="false"><defs><pattern id="ag-cl02-01-p-mesh" width="36" height="36" patternUnits="userSpaceOnUse"><path d="M0 18 18 0 36 18 18 36Z" fill="none" stroke="#E9E9EC" stroke-width="2.2" stroke-linejoin="round"/></pattern></defs><rect width="480" height="480" fill="url(#ag-cl02-01-p-mesh)"/></svg></span></span>
          <span class="ag-mh__shade" aria-hidden="true"></span>
        </span>
        <span class="ag-mh__post" aria-hidden="true"></span>
        <figcaption class="ag-mh__label"><span class="ag-mh__dot" aria-hidden="true"></span>Клетка для ММА · Чкалова,&nbsp;72</figcaption>
      </figure>
```

```css
/* blocks/mma/CL02-01_v1.1.0.html, строки 216–222 и 295–297 */
  #ag-cl02-01 .ag-mh__mesh{
    position:absolute;top:0;right:0;width:min(46%,560px);height:100%;pointer-events:none;overflow:hidden;
    -webkit-mask-image:radial-gradient(120% 110% at 100% 0,#000 22%,rgba(0,0,0,.55) 48%,rgba(0,0,0,0) 74%);
    mask-image:radial-gradient(120% 110% at 100% 0,#000 22%,rgba(0,0,0,.55) 48%,rgba(0,0,0,0) 74%);
  }
  #ag-cl02-01 .ag-mh__meshi{position:absolute;left:0;right:0;top:-12%;bottom:-12%;display:block;}
  #ag-cl02-01 .ag-mh__meshi svg{width:100%;height:100%;opacity:.5;}
/* … */
  /* «Живая сетка клетки»: canvas поверх той же сетки (SVG прячется после первого кадра canvas) */
  #ag-cl02-01 .ag-mh__meshc{position:absolute;inset:0;display:block;width:100%;height:100%;opacity:.5;pointer-events:none;}
  @media (forced-colors:active){#ag-cl02-01 .ag-mh__meshc{display:none;}}
```

```js
/* blocks/mma/CL02-01_v1.1.0.html, строки 394–438 (решётка и поле смещений) и 462–499 (кадр, создание/удаление canvas, удар) */
    function geom() {
      if (!cv) return;
      var r = host.getBoundingClientRect();
      w = Math.max(1, r.width); h = Math.max(1, r.height);
      dpr = Math.min(2, W.devicePixelRatio || 1);
      cv.width = Math.round(w * dpr); cv.height = Math.round(h * dpr);
      sc = Math.max(w / 480, h / 480); ox = w - 480 * sc;
      var s = 18 * sc, i0 = Math.floor(-ox / s) - 1, i1 = Math.ceil((w - ox) / s) + 1, j1 = Math.ceil(h / s) + 1, idx = {};
      nodes = []; segs = [];
      for (var i = i0; i <= i1; i++) for (var j = -1; j <= j1; j++) {
        if (((i + j) % 2 + 2) % 2 !== 1) continue;
        idx[i + "," + j] = nodes.length;
        nodes.push({ x: ox + i * s, y: j * s, px: 0, py: 0 });
      }
      for (var k in idx) {
        var p = k.split(","), a = +p[0], b = +p[1];
        var n1 = idx[(a + 1) + "," + (b + 1)], n2 = idx[(a + 1) + "," + (b - 1)];
        if (n1 !== undefined) segs.push([idx[k], n1]);
        if (n2 !== undefined) segs.push([idx[k], n2]);
      }
    }
    function field(now) {
      var hv = hover && now - hoverAt < 450 ? 1 - (now - hoverAt) / 450 : 0;
      for (var n = 0; n < nodes.length; n++) {
        var q = nodes[n], dx = 0, dy = 0;
        for (var m = 0; m < hits.length; m++) {
          var ht = hits[m], age = (now - ht.t) / 1000;
          var ex = q.x - ht.x, ey = q.y - ht.y, d = Math.sqrt(ex * ex + ey * ey) || 1;
          var front = 520 * sc * age, lam = 34 * sc, g = d - front;
          if (g < lam * 2.5) {
            var amp = ht.a * Math.exp(-age * 3.2) * Math.exp(-(g * g) / (2 * lam * lam)) * Math.max(0, 1 - d / (420 * sc));
            dx += ex / d * amp; dy += ey / d * amp;
          }
          if (d < 120 * sc) {
            var rat = ht.a * 0.35 * Math.exp(-age * 7) * Math.sin(age * 55) * (1 - d / (120 * sc));
            dx += -ey / d * rat; dy += ex / d * rat;
          }
        }
        if (hv && hover) {
          var hx = q.x - hover.x, hy = q.y - hover.y, hd = Math.sqrt(hx * hx + hy * hy) || 1, R = 110 * sc;
          if (hd < R) { var f = 5 * sc * hv * Math.pow(1 - hd / R, 2); dx += hx / hd * f; dy += hy / hd * f; }
        }
        q.px = q.x + dx; q.py = q.y + dy;
      }
    }
    /* … draw(): строки 439–460 — общий штрих #E9E9EC 2,2·sc, затем вспышка rgba(255,226,140,α) … */
    function still() { for (var n = 0; n < nodes.length; n++) { nodes[n].px = nodes[n].x; nodes[n].py = nodes[n].y; } draw(0); }
    function frame(now) {
      raf = 0;
      last = now;
      hits = hits.filter(function (ht) { return now - ht.t < LIFE; });
      var alive = hits.length || (hover && now - hoverAt < 450);
      field(now); draw(now);
      if (alive && seen && !D.hidden) raf = W.requestAnimationFrame(frame);
      else { hits = []; still(); }
    }
    function kick() { if (!raf && cv && seen && !D.hidden) raf = W.requestAnimationFrame(frame); }
    function make() {
      if (cv || off()) return !!cv;
      cv = D.createElement("canvas");
      cv.className = "ag-mh__meshc";
      cv.setAttribute("aria-hidden", "true");
      ctx = cv.getContext && cv.getContext("2d");
      if (!ctx) { cv = null; return false; }
      host.appendChild(cv);
      geom(); still();
      svg.style.visibility = "hidden";
      if ("ResizeObserver" in W) new W.ResizeObserver(function () { if (cv) { geom(); still(); } }).observe(host);
      return true;
    }
    function destroy() {
      if (raf) W.cancelAnimationFrame(raf);
      raf = 0; hits = []; hover = null;
      if (cv && cv.parentNode) cv.parentNode.removeChild(cv);
      cv = null; ctx = null;
      svg.style.visibility = "";
    }
    function at(e) { var r = cv.getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; }
    function hit(e, a) {
      if (!make()) return;
      var p = at(e);
      hits.push({ x: p.x, y: p.y, t: W.performance.now(), a: a * sc });
      if (hits.length > 4) hits.shift();
      kick();
    }
```
- **Режимы:** reduce и forced-colors — слушателей нет, canvas не создаётся; на лету — `destroy()` (canvas удаляется, SVG `visibility` возвращается). forced-colors — сетки нет совсем (как v1.0.0: `.ag-mh__mesh{display:none}`). Печать — сетка скрыта. Без JS — SVG-сетка. Сенсорный экран — слушатели пассивные, `touch-action` не трогается: свайп и щипок работают, кнопка первого экрана кликается (у сетки `pointer-events:none`, слушает `figure`). Телефон — сетка занимает 62 % ширины кадра.
- **Грабли/поправки (v2 §7):** Б3 — техника сетки была не записана: canvas при первом взаимодействии, внутри `.ag-mh__meshi`, первый кадр = SVG, DPR ≤ 2, координаты — `getBoundingClientRect` в каждом событии; З1 — «прогиб под курсором» = третья пружина подряд → главный жест удар, наведение слабое; З2 — маска гасит сетку, фишку плохо видно → вспышка альфой вокруг удара; F-проверки: в покое 0 кадров, вне экрана 0, reduce на лету, canvas не появляется при reduce/forced.
- **Находка закона 10 (важно для «грабель»):** кадр первого экрана с подписью «Клетка для ММА» оказался рингом — заменён на кадр с клеткой, иначе сетка лежала бы поверх ринга.
- **Отвергнуто:** пружина под курсором как главный жест; мотив клетки фоном на всех тёмных блоках (шум, мотив один раз — F30); F04 «Зоны зала» (те же кадры уже лентой прямо над блоком).

---

## 4. /nofitness (CL04) — «Ручка программы крутится» (поворот жестом)

- **Где:** `/nofitness`, CL04-04 «Что делают на каждом занятии», `blocks/nofitness/CL04-04_v1.1.0.html`. Отчёт `passes/nofitness/RESULTS.md`, промт `passes/nofitness/PROMPT_CL04_DESIGN_MOTION_v2.md`.
- **Идея:** круглая ручка пульта велотренажёра под тремя вкладками-программами (по дуге) — её можно повернуть мышью или пальцем; на границе сектора программа переключается вживую, колпачок «щёлкает». **Польза:** предмет страницы (сайкл-студия, «консоль сайкла» с первого экрана), тактильно и на телефоне; выбор ручкой = выбор читателя — направление уходит в ссылку «Спросить расписание» (стандарт 57). Вкладки остаются главным способом (клавиатура, диктор), ручка — дубль (`aria-hidden`, без `tabindex`).
- **Механика (числа):**
  - Фиксаторы −58° / 0° / +58° (Функциональные / Сайкл / Растяжка); в покое угол задаёт CSS `--turn` по атрибуту корня `data-ag-knob`, переход `.45s cubic-bezier(.34,1.35,.64,1)`.
  - Жест начинается после 6 px и только если `|dx| > |dy|` (иначе — отмена, страница прокручивается); `setPointerCapture`.
  - Угол = угол₀ + dx·k, `k = 116 / max(96, 1,2·ширина ручки)` °/px (весь ход ≈ 96 px); за ±58° — «резина» ×0,3; жёсткий предел ±70°. Во время жеста класс `is-drag` снимает переход, угол — inline `--turn` на `.ag-nk__rot`.
  - Секторы: границы ±29° с гистерезисом 4°; на смене сектора `select(s, false, false)` (вживую, не выбор читателя) + «щелчок» `cap.animate(scale .97→1, 120 мс, ease-out)`.
  - Отпустил: inline `--turn` снимается → CSS-переход 450 мс доводит риску до фиксатора; `select(sec, false, true)` — выбор читателя.
  - Касание/щелчок без жеста (< 6 px, ≤ 500 мс): соседняя программа в сторону половины ручки; на краю — ничего.
  - `pointercancel` / `lostpointercapture` / `resize` → вернуть исходную программу. Событие `ag:tab` от табло CL04-01 во время жеста игнорируется.
  - F10 (ведущий приём дополнения, в том же скрипте): жёлтая подложка `::before` у tablist на CSS-переменных `--ix/--iy/--iw/--ih`, переход .34 с; между крайними вкладками — через вершину дуги WAAPI с `pseudoElement:"::before"`, 3 ключа, 380 мс; смена ряда на телефоне — без сдвига, проявление 180 мс; первая установка — без перехода (`is-jump` на 2 кадра). Панели меняются `opacity .001→1` 250 мс.
- **Разметка:** всё в HTML: `div.ag-nk__scale[data-ag-scale][hidden][data-ag-anim="rise"]` (шкала скрыта без JS, движок даёт ей появление — поэтому крутится вложенный `.ag-nk__rot`, а не узел движка), `svg.ag-nk__arc[aria-hidden]` (пунктирная дуга), `[role=tablist][data-ag-tablist]` с `button[role=tab][data-knob][data-key][data-name]`, `span.ag-nk__knob[aria-hidden]` > `.ag-nk__cap` > `.ag-nk__rot` > `.ag-nk__needle`; `p.ag-nk__pick[data-ag-pick][hidden]` с `span[data-ag-pick-name]`, ссылка `a[data-ag-ask]`. Метка фишки — `data-ag-ui-knob` на корне (включает `touch-action:pan-y`, grab).

```html
<!-- blocks/nofitness/CL04-04_v1.1.0.html, строки 63–71 -->
      <div class="ag-nk__scale" data-ag-scale hidden data-ag-anim="rise" data-ag-delay="60" data-ag-distance="14">
        <svg class="ag-nk__arc" viewBox="0 0 560 60" preserveAspectRatio="none" aria-hidden="true" focusable="false"><path d="M94 44Q280 -6 466 44" fill="none" stroke="currentColor" stroke-width="2" stroke-dasharray="2 7" stroke-linecap="round" vector-effect="non-scaling-stroke"/></svg>
        <div class="ag-nk__tabs" role="tablist" aria-label="Занятия зала на Молодогвардейской" aria-orientation="horizontal" data-ag-tablist>
          <button class="ag-nk__tab" type="button" role="tab" id="ag-cl04-04-t1" aria-controls="ag-cl04-04-p1" aria-selected="false" tabindex="-1" data-key="functional-training" data-knob="functional" data-name="Функциональные тренировки"><span>Функциональные</span></button>
          <button class="ag-nk__tab" type="button" role="tab" id="ag-cl04-04-t2" aria-controls="ag-cl04-04-p2" aria-selected="true" data-key="cycle-samara" data-knob="cycle" data-name="Сайкл"><span>Сайкл</span></button>
          <button class="ag-nk__tab" type="button" role="tab" id="ag-cl04-04-t3" aria-controls="ag-cl04-04-p3" aria-selected="false" tabindex="-1" data-key="stretching-samara" data-knob="stretching" data-name="Растяжка"><span>Растяжка</span></button>
        </div>
        <span class="ag-nk__knob" aria-hidden="true"><span class="ag-nk__cap"><span class="ag-nk__rot"><span class="ag-nk__needle"></span></span></span></span>
      </div>
```

```css
/* blocks/nofitness/CL04-04_v1.1.0.html, строки 160–161, 209–225 (ручка), 347–367 (v1.1.0: F10 и жест) */
  #ag-cl04-04[data-ag-knob="functional"]{--turn:-58deg;}
  #ag-cl04-04[data-ag-knob="stretching"]{--turn:58deg;}
/* … */

  /* Ручка: накатка по краю, колпачок, жёлтая риска */
  #ag-cl04-04 .ag-nk__knob{
    position:relative;display:block;width:var(--knob);height:var(--knob);margin-top:22px;border-radius:50%;
    background:repeating-conic-gradient(#23252A 0deg 5deg,#3A3D44 5deg 10deg);
    box-shadow:0 16px 34px rgba(9,9,10,.28),0 0 0 6px rgba(9,9,10,.06);
  }
  #ag-cl04-04 .ag-nk__cap{
    position:absolute;inset:11%;display:block;border-radius:50%;
    background:radial-gradient(circle at 34% 28%,#4A4E57 0%,#22252B 48%,#131418 100%);
    box-shadow:inset 0 2px 3px rgba(255,255,255,.18),inset 0 -6px 14px rgba(0,0,0,.55);
  }
  #ag-cl04-04 .ag-nk__rot{
    position:absolute;inset:0;display:block;border-radius:50%;
    transform:rotate(var(--turn));transition:transform .45s cubic-bezier(.34,1.35,.64,1);
  }
  #ag-cl04-04 .ag-nk__needle{position:absolute;left:50%;top:9%;width:6px;height:34%;margin-left:-3px;border-radius:3px;background:var(--accent);box-shadow:0 0 10px rgba(255,196,0,.6);}
/* … */
  /* F10 · подложка выбранной программы: над фоном вкладок, под подписями */
  #ag-cl04-04 .ag-nk__tabs{isolation:isolate;}
  @media not (forced-colors:active){
    #ag-cl04-04 .ag-nk__tabs.is-ind::before{
      content:"";position:absolute;z-index:1;left:0;top:0;width:var(--iw,0px);height:var(--ih,0px);border-radius:var(--r-pill);
      background:var(--accent);box-shadow:0 6px 16px rgba(255,196,0,.28);pointer-events:none;
      transform:translate(var(--ix,0px),var(--iy,0px));
      transition:transform .34s cubic-bezier(.22,.61,.36,1),width .34s cubic-bezier(.22,.61,.36,1),height .34s cubic-bezier(.22,.61,.36,1);
    }
    #ag-cl04-04 .ag-nk__tabs.is-jump::before{transition:none;}
    #ag-cl04-04 .ag-nk__tabs.is-ind .ag-nk__tab>span{position:relative;z-index:2;}
    #ag-cl04-04 .ag-nk__tabs.is-ind .ag-nk__tab[aria-selected="true"]{background:transparent;border-color:transparent;box-shadow:none;}
  }
  @media print{#ag-cl04-04 .ag-nk__tabs::before{display:none;}}
  /* «Ручка программы крутится» */
  #ag-cl04-04[data-ag-ui-knob] .ag-nk__knob{touch-action:pan-y;-webkit-user-select:none;user-select:none;-webkit-touch-callout:none;}
  #ag-cl04-04 .ag-nk__knob.is-drag .ag-nk__rot{transition:none;}
  @media (hover:hover) and (pointer:fine){
    #ag-cl04-04[data-ag-ui-knob] .ag-nk__knob{cursor:grab;}
    #ag-cl04-04 .ag-nk__knob.is-drag{cursor:grabbing;}
  }
```

```js
/* blocks/nofitness/CL04-04_v1.1.0.html, строки 482–553 (жест ручки) */
    /* v1.1.0 · «Ручка программы крутится» (ведущая фишка страницы). Ручку можно повернуть: потянуть мышью или
       пальцем влево-вправо (угол = угол₀ + сдвиг·k, весь ход ≈ 96 px). Риска идёт за рукой, на границе сектора
       программа переключается вживую (гистерезис 4°) и колпачок коротко «щёлкает»; отпустил — переход 450 мс
       доводит риску до фиксатора, выбор считается выбором читателя (стандарт 57). Касание левой или правой
       половины — соседняя программа в эту сторону. Вертикальный жест — прокрутка страницы (touch-action:pan-y),
       pointercancel возвращает прежнюю программу. Ручка — aria-hidden, без tabindex: она дублирует вкладки. */
    var knob = scale.querySelector(".ag-nk__knob");
    var rot = knob && knob.querySelector(".ag-nk__rot");
    var cap = knob && knob.querySelector(".ag-nk__cap");
    var TURN = [-58, 0, 58];
    var drag = null;
    function rNow() { return W.matchMedia && W.matchMedia("(prefers-reduced-motion: reduce)").matches; }
    function tick() {
      if (rNow() || !cap || !cap.animate) return;
      try { cap.animate([{ transform: "scale(.97)" }, { transform: "scale(1)" }], { duration: 120, easing: "ease-out" }); } catch (err) {}
    }
    function sector(a, cur) {
      var s = a < -29 ? 0 : (a > 29 ? 2 : 1);
      if (s !== cur && Math.abs(Math.abs(a) - 29) < 4) return cur;
      return s;
    }
    function knobCancel() {
      if (!drag) return;
      var d = drag;
      drag = null;
      knob.classList.remove("is-drag");
      rot.style.removeProperty("--turn");
      if (d.on && d.sec !== d.start) select(d.start, false, false);
    }
    if (knob && rot) {
      root.setAttribute("data-ag-ui-knob", "");
      knob.addEventListener("pointerdown", function (e) {
        if (e.button > 0) return;
        var i = current();
        drag = { id: e.pointerId, x: e.clientX, y: e.clientY, t: W.performance.now(), a0: TURN[i], sec: i, start: i, on: false,
                 k: 116 / Math.max(96, 1.2 * knob.offsetWidth) };
        try { knob.setPointerCapture(e.pointerId); } catch (err) {}
      });
      knob.addEventListener("pointermove", function (e) {
        if (!drag || drag.id !== e.pointerId) return;
        var dx = e.clientX - drag.x, dy = e.clientY - drag.y;
        if (!drag.on) {
          if (Math.abs(dx) < 6 && Math.abs(dy) < 6) return;
          if (Math.abs(dx) <= Math.abs(dy)) { knobCancel(); return; }
          drag.on = true;
          knob.classList.add("is-drag");
        }
        var a = drag.a0 + dx * drag.k;
        if (a > 58) a = 58 + (a - 58) * 0.3; else if (a < -58) a = -58 + (a + 58) * 0.3;
        a = Math.max(-70, Math.min(70, a));
        rot.style.setProperty("--turn", a.toFixed(1) + "deg");
        var s = sector(a, drag.sec);
        if (s !== drag.sec) { drag.sec = s; select(s, false, false); tick(); }
      });
      knob.addEventListener("pointerup", function (e) {
        if (!drag || drag.id !== e.pointerId) return;
        var d = drag;
        drag = null;
        if (d.on) {
          knob.classList.remove("is-drag");
          rot.style.removeProperty("--turn");
          select(d.sec, false, true);
          return;
        }
        if (W.performance.now() - d.t > 500) return;
        var r = knob.getBoundingClientRect(), to = current() + (e.clientX > r.left + r.width / 2 ? 1 : -1);
        if (to >= 0 && to < tabs.length) { select(to, false, true); tick(); }
      });
      knob.addEventListener("pointercancel", knobCancel);
      knob.addEventListener("lostpointercapture", function () { if (drag && drag.on) knobCancel(); });
      W.addEventListener("resize", knobCancel);
    }
```

```js
/* blocks/nofitness/CL04-04_v1.1.0.html, строки 422–444: решение «прямо / через вершину / перенос ряда» для подложки F10 (WAAPI на ::before) */
      var x = t.offsetLeft, y = t.offsetTop, w = t.offsetWidth, h = t.offsetHeight, row = rowOf(t);
      var wrapRow = ind.row !== null && Math.abs(row - ind.row) > h / 2;
      var over = ind.on && !jump && !wrapRow && Math.abs(i - prev) === 2 && !reduce && !!list.animate && ind.x !== null;
      if (!ind.on || jump || wrapRow || over) list.classList.add("is-jump");
      list.style.setProperty("--ix", x + "px");
      list.style.setProperty("--iy", y + "px");
      list.style.setProperty("--iw", w + "px");
      list.style.setProperty("--ih", h + "px");
      if (!ind.on) { list.classList.add("is-ind"); ind.on = true; }
      else if (wrapRow && !jump && !reduce && list.animate) {
        try { list.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 180, easing: "ease-out", pseudoElement: "::before" }); } catch (e) {}
      } else if (over) {
        var top = tabs[1] ? rowOf(tabs[1]) : Math.min(y, ind.y);
        try {
          list.animate([
            { transform: "translate(" + ind.x + "px," + ind.y + "px)", width: ind.w + "px" },
            { transform: "translate(" + ((ind.x + x) / 2) + "px," + top + "px)", width: ((ind.w + w) / 2) + "px", offset: 0.5 },
            { transform: "translate(" + x + "px," + y + "px)", width: w + "px" }
          ], { duration: 380, easing: "cubic-bezier(.22,.61,.36,1)", pseudoElement: "::before" });
        } catch (e) {}
      }
      ind.x = x; ind.y = y; ind.w = w; ind.row = row;
      if (list.classList.contains("is-jump")) W.requestAnimationFrame(function () { W.requestAnimationFrame(function () { list.classList.remove("is-jump"); }); });
```
- **Режимы:**
  - reduce — жест РАБОТАЕТ (это прямое управление, не декор), риска встаёт сразу (глобальное `transition-duration:.01ms`), «щелчок» и переезды WAAPI не играют (`rNow()` / `reduce`).
  - forced-colors — ручки и дуги нет (`display:none`, как v1.0.0), подложки нет (`@media not (forced-colors:active)`), выбранная вкладка `Highlight/HighlightText`.
  - печать — шкала скрыта, все три панели столбцом.
  - без JS — шкала `hidden`, три панели столбцом.
  - сенсорный экран — `touch-action:pan-y` только на ручке, `user-select:none`, `-webkit-touch-callout:none`; вертикальный жест прокручивает, горизонтальный крутит.
  - телефон (≤ 767.98 px) — ручка 56 px слева, вкладки справа в два ряда (2+1), дуга скрыта; перенос подложки между рядами — с проявлением (отступление по Р2).
- **Грабли/поправки (v2 §7):** Б1 — определение «другого ряда» по `|dx|>2 && |dy|>2` (как в CL03) на дуге срабатывает всегда → ряд = `offsetTop − marginTop`, перенос только если ряды разнятся > ½ высоты вкладки; З2 — тень выбранной вкладки перешла на подложку, `box-shadow` не анимируется; Б4 — вся техника жеста (выше); З3 — F23 только у кнопок низа, вкладки и ручку не трогать; З10 — на стенде свайп проверяется ручными событиями касания CDP (`Input.dispatchTouchEvent`), `synthesizeScrollGesture` не прокручивает (`passes/nofitness/checks_n.js` стр. 101–106).
- **Отвергнуто:** `navigator.vibrate` при щелчке (в iOS нет, в Chrome без жеста — предупреждение в консоли → щелчок визуальный); вступительное покачивание ручки (П12 — без действия читателя; подсказка жеста — только курсор grab); табло «оживает» цифрами (стандарт 11 — без счётчиков); неоновая полоса по фону.

---

## 5. /prices — «Ценники на канате» (инерция прокрутки) + другие фишки PRICES

- **Где:** `/prices`, PRICES-01 (первый экран), `blocks/prices/PRICES-01_v1.2.0.html`. Отчёт `passes/prices/RESULTS.md`, промт `passes/prices/PROMPT_PRICES_DESIGN_MOTION_v2.md` (§7 ревью, §8 план; §9 нет).
- **Идея:** три ценника (900 ₽ / абонемент 12 / 0 ₽) висят на нитках с провисшего каната и покачиваются по инерции — от разгона и остановки прокрутки и от мыши, прошедшей по ценнику. **Польза:** физика «ценник на верёвочке» работает и на телефоне, где наведения нет; ценники — ссылки к своей колонке прайса (PRICES-02), качание привлекает к ним взгляд без счётчиков и «выгоды».
- **Механика (числа):**
  - Толчок от УСКОРЕНИЯ прокрутки: `s = dy/dt`, `acc = s − lastS`, `push = clamp(acc·0,02, ±0,8)`, знак по ценнику `[+1, −1, +1]` (качаются вразнобой).
  - Пружины на кадр: `k = [0,05; 0,034; 0,042]`, демпфирование 0,07 → периоды ≈ 28/34/31 кадра (≈ 0,47/0,57/0,51 с), ζ ≈ 0,16–0,19. `dt = min(2, Δt/16,67)`.
  - Предел: ПК ±5°; ≤ 599 px — `max(0,5; 4,5 − |rest|)`, т. е. наклон с покоем ≤ 4,5° (ценник не упирается в край); на упоре скорость 0.
  - Мышь: `movementX·0,02`, зажато ±0,7, только `(hover:hover) and (pointer:fine)`.
  - Без толчка: скачок > 0,8 экрана за кадр (якорь, восстановление позиции); первые 1000 мс и пока движок не поставил ценникам `data-ag-done` (появление `stagger`).
  - Ценник в фокусе или под нажатием «держится»: `v·0,6`, `x·0,75` за кадр.
  - Покой: |x| < 0,02 и |v| < 0,005 → `transform:""`, `will-change:""`. rAF идёт, пока ценники качаются, и ещё 140 мс после последнего `scroll`.
  - `scroll` (пассивный) слушается только пока сцена видна (IO); скрытая вкладка — `reset()`.
- **Разметка:** `svg.ag-ph__rope[data-ag-anim="draw"]` (канат рисует движок), `ul.ag-ph__tags[data-ag-anim="stagger"]` > `li.ag-ph__it--N` (CSS-переменные `--ry` высота на канате, `--len` длина нитки, `--rest` угол покоя, `--hit` угол наведения/фокуса) > `a.ag-ph__swing` (ссылка: transform = покой/фокус, CSS) > `span.ag-ph__sway` (НОВАЯ обёртка в разметке: нитка + карточка, качает JS) > `span.ag-ph__str[aria-hidden]` + `span.ag-ph__card`. Метки: `data-ag-ui-swing-on` (монтирование), `data-ag-ui-swing` (фишка активна → hover-поворот ссылки снят).

```html
<!-- blocks/prices/PRICES-01_v1.2.0.html, строки 73–92 -->
        <svg class="ag-ph__rope" viewBox="0 0 100 48" preserveAspectRatio="none" aria-hidden="true" focusable="false" data-ag-anim="draw" data-ag-start="top bottom" data-ag-delay="120">
          <path class="ag-ph__rope-a" d="M0 8 Q50 40 100 8" fill="none" vector-effect="non-scaling-stroke"/>
          <path class="ag-ph__rope-b" d="M0 8 Q50 40 100 8" fill="none" vector-effect="non-scaling-stroke"/>
        </svg>
        <!-- Планка PRICES.md: три факта. Ценник — ссылка на своё место в PRICES-02 -->
        <ul class="ag-ph__tags" data-ag-anim="stagger" data-ag-start="top bottom" data-ag-delay="220" data-ag-stagger="110" data-ag-distance="18">
          <li class="ag-ph__it ag-ph__it--1">
            <a class="ag-ph__swing" href="#ag-price-1" data-ag-track="price_jump" data-ag-params='{"from":"PRICES-01","to":"1"}'>
              <span class="ag-ph__sway">
              <span class="ag-ph__str" aria-hidden="true"></span>
              <span class="ag-ph__card">
                <span class="ag-ph__hole" aria-hidden="true"></span>
                <b class="ag-ph__num">900&nbsp;₽</b>
                <span class="ag-ph__cap">разовое групповое занятие</span>
                <span class="ag-vh">— к таблице цен</span>
                <svg class="ag-ph__go" width="18" height="18" aria-hidden="true" focusable="false"><use href="#ag-prices-01-down"/></svg>
              </span>
              </span>
            </a>
          </li>
```

```css
/* blocks/prices/PRICES-01_v1.2.0.html, строки 139–140, 244–252, 351–360 */
    --ease:cubic-bezier(.22,.61,.36,1);
    --spring:cubic-bezier(.3,1.9,.45,1);
/* … */
  #ag-prices-01 .ag-ph__it{position:relative;min-width:0;}
  #ag-prices-01 .ag-ph__it--1{--ry:18px;--len:44px;--rest:-3deg;--hit:4deg;}
  #ag-prices-01 .ag-ph__it--2{--ry:24px;--len:78px;--rest:2deg;--hit:-4deg;}
  #ag-prices-01 .ag-ph__it--3{--ry:18px;--len:54px;--rest:-2deg;--hit:3.5deg;}
  #ag-prices-01 .ag-ph__swing{
    position:relative;display:block;margin-top:var(--ry);padding-top:var(--len);
    transform:rotate(var(--rest));transform-origin:50% 0;
    transition:transform .9s var(--spring);
  }
/* … */
  /* «Ценники на канате»: качается обёртка, ось — точка на канате; отступ нитки переехал на неё */
  #ag-prices-01 .ag-ph__swing{padding-top:0;}
  #ag-prices-01 .ag-ph__sway{position:relative;display:block;padding-top:var(--len);transform-origin:50% 0;}
  #ag-prices-01[data-ag-ui-swing] .ag-ph__swing:hover{transform:rotate(var(--rest));}
  @media (max-width:599px){
    #ag-prices-01 .ag-ph__jump.is-more{-webkit-mask-image:linear-gradient(90deg,#000 calc(100% - 44px),transparent);mask-image:linear-gradient(90deg,#000 calc(100% - 44px),transparent);}
  }
  @media print{
    #ag-prices-01 .ag-ph__sway{padding-top:0;transform:none !important;}
  }
```

```js
/* blocks/prices/PRICES-01_v1.2.0.html, строки 426–434 (шапка) и 444–502, 527–539 */
  /* v1.2.0 · «Ценники на канате» (ведущая фишка страницы, П12): ценники висят на нитках и покачиваются
     по инерции — от изменения скорости прокрутки (разгон и остановка) и от мыши, прошедшей по ценнику;
     у каждого своя длина нитки, качаются вразнобой и затухают. Качается обёртка .ag-ph__sway (нитка
     и карточка), у ссылки transform занят покоем и фокусом. Ограничения (ревью Б1): скачок больше
     0,8 экрана за кадр (якорь, восстановление позиции) — без толчка; первую секунду и пока движок не
     закончил появление ценников — без толчка; scroll пассивный и только пока сцена видна; rAF — только
     пока ценники качаются, шаг ≤ 2 кадров; скрытая вкладка — сброс; мышь — только точный указатель;
     ценник в фокусе или под нажатием не качается; телефон — наклон с покоем ≤ 4,5°. reduce и
     forced-colors — фишка выключена (и при смене настройки на лету). */
    /* … */
    var mqR = W.matchMedia("(prefers-reduced-motion: reduce)");
    var mqF = W.matchMedia("(forced-colors: active)");
    var fine = W.matchMedia("(hover: hover) and (pointer: fine)");
    var small = W.matchMedia("(max-width: 599px)");
    var K = [0.05, 0.034, 0.042], SIGN = [1, -1, 1];
    var tags = Array.prototype.slice.call(root.querySelectorAll(".ag-ph__swing")).map(function (a, i) {
      var rest = parseFloat(W.getComputedStyle(a.parentNode).getPropertyValue("--rest")) || 0;
      return { a: a, el: a.querySelector(".ag-ph__sway"), x: 0, v: 0, k: K[i % 3], s: SIGN[i % 3], rest: rest, hold: false };
    }).filter(function (t) { return t.el; });
    if (!tags.length) return;
    var on = false, seen = false, raf = 0, last = 0, t0 = Date.now();
    var lastY = W.pageYOffset, lastS = 0, lastScroll = 0;
    function ready() {
      if (Date.now() - t0 < 1000) return false;
      return list.hasAttribute("data-ag-done") || D.documentElement.getAttribute("data-ag-motion") !== "on";
    }
    function lim(t) { return small.matches ? Math.max(0.5, 4.5 - Math.abs(t.rest)) : 5; }
    function paint(t) {
      if (Math.abs(t.x) < 0.02 && Math.abs(t.v) < 0.005) { t.x = 0; t.v = 0; t.el.style.transform = ""; t.el.style.willChange = ""; return false; }
      t.el.style.willChange = "transform";
      t.el.style.transform = "rotate(" + t.x.toFixed(2) + "deg)";
      return true;
    }
    function frame(now) {
      raf = 0;
      var dt = last ? Math.min(2, (now - last) / 16.67) : 1;
      last = now;
      var y = W.pageYOffset, dy = y - lastY;
      lastY = y;
      if (Math.abs(dy) > W.innerHeight * 0.8) { lastS = 0; dy = 0; }
      var s = dy / dt, acc = s - lastS;
      lastS = s;
      var push = ready() ? Math.max(-0.8, Math.min(0.8, acc * 0.02)) : 0;
      var busy = false;
      tags.forEach(function (t) {
        if (t.hold) { t.v *= 0.6; t.x *= 0.75; }
        else {
          t.v += push * t.s;
          t.v += (-t.k * t.x - 0.07 * t.v) * dt;
          t.x += t.v * dt;
          var m = lim(t);
          if (t.x > m) { t.x = m; t.v = 0; } else if (t.x < -m) { t.x = -m; t.v = 0; }
        }
        if (paint(t)) busy = true;
      });
      if (busy || Date.now() - lastScroll < 140) raf = W.requestAnimationFrame(frame);
      else { last = 0; lastS = 0; }
    }
    function kick() { if (!raf && on) { lastY = W.pageYOffset; raf = W.requestAnimationFrame(frame); } }
    function onScroll() { lastScroll = Date.now(); kick(); }
    function onMove(e) {
      if (!fine.matches || !ready()) return;
      var a = e.target.closest && e.target.closest(".ag-ph__swing");
      if (!a) return;
      tags.forEach(function (t) {
        if (t.a === a && !t.hold) t.v += Math.max(-0.7, Math.min(0.7, (e.movementX || 0) * 0.02));
      });
      kick();
    }
    /* … */
    tags.forEach(function (t) {
      t.a.addEventListener("focus", function () { t.hold = true; kick(); });
      t.a.addEventListener("blur", function () { t.hold = false; });
      t.a.addEventListener("pointerdown", function () { t.hold = true; kick(); });
      ["pointerup", "pointercancel", "pointerleave"].forEach(function (ev) {
        t.a.addEventListener(ev, function () { if (D.activeElement !== t.a) t.hold = false; });
      });
    });
    new IntersectionObserver(function (es) {
      seen = es[es.length - 1].isIntersecting;
      if (on) listen(seen);
      if (!seen) reset();
    }).observe(stage);
```
- **Режимы:** reduce и forced-colors — фишка выключена, на лету — сброс (в reduce CSS ставит всем `rotate(var(--rest))`); forced-colors — карточки с рамкой `CanvasText`, нитки/канат `CanvasText`; печать — канат и нитки скрыты, `transform:none`, `padding-top:0`; без JS — как v1.1.0 (CSS-поворот по hover/фокусу, переход `.9s cubic-bezier(.3,1.9,.45,1)`); сенсорный экран — качание от прокрутки, касание «держит» ценник; телефон — нитки короче (22/40/28 px), предел 4,5°.
- **Грабли/поправки (v2 §7):** Б1 — качание от прокрутки вне «карты времени» MOTION_ADDENDUM (от прокрутки — только параллакс) → записано как отступление П12 со всеми ограничениями выше; Б2 — обёртка ломала нитку (`.ag-ph__str` абсолютный от ссылки, `padding-top:var(--len)` у ссылки) → `span.ag-ph__sway` в разметке, отступ нитки переехал на него, ось `50% 0` — точка на канате; З2 — на телефоне ценник упирался в край → ≤ 4,5°; П2-проверки: rAF через 2 с после остановки, якорь из ценника, перезагрузка посреди страницы — без толчка, Tab на ценник — не качается, 320 px.
- **Отвергнуто:** табло/прокрутка цифр цены (F16 — цена не анимируется); «чек» набора (похоже на документ оплаты); монеты/конфетти на 12 (ложная «выгода»); канаты `/boxing` фоном (на первом экране уже свой канат); F17 «разница с N разовыми» (срок абонемента не подтверждён, I037).

### 5.1 Попутно на /prices (кратко)
- **PRICES-01, телефон — затухание края ряда якорей** (стр. 546–559): класс `is-more`, пока `scrollWidth − clientWidth − scrollLeft > 2`; маска `linear-gradient(90deg,#000 calc(100% - 44px),transparent)` только ≤ 599 px.
- **PRICES-02 «Подбор пакета» (F16)** `blocks/prices/PRICES-02_v1.2.0.html`: под колонками набора жёлтая планка-«пол» `::after scaleX(0→1)` 280 мс (без rAF), итог проявляется WAAPI `opacity .25→1` 160 мс (цифры не прокручиваются), «−/+» на 1 и 12 — `aria-disabled` вместо `disabled` (фокус с клавиатуры не теряется).

```css
/* blocks/prices/PRICES-02_v1.2.0.html, строки 360–367 */
  /* «пол» под колонками подбора: планка по нижней кромке, растёт от центра */
  #ag-prices-02 .ag-pl__col::after{
    content:"";position:absolute;left:12%;right:12%;bottom:-7px;height:4px;border-radius:2px;background:var(--accent);
    transform:scaleX(0);transition:transform .28s cubic-bezier(.22,.61,.36,1);pointer-events:none;
  }
  #ag-prices-02 .ag-pl__col.is-pick::after{transform:scaleX(1);}
  @media (forced-colors:active){#ag-prices-02 .ag-pl__col::after{background:Highlight;}}
  @media print{#ag-prices-02 .ag-pl__col::after{display:none;}}
```
- **PRICES-03 F10** — подложка вкладок «Абонемент / Детские…» (как CL04-04, сетка 2×2 на телефоне: внутри ряда сдвиг, между рядами — перенос с проявлением 180 мс). **PRICES-03/05 F29** — зерно бумаги (SVG < 1 КБ, плитка 180 px, `::before`, затемнение ≤ 6 %, ≥ 640 px). **PRICES-05 F22** — плавный FAQ, «Раскрыть все» без перехода.

---


---

## 6. Главная `/`

### 6.1 F01 «Рамка ринга» — канаты из кадра (HOME-01)
- **Файл:** `blocks/home/HOME-01_v9.2.0.html` (запись rec3667640103, v9.1.0 → v9.2.0).
- **Идея:** три каната ринга (верхний жёлтый) выходят из правого края кадра ринга к краю экрана и прорисовываются при загрузке. **Польза:** первый экран сразу говорит «здесь ринг/бокс», связывает кадр с секцией; заменяет дублирующий мотив — скобку «угол канатов».
- **Механика:** запуск — прокрутка/загрузка (движок `draw`, `data-ag-start="top bottom"` → срабатывает сразу на первом экране). Длительности 600 / 700 / 800 мс (`data-ag-dur`), кривая движка для `draw` — `power2.inOut`. Задержку `draw` не читает (поэтому разнесены длительностью, не delay). Медиазапросы: ≥ 900 px — канаты есть, скобка `::before` скрыта; ≤ 899 px — канатов нет, скобка остаётся.
- **Разметка:** `<svg class="ag-hh__ropes" viewBox="0 0 720 84" preserveAspectRatio="xMinYMid meet" aria-hidden="true" focusable="false">` внутри `.ag-hh__frame`; три `<path>` фиксированной длины `M0 yH720`; лишнее обрезает `overflow:hidden` секции `.ag-hh`.
- **Код (HOME-01_v9.2.0.html):**
```html
<!-- F01 · канаты ринга: выходят из кадра к краю экрана. Длина пути постоянна (ст. 81),
     лишнее обрезает overflow секции. Без JS и при reduce — видны целиком. -->
<svg class="ag-hh__ropes" viewBox="0 0 720 84" preserveAspectRatio="xMinYMid meet" aria-hidden="true" focusable="false"><path class="ag-hh__rope ag-hh__rope--hot" d="M0 6H720" data-ag-anim="draw" data-ag-dur="600" data-ag-start="top bottom"/><path class="ag-hh__rope" d="M0 42H720" data-ag-anim="draw" data-ag-dur="700" data-ag-start="top bottom"/><path class="ag-hh__rope" d="M0 78H720" data-ag-anim="draw" data-ag-dur="800" data-ag-start="top bottom"/></svg>
```
```css
/* F01 · канаты: от 900 px заменяют скобку «угол канатов» */
#ag-home-01 .ag-hh__ropes{position:absolute;z-index:4;left:calc(100% - 22px);top:52%;width:720px;height:84px;overflow:visible;pointer-events:none;}
#ag-home-01 .ag-hh__rope{fill:none;stroke:rgba(244,244,245,.5);stroke-width:2;stroke-linecap:round;}
#ag-home-01 .ag-hh__rope--hot{stroke:var(--accent);stroke-width:2.5;}
@media (min-width:900px){
  #ag-home-01 .ag-hh__frame::before{display:none;}
}
@media (max-width:899px){
  #ag-home-01 .ag-hh__ropes{display:none;}
}
@media (forced-colors:active){
  #ag-home-01 .ag-hh__rope,#ag-home-01 .ag-hh__rope--hot{stroke:CanvasText;}
}
@media print{
  #ag-home-01 .ag-hh__ropes{display:none;}
}
```
Обработчик `draw` движка (тот же во всех блоках):
```js
draw: function (el) {
  var isPath = el.tagName.toLowerCase() === "path" || el.tagName.toLowerCase() === "line";
  gsap.set(el, { opacity: 1 });
  if (isPath && el.getTotalLength) {
    var len = el.getTotalLength();
    gsap.fromTo(el, { strokeDasharray: len, strokeDashoffset: len },
      { strokeDashoffset: 0, duration: num(el, "data-ag-dur", 1200) / 1000,
        ease: "power2.inOut", scrollTrigger: trig(el) });
  } else {
    gsap.fromTo(el, { scaleX: 0, transformOrigin: "left center" },
      { scaleX: 1, duration: num(el, "data-ag-dur", 900) / 1000, scrollTrigger: trig(el) });
  }
  done(el);
},
```
- **Режимы:** reduce / без JS / без cdnjs — движок не стартует (`standDown`), канаты видны целиком; forced-colors — `CanvasText`; печать — скрыты; телефон (< 900) — скобка вместо канатов («канатам нет поля»).
- **Грабли/решения (REVIEW_v1 Б1, v2 §8):** `draw` не читает `data-ag-delay` → ступенька длительностями 600/700/800; SVG — фиксированной длины и `meet`, чтобы длина пути не зависела от ширины (иначе скорость прорисовки «плавает»); скобка + канаты = дубль мотива → канаты заменяют скобку от 900 px; врезка-кадр остаётся `scale-in` (draw в лимит типов появления не входит). Отвергнут F05 «наклон» — карточка F05 запрещает блик за курсором, а свет за курсором уже есть.

### 6.2 «Свет над рингом» — свет за курсором (HOME-01, П12)
- **Файл:** тот же `blocks/home/HOME-01_v9.2.0.html` (появился в v9.1.0, П12 — «да» владельца 30.09).
- **Идея:** тёплое пятно лампы на кадре ринга идёт за мышью; по краям кадра — виньетка; на фоне секции — зерно плёнки (PNG 64×64, opacity .05). **Польза:** «живой» первый экран без анимации контента и без трогания LCP-кадра (слой поверх, `::after`).
- **Механика:** только мышь: `(hover: hover) and (pointer: fine)` и не reduce; `pointermove` (passive) → одна запись двух CSS-переменных за кадр через `requestAnimationFrame`; плавность — CSS `transition` зарегистрированных `@property` 0,55 с `cubic-bezier(.22,.61,.36,1)`. Координаты зажаты в −15…115 %. `pointerleave` — переменные снимаются, свет возвращается в исходную точку (46 % / 30 %). Не цикл: rAF только по событию.
- **Разметка:** ничего нового — свет это `.ag-hh__shot::after`; метка монтирования `data-ag-light` на корне.
- **Код (HOME-01_v9.2.0.html):**
```css
@property --h01lx{syntax:"<percentage>";inherits:true;initial-value:46%;}
@property --h01ly{syntax:"<percentage>";inherits:true;initial-value:30%;}
#ag-home-01 .ag-hh__shot::after{
  content:"";position:absolute;z-index:2;inset:0;pointer-events:none;
  background:
    radial-gradient(ellipse 58% 42% at var(--h01lx) var(--h01ly),rgba(255,214,120,.28) 0%,rgba(255,196,0,.10) 42%,transparent 72%),
    radial-gradient(ellipse 120% 95% at 50% 36%,transparent 52%,rgba(6,6,7,.55) 100%);
  transition:--h01lx .55s cubic-bezier(.22,.61,.36,1),--h01ly .55s cubic-bezier(.22,.61,.36,1);
}
```
```js
/* «Свет над рингом»: свет идёт за курсором (П12). Только мышь, без reduce. Не цикл:
   кадр считается по событию pointermove, одна запись переменных за кадр. */
(function () {
  "use strict";
  var W = window, D = document;
  var root = D.currentScript && D.currentScript.closest(".ag-scope");
  if (!root || root.hasAttribute("data-ag-light")) return;
  root.setAttribute("data-ag-light", "");
  var mq = function (q) { return !!(W.matchMedia && W.matchMedia(q).matches); };
  if (!mq("(hover: hover) and (pointer: fine)") || mq("(prefers-reduced-motion: reduce)")) return;
  var sec = root.querySelector(".ag-hh"), shot = root.querySelector(".ag-hh__shot");
  if (!sec || !shot) return;
  var x = 0, y = 0, frame = 0;
  function apply() {
    frame = 0;
    var r = shot.getBoundingClientRect();
    if (!r.width || !r.height) return;
    var px = Math.max(-15, Math.min(115, (x - r.left) / r.width * 100));
    var py = Math.max(-15, Math.min(115, (y - r.top) / r.height * 100));
    shot.style.setProperty("--h01lx", px.toFixed(1) + "%");
    shot.style.setProperty("--h01ly", py.toFixed(1) + "%");
  }
  sec.addEventListener("pointermove", function (e) {
    if (e.pointerType !== "mouse") return;
    x = e.clientX; y = e.clientY;
    if (!frame) frame = W.requestAnimationFrame(apply);
  }, { passive: true });
  sec.addEventListener("pointerleave", function () {
    shot.style.removeProperty("--h01lx"); shot.style.removeProperty("--h01ly");
  });
})();
```
- **Режимы:** телефон/касание, без JS, reduce — свет неподвижен над канатами (initial-value @property); reduce дополнительно глушит все transition блока (`transition-duration:.01ms !important`); печать — медиа-колонка скрыта целиком. Кадр `.ag-hh__img` имеет `parallax 0.06` от движка — поэтому свет на `::after` фигуры, а не на самой картинке (transform картинки принадлежит движку).

### 6.3 Что ещё на главной (кратко)
- **HOME-11 `blocks/home/HOME-11_v1.2.0.html` — контурное APOLLO + заливка по прокрутке (П12).** Буквы — SVG-пути Oswald 700, обводка рисуется движком (`draw`, 2400 мс, `data-ag-start="top 92%"`); заливка — второй `<svg class="ag-ct__wfill">` с `<use>` тех же путей и CSS scroll-driven анимацией. Всё `aria-hidden`.
```css
#ag-home-11 .ag-ct__wfill{position:absolute;left:0;right:0;bottom:0;display:block;margin:0 auto;width:min(100%,3.1 * clamp(96px,27vw,420px));height:auto;overflow:visible;fill:rgba(255,196,0,.11);clip-path:inset(100% 0 0 0);}
@supports (animation-timeline:view()){
  @media (prefers-reduced-motion:no-preference){
    #ag-home-11 .ag-ct__wfill{animation:ag-home-11-fill linear both;animation-timeline:view();animation-range:entry;}
  }
}
@keyframes ag-home-11-fill{from{clip-path:inset(100% 0 0 0);}to{clip-path:inset(0 0 0 0);}}
```
  В v1.2.0 снят `data-ag-magnetic` с главной кнопки (G3: F23 требует неподвижную область, «CTA не убегает от курсора»); проверка F: «кнопка не смещается при движении мыши».
- **HOME-04 `blocks/home/HOME-04_v10.2.0.html` — F10 подложка вкладок «Единоборства / Для формы».** Вкладки только на ≤ 767.98 px и только с JS (`.ag-js`, `list.hidden`); подложка — `::before` у tablist, сдвиг чистым CSS по `data-ag-ui-tab` (вкладки равной ширины `flex:1 1 0` → сдвиг = ширина + зазор, без `:has` и ResizeObserver), 360 мс; после смены панели `ScrollTrigger.refresh()` через 60 мс.
```css
#ag-home-04 .ag-dr__tabs{position:relative;isolation:isolate;}
#ag-home-04 .ag-dr__tabs::before{
  content:"";position:absolute;z-index:-1;top:4px;bottom:4px;left:4px;width:calc(50% - 6px);
  border-radius:999px;background:var(--accent);
  transition:transform 360ms cubic-bezier(.22,.61,.36,1);
}
#ag-home-04 .ag-dr__tabs[data-ag-ui-tab="1"]::before{transform:translateX(calc(100% + 4px));}
#ag-home-04 .ag-dr__tabs[data-ag-ui-tab] .ag-dr__tab[aria-selected="true"]{background:transparent;}
@media (prefers-reduced-motion:reduce){ #ag-home-04 .ag-dr__tabs::before,#ag-home-04 .ag-dr__tab{transition:none;} }
@media (forced-colors:active){ #ag-home-04 .ag-dr__tabs::before{background:Highlight;} }
```
  Клавиатура: стрелки/Home/End, roving `tabIndex`; панели `role="tabpanel"` и `hidden` ставятся только в узком режиме (`matchMedia` + `change`), шире 768 и без JS видны обе. Смена обложки по наведению/фокусу строки — opacity 220 мс, кадры подгружаются из `data-ag-src` при первом `pointerenter` панели.
- **HOME-03 — F20 «Построить маршрут».** Ссылка на Яндекс Карты по адресу, сосед заголовка (не внутри растянутой ссылки карточки), `position:relative; z-index:3; min-height:44px`, `target=_blank rel=noopener`, `data-ag-track="route_click"`, скрытый хвост `<span class="ag-vh"> до зала на …, откроется в новой вкладке</span>`; на печати скрыта. Подпись «Маршрут» отклонена (существительное) → «Построить маршрут».
- **HOME-10 — F22 уже был;** в v3.2.0 — `ScrollTrigger.refresh()` через 380 мс после `toggle` details.
- **Все блоки главной — G1 F23 «нажатие»** (см. общие паттерны), фокус 3 px, отступы секций на ≤ 639 px 44/44 (высота 390 px: 15 227 → 14 535, −4,5 %).
- **Отвергнуто на главной (v2 §2):** F14 номер шага (Р1 без нумерации), F16/F17 калькулятор (таблица отвечает целиком), F12 второй кадр (нет медиа), F05 наклон (конфликт со светом), F26 фильтр хроники (один турнир), сетка 2×2 залов в HOME-07 («Молодогвардейская, 56» не влезает на 390), колода HOME-02 → список (вопрос владельцу, по умолчанию «нет»).
- **Проверки (RESULTS):** L 28/28, T 12/12, M (без JS, reduce, cdnjs отказ/висит — скрытого текста 0; все `data-ag-anim` 12 блоков получили `data-ag-done`), F 15/15, A axe 5/5; без JS axe нашёл прокручиваемую ленту HOME-09 без фокуса — исправлено в v2.2.0. not_tested: реальное касание iOS (`:active`), Safari/Firefox.

---

## 7. `/schedule`

### 7.1 F10 «Кромка закладок» (SCHEDULE-02)
- **Файл:** `blocks/schedule/SCHEDULE-02_v1.1.0.html` (rec4185838801, v1.0.0 → v1.1.0). Ведущий приём страницы.
- **Идея:** жёлтая кромка выбранного зала одна на весь ряд и переезжает к новой закладке. **Польза:** выбор зала читается как состояние и связь «было → стало» видна; страница — сервис «зал → направление → вечера → заявка».
- **Механика:** запуск — клик или стрелки/Home/End по закладкам. Переезд `transform` + `width` 0,34 с `cubic-bezier(.22,.61,.36,1)`. Координаты меряются `offsetLeft/offsetTop/offsetWidth` закладки; ширина = ширина закладки − 2×`--kin` (18 px; на ≤ 767.98 px — 12 px). На телефоне сетка 2×2: смена ряда (`|Δrow| > 2 px`) — без проезда (`is-jump`) + проявление псевдоэлемента WAAPI 180 мс `ease-out` (`pseudoElement:"::before"`). Первая установка, ResizeObserver, `fonts.ready`, загрузка с `?club=` / `#ag-hall-…` — без перехода (кромка сразу на месте). Панель зала при смене — WAAPI opacity 0.001→1, 250 мс.
- **Разметка:** `<div class="ag-sf__tabs" role="tablist" aria-label="Зал" hidden data-ag-anim="rise" data-ag-distance="12">` с четырьмя `button role="tab"` (`aria-controls`, `aria-selected`, roving `tabindex`, `data-club`). Без JS tablist скрыт, панели столбцом. Кромка — `::before` tablist (узла нет), включается классом `is-ind`.
- **Код CSS (SCHEDULE-02_v1.1.0.html):**
```css
/* F10 · кромка выбранной закладки: одна на ряд, над закладками */
#ag-schedule-02 .ag-sf__tabs{position:relative;--kin:18px;}
@media (max-width:767.98px){#ag-schedule-02 .ag-sf__tabs{--kin:12px;}}
@media not (forced-colors:active){
  #ag-schedule-02 .ag-sf__tabs.is-ind::before{
    content:"";position:absolute;z-index:2;left:0;top:0;width:var(--iw,0px);height:4px;border-radius:0 0 4px 4px;background:var(--accent);pointer-events:none;
    transform:translate(var(--ix,0px),var(--iy,0px));
    transition:transform .34s cubic-bezier(.22,.61,.36,1),width .34s cubic-bezier(.22,.61,.36,1);
  }
  #ag-schedule-02 .ag-sf__tabs.is-jump::before{transition:none;}
  #ag-schedule-02 .ag-sf__tabs.is-ind .ag-sf__tab[aria-selected="true"]::after{background:transparent;}
}
```
- **Код JS:**
```js
var ind = { on: false, row: null, cur: 0 };
function placeInd(i, jump) {
  var t = tabs[i];
  ind.cur = i;
  if (!t || !t.offsetWidth) return;
  var kin = parseFloat(W.getComputedStyle(list).getPropertyValue("--kin")) || 18;
  var row = t.offsetTop, change = ind.row !== null && Math.abs(ind.row - row) > 2;
  if (!ind.on || jump || change) list.classList.add("is-jump");
  list.style.setProperty("--ix", (t.offsetLeft + kin) + "px");
  list.style.setProperty("--iy", row + "px");
  list.style.setProperty("--iw", Math.max(0, t.offsetWidth - 2 * kin) + "px");
  if (!ind.on) { list.classList.add("is-ind"); ind.on = true; }
  else if (change && list.animate && !reduceNow()) {
    try { list.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 180, easing: "ease-out", pseudoElement: "::before" }); } catch (e) {}
  }
  ind.row = row; ind.cur = i;
  if (list.classList.contains("is-jump")) W.requestAnimationFrame(function () { W.requestAnimationFrame(function () { list.classList.remove("is-jump"); }); });
}
function reduceNow() { return !!(W.matchMedia && W.matchMedia("(prefers-reduced-motion: reduce)").matches); }
/* ... */
if ("ResizeObserver" in W) new W.ResizeObserver(function () { placeInd(ind.cur, true); }).observe(list);
if (D.fonts && D.fonts.ready) D.fonts.ready.then(function () { placeInd(ind.cur, true); });
```
- **Режимы:** reduce — transition блока гасятся общим правилом, проявление ряда не играет; forced-colors — кромки-псевдоэлемента нет (`@media not (forced-colors:active)`), работает старая кромка `::after` каждой закладки; без JS — закладок нет, панели столбцом; телефон — 2×2 с переносом между рядами.
- **Грабли (v2 §7):** Б2 — tablist был `stagger` движка: закладки въезжали по одной, а кромка висела в воздухе без них → у tablist `stagger` заменён на `rise` (ряд появляется целиком; типов появления меньше). Кромка должна лежать НАД белой закладкой → `::before` у tablist с `z-index:2`, `pointer-events:none`, у выбранной закладки при `is-ind` прячется собственная кромка `::after`. З1 — сетка 2×2 на телефоне противоречит «закладки не переносятся» дополнения → записано отступлением по Р2. Проверки: клик, стрелки, 2×2, загрузка с `?club=` и `#ag-hall-`, ресайз через 767/768.

### 7.2 «Билет-табло» (SCHEDULE-02)
- **Файл:** тот же. Своя фишка страницы (язык «табло» сайта).
- **Идея:** в билете «Ваша заявка» новое значение (зал, направление, вечера) перелистывается, как на табло вокзала. **Польза:** заявка «собирается на глазах» — видна связь выбора и будущего действия (кнопка «Спросить расписание» ведёт на `/request?club=&direction=&days=`).
- **Механика:** запуск — клик по закладке/чипу/дню. WAAPI `rotateX(-90deg)→0` + opacity 0.2→1 на `dd`, 260 мс, `cubic-bezier(.22,.61,.36,1)`, `fill:"backwards"`; ось `transform-origin:50% 0`, `perspective:600px` на `dl`, `backface-visibility:hidden`. Параллельно класс `is-new` (жёлтый цвет) на 700 мс. Чип другого зала: «Зал» сразу, «Направление» +60 мс. Новая смена `cancel()`-ит прежнюю (10 быстрых нажатий → итог верный, через 1 с анимаций 0). Строка «Вечера», только что показанная из `hidden`, не перелистывается (`__agFresh`). reduce проверяется при каждом запуске (`reduceNow()`), т. е. и на лету.
- **Разметка:** строки билета заранее в HTML и `aria-hidden="true"` (дубль для глаз; доступный путь — сами кнопки с `aria-pressed`):
```html
<dl class="ag-sf__tk-rows" aria-hidden="true">
  <div><dt>Зал</dt><dd class="is-empty" data-ag-t="club">Подскажет администратор</dd></div>
  <div><dt>Направление</dt><dd class="is-empty" data-ag-t="direction">Поможем выбрать</dd></div>
  <div data-ag-t-row="days" hidden><dt>Вечера</dt><dd data-ag-t="days">Пн</dd></div>
</dl>
```
- **Код (SCHEDULE-02_v1.1.0.html):**
```css
#ag-schedule-02 .ag-sf__tk-rows dd.is-new{color:var(--accent);}
/* «Билет-табло»: строки перелистываются от верхней кромки */
#ag-schedule-02 .ag-sf__tk-rows{perspective:600px;}
#ag-schedule-02 .ag-sf__tk-rows dd{transform-origin:50% 0;backface-visibility:hidden;}
```
```js
/* текст меняется через nodeValue — без мутаций childList (стандарт 34) */
function setText(el, t) {
  if (!el) return;
  if (el.firstChild && el.firstChild.nodeType === 3) { if (el.firstChild.nodeValue !== t) el.firstChild.nodeValue = t; }
  else el.textContent = t;
}
/* v1.1.0 · «Билет-табло»: новое значение в билете перелистывается, как на табло (rotateX, 260 мс);
   текст уже поставлен через nodeValue — клонов и мутаций childList нет. Новая смена отменяет прежнюю;
   строка, только что показанная из hidden, не перелистывается; reduce — при каждом запуске. */
function flash(el, delay) {
  if (!el || reduceNow()) return;
  el.classList.add("is-new");
  W.setTimeout(function () { el.classList.remove("is-new"); }, 700);
  if (!el.animate || el.__agFresh) return;
  if (el.__agFlip) { try { el.__agFlip.cancel(); } catch (e) {} }
  el.__agFlip = el.animate([{ transform: "rotateX(-90deg)", opacity: 0.2 }, { transform: "rotateX(0deg)", opacity: 1 }],
    { duration: 260, delay: delay || 0, easing: "cubic-bezier(.22,.61,.36,1)", fill: "backwards" });
}
/* в render(): */
if (state.days.length) {
  setText(tDays, state.days.map(function (d) { return DAY_SHORT[d]; }).join(", "));
  tDays.__agFresh = tDaysRow.hidden;
  tDaysRow.hidden = false;
} else {
  tDaysRow.hidden = true;
}
if (changed === "club") flash(tClub);
if (changed === "direction") flash(tDir);
if (changed === "days") flash(tDays);
tDays.__agFresh = false;
```
  Выбор пишется в адрес `history.replaceState` (только по действию, чужие `utm_*`/hash не трогаются) и рассылается событием `document → "ag:schedule"` `{club, direction, days}` — для соседних блоков (SCHEDULE-03 подсвечивает зал, SCHEDULE-04 — лампа).
- **Режимы:** reduce — без перелистывания и без жёлтой вспышки (в т. ч. при смене настройки на лету); без JS — `.ag-sf__tk-main hidden`, в билете только строка и кнопки; телефон — билет ниже панели, перелистывание видно, когда билет на экране (честно записано в §7 З2); WAAPI-анимация на `dd`, а движок анимирует обёртку `.ag-sf__ticket` (`rise`) — узлы разные.
- **Грабли (v2 §7 З2):** без клонов (не делать «верхнюю и нижнюю половину» отдельными узлами) — текст сначала ставится `nodeValue`, потом один rotateX; `cancel()` прежней; появление строки из `hidden` не листать. Отвергнуто: недельная сетка с занятиями (время не подтверждено — вымышленные слоты запрещены), «Сейчас открыто» (часы не подтверждены), заливка «ВЕЧЕР» (третий повтор приёма), выбор в 02 сразу заполняет форму ниже (форма читает адрес только при загрузке, общий блок — вопрос владельцу).

### 7.3 «Лампа отвечает вечерам» (SCHEDULE-04)
- **Файл:** `blocks/schedule/SCHEDULE-04_v1.1.0.html` (rec4185851601).
- **Идея:** чем больше вечеров отмечено в 02, тем шире и теплее лампа над заголовком «Спросить расписание». **Польза:** фон «вечера» реагирует на выбор читателя и подводит к действию; связь блоков без новых обещаний.
- **Механика:** уровень `--lv = min(7, n)/7`, `n` — число дней из `?days=` адреса (белый список `mon…sun`, дубли отброшены). Пересчёт: при загрузке, по `ag:schedule`, а также на `pointerenter/focus/touchstart/mousedown/click` кнопки (тот же `build()`, что собирает `href`). Применяется, только когда блок на экране (IntersectionObserver, порог по умолчанию). Переход: `scale` (отдельное свойство) `1 → 1.1` за 0,6 с `cubic-bezier(.22,.61,.36,1)`; тёплый слой `::after` opacity 0→1 за 0,6 с, потолок цвета `rgba(255,150,40,.12)`.
- **Разметка:** `<span class="ag-sc__lamp" aria-hidden="true"></span>` первым в секции; лампа уже стоит с `transform:translateX(-50%)` для центровки — поэтому масштаб через свойство `scale`, а не `transform`.
- **Код (SCHEDULE-04_v1.1.0.html):**
```css
#ag-schedule-04 .ag-sc__lamp{position:absolute;z-index:-1;left:50%;top:-18%;width:min(980px,120vw);height:78%;transform:translateX(-50%);pointer-events:none;background:radial-gradient(closest-side,rgba(255,196,0,.34),rgba(255,196,0,.12) 45%,rgba(255,196,0,0) 75%);}
/* «Лампа отвечает вечерам»: шире и теплее с числом вечеров (--lv 0…1 ставит скрипт) */
#ag-schedule-04 .ag-sc__lamp{scale:calc(1 + .1 * var(--lv,0));transition:scale .6s cubic-bezier(.22,.61,.36,1);}
#ag-schedule-04 .ag-sc__lamp::after{
  content:"";position:absolute;inset:6% 14%;border-radius:50%;pointer-events:none;
  background:radial-gradient(closest-side,rgba(255,150,40,.12),rgba(255,150,40,.05) 50%,rgba(255,150,40,0) 75%);
  opacity:var(--lv,0);transition:opacity .6s ease;
}
```
```js
var lampLv = 0, lampSeen = false;
function lamp(n) {
  lampLv = Math.max(0, Math.min(7, n)) / 7;
  if (lampSeen) root.style.setProperty("--lv", lampLv.toFixed(3));
}
if ("IntersectionObserver" in W) {
  new IntersectionObserver(function (es) {
    lampSeen = es[es.length - 1].isIntersecting;
    if (lampSeen) root.style.setProperty("--lv", lampLv.toFixed(3));
  }).observe(root);
} else { lampSeen = true; }
function build() {
  var q = [];
  try {
    var p = new URLSearchParams(W.location.search);
    var c = String(p.get("club") || "").toLowerCase();
    var d = String(p.get("direction") || "").toLowerCase();
    var days = [];
    String(p.get("days") || "").toLowerCase().split(",").forEach(function (x) {
      x = x.replace(/^\s+|\s+$/g, "");
      if (DAYS.indexOf(x) > -1 && days.indexOf(x) < 0) days.push(x);
    });
    days.sort(function (a, z) { return DAYS.indexOf(a) - DAYS.indexOf(z); });
    if (CLUB[c]) q.push("club=" + c);
    if (DIR[d]) q.push("direction=" + d);
    if (days.length) q.push("days=" + days.join(","));
    lamp(days.length);
  } catch (e) { /* без URLSearchParams — просто /request */ }
  var href = "/request" + (q.length ? "?" + q.join("&") : "");
  if (go.getAttribute("href") !== href) go.setAttribute("href", href);
}
["pointerenter", "focus", "touchstart", "mousedown", "click"].forEach(function (ev) {
  go.addEventListener(ev, build, ev === "touchstart" ? { passive: true } : false);
});
D.addEventListener("ag:schedule", build);
build();
```
- **Режимы:** reduce — transition блока 0,01 мс (уровень встаёт сразу); forced-colors и печать — лампа `display:none`; без JS — лампа в исходном виде, кнопка на `/request`; без 02 на странице — уровень всё равно по адресу (закон 13). Телефон (≤ 639) — лампа есть, отступы 44/90.
- **Грабли (v2 §7 З3, RESULTS):** 02 не шлёт событие при загрузке с `?days=` → уровень считается в 04 по адресу, а не по событию; центровка `translateX(-50%)` → масштаб свойством `scale`, чтобы не перетирать transform; план — потолок тёплого слоя 0,22, в коде снижен до 0,12: «надзаголовок над лампой ≥ 4,5:1» (ручной замер при 7 вечерах: надзаголовок #7A5C00 — 4,55; текст — 7,89; заголовок — 14,48). Зерно бумаги F29 в 04 снято: над лампой оно роняет контраст надзаголовка ниже 4,5. Проверки: 7 вечеров по адресу, блок один с `?days=`.

### 7.4 Рядом на странице: «В зале включают свет» (SCHEDULE-01, было с v1.0.0)
Лента входит в экран «в сумерках» (`filter:brightness(.42) saturate(.45) contrast(1.05)`, лампа `scaleY(0)`), через 260 мс после пересечения 30 % (IO `threshold:0.3`, однократно) — `is-lit`: фильтр уходит за 1,5 с `cubic-bezier(.3,.6,.2,1)`, свет стекает вниз за 1,3 с с задержкой 0,35 с. По умолчанию (без JS, reduce, нет IO) — светло: сумерки ставит только JS.

---

## 8. `/boxing-samara`

### 8.1 F14 «Живые пиктограммы» шагов (DIR01-02)
- **Файл:** `blocks/boxing-samara/DIR01-02_v1.2.0.html` (rec3781880401, v1.1.0 → v1.2.0). Ведущая фишка страницы.
- **Идея:** пиктограмма текущего шага тренировки показывает действие: скакалка прокручивается, стопы шагают по очереди, перчатка бьёт прямой со штрихами удара, лапа принимает удар и отскакивает, пара сходится и расходится. **Польза:** блок «как проходит тренировка» превращается в историю часа — предметно про бокс, без нового текста и нумерации (Р1).
- **Механика:**
  - Текущий шаг — IntersectionObserver с `rootMargin:"-45% 0px -45% 0px"` (полоса в середине экрана), без scroll-слушателей; классы `is-now`/`is-past` на `li`, `data-cur` на сцене.
  - Играет, когда шаг продержался текущим **180 мс**; один шаг — не чаще раза в **1,6 с**; прежняя анимация `cancel()`; без циклов (максимум `iterations:2`); каждое действие ≤ 900 мс (420×2, 420+300, 560, 620, 380×2).
  - ≥ 1024 px — крупная пиктограмма прилипающей сцены (`position:sticky; top:112px`) + повтор при `pointerenter` сцены только для `(hover: hover) and (pointer: fine)`; < 1024 — то же действие в узле шага (26 px), сцена скрыта.
  - Кривые: `IN = cubic-bezier(.22,.61,.36,1)`, `SWG = cubic-bezier(.45,0,.55,1)`.
  - Фон: жёлтое свечение `.ag-tl__glow` (360×360, на ≤ 599 — 260×260) переезжает к узлу текущего шага — `transform` 0,6 с + `opacity` 0,5 с, без rAF.
- **Разметка:** все 5 сценовых и 5 узловых SVG встроены (без `<use>` и без `id`), подвижные части — `<g class="ag-pz" data-p="rope|l|r|glove|hit|pad|c">`; штрихи удара `.ag-pz--hit` по умолчанию `opacity:0`. Сцена `.ag-tl__stage aria-hidden="true"` (повтор текста справа), названия шагов в сцене — сложены в одну ячейку сетки и переключаются `visibility` по `data-cur` (без смены текста). `<span class="ag-tl__glow" aria-hidden="true">` заранее в `.ag-tl__body`. Список шагов `<ol class="ag-tl__steps" data-ag-anim="stagger">` — его `li` анимирует движок, поэтому скрипт анимирует только `<g>` внутри svg, а сам `.ag-tl__pic` (у него свой CSS-переход смены) не трогает.
```html
<svg class="ag-tl__pic" data-i="2" viewBox="0 0 48 48" focusable="false"><g class="ag-pz" data-p="glove"><path d="M14 30V17a9 9 0 0 1 9-9h5a9 9 0 0 1 9 9v7a8 8 0 0 1-8 8h-2" .../>...</g><g class="ag-pz ag-pz--hit" data-p="hit"><path d="M44 12l3-2.5M44.5 20H48M44 28l3 2.5" .../></g></svg>
```
- **Код CSS (DIR01-02_v1.2.0.html):**
```css
/* «Живые пиктограммы»: части пиктограмм — группы; ось каждой — по своей рамке */
#ag-dir01-02 .ag-pz{transform-box:fill-box;transform-origin:50% 50%;}
#ag-dir01-02 .ag-pz[data-p="rope"]{transform-origin:50% 0;}
#ag-dir01-02 .ag-pz--hit{opacity:0;}
/* свечение за линией шагов: едет к узлу текущего шага (координаты ставит скрипт) */
#ag-dir01-02 .ag-tl__body{position:relative;isolation:isolate;}
#ag-dir01-02 .ag-tl__glow{
  position:absolute;z-index:-1;left:0;top:0;width:360px;height:360px;margin:-180px 0 0 -180px;border-radius:50%;pointer-events:none;
  background:radial-gradient(closest-side,rgba(255,196,0,.13),rgba(255,196,0,.05) 55%,rgba(255,196,0,0));
  opacity:0;transform:translate(var(--gx,0px),var(--gy,0px));
  transition:transform .6s cubic-bezier(.22,.61,.36,1),opacity .5s ease;
}
#ag-dir01-02 .ag-tl.is-live .ag-tl__glow.is-on{opacity:1;}
@media (prefers-reduced-motion:reduce){ #ag-dir01-02 .ag-tl__glow{display:none;} }
@media (forced-colors:active){ #ag-dir01-02 .ag-tl__glow{display:none;} }
```
- **Код JS:**
```js
var wide = W.matchMedia("(min-width: 1024px)");
var mqR = W.matchMedia("(prefers-reduced-motion: reduce)");
var mqF = W.matchMedia("(forced-colors: active)");
var fine = W.matchMedia("(hover: hover) and (pointer: fine)");
var stagePics = art ? Array.prototype.slice.call(art.querySelectorAll(".ag-tl__pic")) : [];
var nodePics = steps.map(function (s) { return s.querySelector(".ag-tl__node svg"); });
var running = [], last = [0, 0, 0, 0, 0], timer = 0;
var canAnim = typeof D.documentElement.animate === "function";
var IN = "cubic-bezier(.22,.61,.36,1)", SWG = "cubic-bezier(.45,0,.55,1)";
function stop() { running.forEach(function (a) { try { a.cancel(); } catch (e) {} }); running = []; }
function go(el, frames, opts) { if (el) running.push(el.animate(frames, opts)); }
function part(svg, p) { return svg.querySelector('[data-p="' + p + '"]'); }
var FX = [
  function (s) { go(part(s, "rope"), [{ transform: "scaleY(1)" }, { transform: "scaleY(-.55)", offset: .5 }, { transform: "scaleY(1)" }], { duration: 420, iterations: 2, easing: SWG }); },
  function (s) {
    var k = [{ transform: "translateY(0)" }, { transform: "translateY(-6px)", offset: .45 }, { transform: "translateY(0)" }];
    go(part(s, "l"), k, { duration: 420, easing: IN });
    go(part(s, "r"), k, { duration: 420, delay: 300, easing: IN });
  },
  function (s) {
    go(part(s, "glove"), [{ transform: "translateX(0)" }, { transform: "translateX(5px)", offset: .3 }, { transform: "translateX(0)" }], { duration: 560, easing: IN });
    go(part(s, "hit"), [{ opacity: 0, transform: "translateX(-3px)" }, { opacity: 1, transform: "translateX(0)", offset: .35 }, { opacity: 0, transform: "translateX(2px)" }], { duration: 560, easing: "ease-out" });
  },
  function (s) {
    go(part(s, "pad"), [{ transform: "scale(1)" }, { transform: "scale(.86)", offset: .25 }, { transform: "scale(1.05)", offset: .55 }, { transform: "scale(1)" }], { duration: 620, easing: IN });
    go(part(s, "hit"), [{ opacity: 0 }, { opacity: 1, offset: .25 }, { opacity: 0 }], { duration: 620, easing: "ease-out" });
  },
  function (s) {
    go(part(s, "l"), [{ transform: "translateX(0)" }, { transform: "translateX(2.5px)", offset: .5 }, { transform: "translateX(0)" }], { duration: 380, iterations: 2, easing: SWG });
    go(part(s, "r"), [{ transform: "translateX(0)" }, { transform: "translateX(-2.5px)", offset: .5 }, { transform: "translateX(0)" }], { duration: 380, iterations: 2, easing: SWG });
    go(part(s, "c"), [{ transform: "scale(1)" }, { transform: "scale(1.5)", offset: .5 }, { transform: "scale(1)" }], { duration: 380, iterations: 2, easing: SWG });
  }
];
function play(i, force) {
  if (!canAnim || i < 0 || mqR.matches || mqF.matches) return;
  var now = Date.now();
  if (!force && now - last[i] < 1600) return;
  last[i] = now;
  stop();
  var svg = wide.matches ? stagePics[i] : nodePics[i];
  if (svg) FX[i](svg);
}
function schedule(i) {
  W.clearTimeout(timer);
  timer = W.setTimeout(function () { if (i === cur) play(i); }, 180);
}
function place(i) {
  if (!glow || !body || i < 0) return;
  /* координаты по раскладке (offset*), не по экрану: шаги могут ещё въезжать анимацией движка */
  var n = steps[i].querySelector(".ag-tl__node"), x = n.offsetWidth / 2, y = n.offsetHeight / 2, el = n;
  while (el && el !== body) { x += el.offsetLeft; y += el.offsetTop; el = el.offsetParent; }
  if (el !== body) return;
  glow.style.setProperty("--gx", Math.round(x) + "px");
  glow.style.setProperty("--gy", Math.round(y) + "px");
  glow.classList.add("is-on");
}
function onPref() { if (mqR.matches || mqF.matches) stop(); }
[mqR, mqF].forEach(function (q) { if (q.addEventListener) q.addEventListener("change", onPref); else if (q.addListener) q.addListener(onPref); });
if (art) art.addEventListener("pointerenter", function () { if (fine.matches && cur >= 0) play(cur); });
if (glow && "ResizeObserver" in W) new W.ResizeObserver(function () { place(cur); }).observe(body);
var io = new IntersectionObserver(function (entries) {
  entries.forEach(function (e) {
    if (e.isIntersecting) set(steps.indexOf(e.target));
  });
}, { rootMargin: "-45% 0px -45% 0px", threshold: 0 });
steps.forEach(function (s) { io.observe(s); });
```
- **Режимы:** reduce (на старте) — живой режим не включается, линия залита целиком, все шаги равны; reduce/forced-colors на лету — `change` → `cancel()` всех анимаций, `play()` проверяет `matches` при каждом запуске; forced — свечение скрыто, узлы `forced-color-adjust:none` + системные цвета; печать — сцена скрыта, одна колонка; без JS / без IO — как v1.1.0 (статично); телефон/планшет < 1024 — анимация в узле шага, наведения нет, нажатий на скрытую сцену нет.
- **Грабли (v2 §7):** З1 — в v1 на телефоне был только «толчок» узла (`scale 1→1.12→1`) — ревью: «это не пиктограмма» → узловые SVG тоже встроены и играют то же действие, толчок снят. З2 — движение от прокрутки ограничить: 180 мс задержка, 1,6 с на шаг, `cancel()`, наведение только для точной мыши. З3 — только `transform`/`opacity` групп `<g>` с `transform-box:fill-box`; без морфинга `d` и без SMIL; скакалка — `scaleY` дуги от линии ручек (`transform-origin:50% 0`); без `id` во встроенных svg (дубли id на странице). З4 — сцена прилипает, а F14 «без pin» → отступление по Р2 (прилипалка была с v1.0.0). З7 — «фон рассказывает процесс»: только свечение у узла; координаты свечения по `offset*`, не `getBoundingClientRect` — шаги могут ещё въезжать анимацией движка. Проверки: `document.getAnimations()` без `CSSTransition` = 0 через 2 с покоя и после быстрой прокрутки; пиктограммы ×5 (ПК) и ×2 (телефон). Отвергнуто: подсветка колонки 07 наведением (нечему принять фокус; F08 — по выбору), заливка «БОКС» от кнопки (нужен JS или запрещённый `:has()`, третий повтор заливки), канаты (подпись `/boxing` и главной), таймер раунда/частицы/гонг (ложная срочность / постоянный rAF / звук без спроса), номера ударов «1-2-3» (новый учебный текст, Р1).

### 8.2 F22 плавный FAQ (DIR01-08)
- **Файл:** `blocks/boxing-samara/DIR01-08_v1.2.0.html` (rec3785499001).
- **Идея:** ответ раскрывается плавной высотой, значок-стрелка в круге поворачивается, слева жёлтая черта `scaleY`. **Польза:** 12 ответов открываются аккуратно, без скачка страницы; «Раскрыть все» — для тех, кто читает всё; поиск по странице открывает ответы нативно (`<details>`).
- **Механика:** прогрессивно, только где есть `interpolate-size` и `::details-content` (Chromium 131+): `height 0 ↔ auto` 0,32 с `cubic-bezier(.22,.61,.36,1)` + `content-visibility .32s allow-discrete`. Иначе — мгновенно, как было. `ScrollTrigger.refresh()` в кадре rAF — по `toggle` и по `transitionend` высоты `::details-content` (позиции анимаций ниже пересчитываются, когда высота доехала). Телефон (≤ 599): строка вопроса 54 → 48 px.
- **Разметка:** `<details class="ag-fq__item"><summary class="ag-fq__q"><span class="ag-fq__qt">…</span><span class="ag-fq__ic" aria-hidden="true"></span></summary><div class="ag-fq__a">…</div></details>`; кнопка `<button class="ag-fq__all" data-ag-all aria-controls="ag-dir01-08-list" aria-expanded="false" hidden>` (показывается JS); подпись меняется `nodeValue`. Список `.ag-fq__list` — узел движка (`stagger`), анимация высоты — на псевдоэлементе детей, конфликта нет.
- **Код (DIR01-08_v1.2.0.html):**
```css
/* F22 · плавное раскрытие ответа (Chromium 131+); иначе — мгновенно, как было */
@supports (interpolate-size:allow-keywords) and selector(::details-content){
  #ag-dir01-08 .ag-fq__list{interpolate-size:allow-keywords;}
  #ag-dir01-08 .ag-fq__item::details-content{
    height:0;overflow:clip;
    transition:height .32s cubic-bezier(.22,.61,.36,1),content-visibility .32s allow-discrete;
  }
  #ag-dir01-08 .ag-fq__item[open]::details-content{height:auto;}
  @media (prefers-reduced-motion:reduce){
    #ag-dir01-08 .ag-fq__item::details-content{transition:none;}
  }
}
```
```js
var busy = false, queued = 0;
function refresh() {
  if (queued) return;
  queued = W.requestAnimationFrame(function () {
    queued = 0;
    var M = W.ApolloMotion;
    if (M && M.ready && M.ScrollTrigger) M.ScrollTrigger.refresh();
  });
}
function sync() {
  var all = items.every(function (d) { return d.open; });
  btn.setAttribute("aria-expanded", all ? "true" : "false");
  label.firstChild.nodeValue = all ? "Свернуть ответы" : "Раскрыть все ответы";
}
btn.addEventListener("click", function () {
  var open = btn.getAttribute("aria-expanded") !== "true";
  busy = true;
  items.forEach(function (d) { d.open = open; });
  busy = false;
  sync();
  refresh();
});
items.forEach(function (d) {
  d.addEventListener("toggle", function () { if (!busy) { sync(); refresh(); } });
});
/* v1.2.0: высота ответа меняется переходом — пересчитать позиции анимаций ниже по окончании */
root.addEventListener("transitionend", function (e) {
  if (e.propertyName === "height" && e.pseudoElement === "::details-content") refresh();
});
```
- **Режимы:** reduce — без перехода высоты, все transition блока 0,01 мс; forced-colors — значок/черта `CanvasText`, кнопки с рамкой; печать — «Раскрыть все» скрыта; без JS — обычные `<details>`, кнопки нет (`hidden`).
- **Грабли:** у DIR03-07 (кикбоксинг) `overflow:clip` обрезал кольцо фокуса ссылок в ответах → `overflow-clip-margin:8px` (DIR03 v2 §7 З23); FAQPage в HEAD = текст блока, текст не меняется.
- **Также на странице:** DIR01-03 — адрес на рамке карточки зала стал ссылкой «Построить маршрут» (видимый текст тот же, значок-булавка, доступное имя «Построить маршрут: <адрес> (откроется в новой вкладке)», цель касания ≥ 44 px псевдоэлементом — итог 54 px; подпись «Маршрут» отклонена как существительное, строка на телефоне переносилась).
- **Проверки (RESULTS):** F 25/25 (пиктограммы ×5 ПК и ×2 телефон, свечение у узла, 0 анимаций в покое, наведение, быстрая прокрутка, маршрут, FAQ Enter + «Раскрыть все», магнитов 0, F23, reduce, forced, reduce на лету); A — axe 0 нарушений, включая «все ответы открыты»; WebKit — not_tested.

---

## 9. `/muay-thai-samara` — «Боец показывает удар» (DIR02-02)
- **Файл:** `blocks/muay-thai-samara/DIR02-02_v1.1.0.html` (rec3972837301). Ведущая фишка страницы. Рядом там же: F10-подложка легенды; в DIR02-04 — F10-подложка вкладок залов; DIR02-07 — F22.
- **Идея:** схема «восемь ударных точек» (боец в стойке на графитовой плашке): при выборе пары легенды боец принимает позу — «Руки»: прямой к зрителю, перчатка крупнее; «Локти»: локоть поднят к лицу; «Колени»: колено вверх; «Ноги»: голень по дуге в сторону, не выше пояса; «Все восемь» и повторное нажатие — стойка. **Польза:** «бой восьми конечностей» становится видимым — читатель видит, чем именно бьют, а не только где точка; работает на телефоне касанием фигуры.
- **Механика:**
  - Запуск — клик по кнопке легенды или касание/клик по фигуре (только `click`). Поза — CSS-переход `transform` 300 мс `cubic-bezier(.22,.61,.36,1)` по атрибуту корня `data-ag-pose`.
  - Наведение мыши (`(hover: hover) and (pointer: fine)`, `pointerType==="mouse"`) — только предпросмотр подсветки (`data-ag-show`), поза и подложка не меняются, `aria-pressed` не трогается.
  - Подсветка (`data-ag-show`): сегменты пары жёлтые (`stroke` 0,25 с), точки пары `scale(1.22)` (0,25 с), чужие точки — тёмно-серые (цвет, не прозрачность); фраза абзаца получает жёлтый «маркер» `background-size 0→100% 42%` за 0,45 с; фраза дублируется в `aria-live="polite"` через `nodeValue`.
  - F10 подложка легенды: `::before` у `.ag-wp__legend`, `translate(--ix,--iy)` + `height` 300 мс, та же кривая; текст нажатой темнеет с задержкой 140 мс (`color .2s ease .14s`).
  - Полосы-цели по высоте фигуры (viewBox 240×360): перчатки 0–98, локти 98–196, колени 196–270, голени 270–350 → на 320 px 50/50/37/41 px (все ≥ 36).
- **Разметка (всё в HTML заранее):** суставы — вложенные группы: плечо (96,88) ⊃ сегмент локтя ⊃ локоть (69,138) ⊃ сегмент кулака; бедро (110,168) ⊃ сегмент колена ⊃ колено (84,244) ⊃ сегмент голени. Сегменты и точки — в двух слоях (порядок отрисовки как в v1.0.0), поэтому в каждом слое свой набор `.ag-wp__j--*` с одинаковыми классами — CSS поворачивает оба синхронно, точки едут с конечностями. Полосы `<g class="ag-wp__zones" data-ag-ui-zones hidden>` открывает JS. Схема `aria-hidden="true"`; доступный путь — легенда (`role="group"`, кнопки `aria-pressed`, `hidden` до JS).
```html
<g class="ag-wp__j ag-wp__j--hip"><path class="ag-wp__seg ag-wp__seg--knees" d="M110 168 84 244"/><g class="ag-wp__j ag-wp__j--knee"><path class="ag-wp__seg ag-wp__seg--shins" d="M84 244 86 318 70 324"/></g></g>
<g class="ag-wp__j ag-wp__j--sh"><path class="ag-wp__seg ag-wp__seg--elbows" d="M96 88 69 138"/><g class="ag-wp__j ag-wp__j--el"><path class="ag-wp__seg ag-wp__seg--fists" d="M69 138 80 72"/></g></g>
<!-- … слой точек: -->
<g class="ag-wp__j ag-wp__j--hip"><circle class="ag-wp__pt ag-wp__pt--knees" cx="84" cy="244" r="10"/><g class="ag-wp__j ag-wp__j--knee"><circle class="ag-wp__pt ag-wp__pt--shins" cx="85" cy="288" r="10"/></g></g>
<g class="ag-wp__j ag-wp__j--sh"><circle class="ag-wp__pt ag-wp__pt--elbows" cx="69" cy="138" r="10"/><g class="ag-wp__j ag-wp__j--el"><g class="ag-wp__j ag-wp__j--glove"><circle class="ag-wp__pt ag-wp__pt--fists" cx="82" cy="54" r="16"/></g></g></g>
<g class="ag-wp__zones" data-ag-ui-zones hidden>
  <rect data-ag-ui-zone="fists" x="20" y="0" width="200" height="98"/>
  <rect data-ag-ui-zone="elbows" x="20" y="98" width="200" height="98"/>
  <rect data-ag-ui-zone="knees" x="20" y="196" width="200" height="74"/>
  <rect data-ag-ui-zone="shins" x="20" y="270" width="200" height="80"/>
</g>
```
- **Код CSS (DIR02-02_v1.1.0.html):**
```css
/* «Боец показывает удар»: суставы — вложенные группы, поворот вокруг сустава (координаты viewBox 240×360) */
#ag-dir02-02 .ag-wp__j{transform-origin:0 0;transition:transform .3s cubic-bezier(.22,.61,.36,1);}
#ag-dir02-02[data-ag-pose="fists"] .ag-wp__j--sh{transform:translate(96px,88px) rotate(15deg) translate(-96px,-88px);}
#ag-dir02-02[data-ag-pose="fists"] .ag-wp__j--el{transform:translate(69px,138px) rotate(18deg) translate(-69px,-138px);}
#ag-dir02-02[data-ag-pose="elbows"] .ag-wp__j--sh{transform:translate(96px,88px) rotate(62deg) translate(-96px,-88px);}
#ag-dir02-02[data-ag-pose="elbows"] .ag-wp__j--el{transform:translate(69px,138px) rotate(10deg) translate(-69px,-138px);}
#ag-dir02-02[data-ag-pose="knees"] .ag-wp__j--hip{transform:translate(110px,168px) rotate(85deg) translate(-110px,-168px);}
#ag-dir02-02[data-ag-pose="knees"] .ag-wp__j--knee{transform:translate(84px,244px) rotate(-120deg) translate(-84px,-244px);}
#ag-dir02-02[data-ag-pose="shins"] .ag-wp__j--hip{transform:translate(110px,168px) rotate(36deg) translate(-110px,-168px);}
#ag-dir02-02[data-ag-pose="shins"] .ag-wp__j--knee{transform:translate(84px,244px) rotate(-30deg) translate(-84px,-244px);}
/* «Руки»: прямой на зрителя — перчатка у осевой на уровне подбородка и крупнее */
#ag-dir02-02[data-ag-pose="fists"] .ag-wp__j--glove{transform:translate(82px,54px) scale(1.15) translate(-82px,-54px);}
#ag-dir02-02 .ag-wp__zones{fill:transparent;cursor:pointer;}
#ag-dir02-02 .ag-wp__zones[hidden]{display:none;}
@media print{#ag-dir02-02 .ag-wp__j{transform:none !important;transition:none !important;}}
/* F10 · подложка нажатой кнопки легенды: над фоном кнопок, под подписью */
#ag-dir02-02 .ag-wp__legend{position:relative;isolation:isolate;}
@media not (forced-colors:active){
  #ag-dir02-02 .ag-wp__legend.is-ind::before{
    content:"";position:absolute;z-index:1;left:0;top:0;width:var(--iw,0px);height:var(--ih,0px);border-radius:14px;background:var(--accent);pointer-events:none;
    transform:translate(var(--ix,0px),var(--iy,0px));transition:transform .3s cubic-bezier(.22,.61,.36,1),height .3s cubic-bezier(.22,.61,.36,1);
  }
  #ag-dir02-02 .ag-wp__legend.is-jump::before{transition:none;}
  #ag-dir02-02 .ag-wp__legend.is-ind .ag-wp__key>span{position:relative;z-index:2;}
  #ag-dir02-02 .ag-wp__legend.is-ind .ag-wp__key[aria-pressed="true"]{background:transparent;border-color:transparent;transition:background-color .25s ease,border-color .25s ease,color .2s ease .14s;}
}
```
  Подсветка пары (v1.0.0, остаётся): `.ag-wp__pt{transform-box:fill-box;transform-origin:center;transition:fill .25s ease,transform .25s ease;}` и `[data-ag-show="fists"] .ag-wp__pt--fists{fill:var(--accent);transform:scale(1.22);}` — `scale` на кругах точек, поворот — на группах-предках: разные узлы, «один transform — одному поведению».
- **Код JS:**
```js
var fine = W.matchMedia ? W.matchMedia("(hover: hover) and (pointer: fine)") : null;
var state = "all", peek = "";
function paint() { root.setAttribute("data-ag-show", peek || state); }
var leg = { on: false, cur: -1 };
function placeLeg(jump) {
  var i = -1;
  keys.forEach(function (b, k) { if (b.getAttribute("aria-pressed") === "true") i = k; });
  var b = keys[i];
  if (!b || !b.offsetWidth) return;
  if (!leg.on || jump) legend.classList.add("is-jump");
  legend.style.setProperty("--iy", b.offsetTop + "px");
  legend.style.setProperty("--ix", b.offsetLeft + "px");
  legend.style.setProperty("--iw", b.offsetWidth + "px");
  legend.style.setProperty("--ih", b.offsetHeight + "px");
  if (!leg.on) { legend.classList.add("is-ind"); leg.on = true; }
  leg.cur = i;
  if (legend.classList.contains("is-jump")) W.requestAnimationFrame(function () { W.requestAnimationFrame(function () { legend.classList.remove("is-jump"); }); });
}
function choose(k) {
  state = k;
  keys.forEach(function (b) { b.setAttribute("aria-pressed", b.getAttribute("data-ag-key") === k ? "true" : "false"); });
  var hl = k === "all" ? null : root.querySelector('.ag-wp__hl[data-ag-pair="' + k + '"]');
  live.firstChild.nodeValue = hl ? hl.textContent : " ";
  root.setAttribute("data-ag-pose", k);
  paint();
  placeLeg(false);
}
keys.forEach(function (b) {
  var k = b.getAttribute("data-ag-key");
  b.addEventListener("click", function () {
    peek = "";
    choose(k === state && k !== "all" ? "all" : k);
  });
  b.addEventListener("pointerenter", function (e) {
    if (e.pointerType !== "mouse" || !fine || !fine.matches) return;
    peek = k; paint();
  });
  b.addEventListener("pointerleave", function () {
    if (!peek) return;
    peek = ""; paint();
  });
});
root.setAttribute("data-ag-js", "");
legend.hidden = false;
choose("all");
if ("ResizeObserver" in W) new W.ResizeObserver(function () { placeLeg(true); }).observe(legend);
if (D.fonts && D.fonts.ready) D.fonts.ready.then(function () { placeLeg(true); });
/* касание фигуры: полоса по высоте = кнопка легенды той же пары */
var zones = root.querySelector("[data-ag-ui-zones]");
if (zones) {
  zones.removeAttribute("hidden");
  zones.addEventListener("click", function (e) {
    var z = e.target && e.target.getAttribute && e.target.getAttribute("data-ag-ui-zone");
    var b = z && root.querySelector('.ag-wp__key[data-ag-key="' + z + '"]');
    if (b) b.click();
  });
}
```
  Касание фигуры делегируется `b.click()` → та же аналитика `technique_pair` (в отчёте — с `from:"figure"`), та же логика «повторное нажатие — стойка».
- **Режимы:** reduce — поза встаёт сразу (transition 0,01 мс), в т. ч. если режим включили на лету; forced-colors — поза работает, подложки нет, нажатая кнопка `outline:3px solid Highlight`, маркер фразы → подчёркивание 2 px; печать — стойка (`transform:none !important; transition:none !important`), легенда скрыта; без JS — легенды нет, полос нет, все восемь точек на стойке; сенсорный экран — наведения нет, поза по касанию полосы или кнопки; вертикальный свайп от схемы прокручивает страницу (только `click`, без `touchmove`/`preventDefault`); зерно F29 только ≥ 640 px.
- **Грабли (v2 §7, §9):**
  - Б1 (ревью): «точки не поедут, колено уйдёт под шорты» → вложенные группы по суставам, точки в своих группах; поворот вокруг сустава записан явно `translate(o) rotate(a) translate(−o)` при `transform-origin:0 0` (а не `transform-box`) — так точка поворота в координатах viewBox одинакова для обоих слоёв; шорты — половина ноги в её группе; порядок: тело → неподвижные конечности → подвижная нога → пояс → подвижная рука.
  - Б2: поза дёргалась от наведения → отдельный атрибут `data-ag-pose`, его ставит только `choose`.
  - §9.1: стартовые углы «Руки» (−75°/+150°) уводили перчатку за плашку на 390 (−31 px) и читались как замах → прямой к зрителю: плечо +15°, локоть +18°, перчатка ×1,15.
  - §9.2: «Колени»/«Ноги» по стартовым углам — голень у края и над корпусом → «Колени» бедро +85°, колено −120°; «Ноги» бедро +36°, колено −30° (на 320 запас слева 7 px).
  - §9.3: полоса «Колени» на 320 — 32 px (< 36) → границы 0/98/196/270/350.
  - §9.4: на печати переход позы успевал пройти, `transform ≠ none` → в print ещё `transition:none !important`.
  - Отвергнуто: «вспышка удара» у точки (контракт блока: без `@keyframes` и мерцания, бюджет движения); заливка «МУАЙ-ТАЙ» по прокрутке (декор без действия, П12); клинч на схеме (два бойца на 320 не читаются); F03 приближение кадра (первый экран — LCP).
  - Проверки: стойка = v1.0.0 попиксельно, рамка позы внутри плашки 320–1440, наведение не меняет позу, прокрутка со схемы, reduce на лету, forced, print, 959/960; F 23/23, axe 0 (с позой «Колени»).

---

## 10. `/kickboxing-samara` — «Разница на схеме» (DIR03-02)
- **Файл:** `blocks/kickboxing-samara/DIR03-02_v1.1.0.html` (rec3981112301). Ведущая фишка страницы (F08 + F10).
- **Идея:** таблица «кикбоксинг закреплён, сравнить с: Бокс / Тайский бокс»; строка «Что бьют» показывается на мини-схемах бойцов в шапке: «Бокс» — у кикбоксинга обведены голени сплошной линией, у бокса те же голени пунктиром (их у бокса нет); «Тайский» — у тайского обведены колени и локти, у кикбоксинга — пунктиром. **Польза:** разница дисциплин видна за секунду, нейтрально (обе стороны отмечены, цвет `--text`, без чисел — не читается как «больше = лучше»).
- **Механика:**
  - Запуск — клик по кнопке «Сравнить с» (`aria-pressed`, одна нажата всегда) → атрибут корня `data-ag-vs` (стандарт 69). `?vs=boxing|thai` выбирает при загрузке без перехода; мусор → «boxing»; адрес не переписывается.
  - Всё в блоке — одна длительность **220 мс** `cubic-bezier(.22,.61,.36,1)` (отступление от F10 320 мс записано): обводка точек (`stroke`, `stroke-width`), полоса колонки, подложка кнопки, въезд ячеек.
  - Отметки: «есть» — сплошная обводка 10 ед.; «нет» — пунктир 7 ед. `8 7` вокруг серой точки. Без колец и без `scale`.
  - ПК ≥ 820: подсветка выбранной колонки — одна полоса `::before` у `.ag-cmp__tw`, `translateX(0 ↔ 100%)`; на 820–959 другая геометрия колонок (`left:calc(19% + 81%/3)`).
  - F10: подложка нажатой кнопки — `::before` у `.ag-cmp__vs`, повторяет вид нажатой кнопки (тон + рамка), `translate` + `width`; смена ряда (`|Δrow| > h/2`) — без проезда.
  - Телефон 360–819 (с JS): над рядами шапка из существующего `thead` — схема кикбоксинга и схема выбранной (40×60) + имя; подписи первой строки скрыты визуально (остаются для чтения с экрана); при переключении выбранные ячейки и `th` въезжают WAAPI `opacity 0.001→1, translateY(4px)→none` 220 мс, прежние анимации `cancel()`; reduce проверяется в момент нажатия. ≤ 359 — как v1.0.0 (столбик, без шапки).
- **Разметка:** три схемы шапки встроены в `th` (viewBox 240×360, точки — `<circle class="ag-cmp__p ag-cmp__p--fists|elbows|knees|shins" style="fill:var(--p-…)">`), кнопки и легенда — `<use href="#ag-dir03-02-i-fig">` (один `<symbol>`, точки красят наследуемые custom properties). Таблица — `<table>` с явными `role` (семантика сохраняется, когда ряды становятся сеткой). Значки `aria-hidden`. Группа кнопок `hidden` до JS; ячейки бокса и тайского на телефоне в одной ячейке сетки (высота не прыгает), невыбранная `visibility:hidden`.
- **Код CSS (DIR03-02_v1.1.0.html):**
```css
/* «Разница на схеме»: обводка отличающихся точек (без колец и масштаба — точки стоят плотно) */
#ag-dir03-02 .ag-cmp__p{transition:stroke .22s cubic-bezier(.22,.61,.36,1),stroke-width .22s cubic-bezier(.22,.61,.36,1);}
#ag-dir03-02[data-ag-vs="boxing"] .ag-cmp__h--kick .ag-cmp__p--shins,
#ag-dir03-02[data-ag-vs="thai"] .ag-cmp__h--thai .ag-cmp__p--knees,
#ag-dir03-02[data-ag-vs="thai"] .ag-cmp__h--thai .ag-cmp__p--elbows{stroke:var(--text);stroke-width:10px;}
#ag-dir03-02[data-ag-vs="boxing"] .ag-cmp__h--boxing .ag-cmp__p--shins,
#ag-dir03-02[data-ag-vs="thai"] .ag-cmp__h--kick .ag-cmp__p--knees,
#ag-dir03-02[data-ag-vs="thai"] .ag-cmp__h--kick .ag-cmp__p--elbows{stroke:var(--text);stroke-width:7px;stroke-dasharray:8 7;}

/* ПК (≥ 820): подсветка выбранной колонки — одна полоса, переезжает (F08, 220 мс) */
@media (min-width:820px){
  #ag-dir03-02[data-ag-js] .ag-cmp__tw{position:relative;}
  #ag-dir03-02[data-ag-js] .ag-cmp__t{position:relative;z-index:1;}
  #ag-dir03-02[data-ag-js] .ag-cmp__tw::before{
    content:"";position:absolute;top:0;bottom:0;left:calc(17% + 83% / 3);width:calc(83% / 3);z-index:0;pointer-events:none;
    background:rgba(255,255,255,.05);border-radius:0;transition:transform .22s cubic-bezier(.22,.61,.36,1),border-radius .22s cubic-bezier(.22,.61,.36,1);
  }
  #ag-dir03-02[data-ag-vs="thai"] .ag-cmp__tw::before{transform:translateX(100%);border-radius:0 18px 18px 0;}
  #ag-dir03-02[data-ag-js][data-ag-vs] .ag-cmp__h--boxing,
  #ag-dir03-02[data-ag-js][data-ag-vs] .ag-cmp__c--boxing,
  #ag-dir03-02[data-ag-js][data-ag-vs] .ag-cmp__h--thai,
  #ag-dir03-02[data-ag-js][data-ag-vs] .ag-cmp__c--thai{background:transparent;}
}
/* Телефон 360–819 с JS: шапка из thead — схемы кикбоксинга и выбранной рядом, над рядами */
@media (min-width:360px) and (max-width:819px){
  #ag-dir03-02[data-ag-js] .ag-cmp__t thead{display:block;}
  #ag-dir03-02[data-ag-js] .ag-cmp__corner{display:none;}
  #ag-dir03-02[data-ag-js] .ag-cmp__h--kick{grid-area:kick;}
  #ag-dir03-02[data-ag-js] .ag-cmp__h--boxing,
  #ag-dir03-02[data-ag-js] .ag-cmp__h--thai{grid-area:other;}
  #ag-dir03-02[data-ag-vs="boxing"] .ag-cmp__h--thai,
  #ag-dir03-02[data-ag-vs="thai"] .ag-cmp__h--boxing{visibility:hidden;}
  #ag-dir03-02[data-ag-js] .ag-cmp__h .ag-cmp__ico{width:40px;height:60px;margin:0;}
  /* подписи дисциплин первой строки повторяют шапку — только для чтения с экрана */
  #ag-dir03-02[data-ag-js] .ag-cmp__t tbody tr:first-child .ag-cmp__who{position:absolute;width:1px;height:1px;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;}
}
@media print{
  #ag-dir03-02 .ag-cmp__p{transition:none !important;stroke:#0E0E10 !important;stroke-width:5px !important;stroke-dasharray:none !important;}
  #ag-dir03-02 .ag-cmp__tw::before,
  #ag-dir03-02 .ag-cmp__vs::before{display:none !important;}
  /* A4 попадает в телефонную сетку: печатаем все три ячейки ряда */
  #ag-dir03-02 .ag-cmp__c--boxing,
  #ag-dir03-02 .ag-cmp__c--thai,
  #ag-dir03-02 .ag-cmp__h{visibility:visible !important;}
}
```
- **Код JS:**
```js
var LIST = ["boxing", "thai"];
var still = W.matchMedia ? W.matchMedia("(prefers-reduced-motion: reduce)") : { matches: false };
var narrow = W.matchMedia ? W.matchMedia("(max-width: 819px)") : null;
var state = "boxing";
try {
  var q = new URLSearchParams(W.location.search).get("vs");
  if (LIST.indexOf(q) >= 0) state = q;
} catch (e) { /* старый браузер: по умолчанию «Бокс» */ }
var pill = { on: false, row: null };
function placeVs(jump) {
  var b = null;
  keys.forEach(function (k) { if (k.getAttribute("aria-pressed") === "true") b = k; });
  if (!b || !b.offsetWidth) return;
  var row = b.offsetTop, wrapRow = pill.row !== null && Math.abs(row - pill.row) > b.offsetHeight / 2;
  if (!pill.on || jump || wrapRow) group.classList.add("is-jump");
  group.style.setProperty("--ix", b.offsetLeft + "px");
  group.style.setProperty("--iy", row + "px");
  group.style.setProperty("--iw", b.offsetWidth + "px");
  group.style.setProperty("--ih", b.offsetHeight + "px");
  if (!pill.on) { group.classList.add("is-ind"); pill.on = true; }
  pill.row = row;
  if (group.classList.contains("is-jump")) W.requestAnimationFrame(function () { W.requestAnimationFrame(function () { group.classList.remove("is-jump"); }); });
}
var running = [];
function choose(k, animate) {
  if (LIST.indexOf(k) < 0) return;
  var was = state;
  state = k;
  keys.forEach(function (b) { b.setAttribute("aria-pressed", b.getAttribute("data-ag-vs") === k ? "true" : "false"); });
  root.setAttribute("data-ag-vs", k);
  placeVs(!animate);
  if (animate && was !== k && !still.matches && narrow && narrow.matches) {
    running.forEach(function (a) { try { a.cancel(); } catch (e) {} });
    running = [];
    Array.prototype.forEach.call(root.querySelectorAll(".ag-cmp__c--" + k + ", .ag-cmp__h--" + k), function (c) {
      if (c.animate) running.push(c.animate([{ opacity: 0.001, transform: "translateY(4px)" }, { opacity: 1, transform: "none" }], { duration: 220, easing: "cubic-bezier(.22,.61,.36,1)" }));
    });
  }
}
keys.forEach(function (b) {
  b.addEventListener("click", function () { choose(b.getAttribute("data-ag-vs"), true); });
});
root.setAttribute("data-ag-js", "");
group.hidden = false;
choose(state, false);
if ("ResizeObserver" in W) new W.ResizeObserver(function () { placeVs(true); }).observe(group);
if (D.fonts && D.fonts.ready) D.fonts.ready.then(function () { placeVs(true); });
```
  Узлы движка здесь — `.ag-cmp__head` (rise) и `.ag-cmp__body` (stagger: его дети — группа кнопок и обёртка таблицы); WAAPI идёт на `td/th` глубже — разные узлы.
- **Режимы:** reduce — переходы гасятся, въезд ячеек не играет (проверка `still.matches` в момент нажатия); forced-colors — отметки `CanvasText` (проверено эмуляцией, снимок `shots/forced_02.png`), подложки нет; печать — вся таблица, все три колонки и подписи, отметки/полоса/подложка скрыты (дефект v1.0.0 «на A4 пропадала колонка» исправлен); без JS — полная таблица, три ячейки подряд, кнопок нет; телефон 360–819 — шапка со схемами; ≤ 359 — столбик.
- **Грабли (v2 §7, §9):**
  - Б1: в v1 — кольца вокруг точек с «посадкой» 1,5× — у колена и голени зазор 6 ед., кольца налезали, масштаб вне карты MOTION → обводка самой точки.
  - Б2: телефонная шапка не влезала в бюджет +40 px → компенсация плотнее рядами; §9.2 — на 600–819 уплотнение было только < 600, шапка давала +77 → ряды 8 px на всём < 820 → +37; итог честно в отчёте (390: 1 233 → 1 264, страница +31 px; ПК без изменений).
  - П3: шапку не вставлять из JS — собрать из существующего `thead` (`thead tr` сеткой «kick other» под `[data-ag-js]`).
  - З7: отметка как рейтинг → нейтральный цвет, обе стороны, без чисел; подпись легенды «обведено — отличие» — новый текст, вопрос владельцу.
  - З10: пять разных длительностей на одно нажатие → всё 220 мс.
  - З11/З17: подсветка строки при наведении и подъём узла станции 03 — сняты (бюджет движения, F08 запрещает «дрожание таблицы», станции не интерактивны — П12).
  - §9.1: на 320 px неразрывный «для&nbsp;взрослых» оставлял слово одно в строке (+43 px) → неразрывный только перед тире (+21).
  - Не взято: «линии скорости» в 01, «пробивка талона» в 06, заливка «КИКБОКСИНГ», зерно на 03 (вокруг узлов трассы видны «шайбы» цвета бумаги), связь 02 ↔ 05 (нарушит автономность, закон 13).
  - Проверки: «отмечено = разность горящих точек», 10 быстрых переключений, 820/959/960, `?vs=`, телефон 320/360/390/600, reduce на лету, печать, forced; F 32/32; axe 0.
- **Рядом на странице:** DIR03-03 (F14-трасса) — точки ленты на телефоне: текущая вытягивается в пилюлю `scaleX` псевдоэлемента внутри слота постоянной ширины (иначе ряд дёргается; `scale(1.3)` снят), `draw` линии 1 400 → 700 мс, шаг станций 80 → 50 мс (только атрибуты движка). DIR03-04 — F10-подложка карточек «Группа / Детская / Персонально»: фон выбранной прозрачный, цвета подписи меняются с задержкой 120 мс (иначе «тёмный текст на тёмном» во время проезда). DIR03-07 — F22 с `overflow-clip-margin:8px`.

---


---

## 11. «Что уже есть — что добрать» · /mma-samara

**Страница / блок / файл:** /mma-samara, DIR04-04 «С каким опытом приходят в ММА» (запись rec3992216701) — `blocks/mma-samara/DIR04-04_v1.1.0.html`. Отчёт: `passes/mma-samara/RESULTS.md`, `PROMPT_DIR04_DESIGN_MOTION_v2.md`, сборщик `build_dir04_dm.py`.

**Идея:** над текстом вкладки опыта стоит знак «линия пола» (тот же, что в таблице сравнения 07): точка над жёлтой линией — стойка, под ней — пол; залита — «уже есть», пустой кружок — «добрать». **Польза:** концепция страницы «две плоскости — стойка и борьба» становится видимой ровно в момент, когда человек выбирает, с чем он приходит; знак повторяет текст панели, а не украшает.
- «Из ударных единоборств» — стойка ●, пол ○; «Из борьбы» — стойка ○, пол ●; «Без опыта» — ○ ○; «Ребёнку» — знака нет (`visibility:hidden`, без утверждений про детей).

**Механика (числа):**
- Пуск — выбор вкладки (клик, ← → ↑ ↓, Home/End; роуминг tabindex; автоматическая активация). Скрипт ставит корню `data-ag-tab="0…3"`, всё остальное — CSS.
- Знак меняется переходом 380 мс `cubic-bezier(.22,.61,.36,1)` (`background-color` точки, `color` подписи) — синхронно с чертой вкладок (`transform .38s` того же изгиба). Своего transform у знака нет.
- Панель при смене — WAAPI 250 мс `ease-out` (`opacity .001→1`, `translateY(6px)→none`) — анимируется сама панель, а не узел движка (`data-ag-anim="rise"` стоит на обёртке `.ag-fl__panels`). При reduce WAAPI не вызывается.
- Маркер фразы «Скажите…» — `background-size 0→100% 42%`, 0,8 с, задержка 0,12 с.
- F10 на ПК: одна жёлтая черта 25 % ширины, `translateX(calc(var(--i)*100%))`, 380 мс. **Телефон (≤ 767):** сетка 2×2 (`grid-auto-rows:1fr`), одна рамка с жёлтой полосой едет по `--c/--r`: `translate(calc(var(--c)*(100% + 8px)), calc(var(--r)*(100% + 8px)))` — в том числе по диагонали; у кнопок своя рамка и `::after` сняты.
- Смена раскладки 767/768 (matchMedia `change`) — класс `is-jump` (`transition:none`) на два кадра rAF: черта встаёт без проезда.
- Высота: знак лежит в **той же ячейке grid**, что и панели (`grid-area:1/1`, сверху, `pointer-events:none`); у панелей 1–3 текст опущен на высоту знака (`margin-top:56px`, ≤ 599 — 54px); ячейку по высоте держит «Ребёнку» (самая длинная) → рост ≈ 0 (390 и 1440 — без изменений; 320/360 +13 px из-за «для взрослых»).
- Подгонка подписей вкладок (стандарт 61): canvas `measureText` по самому длинному слову, одна кегль на все, ×0,96, таймер 30 мс вместо rAF, пересчёт по `document.fonts.ready`, `loadingdone`, `ResizeObserver` (только при смене ширины).

**Разметка (заранее в HTML):** `role="tablist"` с `hidden` (до JS), 4 `button role="tab"` с `aria-controls`/`aria-selected`/`tabindex="-1"`, `<span class="ag-fl__bar" aria-hidden="true">` (черта); панели — `div role="group" aria-labelledby` с видимым `h3` (без JS — столбцом с заголовками); скрипт меняет роль на `tabpanel`, `aria-labelledby` → id вкладки, `tabindex="0"`, `h3` визуально скрывается. Знак — последний ребёнок `.ag-fl__panels`:

```html
        <div class="ag-fl__lv" aria-hidden="true">
          <span class="ag-fl__lvr ag-fl__lvr--up"><i class="ag-fl__pt"></i><span>Стойка</span></span>
          <span class="ag-fl__lvl"></span>
          <span class="ag-fl__lvr ag-fl__lvr--dn"><i class="ag-fl__pt"></i><span>Пол</span></span>
        </div>
```

**Ключевой код** (`blocks/mma-samara/DIR04-04_v1.1.0.html`), CSS:

```css
  /* «Что уже есть — что добрать»: знак «линия пола» в ячейке панелей, над текстом панелей 1–3 */
  #ag-dir04-04 .ag-fl__lv{display:none;}
  #ag-dir04-04 .ag-fl__panels.is-js>.ag-fl__lv{
    display:grid;grid-area:1 / 1;align-self:start;justify-self:start;z-index:1;row-gap:7px;width:max-content;pointer-events:none;
    margin:clamp(20px,2.6vw,34px) 0 0 clamp(20px,3vw,40px);
  }
  #ag-dir04-04 .ag-fl__lvr{display:flex;align-items:center;gap:10px;font-family:var(--f-display);font-size:13px;font-weight:600;line-height:1;letter-spacing:.14em;text-transform:uppercase;color:var(--muted);transition:color .38s cubic-bezier(.22,.61,.36,1);}
  #ag-dir04-04 .ag-fl__pt{display:block;width:14px;height:14px;border-radius:50%;border:2px solid var(--ink);background:transparent;transition:background-color .38s cubic-bezier(.22,.61,.36,1);}
  #ag-dir04-04 .ag-fl__lvl{display:block;width:112px;height:3px;margin-left:-6px;border-radius:2px;background:var(--accent);box-shadow:0 1px 0 rgba(9,9,10,.35);}
  #ag-dir04-04[data-ag-tab="0"] .ag-fl__lvr--up .ag-fl__pt,
  #ag-dir04-04[data-ag-tab="1"] .ag-fl__lvr--dn .ag-fl__pt{background:var(--ink);}
  #ag-dir04-04[data-ag-tab="0"] .ag-fl__lvr--up,
  #ag-dir04-04[data-ag-tab="1"] .ag-fl__lvr--dn{color:var(--ink);}
  #ag-dir04-04[data-ag-tab="3"] .ag-fl__lv{visibility:hidden;}
  #ag-dir04-04 .ag-fl__panels.is-js :is(#ag-dir04-04-p1,#ag-dir04-04-p2,#ag-dir04-04-p3) .ag-fl__text{margin-top:56px;}
  /* F10 на телефоне: одна рамка с жёлтой чертой едет по сетке 2×2 */
  @media (max-width:767px){
    #ag-dir04-04 .ag-fl__tabs{grid-auto-rows:1fr;}
    #ag-dir04-04 .ag-fl__bar{
      display:block;z-index:2;top:0;left:0;bottom:auto;width:calc(50% - 4px);height:calc((100% - 8px) / 2);
      border:1px solid var(--ink);border-radius:6px;background:none;box-shadow:none;
      transform:translate(calc(var(--c,0) * (100% + 8px)),calc(var(--r,0) * (100% + 8px)));
    }
    #ag-dir04-04 .ag-fl__bar::after{content:"";position:absolute;left:12px;right:12px;bottom:-1px;height:4px;background:var(--accent);box-shadow:inset 0 -1px 0 rgba(9,9,10,.25);}
    #ag-dir04-04[data-ag-tab="1"] .ag-fl__bar{--c:1;--r:0;}
    #ag-dir04-04[data-ag-tab="2"] .ag-fl__bar{--c:0;--r:1;}
    #ag-dir04-04[data-ag-tab="3"] .ag-fl__bar{--c:1;--r:1;}
  }
  #ag-dir04-04 .ag-fl__tabs.is-jump .ag-fl__bar{transition:none;}
  @media print{
    #ag-dir04-04 .ag-fl__lv{display:none !important;}
    #ag-dir04-04 .ag-fl__panels.is-js .ag-fl__panel .ag-fl__text{margin-top:10px !important;}
  }
```

JS (тот же файл):

```js
    function select(i, focus) {
      var was = current();
      tabs.forEach(function (t, k) {
        var on = k === i;
        t.setAttribute("aria-selected", on ? "true" : "false");
        t.setAttribute("tabindex", on ? "0" : "-1");
        panels[k].classList.toggle("is-on", on);
      });
      root.setAttribute("data-ag-tab", String(i));
      if (focus) tabs[i].focus();
      if (was !== i && !reduce && panels[i].animate) {
        panels[i].animate([{ opacity: 0.001, transform: "translateY(6px)" }, { opacity: 1, transform: "none" }], { duration: 250, easing: "ease-out" });
      }
    }
    /* v1.1.0: смена раскладки (ПК ↔ сетка 2×2) — черта встаёт без проезда */
    var mq = W.matchMedia ? W.matchMedia("(max-width: 767px)") : null;
    if (mq) {
      var jump = function () {
        list.classList.add("is-jump");
        W.requestAnimationFrame(function () { W.requestAnimationFrame(function () { list.classList.remove("is-jump"); }); });
      };
      if (mq.addEventListener) mq.addEventListener("change", jump); else if (mq.addListener) mq.addListener(jump);
    }
```

**Режимы:**
- reduce: общее правило блока `transition-duration:.01ms !important; transition-delay:0s` для `*`; WAAPI панели не вызывается (флаг `reduce` при монтировании).
- forced-colors: точки — контур `CanvasText`, залитая — `background:CanvasText`, линия — `CanvasText`; на телефоне рамка-черта `border-color:CanvasText`, полоса `::after` — `CanvasText`; выбранная вкладка `outline:2px solid CanvasText`; маркер «Скажите…» → `text-decoration:underline`; зерно скрыто. Проверено снимком.
- печать: ряд вкладок и знак скрыты, все панели видны (`grid-area:auto; visibility:visible`), текст с `margin-top:10px`.
- без JS: вкладок нет (`hidden`), панели столбцом с `h3`, знака нет (`display:none` без `.is-js`).
- сенсор/телефон: 2×2, та же логика; стрелки ↑ ↓ в 2×2 переключают на соседнюю вкладку (шаблон ARIA) — записано как отступление.

**Грабли и поправки (§7, §9, RESULTS):**
- Ревью З4–5: плашки отдельной строкой давали +40 px и пустую строку у «Ребёнку» → слой знака в той же ячейке grid, рост ≈ 0.
- П6: вместо придуманных плашек «Стойка/Пол» взят знак «линия пола» из блока 07 — один мотив на странице.
- З8: контраст жёлтого на бумаге 1,5:1 → точки чернилами, линия жёлтая с тёмной кромкой (`box-shadow:0 1px 0 rgba(9,9,10,.35)`).
- §9.1: пунктирный кружок 14 px на телефоне читался как «загрузка» → «добрать» = пустой кружок со сплошным контуром. (В шапке-комментарии файла осталось «обе пунктиром» — устаревшая формулировка; правда — в CSS.)
- П11/З12: черта телефона — CSS от `data-ag-tab`, не замеры JS; переход через 767/768 — `is-jump` без проезда.
- З7: подписи «Стойка»/«Пол» — новые видимые слова (слова страницы, `aria-hidden`, без чисел «0 из 2») → вынесены владельцу как исключение из заморозки текста.
- Отвергнуто: маркер «пробегает» по линии пола в 03 (декор, строка и так подсвечивается); конус света за курсором (П12, отвлекает от записи); «живая сетка клетки» (повтор /mma); заливка контура «ММА» (П12).
- Попутно в 08 (F22): при «Раскрыть все» ответы всё равно анимировались — `toggle` приходит асинхронно после клика, флаг `busy` уже снят → флаг снимается таймером 80 мс; проверка — анимаций 0.

---

## 12. «Пройти схватку» + вертикальный профиль + F10 · /grappling-samara

**Страница / блок / файл:** /grappling-samara, DIR05-02 «Как идёт схватка от стойки до партера» (rec3993639201) — `blocks/grappling-samara/DIR05-02_v1.1.0.html`; F10 — DIR05-04 «Зачем приходят на ковёр» — `DIR05-04_v1.1.0.html`. Отчёт: `passes/grappling-samara/RESULTS.md`, `PROMPT_DIR05_DESIGN_MOTION_v2.md`, `build_dir05_dm.py`, `checks_g.js`.

**Идея:** пять шагов занятия стоят на «профиле схватки» — две тоновые дорожки «в стойке / в партере», жёлтый путь идёт так, как идёт занятие (разминка внизу → захват наверху → перевод на спуске → контроль и болевой внизу → знак хлопка ладонью). На ПК наведение на шаг катит жёлтого «борца» по пути к узлу шага; на < 1024 профиль вертикальный, слева от шагов, текущий шаг — у середины экрана. **Польза:** «от стойки до партера» видно движением и положением узла, а на телефоне профиль идёт рядом с каждым шагом вместо полосы над списком (которая уезжала из экрана); блок стал короче.

**Механика (числа):**
- ПК: только `(min-width:1024px) and (hover:hover) and (pointer:fine)`, `mouseenter` на `li`. «Борец» — статичный `<circle r="10">`, двигается inline `transform:translate(…px,…px)` (в единицах viewBox). Кадры WAAPI: 25 точек `getPointAtLength` по пути, внутри — ease-in-out (квадратичный), `easing:"linear"` у самой анимации, длительность `380 + min(1, |Δs|/L)·320` → 380–700 мс по расстоянию. Позиции узлов на пути находятся перебором длины с шагом 2 (ближайшая точка к `cx/cy` узла). Перебивание — с текущей точки: `pos = a0 + (a1−a0)·ease(currentTime/dur)`, затем `cancel()`. Узел шага — `fill` жёлтый за 0,3 с; засечка шага `li::before` растёт 14 → 26 px.
- «Борца» нет, пока путь не прорисован (`stroke-dashoffset` пути < 1; при `data-ag-motion="off"` — сразу). draw пути укорочен 1800 → 800 мс, задержки хлопка сдвинуты на −800 (1100…1700 мс).
- < 1024: `IntersectionObserver` с `rootMargin:"-45% 0px -50% 0px"` (полоса у середины экрана); шаг становится текущим, если держится там 180 мс (`setTimeout`); только состояние (`is-done` для пройденных, `is-cur`), без проезда. Переходы цвета 380 мс `cubic-bezier(.22,.61,.36,1)`; текущий узел `scale(1.15)` + ореол 5 px.
- Геометрия вертикали: поле 44 px (две тоновые полосы по 22 px: партер `#141417` слева, стойка `#222226` справа); `--x` узла: down 12 px, edge 22 px, up 32 px; `--ny` (высота узла = высота заголовка) 26 px, ≤ 599 — 21 px; ≤ 359 поле текста 50 px. Колено между дорожками — маленький SVG 44×14 в начале `li`.
- F10 (DIR05-04): светлая подложка `::before` у tablist, 380 мс; колонки равные (ПК `width:calc((100% - 30px)/4)`, сдвиг `100% + 10px`), телефон 2×2 по `--c/--r`; старая вкладка светлеет сразу (`transition:color 0s`), новая темнеет с задержкой 180 мс; `is-jump` при первой установке и на 767↔768.

**Разметка:** профиль ПК — `div.ag-yp__chart--wide aria-hidden` с SVG `viewBox="0 0 1000 160" preserveAspectRatio="xMidYMid meet"` (постоянный viewBox → длина пути не меняется, draw считает её один раз), пять `circle.ag-yp__node`, `circle.ag-yp__runner cx=0 cy=0`; путь и хлопок — `data-ag-anim="draw"` (скрипт их только читает). Вертикаль — статичная разметка **внутри каждого `li`** (в `ol` только `li`):

```html
        <li class="ag-yp__step" data-ag-lane="up">
          <span class="ag-yp__v" aria-hidden="true"><svg class="ag-yp__vk" width="44" height="14" viewBox="0 0 44 14" focusable="false"><path d="M12 0C12 8 32 6 32 14"/></svg><i class="ag-yp__vl"></i><i class="ag-yp__vn"></i></span>
          <h3 class="ag-yp__name">Захват в стойке</h3>
```

Легенда `<p class="ag-yp__key" aria-hidden="true">` «в партере / в стойке» (слова снятой полосы). Шаги без `tabindex`, ролей и «руки».

**Ключевой код** (`blocks/grappling-samara/DIR05-02_v1.1.0.html`), CSS:

```css
  #ag-dir05-02 .ag-yp__runner{fill:var(--accent);stroke:var(--bg);stroke-width:3;opacity:0;transition:opacity .2s ease;pointer-events:none;}
  #ag-dir05-02 .ag-yp__runner.is-on{opacity:1;}
  #ag-dir05-02 .ag-yp__node.is-on{fill:var(--accent);}
  #ag-dir05-02 .ag-yp__step.is-hover::before{height:26px;background:var(--accent);}
  @media not ((hover:hover) and (pointer:fine)){#ag-dir05-02 .ag-yp__runner{display:none;}}
  @media (max-width:1023px){
    #ag-dir05-02 .ag-yp__steps::before{content:"";position:absolute;left:0;top:0;bottom:0;width:44px;border-radius:6px;pointer-events:none;
      background:linear-gradient(90deg,#141417 0,#141417 22px,#222226 22px,#222226 44px);}
    #ag-dir05-02 .ag-yp__step{padding:16px 0 18px 58px;--ny:26px;}
    #ag-dir05-02 .ag-yp__step[data-ag-lane="down"]{--x:12px;}
    #ag-dir05-02 .ag-yp__step[data-ag-lane="edge"]{--x:22px;}
    #ag-dir05-02 .ag-yp__step[data-ag-lane="up"]{--x:32px;}
    #ag-dir05-02 .ag-yp__v{display:block;position:absolute;left:0;top:-1px;bottom:0;width:44px;pointer-events:none;--c:var(--accent);}
    #ag-dir05-02 .ag-yp__vl{position:absolute;left:calc(var(--x) - 1.5px);top:14px;bottom:0;width:3px;border-radius:2px;background:var(--c);transition:background-color .38s cubic-bezier(.22,.61,.36,1);}
    #ag-dir05-02 .ag-yp__vn{position:absolute;left:calc(var(--x) - 7px);top:calc(var(--ny) - 7px);width:14px;height:14px;border-radius:50%;background:var(--bg);box-shadow:inset 0 0 0 3px var(--c);
      transition:background-color .38s cubic-bezier(.22,.61,.36,1),box-shadow .38s cubic-bezier(.22,.61,.36,1),transform .38s cubic-bezier(.22,.61,.36,1);}
    /* с JS: впереди — приглушённо-жёлтое, пройденное и текущее — жёлтое */
    #ag-dir05-02[data-ag-js] .ag-yp__v{--c:rgba(255,196,0,.32);}
    #ag-dir05-02[data-ag-js] .ag-yp__step.is-done .ag-yp__v{--c:var(--accent);}
    #ag-dir05-02[data-ag-js] .ag-yp__step.is-cur .ag-yp__vn{background:var(--accent);box-shadow:inset 0 0 0 3px var(--accent),0 0 0 5px rgba(255,196,0,.22);transform:scale(1.15);}
  }
```

JS (тот же файл):

```js
    var still = W.matchMedia ? W.matchMedia("(prefers-reduced-motion: reduce)") : { matches: false };
    var narrow = W.matchMedia ? W.matchMedia("(max-width: 1023px)") : { matches: false };
    var fine = W.matchMedia ? W.matchMedia("(min-width: 1024px) and (hover: hover) and (pointer: fine)") : { matches: false };

    var cur = -1, pend = -1, timer = 0;
    function setCur(i) {
      cur = i;
      steps.forEach(function (s, k) { s.classList.toggle("is-done", k < i); s.classList.toggle("is-cur", k === i); });
    }
    if ("IntersectionObserver" in W) {
      var io = new W.IntersectionObserver(function (es) {
        es.forEach(function (e) {
          if (!e.isIntersecting || !narrow.matches) return;
          pend = steps.indexOf(e.target);
          W.clearTimeout(timer);
          timer = W.setTimeout(function () { if (pend !== cur) setCur(pend); }, 180);
        });
      }, { rootMargin: "-45% 0px -50% 0px" });
      steps.forEach(function (s) { io.observe(s); });
    }
    /* [пропуск: поиск svg, path, run, nodes] */
    var L = path.getTotalLength(), at = [];
    nodes.forEach(function (n) {
      var cx = +n.getAttribute("cx"), cy = +n.getAttribute("cy"), best = 0, bd = 1e9;
      for (var s = 0; s <= L; s += 2) {
        var p = path.getPointAtLength(s), d = (p.x - cx) * (p.x - cx) + (p.y - cy) * (p.y - cy);
        if (d < bd) { bd = d; best = s; }
      }
      at.push(best);
    });
    var pos = 0, anim = null, a0 = 0, a1 = 0, dur = 0, on = -1;
    function xy(s) {
      var p = path.getPointAtLength(Math.max(0, Math.min(L, s)));
      return "translate(" + p.x.toFixed(1) + "px," + p.y.toFixed(1) + "px)";
    }
    function ease(t) { return t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2; }
    function drawn() {
      if (D.documentElement.getAttribute("data-ag-motion") === "off") return true;
      var o = parseFloat(W.getComputedStyle(path).strokeDashoffset) || 0;
      return Math.abs(o) < 1;
    }
    function go(i) {
      if (!fine.matches || !drawn()) return;
      if (on >= 0) nodes[on].classList.remove("is-on");
      on = i;
      nodes[i].classList.add("is-on");
      steps.forEach(function (s, k) { s.classList.toggle("is-hover", k === i); });
      if (anim) {
        var t = Math.min(1, (anim.currentTime || 0) / dur);
        pos = a0 + (a1 - a0) * ease(t);
        anim.cancel();
        anim = null;
      }
      run.classList.add("is-on");
      var to = at[i];
      if (still.matches || Math.abs(to - pos) < 1) { pos = to; run.style.transform = xy(pos); return; }
      a0 = pos; a1 = to;
      dur = Math.round(380 + Math.min(1, Math.abs(a1 - a0) / L) * 320);
      var fr = [];
      for (var k = 0; k <= 24; k++) fr.push({ transform: xy(a0 + (a1 - a0) * ease(k / 24)) });
      run.style.transform = xy(a1);
      pos = a1;
      anim = run.animate(fr, { duration: dur, easing: "linear" });
      anim.onfinish = function () { anim = null; };
    }
    run.style.transform = xy(0);
    steps.forEach(function (s, i) { s.addEventListener("mouseenter", function () { go(i); }); });
```

F10-подложка (`blocks/grappling-samara/DIR05-04_v1.1.0.html`):

```css
  @media not (forced-colors:active){
    #ag-dir05-04 .ag-yw__tabs.is-ind::before{
      content:"";position:absolute;z-index:1;left:0;top:0;pointer-events:none;border-radius:8px;background:var(--plate);
      width:calc((100% - 30px) / 4);height:100%;
      transform:translate(calc(var(--c,0) * (100% + 10px)),calc(var(--r,0) * (100% + 8px)));
      transition:transform .38s cubic-bezier(.22,.61,.36,1);
    }
    #ag-dir05-04 .ag-yw__tabs.is-ind .ag-yw__tab[aria-selected="true"]{background:transparent;border-color:transparent;transition:background-color 0s,border-color .2s ease,color .2s ease .18s;}
    #ag-dir05-04 .ag-yw__tabs.is-ind .ag-yw__tab[aria-selected="false"]{transition:color 0s,border-color .25s ease;}
  }
```

**Режимы:**
- reduce: «борец» прыгает сразу на узел (`still.matches` проверяется в момент события); вертикаль — только смена цвета.
- forced-colors: «борец» и подсвеченный узел `fill:Highlight`; вертикаль `--c:CanvasText !important`, колено и хлопок `stroke:CanvasText`, текущий узел `Highlight`, поле — `border:1px solid CanvasText` вместо тоновых полос; F10-подложка в forced отключена целиком (`@media not (forced-colors:active)`).
- печать: профиль ПК скрыт; вертикаль, легенда и поле скрыты, `padding-left:0`.
- без JS: нет атрибута `data-ag-js` → вертикальная линия целиком жёлтая (`--c:var(--accent)`); на ПК путь целиком.
- сенсорный ≥ 1024: «борца» нет (`@media not ((hover:hover) and (pointer:fine))` + проверка `fine` в `go`).
- телефон: текущий шаг только по прокрутке (касание не участвует — Б4: два источника «текущего» спорили бы).

**Грабли и поправки:**
- Б1: фокус на шагах дал бы пустые остановки Tab → шаги без tabindex/ролей; текст виден весь.
- Б2: линию телефона строить JS по замерам — это вставки в `ol` и срабатывание MutationObserver движка → статичная разметка в каждом `li` + CSS по `data-ag-lane`.
- Б3: путь движка (`draw`) не трогать (ни `d`, ни `dash*`) → «борец» — отдельный `<circle>`.
- П5: вертикаль на всём < 1024, полоса и две колонки удалены из разметки — по замеру ревью блок короче на всех ширинах (390: −67, 599: −201).
- З10: не ехать по недорисованному пути. §9.3: тест «борца» до draw сначала шёл с предварительной прокруткой (draw уже прошёл) — тест исправлен.
- §9.1: тоновые дорожки `#141417/#1B1B1E` почти не различались → стойка `#222226`, легенда тем же тоном.
- §9.2: на 320 поле 54 px удлиняло 02 на +56 → ≤ 359 поле 50 px, легенда плотнее; итог +17 на всю страницу.
- З15: не обучать приёмам схемой — одна точка, без второй фигуры.
- Отвергнуто: хлопок «стучит» по нажатию (П12, декор); «борец» в мини-профиле 04 (дубль 02); сетка ковра F30 (оборудование не подтверждено); фокус/касание шагов.

---

## 13. «Зоны зала» (F04) · /functional-training

**Страница / блок / файл:** /functional-training, DIR06-04 «Где идут функциональные тренировки» (rec3998485801) — `blocks/functional-training/DIR06-04_v1.1.0.html`. Отчёт: `passes/functional-training/RESULTS.md`, `PROMPT_DIR06_DESIGN_MOTION_v2.md`, `build_dir06_dm.py`, `checks_f.js`.

**Идея:** над кадром зала — три вкладки-зоны «Свободные веса» / «Весь зал» / «Сайкл-студия»; вкладка меняет кадр и подпись на стекле. **Польза:** сверка кадров глазами показала, что прежний кадр «зона со свободными весами» на самом деле рама с турниками — вместо одного неверного снимка читатель видит три честных, каждый со своей подписью. Фишка выросла из ошибки факта, а не из желания «оживить».

**Механика (числа):**
- Пуск — клик/клавиши (← → ↑ ↓, Home, End; автоматическая активация). Скрипт ставит корню `data-ag-zone="0…2"`.
- Кадр: все три панели в одной ячейке (`grid-area:1/1`), смена — `opacity .18s ease` + `visibility` (уходящая: `visibility 0s linear .18s`, приходящая: `visibility 0s`) → высота рамки не прыгает; рамка держит пропорцию v1.0.0 (ПК 3:2, телефон 16:9).
- Подложка: `.ag-uz__ind` жёлтая «пилюля», `translateX(calc(var(--i)*100%))`, 320 мс `cubic-bezier(.22,.61,.36,1)`; цвет текста вкладки — с задержкой 0,1 с.
- `is-jump` при первой установке и при смене раскладки 1023/1024 (matchMedia).
- ≥ 1024: ряд вкладок — стеклянная полоса поверх верхней кромки кадра (`rgba(9,9,10,.62)` + `backdrop-filter:blur(10px)`); < 1024 — светлая полоса над кадром (12 px, разрядка .03em, поля 4 px, `nowrap`); ≤ 374 — 11,5 px с переносом `text-wrap:balance`; высота вкладки 44 px.
- Переходы только CSS, WAAPI нет → быстрые клики не копят анимаций (проверка `getAnimations()` после 9 кликов = 0).
- Тип появления движка `scale-in` — только у обёртки панелей (как у кадра в v1.0.0); рамка с вкладками не масштабируется, смена зон не перезапускает появление.

**Разметка:**

```html
          <div class="ag-uz__tabs" role="tablist" aria-label="Зоны зала на Молодогвардейской, 56" data-ag-tablist hidden>
            <button class="ag-uz__tab" type="button" role="tab" id="ag-dir06-04-z1" aria-controls="ag-dir06-04-zp1" aria-selected="true"><span>Свободные веса</span></button>
            <button class="ag-uz__tab" type="button" role="tab" id="ag-dir06-04-z2" aria-controls="ag-dir06-04-zp2" aria-selected="false" tabindex="-1"><span>Весь зал</span></button>
            <button class="ag-uz__tab" type="button" role="tab" id="ag-dir06-04-z3" aria-controls="ag-dir06-04-zp3" aria-selected="false" tabindex="-1"><span>Сайкл-студия</span></button>
            <span class="ag-uz__ind" aria-hidden="true"></span>
          </div>
          <div class="ag-uz__panels" data-ag-anim="scale-in" data-ag-delay="80">
            <div class="ag-uz__panel is-on" id="ag-dir06-04-zp1" role="group" aria-label="Зона со свободными весами">
              <figure class="ag-uz__fig" data-ag-slot="DIR06-04-weights" data-ag-ratio="4:5" data-ag-brief="…">
                <img class="ag-uz__img" src="…/57-1024x683.jpg" width="1024" height="683" alt="Зона со свободными весами в Apollo NoFitness на Молодогвардейской, 56" loading="lazy" decoding="async">
                <figcaption class="ag-uz__label"><span class="ag-uz__dot" aria-hidden="true"></span><span>Зона со свободными весами</span></figcaption>
```

Без JS — `role="group"` с `aria-label`; скрипт меняет на `tabpanel` + `aria-labelledby`, снимает `aria-label`, ставит `tabindex`.

**Ключевой код** (`blocks/functional-training/DIR06-04_v1.1.0.html`), CSS:

```css
  /* F04 · «Зоны зала» */
  #ag-dir06-04 .ag-uz__panels{display:grid;gap:14px;}
  #ag-dir06-04 .ag-uz__panels.is-js{gap:0;}
  #ag-dir06-04 .ag-uz__panels.is-js>.ag-uz__panel{grid-area:1 / 1;opacity:0;visibility:hidden;transition:opacity .18s ease,visibility 0s linear .18s;}
  #ag-dir06-04 .ag-uz__panels.is-js>.ag-uz__panel.is-on{opacity:1;visibility:visible;transition:opacity .18s ease,visibility 0s;}
  #ag-dir06-04 .ag-uz__tabs{position:relative;display:grid;grid-template-columns:repeat(3,minmax(0,1fr));padding:4px;border-radius:var(--r-pill);isolation:isolate;}
  #ag-dir06-04 .ag-uz__tab[aria-selected="true"]{color:#09090A;}
  #ag-dir06-04 .ag-uz__ind{position:absolute;z-index:1;left:4px;top:4px;bottom:4px;width:calc((100% - 8px) / 3);border-radius:var(--r-pill);background:var(--accent);pointer-events:none;
    transform:translateX(calc(var(--i,0) * 100%));transition:transform .32s cubic-bezier(.22,.61,.36,1);}
  #ag-dir06-04[data-ag-zone="1"] .ag-uz__ind{--i:1;}
  #ag-dir06-04[data-ag-zone="2"] .ag-uz__ind{--i:2;}
  #ag-dir06-04 .ag-uz__tabs.is-jump .ag-uz__ind{transition:none;}
  /* ПК: стеклянный ряд поверх верхней кромки кадра */
  @media (min-width:1024px){
    #ag-dir06-04 .ag-uz__tabs{position:absolute;z-index:3;left:clamp(14px,1.6vw,20px);right:clamp(14px,1.6vw,20px);top:clamp(14px,1.6vw,20px);
      border:1px solid rgba(255,255,255,.26);background:rgba(9,9,10,.62);-webkit-backdrop-filter:blur(10px);backdrop-filter:blur(10px);}
  }
  /* < 1024: ряд над кадром, на бумаге */
  @media (max-width:1023px){
    #ag-dir06-04 .ag-uz__tabs{margin-bottom:10px;border:1px solid var(--edge);background:var(--card);}
    #ag-dir06-04 .ag-uz__tab{color:var(--ink);font-size:12px;letter-spacing:.03em;padding:6px 4px;white-space:nowrap;}
  }
  @media (max-width:374px){#ag-dir06-04 .ag-uz__tab{font-size:11.5px;letter-spacing:.02em;white-space:normal;text-wrap:balance;}}
  @media (forced-colors:active){
    #ag-dir06-04 .ag-uz__ind{display:none;}
    #ag-dir06-04 .ag-uz__tabs{border:1px solid CanvasText;}
    #ag-dir06-04 .ag-uz__tab[aria-selected="true"]{outline:2px solid CanvasText;outline-offset:-4px;}
  }
```

JS (тот же файл):

```js
    panels.forEach(function (p, i) {
      p.setAttribute("role", "tabpanel");
      p.setAttribute("aria-labelledby", tabs[i].id);
      p.removeAttribute("aria-label");
    });
    box.classList.add("is-js");
    list.hidden = false;
    function select(i, focus) {
      tabs.forEach(function (t, k) {
        var on = k === i;
        t.setAttribute("aria-selected", on ? "true" : "false");
        t.setAttribute("tabindex", on ? "0" : "-1");
        panels[k].classList.toggle("is-on", on);
        panels[k].setAttribute("tabindex", on ? "0" : "-1");
      });
      root.setAttribute("data-ag-zone", String(i));
      if (focus) tabs[i].focus();
    }
    /* [пропуск: click и keydown — как в DIR04-04] */
    select(0, false);
    list.classList.add("is-jump");
    W.requestAnimationFrame(function () { W.requestAnimationFrame(function () { list.classList.remove("is-jump"); }); });
    var mq = W.matchMedia ? W.matchMedia("(max-width: 1023px)") : null;
    if (mq) {
      var jump = function () {
        list.classList.add("is-jump");
        W.requestAnimationFrame(function () { W.requestAnimationFrame(function () { list.classList.remove("is-jump"); }); });
      };
      if (mq.addEventListener) mq.addEventListener("change", jump); else if (mq.addListener) mq.addListener(jump);
    }
```

**Режимы:**
- reduce: общее правило блока `transition-duration:.01ms !important` — подложка и кадр меняются мгновенно (проверено «на лету»).
- forced: подложки нет, выбранная вкладка — обводка `CanvasText`, рамки кадра/карточки/подписи — `CanvasText`.
- печать: весь медиаблок скрыт (как в v1.0.0), карточка на всю ширину.
- без JS: три кадра столбцом с подписями (Б1 ревью — вкладки не прячут кадры); tablist `hidden`.
- сенсор/телефон: та же разметка, ряд над кадром; рост телефона +64 px (ряд вкладок) — объяснён «три честных кадра вместо одного неверного».
- Tab: в порядок фокуса попадают только выбранная вкладка и её панель (фокус 3 px).

**Грабли и поправки:**
- Б5: кадр 50 (рама с турниками) — оборудование не подтверждено для страницы → вкладка «Рама» снята, вместо неё «Весь зал» (кадр 51); вопрос владельцу.
- З6: сайкл — не функциональная зона → вкладка последней, подпись «Отдельная сайкл-студия», без условий и цен. З7: состав свободных весов не называть (урок I071).
- Б2: `scale-in` на рамке сработал бы повторно → только у обёртки панелей.
- §9.1: на 390 «Свободные веса» переносилось, ряд разной высоты → 12 px + `nowrap`, ≤ 374 — перенос с `balance`.
- §9.3: во время проявления 180 мс уходящая панель ещё в Tab → `tabindex` 0 только у выбранной панели.
- §9.2 (FAQ 07): не было «страховки скана», некуда повесить iOS `touchstart` для F23 → слушатель касания ставится в скрипте FAQ после `btn.hidden = false`.
- Отвергнуто: «вздрагивание» значка колонки в 02 (П12); F10-подложка корешков в 03 (ломает метафору «корешок сливается с карточкой»); «линейка» с пробегающими делениями в 06 (стандарт 11, без счётчиков); заливка контура «ФУНКЦИОНАЛЬНЫЕ» (П12).

---

## 14. /cycle-samara · «Педаль по кругу», «мини-маховики», «Деталь на чертеже»

Отчёт: `passes/cycle-samara/RESULTS.md`, `PROMPT_DIR07_DESIGN_MOTION_v2.md`, `build_dir07_dm.py`, `checks_c.js`.

### 14.1 «Педаль по кругу» (F30 + F14)

**Страница / блок / файл:** /cycle-samara, DIR07-03 «Из каких отрезков собирают занятие на сайкле» (rec4003190901) — `blocks/cycle-samara/DIR07-03_v1.1.0.html`.

**Идея:** схема занятия — «дорога» входа (Разогрев), круг из трёх дуг (Подъём → Ускорение → Восстановление, «по кругу»), дорога выхода (Заминка). На ПК наведение мышью на шаг: жёлтая «педаль» проезжает отрезок этого шага от начала до наконечника стрелки, отрезок и его подпись светятся, остальные приглушены. **Польза:** «отрезки чередуются по кругу» видно движением ровно по действию читателя; круг сам не крутится (F30: «круг не вращается бесконечно»).

**Механика (числа):**
- Только `(min-width:1024px) and (hover:hover) and (pointer:fine)` + `pointerenter` с `pointerType==="mouse"`; проверка в момент события.
- Маршрут — **аналитически**, не `getPointAtLength` (Б2: 9 путей с разрывами, петля замкнута): петля — центр (260,150), r 100, **угол только растёт**; дороги — прямые y = 50. Отрезки: вход x 16→258; дуги −86°→26°, 34°→146°, 154°→266°; выход x 262→504. Мосты между отрезками в `BRIDGE` (зазоры у наконечников); «Восстановление → Подъём» — дуга 274°→386° (угол продолжает расти).
- Длительность проезда `450 + min(1, L/420)·200` → 450–650 мс; 29 кадров WAAPI, ease-in-out внутри, `easing:"linear"` у анимации.
- По ходу круга (0→1, 1→2, 2→3, 3→1, 3→4) — продолжает с текущего места без скачка (`rest()` остатка старого маршрута + мост + новый отрезок); иначе гаснет за 120 мс (`is-off`, `opacity .12s`) и стартует с начала нового отрезка.
- Подсветка: `stroke-opacity` прочих .3, у дороги активной — цвет текста, у дуги — `stroke-width` 4 → 5,5; подписи — `color`; всё 0,2 с. Ушли со списка — через 250 мс приглушение снимается, педаль остаётся на месте. Потеря медиазапроса `fine` — `reset()` + `cancel()`.
- Педаль не видна до конца draw (по `stroke-dashoffset` выхода — последнего пути). draw схемы ускорен: 500/600/700/800/900 мс (было 0,7–1,9 с), порядок прежний.

**Разметка:** SVG `aria-hidden` (фигура целиком), 9 путей с `data-ag-seg="0…4"` и `data-ag-anim="draw"`, подписи `span.ag-xr__nl[data-ag-seg]`, статичный `<circle class="ag-xr__ped" cx="0" cy="0" r="7"/>` (без `data-ag-anim`):

```html
              <path data-ag-seg="0" class="ag-xr__road" d="M16 50H258" data-ag-anim="draw" data-ag-dur="500"/>
              <path data-ag-seg="1" class="ag-xr__loop" d="M267.0 50.2A100 100 0 0 1 349.9 193.8" data-ag-anim="draw" data-ag-dur="600"/>
              <path data-ag-seg="1" class="ag-xr__loop" d="M359.2 187.3L349.9 193.8L349.3 182.4" data-ag-anim="draw" data-ag-dur="600"/>
              <!-- … сегменты 2, 3 … -->
              <path data-ag-seg="4" class="ag-xr__road" d="M262 50H504" data-ag-anim="draw" data-ag-dur="900"/>
              <path data-ag-seg="4" class="ag-xr__road" d="M494 44L504 50L494 56" data-ag-anim="draw" data-ag-dur="900"/>
              <circle class="ag-xr__ped" cx="0" cy="0" r="7"/>
```

**Ключевой код** (`blocks/cycle-samara/DIR07-03_v1.1.0.html`), CSS:

```css
  /* «Педаль по кругу» — подсветка отрезка: stroke-opacity, толщина и цвет (opacity путей пишет движок) */
  #ag-dir07-03 .ag-xr__svg [data-ag-seg]{transition:stroke-opacity .2s ease,stroke-width .2s ease,stroke .2s ease;}
  #ag-dir07-03 .ag-xr__fig.is-focus .ag-xr__svg [data-ag-seg]{stroke-opacity:.3;}
  #ag-dir07-03 .ag-xr__fig.is-focus .ag-xr__svg [data-ag-seg].is-on{stroke-opacity:1;}
  #ag-dir07-03 .ag-xr__fig.is-focus .ag-xr__road.is-on{stroke:var(--text);}
  #ag-dir07-03 .ag-xr__fig.is-focus .ag-xr__loop.is-on{stroke-width:5.5;}
  #ag-dir07-03 .ag-xr__ped{fill:var(--accent);stroke:var(--bg);stroke-width:3;opacity:0;transition:opacity .12s ease;pointer-events:none;}
  #ag-dir07-03 .ag-xr__ped.is-on{opacity:1;}
  #ag-dir07-03 .ag-xr__ped.is-on.is-off{opacity:0;}
  @media (max-width:1023px),(hover:none),(pointer:coarse){#ag-dir07-03 .ag-xr__ped{display:none;}}
```

JS:

```js
    var CX = 260, CY = 150, R = 100, RAD = Math.PI / 180;
    var SEG = [{ l: [16, 258] }, { a: [-86, 26] }, { a: [34, 146] }, { a: [154, 266] }, { l: [262, 504] }];
    var BRIDGE = {
      "0>1": [{ l: [258, 260] }, { a: [-90, -86] }], "1>2": [{ a: [26, 34] }], "2>3": [{ a: [146, 154] }],
      "3>1": [{ a: [266, 274] }], "3>4": [{ a: [266, 270] }, { l: [260, 262] }]
    };
    function len(p) { return p.l ? Math.abs(p.l[1] - p.l[0]) : Math.abs(p.a[1] - p.a[0]) * RAD * R; }
    function at(p, f) {
      if (p.l) return [p.l[0] + (p.l[1] - p.l[0]) * f, 50];
      var a = (p.a[0] + (p.a[1] - p.a[0]) * f) * RAD;
      return [CX + R * Math.cos(a), CY + R * Math.sin(a)];
    }
    /* [пропуск: total(), point(), rest() — длина маршрута, точка на расстоянии s, остаток маршрута после s] */
    function ride(r) {
      route = r;
      var L = total(r);
      dur = Math.round(450 + Math.min(1, L / 420) * 200);
      var fr = [];
      for (var k = 0; k <= 28; k++) fr.push({ transform: tr(point(r, ease(k / 28) * L)) });
      ped.style.transform = tr(point(r, L));
      anim = ped.animate(fr, { duration: dur, easing: "linear" });
      anim.onfinish = function () { anim = null; };
    }
    function go(i) {
      if (!fine.matches || !drawn()) return;
      light(i);
      if (i === cur) return;
      var key = cur + ">" + i, seg = i === 1 && cur === 3 ? { a: [274, 386] } : SEG[i];
      var fading = ped.classList.contains("is-off");
      var cont = ped.classList.contains("is-on") && !fading && !!BRIDGE[key];
      var s = nowS(), old = route;
      stop();
      W.clearTimeout(fadeT);
      cur = i;
      if (still.matches) {
        route = [seg]; ped.style.transform = tr(at(seg, 1)); ped.classList.remove("is-off"); ped.classList.add("is-on");
        return;
      }
      if (cont) { ride(rest(old || [], s).concat(BRIDGE[key], [seg])); return; }
      if (ped.classList.contains("is-on")) {
        ped.classList.add("is-off");
        fadeT = W.setTimeout(function () {
          ped.style.transform = tr(at(seg, 0));
          ped.classList.remove("is-off");
          ride([seg]);
        }, 120);
        return;
      }
      ped.style.transform = tr(at(seg, 0));
      ped.classList.add("is-on");
      ride([seg]);
    }
    steps.forEach(function (s, i) {
      s.addEventListener("pointerenter", function (e) { if (e.pointerType === "mouse") go(i); });
    });
    list.addEventListener("pointerleave", function () { W.clearTimeout(leaveT); leaveT = W.setTimeout(calm, 250); });
    if (fine.addEventListener) fine.addEventListener("change", reset); else if (fine.addListener) fine.addListener(reset);
```

**Режимы:**
- reduce: педаль ставится сразу в конец отрезка, без WAAPI (проверка в момент события, работает «на лету»).
- forced: педаль `fill:Highlight; stroke:Canvas`; при фокусе прочие отрезки `GrayText`, свой — `Highlight`.
- печать: схема скрыта (как в v1.0.0).
- без JS: схема и маховики есть, педали нет (opacity 0, класс не ставится).
- сенсорный ≥ 1024 и < 1024: педали нет (`(hover:none),(pointer:coarse)` в CSS + `pointerType` в JS).

### 14.2 «Мини-маховики» (тот же блок DIR07-03)

**Идея:** у каждого шага в строке названия — маленький круг 30 × 27,5 px с дорогами, на котором выделен отрезок этого шага. **Польза:** на телефоне схема стоит выше списка и уходит из экрана — маховик держит связь «шаг ↔ место на круге» рядом с каждым шагом; статичная картинка, работает без JS; поле слева у текста снято → блок 03 стал короче (390: −67 px).

**Механика:** только < 1024 (на ПК схема рядом со списком и прежний маркер 9 px); никакой анимации. «Свой» отрезок — класс `is-me` в разметке.

**Разметка и код** (`blocks/cycle-samara/DIR07-03_v1.1.0.html`):

```html
            <h3 class="ag-xr__name"><svg class="ag-xr__w" width="24" height="22" viewBox="0 0 24 22" aria-hidden="true" focusable="false"><path class="ag-xr__wr" d="M1 6H11.4"/><path class="ag-xr__wl is-me" d="M12.49 6.02A7 7 0 0 1 18.29 16.07"/><path class="ag-xr__wl" d="M17.80 16.91A7 7 0 0 1 6.20 16.91"/><path class="ag-xr__wl" d="M5.71 16.07A7 7 0 0 1 11.51 6.02"/><path class="ag-xr__wr" d="M12.6 6H23"/></svg><span class="ag-xr__nt">Подъём</span></h3>
```

```css
  #ag-dir07-03 .ag-xr__w{display:none;}
  #ag-dir07-03 .ag-xr__w path{fill:none;stroke-linecap:round;}
  #ag-dir07-03 .ag-xr__wr{stroke:rgba(244,244,245,.28);stroke-width:1.6;}
  #ag-dir07-03 .ag-xr__wl{stroke:rgba(255,196,0,.3);stroke-width:1.8;}
  #ag-dir07-03 .ag-xr__wr.is-me{stroke:var(--text);stroke-width:2.4;}
  #ag-dir07-03 .ag-xr__wl.is-me{stroke:var(--accent);stroke-width:2.8;}
  @media (max-width:1023px){
    #ag-dir07-03 .ag-xr__step{padding-left:0;}
    #ag-dir07-03 .ag-xr__step::before{display:none;}
    #ag-dir07-03 .ag-xr__name{display:flex;align-items:center;gap:10px;}
    #ag-dir07-03 .ag-xr__w{display:block;flex:none;width:30px;height:27.5px;margin:-4px 0;overflow:visible;}
  }
  @media (forced-colors:active){
    #ag-dir07-03 .ag-xr__w path{stroke:GrayText;}
    #ag-dir07-03 .ag-xr__w path.is-me{stroke:Highlight;}
  }
  @media print{#ag-dir07-03 .ag-xr__w{display:none !important;}}
```

Режимы: reduce — не нужен (статика); forced — свой отрезок `Highlight`, остальное `GrayText`; печать — скрыты; без JS — есть; телефон — основная аудитория.

### 14.3 «Деталь на чертеже»

**Страница / блок / файл:** /cycle-samara, DIR07-02 (посадка на велотренажёре, технический чертёж с выносками) — `blocks/cycle-samara/DIR07-02_v1.1.0.html`.

**Идея:** на ПК наведение мышью на термин в тексте («Седло», «Руль», «педали», «рукоятка сопротивления» — `<mark>`) подсвечивает выноску, точку и подпись этой детали на чертеже. **Польза:** связывает инструкцию по посадке с местом на тренажёре — читатель не ищет глазами, о какой детали речь.

**Механика:** только `(min-width:1024px) and (hover:hover) and (pointer:fine)` (и в CSS, и в JS) + `pointerType==="mouse"`; скрипт ставит один атрибут корня `data-ag-part`; снятие — через 150 мс после `pointerleave`. Подсветка 180 мс: выноска `stroke` ink, толщина 1,3 → 2,4; точка `fill` ink + `scale(1.7)` (`transform-box:fill-box`); подпись — жёлтая подложка (`background` + `box-shadow:0 0 0 4px`), тёмный текст, без сдвига. Работает только после того, как последняя подпись чертежа видна (вычисленный `opacity` > 0,99 — подписи появляются stagger с задержкой 1,5 с) или движок выключен.

**Разметка:** `data-ag-part` на `mark` в тексте, на выносках `.ag-xs__ld`, точках `.ag-xs__dot`, кольце рукоятки `.ag-xs__mk` и подписях `.ag-xs__co`. Подписи — дети stagger (`data-ag-anim="stagger" data-ag-children=".ag-xs__co" data-ag-from="none" data-ag-delay="1500" data-ag-stagger="120"`), поэтому у них меняются только фон и цвет. Термины — без tabindex/ролей/cursor.

```html
        <p class="ag-xs__p">Занятие начинается с посадки. <mark class="ag-xs__m" data-ag-part="saddle">Седло</mark> поднимают …</p>
            <path class="ag-xs__ld" d="M214 160L168 126" data-ag-part="saddle"/>
            <circle class="ag-xs__dot" cx="214" cy="160" r="3.2" data-ag-part="saddle"/>
            <span class="ag-xs__co ag-xs__co--saddle" data-ag-part="saddle">Седло</span>
```

**Ключевой код** (`blocks/cycle-samara/DIR07-02_v1.1.0.html`):

```css
  /* «Деталь на чертеже» — только мышь на ПК. Не трогаем opacity/transform/dash у узлов движка: подписи —
     дети stagger, поэтому у них меняются только фон и цвет; линии — stroke и толщина. */
  @media (min-width:1024px) and (hover:hover) and (pointer:fine){
    #ag-dir07-02 .ag-xs__m[data-ag-part]:hover{background:linear-gradient(transparent 58%,rgba(255,196,0,.9) 58%);}
    #ag-dir07-02 .ag-xs__svg [data-ag-part]{transition:stroke .18s ease,stroke-width .18s ease,fill .18s ease,transform .18s ease;}
    #ag-dir07-02 .ag-xs__dot[data-ag-part]{transform-box:fill-box;transform-origin:center;}
    #ag-dir07-02 .ag-xs__co[data-ag-part]{border-radius:2px;transition:background-color .18s ease,box-shadow .18s ease,color .18s ease;}
    #ag-dir07-02[data-ag-part="saddle"] .ag-xs__ld[data-ag-part="saddle"],#ag-dir07-02[data-ag-part="saddle"] .ag-xs__mk[data-ag-part="saddle"]{stroke:var(--ink);stroke-width:2.4;}
    #ag-dir07-02[data-ag-part="saddle"] .ag-xs__dot[data-ag-part="saddle"]{fill:var(--ink);transform:scale(1.7);}
    #ag-dir07-02[data-ag-part="saddle"] .ag-xs__co[data-ag-part="saddle"]{background:var(--accent);box-shadow:0 0 0 4px var(--accent);color:var(--ink);}
    /* … те же три правила для bar, pedal, knob … */
  }
  @media (forced-colors:active){
    #ag-dir07-02[data-ag-part] .ag-xs__co[data-ag-part]{background:none !important;box-shadow:none !important;}
  }
```

```js
    var terms = Array.prototype.slice.call(root.querySelectorAll(".ag-xs__m[data-ag-part]"));
    var cos = root.querySelectorAll(".ag-xs__co");
    if (terms.length !== 4 || !cos.length) return;
    root.setAttribute("data-ag-ui-mounted", "");
    var fine = W.matchMedia ? W.matchMedia("(min-width: 1024px) and (hover: hover) and (pointer: fine)") : { matches: false };
    var timer = 0;
    function shown() {
      if (D.documentElement.getAttribute("data-ag-motion") === "off") return true;
      return parseFloat(W.getComputedStyle(cos[cos.length - 1]).opacity) > 0.99;
    }
    function off() { W.clearTimeout(timer); root.removeAttribute("data-ag-part"); }
    terms.forEach(function (m) {
      m.addEventListener("pointerenter", function (e) {
        if (e.pointerType !== "mouse" || !fine.matches || !shown()) return;
        W.clearTimeout(timer);
        root.setAttribute("data-ag-part", m.getAttribute("data-ag-part"));
      });
      m.addEventListener("pointerleave", function () {
        W.clearTimeout(timer);
        timer = W.setTimeout(off, 150);
      });
    });
    if (fine.addEventListener) fine.addEventListener("change", off); else if (fine.addListener) fine.addListener(off);
```

Режимы: reduce — общее сокращение переходов блока; forced — подложка подписи снята (системные цвета); печать — как v1.0.0; без JS — чертёж целиком, подсветки нет; сенсор/телефон — как было (только наведение, записано в отчёт как отступление). Точки `.ag-xs__dot` — не узлы движка, поэтому `transform:scale` им можно.

**Грабли и поправки по /cycle-samara (§7, §9):**
- Б1: «только по часовой» было не определено (в Разогрев по ходу не попасть, из Заминки некуда, Ускорение → Подъём — 2/3 круга) → модель «проезд отрезка» + продолжение только по ходу.
- Б2: `getPointAtLength` одного пути не годится → маршрут аналитически.
- Б3: приглушение через `opacity` перебивается inline `opacity:1` движка → `stroke-opacity`, толщина, цвет; `opacity` — только у педали (не узел движка).
- П5: жёлтая точка на жёлтой дуге не видна → r 7, кольцо цвета фона толщиной 3.
- П9–П11: маховики сначала хотели на всех ширинах (дубль на ПК, рост строк) → только < 1024, inline-SVG в строке названия.
- §9.1: маховик 24 px на телефоне читался плохо → 30 × 27,5 px, поле ряда −4 px сверху и снизу (строка не выше прежней).
- §9.2: после серии быстрых наведений педаль оставалась невидимой — «проезд по ходу» начинался, пока педаль гасла → пока есть `is-off`, переход считается «не по ходу»; 11 быстрых наведений — педаль видна, анимаций 0.
- П13 (чертёж): колец у деталей нет (только у рукоятки) — новых не рисовали, подсвечивают выноску/точку/подпись. П14: подписи появляются stagger с 1,5 с → подсветка только после показа.
- §9.6: на 1024 × 768 при наведении на 5-й шаг у низа экрана схема видна целиком — проверено замером.
- Отвергнуто: большой маховик фоном в 01 (второй мотив, F30: один); вращение круга по прокрутке; F21 «вход с улицы» (нет кадра); F16 калькулятор (тариф не подтверждён); заливка «САЙКЛ» (П12).

---

## 15. /stretching-samara · «Три темпа на знаке», «Глубина наклона», соглашение `data-cue`

Отчёт: `passes/stretching-samara/RESULTS.md`, `PROMPT_DIR08_DESIGN_MOTION_v2.md`, `build_dir08_dm.py` (точечные замены по v1.0.0), `checks_s8.js`.

### 15.1 «Три темпа на знаке» (F08 + предмет)

**Страница / блок / файл:** /stretching-samara, DIR08-02 «Растяжка, мобилити или восстановление» (rec4006402501) — `blocks/stretching-samara/DIR08-02_v1.1.0.html`.

**Идея:** таблица трёх задач с одинаковыми строками («Что делают / Как работают / Кому подходит / Что сказать при записи»); в шапке колонок — знаки движения. Строка «Как работают» показана движением: три знака одновременно, ~3 с, один раз играют свой темп — растяжка держит (луч поднимается до нарисованного угла, держит под счёт трёх точек, опускается), подвижность суставов повторяет круг туда и обратно (дважды), восстановление — точка медленно проходит волну. **Польза:** разница трёх задач видна за 3 секунды без чтения и привязана к конкретной строке сравнения (F08), а не к декору.

**Механика (числа):**
- Окно T = 3000 мс; все анимации стартуют и заканчиваются вместе; одна WAAPI-анимация на узел; изгиб `cubic-bezier(.22,.61,.36,1)`.
- Конверт видимости групп: `opacity 0 → 1` (offset 0,06) → 1 (0,93) → 0.
- Растяжка: накладной луч вращается вокруг (14,38), `transform-box:view-box`: `rotate(26.57deg)` (лежит на базовой линии) → `0deg` к offset 0,2 (подъём 0,6 с), держит до 0,7, возврат к 0,9; точки счёта r 2,6 на y 44, x 22/30/38 загораются `0.25 → 1` в моменты `(600 + 500·k)/T` (через 0,5 с), гаснут на 0,88–0,92. (Числа знака: `rotate(26.57deg)` — это нарисованный угол 26,6°; луч не заходит дальше.)
- Мобилити: группа «радиус + точка» вокруг (36,24): 0 → 360 → 0 → 360 → 0°, offsets 0/.25/.5/.75/1, `ease-in-out` на каждом.
- Восстановление: точка по 29 точкам волны (`getPointAtLength` — только чтение; запасной вариант — формула кривой), offsets 0,03…0,93 по ease-in-out, доезжает до (62,30) и гаснет у статичной точки (66,30).
- Пуски:
  1. **Автопоказ один раз:** `IntersectionObserver` на три знака, `threshold:[0,.6,1]`, каждый ≥ 60 % и держится 400 мс; прорисовка закончена (все 8 draw-путей `data-ag-done` и `stroke-dashoffset` ≤ 0,5, колонки stagger `opacity` ≥ 0,99; `data-ag-motion="off"` — готово сразу; пока движок грузится — не готово); вкладка не скрыта; на странице нет чужого показа (`.ag-scope[data-cue]`) — иначе повтор через 300 мс. На время показа корню ставится `data-cue="2"`: ≥ 1024 подсвечивает строку «Как работают» (если мышь не стоит на другой строке), < 1024 — тихая рамка охрой у кнопки «Как работают». Снимается через T + 40 мс.
  2. **Мышь ≥ 1024:** переход подсветки строки (`data-hl`) с «не 2» на «2»; во время показа повторный вход не перезапускает; ушли — показ доигрывает. Подсветка строки 0,35 → 0,22 с и снимается через 220 мс (переход по строке через колонки не мигает).
  3. **< 1024:** выбор «Как работают» в переключателе строк (`data-row="2"`); повторное нажатие — заново (тот же атрибут → MutationObserver видит `old="2", v="2"`); уход на другую строку — `cancel()`.
- Скрипт фишки не слушает события напрямую: ловит атрибуты `data-hl`/`data-row`, которые ставит скрипт строк, через `MutationObserver({attributes:true, attributeOldValue:true, attributeFilter:[…]})` — атрибутный наблюдатель, не childList.
- `cancel()` по `change` любого из медиазапросов (reduce, fine, narrow) и при `visibilitychange` → скрыто.

**Разметка:** новые узлы заранее в SVG знака (`aria-hidden`), без `data-ag-anim`, группа `.ag-zc__tp[data-ag-tempo]`, в покое `opacity:0` (покой = v1.0.0, разница пикселей 0):

```html
            <svg class="ag-zc__sign" viewBox="0 0 72 48" width="72" height="48" aria-hidden="true" focusable="false">
              <path class="ag-zc__dim" d="M14 38H46"/>
              <path d="M14 38L60 15" data-ag-anim="draw" data-ag-dur="900"/>
              <path class="ag-zc__acc" d="M34 38A20 20 0 0 0 31.9 29.1" data-ag-anim="draw" data-ag-dur="1200"/>
              <path d="M57.8 10.5L62.2 19.5" data-ag-anim="draw" data-ag-dur="1300"/>
              <path class="ag-zc__dot" d="M11.4 38A2.6 2.6 0 1 0 16.6 38A2.6 2.6 0 1 0 11.4 38"/>
              <g class="ag-zc__tp" data-ag-tempo="hold">
                <path class="ag-zc__tray" d="M14 38L60 15"/>
                <circle class="ag-zc__tc" cx="22" cy="44" r="2.6"/>
                <circle class="ag-zc__tc" cx="30" cy="44" r="2.6"/>
                <circle class="ag-zc__tc" cx="38" cy="44" r="2.6"/>
              </g>
            </svg>
```

(у мобилити — `<g class="ag-zc__tp" data-ag-tempo="loop"><g class="ag-zc__trot">радиус + точка</g></g>`, у восстановления — `<g … data-ag-tempo="glide"><circle class="ag-zc__tdot ag-zc__tglide" cx="0" cy="0" r="2.8"/></g>`). Колонки `.ag-zc__col` — дети stagger: их `opacity` только читается.

**Ключевой код** (`blocks/stretching-samara/DIR08-02_v1.1.0.html`), CSS:

```css
  /* «Три темпа на знаке»: в покое скрыто — знак как в v1.0.0 */
  #ag-dir08-02 .ag-zc__tp{opacity:0;pointer-events:none;}
  #ag-dir08-02 .ag-zc__sign .ag-zc__tray{stroke:var(--ochre);stroke-width:3.2;transform-box:view-box;transform-origin:14px 38px;transform:rotate(26.57deg);}
  #ag-dir08-02 .ag-zc__sign .ag-zc__tc{fill:var(--ochre);stroke:none;opacity:.25;}
  #ag-dir08-02 .ag-zc__trot{transform-box:view-box;transform-origin:36px 24px;}
  #ag-dir08-02 .ag-zc__tglide{transform-box:view-box;transform-origin:0 0;transform:translate(6px,30px);}
  /* автопоказ отмечает строку «Как работают» (ПК) или её кнопку (< 1024) */
  @media (min-width:1024px){
    #ag-dir08-02[data-cue="2"]:not([data-hl]) .ag-zc__row[data-r="2"]{background:var(--hl);}
    #ag-dir08-02[data-cue="2"]:not([data-hl]) .ag-zc__row[data-r="2"] dt{color:var(--ochre);}
  }
  @media (max-width:1023px){
    #ag-dir08-02[data-cue="2"] .ag-zc__sw[data-r="2"][aria-pressed="false"]{border-color:var(--ochre);color:var(--ink);}
  }
  @media (forced-colors:active){
    #ag-dir08-02 .ag-zc__sign .ag-zc__tray,
    #ag-dir08-02 .ag-zc__sign .ag-zc__trad{stroke:Highlight;}
    #ag-dir08-02 .ag-zc__sign .ag-zc__tc,
    #ag-dir08-02 .ag-zc__sign .ag-zc__tdot{fill:Highlight;stroke:CanvasText;}
  }
  @media print{
    #ag-dir08-02 .ag-zc__tp{display:none !important;}
  }
```

JS (тот же файл; пропущены объявления и расчёт `PTS`):

```js
    var T = 3000, EASE = "cubic-bezier(.22,.61,.36,1)", A0 = "rotate(26.57deg)", A1 = "rotate(0deg)";
    function ready() {
      var m = D.documentElement.getAttribute("data-ag-motion");
      if (m === "off") return true;
      if (m !== "on") return false;
      for (var k = 0; k < draws.length; k++) {
        if (!draws[k].hasAttribute("data-ag-done")) return false;
        if (Math.abs(parseFloat(W.getComputedStyle(draws[k]).strokeDashoffset) || 0) > 0.5) return false;
      }
      for (var c = 0; c < cols.length; c++) if (parseFloat(W.getComputedStyle(cols[c]).opacity) < 0.99) return false;
      return true;
    }
    function play(cue) {
      if (still.matches || !ready()) return false;
      stop();
      autoDone = true;
      var env = [{ opacity: 0 }, { opacity: 1, offset: 0.06 }, { opacity: 1, offset: 0.93 }, { opacity: 0 }];
      [hold, loop, glide].forEach(function (g) { anims.push(g.animate(env, { duration: T })); });
      anims.push(ray.animate([
        { transform: A0, easing: EASE }, { transform: A1, offset: 0.2 },
        { transform: A1, offset: 0.7, easing: EASE }, { transform: A0, offset: 0.9 }, { transform: A0 }
      ], { duration: T }));
      dots.forEach(function (d, k) {
        var on = (600 + 500 * k) / T;
        anims.push(d.animate([{ opacity: 0.25 }, { opacity: 0.25, offset: on }, { opacity: 1, offset: on + 0.03 },
          { opacity: 1, offset: 0.88 }, { opacity: 0.25, offset: 0.92 }, { opacity: 0.25 }], { duration: T }));
      });
      var R = [];
      for (var k = 0; k <= 4; k++) R.push({ transform: "rotate(" + (k % 2 ? 360 : 0) + "deg)", offset: k / 4, easing: "ease-in-out" });
      anims.push(rot.animate(R, { duration: T }));
      /* [пропуск: кадры G по 29 точкам волны] */
      anims.push(gdot.animate(G, { duration: T }));
      if (cue) root.setAttribute("data-cue", "2");
      endT = W.setTimeout(function () { anims = []; root.removeAttribute("data-cue"); }, T + 40);
      return true;
    }
    /* Автопоказ — один раз, когда три знака видны и прорисованы */
    if ("IntersectionObserver" in W) {
      var vis = [0, 0, 0];
      var io = new IntersectionObserver(function (en) {
        en.forEach(function (e) { vis[signs.indexOf(e.target)] = e.intersectionRatio >= 0.6 ? 1 : 0; });
        seen = vis[0] && vis[1] && vis[2];
        W.clearTimeout(dwellT);
        if (seen && !autoDone) dwellT = W.setTimeout(tryAuto, 400);
      }, { threshold: [0, 0.6, 1] });
      signs.forEach(function (s) { io.observe(s); });
      var tryAuto = function () {
        W.clearTimeout(tryT);
        if (autoDone) { io.disconnect(); return; }
        if (!seen || still.matches || D.hidden) return;
        var other = D.querySelector(".ag-scope[data-cue]");
        if (!(other && other !== root) && play(true)) { io.disconnect(); return; }
        tryT = W.setTimeout(tryAuto, 300);
      };
    }
    /* Наведение (ПК) и переключатель (< 1024) — через атрибуты корня, которые ставит скрипт строк */
    new MutationObserver(function (list) {
      list.forEach(function (m) {
        var v = root.getAttribute(m.attributeName), old = m.oldValue;
        if (m.attributeName === "data-hl") {
          if (v === "2" && old !== "2" && fine.matches && !playing()) play(false);
        } else if (m.attributeName === "data-row" && narrow.matches) {
          if (v === "2") play(false);
          else if (old === "2") stop();
        }
      });
    }).observe(root, { attributes: true, attributeOldValue: true, attributeFilter: ["data-hl", "data-row"] });
    [still, fine, narrow].forEach(function (q) {
      if (q.addEventListener) q.addEventListener("change", stop); else if (q.addListener) q.addListener(stop);
    });
    D.addEventListener("visibilitychange", function () { if (D.hidden) stop(); });
```

**Режимы:**
- reduce: не играет (проверка в момент пуска) и останавливается на лету (`change` → `cancel()`); узлы скрыты CSS — покой = v1.0.0.
- forced: луч и радиус `Highlight`, точки `Highlight` с кромкой `CanvasText`.
- печать: узлы темпа `display:none`.
- без JS / отказ CDN: знак как в v1.0.0 (узлы `opacity:0`), текст виден; при `data-ag-motion="off"` (CDN висит/отказ) — ready сразу, показ возможен.
- сенсорный ≥ 1024: касание строки не запускает (строки не кнопки) — только автопоказ.
- клавиатура на ПК: только автопоказ (движение дублирует текст строки); узлы внутри `aria-hidden` svg без role/tabindex/aria-live.
- телефон: переключатель строк 2×2 (раскладка v1.0.0 прячет три строки из четырёх — отступление от F08, в отчёт).

**Грабли и поправки:**
- Б4: «луч уходит глубже» пересекал засечку и читался как обещание прогресса → луч поднимается от базовой линии до нарисованного угла и не дальше (§6: «обещать результат движением нельзя»).
- Б7: готовность — по вычисленному `stroke-dashoffset` всех 8 путей и `opacity` колонок (только чтение).
- П8: автопоказ сначала не был привязан к строке → `data-cue="2"` отмечает строку/кнопку.
- П9: лишние перезапуски наведением → пуск только на переходе «не 2 → 2», снятие `data-hl` через 220 мс, во время показа не перезапускать; 11 быстрых наведений — 1 пуск и покой.
- §6: дети stagger `.ag-zc__col` — `opacity`/`transform` не трогать; новые узлы свои, без `data-ag-anim`; нового типа появления не добавлять.
- §9.2: точки счёта r 2,2 на телефоне (знак 52 px) почти не видны → r 2,6.
- §9.1: автопоказ 02 и подсказка шкалы 03 помещаются в один экран (390×844, 1920×1080, 1920×1200) → соглашение `data-cue` (ниже).
- Отвергнуто: подсветка колонки при наведении на знак (дубль строки); «линия цены» в 06 (Б15/П16: разная ширина карточек — нет честного масштаба, разница 900/875 — 3 px, рост был бы новым типом появления); «буквы тянутся» в 08 (П12); F03 (кадр не про растяжку); F12 (нет второго кадра).

### 15.2 «Глубина наклона» (шкала в DIR08-03)

**Страница / блок / файл:** /stretching-samara, DIR08-03 «Что делают на занятии по растяжке» (rec4006422401) — `blocks/stretching-samara/DIR08-03_v1.1.0.html`. Шкала — из v1.0.0 («фишка страницы» до v1.1.0); в v1.1.0 добавлены F23 на «−/+», фокус 3 px и `data-cue`.

**Идея:** текст говорит «Глубину выбираете вы» и «наклон, который заканчивается на ладонь выше пола, — обычная точка старта». Пиктограмма человека в наклоне (толстая скруглённая линия) + шкала «Глубина наклона»: читатель сам двигает глубину, корпус с головой поворачивается вокруг таза, руки висят отвесно, у пола ложатся пальцами на пол; жёлтая дуга от вертикали — своя амплитуда. По умолчанию шкала стоит на засечке «Ладонь выше пола». **Польза:** снимает страх «я не достану до пола» — норма показана и выбирается руками, без обещания результата.

**Механика (числа):**
- `input type="range"` 0–100, шаг 1, значение 69 (засечка); кнопки «−»/«+» по 44 px, шаг 10 (альтернатива перетаскиванию, WCAG 2.5.7).
- Значение → угол корпуса 35°…115° от вертикали; засечка — 90° (кончики пальцев на ~16 единиц выше пола), касание — ≈ 100,6°. Анатомия viewBox: таз на высоте 180 (y), корпус 87, рука 128, пол пальцев 324.
- Рука: пока пальцы не дошли до пола — отвесно (`--arm = −t`), дальше `φ = acos((TIP − HIP + TORSO·cos t)/ARM)` и `--arm = φ − t`.
- Скрипт пишет на корень `--t`, `--arm`, `--arc` (= t/115), `--fill` (%); всё движение — CSS `transition` 600 мс `cubic-bezier(.3,.7,.2,1)`: `rotate()` у групп с `transform-box:view-box` и `transform-origin` в координатах viewBox (190 180 — таз, 190 93 — плечо); жёлтая дуга — `pathLength="100"` + `stroke-dashoffset:calc(100 - var(--arc)*100)`. Без rAF, `@keyframes` и прозрачности.
- `aria-valuetext`: < 66 «Лёгкий наклон»; 66–72 «Ладонь выше пола — обычная точка старта»; > 72 «Глубже — по своей амплитуде».
- Маркер фразы «Глубину выбираете вы» (`background-size 0 → 100% 38%`, 0,9 с) — только после первого действия читателя (`data-ag-touched`).
- Подсказка: один раз, когда лист впервые виден на 50 % (`IntersectionObserver threshold:.5`), не при reduce и не после действия читателя: значения 62 → 55 → 50 → 55 → 62 → 69 с шагом 320 мс, старт через 700 мс; любое `pointerdown`/`focus`/`keydown`/`input` прерывает.
- F23 (v1.1.0): у «−/+» сжимается знак внутри (`scale(.86)`, 140 мс), сама кнопка неподвижна; отпускание — 260 мс `cubic-bezier(.34,1.56,.64,1)`; iOS — пустой `touchstart` passive на корне.

**Разметка:** фигура — `svg.ag-zs__fig aria-hidden` (вертикаль, пунктир всего хода, жёлтая `.ag-zs__amp` с `pathLength="100"`, засечка, пол, ноги, `g.ag-zs__torso` с головой и вложенной `g.ag-zs__arms`); управление `div.ag-zs__ctl hidden` (до JS): `label for`, кнопки с `aria-label` «Меньше наклон»/«Глубже наклон» и `aria-controls`, подпись засечки и концов шкалы `aria-hidden`. Значения по умолчанию в CSS корня: `--t:90deg; --arm:-90deg; --arc:.7826; --fill:69%` — без JS фигура стоит на засечке.

**Ключевой код** (`blocks/stretching-samara/DIR08-03_v1.1.0.html`), CSS:

```css
  #ag-dir08-03 .ag-zs__amp{
    stroke:var(--accent);stroke-width:5;stroke-dasharray:100 100;
    stroke-dashoffset:calc(100 - var(--arc) * 100);
    transition:stroke-dashoffset .6s cubic-bezier(.3,.7,.2,1);
  }
  #ag-dir08-03 .ag-zs__torso{
    transform-box:view-box;transform-origin:190px 180px;transform:rotate(var(--t));
    transition:transform .6s cubic-bezier(.3,.7,.2,1);
  }
  #ag-dir08-03 .ag-zs__arms{
    transform-box:view-box;transform-origin:190px 93px;transform:rotate(var(--arm));
    transition:transform .6s cubic-bezier(.3,.7,.2,1);
  }
  #ag-dir08-03[data-ag-touched] .ag-zs__hl{background-size:100% 38%;}
  /* F23 · нажатие «−» / «+»: круг неподвижен, сжимается знак */
  #ag-dir08-03 .ag-zs__step>span{display:block;transition:transform 260ms cubic-bezier(.34,1.56,.64,1);}
  #ag-dir08-03 .ag-zs__step:active>span{transform:scale(.86);transition-duration:140ms;transition-timing-function:cubic-bezier(.22,.61,.36,1);}
```

JS:

```js
    var T0 = 35, T1 = 115, HIP = 180, TORSO = 87, ARM = 128, TIP = 324;
    var reduced = W.matchMedia && W.matchMedia("(prefers-reduced-motion: reduce)").matches;
    var touched = false, hintTimers = [];
    function apply(v) {
      v = Math.max(0, Math.min(100, Math.round(v)));
      var t = T0 + (T1 - T0) * v / 100, tr = t * Math.PI / 180;
      /* высота кончиков пальцев при отвесной руке: HIP − TORSO·cos t + ARM */
      var c = (TIP - HIP + TORSO * Math.cos(tr)) / ARM, phi = 0;
      if (c < 1) phi = Math.acos(Math.max(-1, c)) * 180 / Math.PI;
      root.style.setProperty("--t", t.toFixed(2) + "deg");
      root.style.setProperty("--arm", (phi - t).toFixed(2) + "deg");
      root.style.setProperty("--arc", (t / T1).toFixed(4));
      root.style.setProperty("--fill", v + "%");
      if (String(input.value) !== String(v)) input.value = v;
      input.setAttribute("aria-valuetext", text(v));
    }
    function stopHint() {
      hintTimers.forEach(function (id) { W.clearTimeout(id); });
      hintTimers = [];
      root.removeAttribute("data-cue");
    }
    /* [пропуск: touch(), слушатели input/pointerdown/focus/keydown и кнопок ±] */
    if (!reduced && sheet && "IntersectionObserver" in W) {
      var io = new IntersectionObserver(function (en) {
        if (!en[0] || !en[0].isIntersecting) return;
        io.disconnect();
        if (touched) return;
        var waited = 0;
        (function go() {
          /* v1.1.0: пока на странице идёт показ другого блока (атрибут data-cue у его корня, DIR08-02) — ждём, до 4 с */
          var other = D.querySelector(".ag-scope[data-cue]");
          if (other && other !== root && waited < 4000) { waited += 250; hintTimers.push(W.setTimeout(go, 250)); return; }
          var seq = [62, 55, 50, 55, 62, 69];
          root.setAttribute("data-cue", "hint");
          seq.forEach(function (v, i) {
            hintTimers.push(W.setTimeout(function () { if (!touched) apply(v); }, 700 + i * 320));
          });
          hintTimers.push(W.setTimeout(function () { root.removeAttribute("data-cue"); }, 700 + 5 * 320 + 450));
        })();
      }, { threshold: 0.5 });
      io.observe(sheet);
    }
```

**Режимы:**
- reduce: подсказки нет; переходы блока `.01ms` (фигура встаёт сразу); F23 без масштаба.
- forced: линии фигуры, пол, ход, вертикаль, засечка — `CanvasText`; дуга — `Highlight`; кнопки `border:1px solid ButtonText`; маркер фразы → подчёркивание.
- печать: шкала скрыта, лист с рамкой, фигура чёрная.
- без JS: фигура на засечке (значения по умолчанию в CSS), шкала и кнопки `hidden`.
- сенсор/телефон: `range` + кнопки по 44 px; на < 1024 одна колонка (`max-width:620px` у листа).

### 15.3 Соглашение `data-cue` (DIR08-02 ↔ DIR08-03)

**Проблема (§9.1):** блоки автономны, но автопоказ 02 и подсказка шкалы 03 оказались в одном экране на 390×844, 1920×1080, 1920×1200 (подсказка стартовала раньше — 02 ждёт конца прорисовки). Ревью П14 сначала предлагало «замер вместо связи блоков», замер показал пересечение.

**Решение:** без прямых ссылок между блоками — общий атрибут на корне `.ag-scope`:
- блок ставит `data-cue` на свой корень **на время своего показа** и снимает по окончании или при прерывании (`"2"` у 02, `"hint"` у 03);
- перед автопоказом блок проверяет `document.querySelector(".ag-scope[data-cue]")`, и если это чужой корень — ждёт: 03 опрашивает каждые 250 мс до 4 с (потом играет), 02 повторяет попытку каждые 300 мс;
- ручные действия читателя (наведение, переключатель, шкала) соглашение не ждут;
- атрибут заодно служит стилем «отметки» (строка/кнопка «Как работают» в 02).
- Проверка (`checks_s8.js`): при обоих блоках в одном экране 10 с опроса раз в 100 мс — одновременно `data-cue` у двух корней ни разу (показы по очереди).

---
