# -*- coding: utf-8 -*-
"""/nofitness (CL04) · проход «дизайн, движение и фишка» (PROMPT_CL04_DESIGN_MOTION_v2, 01.10.2026).
src/CL04-0N_v1.0.0.html → out/CL04-0N_v1.1.0.html. Каждая замена обязана найтись нужное число раз."""
import re, os, sys

sys.path.insert(0, '/home/claude/pr')
from build_prices_dm import rep, rx, focus3, wrap, press_css, touch, GRAIN  # noqa: E402

SRC, OUT = 'src', 'out'
os.makedirs(OUT, exist_ok=True)
DATE = '01.10.2026'

IMG = {
    '22': 'https://static.tildacdn.pub/tild3961-6563-4163-a135-366239333639/22-1024x683.jpg',
    '50': 'https://static.tildacdn.pub/tild3138-6263-4139-a231-383132386437/50-1024x683.jpg',
    '51': 'https://static.tildacdn.pub/tild6464-3663-4266-a161-383031663236/51-1024x683.jpg',
    '57': 'https://static.tildacdn.pub/tild3436-6332-4330-a164-623465663263/57-1024x683.jpg',
}


def load(n):
    return open('%s/CL04-0%d_v1.0.0.html' % (SRC, n), encoding='utf-8').read()


def save(n, t):
    p = '%s/CL04-0%d_v1.1.0.html' % (OUT, n)
    open(p, 'w', encoding='utf-8').write(t)
    print('CL04-0%d v1.1.0 %6d байт' % (n, len(t.encode('utf-8'))))


def bump(t, n, note):
    t = rx(t, r'(APOLLO GYM · CL04-0\d[^\n]*?)· v1\.0\.0 · \d\d\.09\.2026', r'\1· v1.1.0 · 01.10.2026')
    i = t.index('-->') + 3
    return t[:i] + '\n<!-- v1.1.0 (проход «дизайн, движение и фишка», PROMPT_CL04_DESIGN_MOTION_v2, %s):\n     %s -->' % (DATE, note) + t[i:]


def add_css(t, css):
    i = t.index('  </style>')
    return t[:i] + '\n  /* ===== v1.1.0 · дизайн, движение и фишка (01.10) ===== */\n' + css + t[i:]


def grain_css(root, sec, wrap_cls):
    return '''  /* F29 · зерно бумаги (статично, только ≥ 640 px; forced-colors и печать — без зерна) */
  @media (min-width:640px){
    %(r)s .%(s)s::before{content:"";position:absolute;inset:0;z-index:0;pointer-events:none;opacity:.12;background-image:%(g)s;background-size:180px 180px;}
    %(r)s .%(w)s{position:relative;z-index:1;}
  }
  @media (forced-colors:active){%(r)s .%(s)s::before{display:none;}}
  @media print{%(r)s .%(s)s::before{display:none;}}
''' % {'r': root, 's': sec, 'w': wrap_cls, 'g': GRAIN}


# ---------------------------------------------------------------- CL04-01
def c01():
    t = load(1); R = '#ag-cl04-01'
    t = bump(t, 1, 'Факт № 11: «0 ₽ — первое групповое занятие для взрослых» (ряд табло не растёт). Кадр 48 сверен глазами\n'
                   '     01.10: зал с росписью, стойками и покрытием — подпись адресом верна. Магнит снят, F23, фокус 3 px.')
    t = rep(t, 'Плашка «Первое групповое\n     занятие — бесплатно» слита с ячейкой «0 ₽» табло',
            'Плашка «Первое групповое\n     занятие для взрослых — бесплатно» (v1.1.0) слита с ячейкой «0 ₽» табло')
    t = rep(t, '<b>0&nbsp;₽</b><span>первое групповое занятие</span>', '<b>0&nbsp;₽</b><span>первое групповое занятие для&nbsp;взрослых</span>')
    t = rep(t, ' data-ag-magnetic="0.18"', '')
    t = wrap(t, 'a', 'ag-btn ag-btn--primary', 'ag-btn__in')
    t = wrap(t, 'a', 'ag-btn ag-btn--ghost', 'ag-btn__in')
    t = focus3(t, R)
    t = add_css(t, press_css(R, [('ag-btn', 'ag-btn__in')]))
    t = touch(t)
    save(1, t)


# ---------------------------------------------------------------- CL04-02
def c02():
    t = load(2); R = '#ag-cl04-02'
    t = bump(t, 2, 'F29 зерно бумаги (≥ 640 px), фокус 3 px. Текст и строки — как есть.')
    t = focus3(t, R)
    t = add_css(t, grain_css(R, 'ag-nd', 'ag-nd__wrap'))
    save(2, t)


# ---------------------------------------------------------------- CL04-03
def c03():
    t = load(3); R = '#ag-cl04-03'
    t = bump(t, 3, 'Кадр — 57 (сверено глазами 01.10): зона со свободными весами — подпись «Зона со свободными весами» теперь\n'
                   '     правда. Прежний 50 — функциональная рама, ушёл в CL04-04 («Функциональные»). Состав зоны в подписи и alt\n'
                   '     не называем (I071). Фокус 3 px.')
    t = rep(t, '<img class="ag-ns__img" src="%s" width="1024" height="683"' % IMG['50'],
            '<img class="ag-ns__img" src="%s" width="1024" height="683"' % IMG['57'])
    t = focus3(t, R)
    save(3, t)


# ---------------------------------------------------------------- CL04-04
KNOB_JS = r'''    /* v1.1.0 · «Ручка программы крутится» (ведущая фишка страницы). Ручку можно повернуть: потянуть мышью или
       пальцем влево-вправо (угол = угол₀ + сдвиг·k, весь ход ≈ 96 px). Риска идёт за рукой, на границе сектора
       программа переключается вживую (гистерезис 4°) и колпачок коротко «щёлкает»; отпустил — переход 450 мс
       доводит риску до фиксатора, выбор считается выбором читателя (стандарт 57). Касание левой или правой
       половины — соседняя программа в эту сторону. Вертикальный жест — прокрутка страницы (touch-action:pan-y),
       pointercancel возвращает прежнюю программу. Ручка — aria-hidden, без tabindex: она дублирует вкладки. */
    var knob = scale.querySelector(".ag-nk__knob");
    var rot = knob && knob.querySelector(".ag-nk__rot");
    var cap = knob && knob.querySelector(".ag-nk__cap");
    var TURN = [-58, 0, 58];
    var drag = null;
    function rNow() { return W.matchMedia && W.matchMedia("(prefers-reduced-motion: reduce)").matches; }
    function tick() {
      if (rNow() || !cap || !cap.animate) return;
      try { cap.animate([{ transform: "scale(.97)" }, { transform: "scale(1)" }], { duration: 120, easing: "ease-out" }); } catch (err) {}
    }
    function sector(a, cur) {
      var s = a < -29 ? 0 : (a > 29 ? 2 : 1);
      if (s !== cur && Math.abs(Math.abs(a) - 29) < 4) return cur;
      return s;
    }
    function knobCancel() {
      if (!drag) return;
      var d = drag;
      drag = null;
      knob.classList.remove("is-drag");
      rot.style.removeProperty("--turn");
      if (d.on && d.sec !== d.start) select(d.start, false, false);
    }
    if (knob && rot) {
      root.setAttribute("data-ag-ui-knob", "");
      knob.addEventListener("pointerdown", function (e) {
        if (e.button > 0) return;
        var i = current();
        drag = { id: e.pointerId, x: e.clientX, y: e.clientY, t: W.performance.now(), a0: TURN[i], sec: i, start: i, on: false,
                 k: 116 / Math.max(96, 1.2 * knob.offsetWidth) };
        try { knob.setPointerCapture(e.pointerId); } catch (err) {}
      });
      knob.addEventListener("pointermove", function (e) {
        if (!drag || drag.id !== e.pointerId) return;
        var dx = e.clientX - drag.x, dy = e.clientY - drag.y;
        if (!drag.on) {
          if (Math.abs(dx) < 6 && Math.abs(dy) < 6) return;
          if (Math.abs(dx) <= Math.abs(dy)) { knobCancel(); return; }
          drag.on = true;
          knob.classList.add("is-drag");
        }
        var a = drag.a0 + dx * drag.k;
        if (a > 58) a = 58 + (a - 58) * 0.3; else if (a < -58) a = -58 + (a + 58) * 0.3;
        a = Math.max(-70, Math.min(70, a));
        rot.style.setProperty("--turn", a.toFixed(1) + "deg");
        var s = sector(a, drag.sec);
        if (s !== drag.sec) { drag.sec = s; select(s, false, false); tick(); }
      });
      knob.addEventListener("pointerup", function (e) {
        if (!drag || drag.id !== e.pointerId) return;
        var d = drag;
        drag = null;
        if (d.on) {
          knob.classList.remove("is-drag");
          rot.style.removeProperty("--turn");
          select(d.sec, false, true);
          return;
        }
        if (W.performance.now() - d.t > 500) return;
        var r = knob.getBoundingClientRect(), to = current() + (e.clientX > r.left + r.width / 2 ? 1 : -1);
        if (to >= 0 && to < tabs.length) { select(to, false, true); tick(); }
      });
      knob.addEventListener("pointercancel", knobCancel);
      knob.addEventListener("lostpointercapture", function () { if (drag && drag.on) knobCancel(); });
      W.addEventListener("resize", knobCancel);
    }
'''

IND_JS = r'''    /* v1.1.0 · F10: жёлтая подложка выбранной программы переезжает (::before у tablist, над фоном вкладок,
       под подписями). Ряд вкладки — offsetTop без margin дуги: смена ряда (телефон, перенос 2+1 — отступление по Р2) —
       перенос с проявлением; между крайними вкладками на дуге — через вершину (WAAPI, 380 мс). */
    var ind = { on: false, cur: 1, x: null, y: null, w: 0, row: null };
    function rowOf(t) { return t.offsetTop - (parseFloat(W.getComputedStyle(t).marginTop) || 0); }
    function placeInd(i, jump) {
      var t = tabs[i], prev = ind.cur;
      ind.cur = i;
      if (!t || !t.offsetWidth) return;
      var x = t.offsetLeft, y = t.offsetTop, w = t.offsetWidth, h = t.offsetHeight, row = rowOf(t);
      var wrapRow = ind.row !== null && Math.abs(row - ind.row) > h / 2;
      var over = ind.on && !jump && !wrapRow && Math.abs(i - prev) === 2 && !reduce && !!list.animate && ind.x !== null;
      if (!ind.on || jump || wrapRow || over) list.classList.add("is-jump");
      list.style.setProperty("--ix", x + "px");
      list.style.setProperty("--iy", y + "px");
      list.style.setProperty("--iw", w + "px");
      list.style.setProperty("--ih", h + "px");
      if (!ind.on) { list.classList.add("is-ind"); ind.on = true; }
      else if (wrapRow && !jump && !reduce && list.animate) {
        try { list.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 180, easing: "ease-out", pseudoElement: "::before" }); } catch (e) {}
      } else if (over) {
        var top = tabs[1] ? rowOf(tabs[1]) : Math.min(y, ind.y);
        try {
          list.animate([
            { transform: "translate(" + ind.x + "px," + ind.y + "px)", width: ind.w + "px" },
            { transform: "translate(" + ((ind.x + x) / 2) + "px," + top + "px)", width: ((ind.w + w) / 2) + "px", offset: 0.5 },
            { transform: "translate(" + x + "px," + y + "px)", width: w + "px" }
          ], { duration: 380, easing: "cubic-bezier(.22,.61,.36,1)", pseudoElement: "::before" });
        } catch (e) {}
      }
      ind.x = x; ind.y = y; ind.w = w; ind.row = row;
      if (list.classList.contains("is-jump")) W.requestAnimationFrame(function () { W.requestAnimationFrame(function () { list.classList.remove("is-jump"); }); });
    }
'''


def c04():
    t = load(4); R = '#ag-cl04-04'
    t = bump(t, 4, 'Ведущая фишка «Ручка программы крутится»: ручку можно повернуть мышью или пальцем (влево-вправо), на границе\n'
                   '     сектора программа переключается, отпустил — риска встаёт на фиксатор; касание половины — соседняя программа.\n'
                   '     F10: жёлтая подложка программы переезжает по дуге (между крайними — через вершину). Кадры сверены 01.10:\n'
                   '     «Функциональные» — 50 (рама с турниками; прежний 22 — сайкл-студия, со страницы снят), «Сайкл» — 24,\n'
                   '     «Растяжка» — 51 (общий вид зала, кадра занятия нет — слот), alt по кадру. F23 у кнопок низа, фокус 3 px.')
    t = rep(t, '<img class="ag-nk__img" src="%s" width="1024" height="683" alt="Функциональная тренировка в зале на Молодогвардейской"' % IMG['22'],
            '<img class="ag-nk__img" src="%s" width="1024" height="683" alt="Рама с турниками в зале на Молодогвардейской"' % IMG['50'])
    t = rep(t, 'alt="Занятие по растяжке в зале на Молодогвардейской"', 'alt="Общий вид зала на Молодогвардейской"')
    t = wrap(t, 'a', 'ag-btn ag-btn--primary', 'ag-btn__in')
    t = wrap(t, 'a', 'ag-btn ag-btn--ghost ag-nk__call', 'ag-btn__in')
    t = focus3(t, R)
    # вкладки: тень выбранной уходит на подложку, тень не анимируем
    t = rep(t, 'transition:background-color .2s ease,border-color .2s ease,color .2s ease,box-shadow .2s ease;',
            'transition:background-color .2s ease,border-color .2s ease,color .2s ease;')
    t = rep(t, '    function select(i, focus, byReader) {\n', IND_JS + '    function select(i, focus, byReader) {\n')
    t = rep(t, '      root.setAttribute("data-ag-knob", tabs[i].getAttribute("data-knob"));\n',
            '      root.setAttribute("data-ag-knob", tabs[i].getAttribute("data-knob"));\n      placeInd(i, false);\n')
    t = rep(t, '    D.addEventListener("ag:tab", function (e) {\n      var d = e && e.detail;\n',
            KNOB_JS + '    D.addEventListener("ag:tab", function (e) {\n      if (drag) return;\n      var d = e && e.detail;\n')
    t = rep(t, '    select(current(), false, false);\n  })();',
            '    select(current(), false, false);\n'
            '    if ("ResizeObserver" in W) new W.ResizeObserver(function () { placeInd(ind.cur, true); }).observe(list);\n'
            '    if (D.fonts && D.fonts.ready) D.fonts.ready.then(function () { placeInd(ind.cur, true); });\n  })();')
    css = press_css(R, [('ag-btn', 'ag-btn__in')])
    css += '''  /* F10 · подложка выбранной программы: над фоном вкладок, под подписями */
  #ag-cl04-04 .ag-nk__tabs{isolation:isolate;}
  @media not (forced-colors:active){
    #ag-cl04-04 .ag-nk__tabs.is-ind::before{
      content:"";position:absolute;z-index:1;left:0;top:0;width:var(--iw,0px);height:var(--ih,0px);border-radius:var(--r-pill);
      background:var(--accent);box-shadow:0 6px 16px rgba(255,196,0,.28);pointer-events:none;
      transform:translate(var(--ix,0px),var(--iy,0px));
      transition:transform .34s cubic-bezier(.22,.61,.36,1),width .34s cubic-bezier(.22,.61,.36,1),height .34s cubic-bezier(.22,.61,.36,1);
    }
    #ag-cl04-04 .ag-nk__tabs.is-jump::before{transition:none;}
    #ag-cl04-04 .ag-nk__tabs.is-ind .ag-nk__tab>span{position:relative;z-index:2;}
    #ag-cl04-04 .ag-nk__tabs.is-ind .ag-nk__tab[aria-selected="true"]{background:transparent;border-color:transparent;box-shadow:none;}
  }
  @media print{#ag-cl04-04 .ag-nk__tabs::before{display:none;}}
  /* «Ручка программы крутится» */
  #ag-cl04-04[data-ag-ui-knob] .ag-nk__knob{touch-action:pan-y;-webkit-user-select:none;user-select:none;-webkit-touch-callout:none;}
  #ag-cl04-04 .ag-nk__knob.is-drag .ag-nk__rot{transition:none;}
  @media (hover:hover) and (pointer:fine){
    #ag-cl04-04[data-ag-ui-knob] .ag-nk__knob{cursor:grab;}
    #ag-cl04-04 .ag-nk__knob.is-drag{cursor:grabbing;}
  }
'''
    t = add_css(t, css)
    t = touch(t)
    save(4, t)


# ---------------------------------------------------------------- CL04-05
def c05():
    t = load(5); R = '#ag-cl04-05'
    t = bump(t, 5, 'F23 — нажатие кнопки, фокус 3 px. Состав и текст — как есть (I040 — написание фамилии ждёт владельца).')
    t = wrap(t, 'a', 'ag-btn ag-btn--ghost', 'ag-btn__in')
    t = focus3(t, R)
    t = add_css(t, press_css(R, [('ag-btn', 'ag-btn__in')]))
    t = touch(t)
    save(5, t)


# ---------------------------------------------------------------- CL04-06
def c06():
    t = load(6); R = '#ag-cl04-06'
    t = bump(t, 6, 'Факт № 11: «Первое групповое занятие для взрослых — бесплатно.» Таблица и тариф — как есть.\n'
                   '     F29 зерно бумаги (≥ 640 px). F23 — нажатие кнопок, фокус 3 px. Телефон: условия плотнее.')
    t = rep(t, '<span>Первое групповое занятие — бесплатно.</span>', '<span>Первое групповое занятие для взрослых — бесплатно.</span>')
    t = wrap(t, 'a', 'ag-btn ag-btn--primary', 'ag-btn__in')
    t = wrap(t, 'a', 'ag-btn ag-btn--ghost', 'ag-btn__in')
    t = focus3(t, R)
    css = press_css(R, [('ag-btn', 'ag-btn__in')])
    css += grain_css(R, 'ag-np', 'ag-np__wrap')
    css += '''  @media (max-width:599px){
    /* «для взрослых» переносит строку — лист плотнее, телефон не длиннее v1.0.0 */
    #ag-cl04-06 .ag-np__terms li{line-height:1.35;}
    #ag-cl04-06 .ag-np__card{padding-top:16px;padding-bottom:14px;}
    #ag-cl04-06 .ag-np__terms{gap:4px;}
    #ag-cl04-06 .ag-np__table{margin-top:14px;}
  }
'''
    t = add_css(t, css)
    t = touch(t)
    save(6, t)


# ---------------------------------------------------------------- CL04-07
def share_new():
    src = open('/home/claude/mm/build_cl02_dm.py', encoding='utf-8').read()
    s = re.search(r"SHARE_NEW = '''(.*?)'''", src, re.S).group(1)
    s = s.replace('\\\\s', '\\s')
    for o, n in [('.ag-mr__street', '.ag-nr__street'), ('"Самара, улица Чкалова, 72"', '"Самара, улица Молодогвардейская, 56"'),
                 ('title: "Apollo MMA Gym", text: "Apollo MMA Gym, "', 'title: "Apollo NoFitness", text: "Apollo NoFitness, "')]:
        assert s.count(o) == 1, o
        s = s.replace(o, n)
    return s


def c07():
    t = load(7); R = '#ag-cl04-07'
    t = bump(t, 7, '«Скопировать адрес» (ПК и телефон, где есть буфер обмена) с подтверждением «Адрес скопирован» в aria-live;\n'
                   '     «Поделиться адресом» — только на сенсорном экране (на телефоне обе кнопки в один ряд). Карта — как была.\n'
                   '     F23 — нажатие кнопок, фокус 3 px.')
    t = rx(t, r'(<button class="ag-btn ag-btn--quiet" type="button" data-ag-share hidden>)(.*?)(</button>)',
           lambda m: m.group(1) + '<span class="ag-btn__in">' + m.group(2) + '</span>' + m.group(3))
    copybtn = ('<button class="ag-btn ag-btn--quiet" type="button" data-ag-ui-copy hidden><span class="ag-btn__in">'
               '<svg class="ag-btn__i" width="16" height="16" viewBox="0 0 16 16" aria-hidden="true" focusable="false">'
               '<rect x="5.5" y="5.5" width="8" height="8.5" rx="1.6" fill="none" stroke="currentColor" stroke-width="1.6"/>'
               '<path d="M10.5 3.5V3a1.5 1.5 0 0 0-1.5-1.5H4A1.5 1.5 0 0 0 2.5 3v6A1.5 1.5 0 0 0 4 10.5h.5" fill="none" stroke="currentColor" stroke-width="1.6"/></svg>'
               'Скопировать адрес</span></button> <span class="ag-nr__copied" data-ag-ui-copied aria-live="polite"></span>')
    t = rx(t, r'(<button class="ag-btn ag-btn--quiet" type="button" data-ag-share hidden>.*?</button>)', lambda m: m.group(1) + '\n          ' + copybtn)
    t = wrap(t, 'a', 'ag-btn ag-btn--primary', 'ag-btn__in')
    t = wrap(t, 'a', 'ag-btn ag-btn--ghost', 'ag-btn__in')
    t = wrap(t, 'a', 'ag-btn ag-btn--ghost ag-nr__call', 'ag-btn__in')
    t = focus3(t, R)
    old = '    var btn = root.querySelector("[data-ag-share]");\n'
    i = t.index(old)
    j = t.index('  })();\n', i) + len('  })();\n')
    t = t[:i] + share_new() + t[j:]
    css = press_css(R, [('ag-btn', 'ag-btn__in')])
    css += '''  #ag-cl04-07 .ag-nr__copied{flex-basis:100%;font-size:14px;font-weight:600;color:var(--accent);}
  #ag-cl04-07 .ag-nr__copied:empty{display:none;}
  @media (max-width:767.98px){
    /* «Скопировать» и «Поделиться» — в один ряд */
    #ag-cl04-07 .ag-btn--quiet{flex:1 1 40%;}
  }
'''
    t = add_css(t, css)
    save(7, t)


# ---------------------------------------------------------------- CL04-08
def c08():
    t = load(8); R = '#ag-cl04-08'
    t = bump(t, 8, 'Факт № 11 и условие сайкла в ответе «Сколько стоит заниматься?»: «Первое групповое для взрослых — бесплатно.\n'
                   '     Условия для сайкла уточните отдельно при записи.» (фраза уже есть на странице; FAQPage в HEAD — тем же\n'
                   '     текстом, генератор). F22: ответ раскрывается плавно (::details-content + interpolate-size, прогрессивно);\n'
                   '     «Раскрыть все» — без перехода; refresh и по toggle, и по окончании перехода высоты. F23, фокус 3 px.')
    t = rep(t, 'это 500&nbsp;₽ за занятие. Первое групповое — бесплатно.</p>',
            'это 500&nbsp;₽ за занятие. Первое групповое для взрослых — бесплатно. Условия для сайкла уточните отдельно при записи.</p>')
    t = wrap(t, 'button', 'ag-fq__all', 'ag-fq__ain')
    t = focus3(t, R)
    css = press_css(R, [('ag-fq__all', 'ag-fq__ain')])
    css += '''  /* F22 · плавное раскрытие ответа (Chromium 131+); иначе — мгновенно, как было */
  @supports (interpolate-size:allow-keywords) and selector(::details-content){
    #ag-cl04-08 .ag-fq__list{interpolate-size:allow-keywords;}
    #ag-cl04-08 .ag-fq__item::details-content{
      height:0;overflow:clip;
      transition:height .32s cubic-bezier(.22,.61,.36,1),content-visibility .32s allow-discrete;
    }
    #ag-cl04-08 .ag-fq__item[open]::details-content{height:auto;}
    #ag-cl04-08.is-bulk .ag-fq__item::details-content{transition:none;}
    @media (prefers-reduced-motion:reduce){
      #ag-cl04-08 .ag-fq__item::details-content{transition:none;}
    }
  }
'''
    t = add_css(t, css)
    t = rx(t, r'(      busy = true;\n)(.*?)(      busy = false;\n)',
           lambda m: m.group(1) + '      root.classList.add("is-bulk");\n' + m.group(2) + m.group(3)
           + '      W.requestAnimationFrame(function () { W.requestAnimationFrame(function () { root.classList.remove("is-bulk"); }); });\n')
    t = rep(t, '      d.addEventListener("toggle", function () { if (!busy) { sync(); refresh(); } });\n    });\n',
            '      d.addEventListener("toggle", function () { if (!busy) { sync(); refresh(); } });\n    });\n'
            '    /* v1.1.0: высота ответа меняется переходом — пересчитать позиции анимаций ниже по окончании */\n'
            '    root.addEventListener("transitionend", function (e) {\n'
            '      if (e.propertyName === "height" && e.pseudoElement === "::details-content") refresh();\n'
            '    });\n')
    t = touch(t)
    save(8, t)


# ---------------------------------------------------------------- CL04-09
def c09():
    t = load(9); R = '#ag-cl04-09'
    t = bump(t, 9, 'Фокус 3 px. Остальное — как есть.')
    t = focus3(t, R)
    save(9, t)


if __name__ == '__main__':
    for f in (c01, c02, c03, c04, c05, c06, c07, c08, c09):
        f()
