// /nofitness (CL04) · проверки прохода «дизайн, движение и фишка» (PROMPT_CL04_DESIGN_MOTION_v2)
const {open,settle}=require('./lib');const fs=require('fs'),path=require('path');
const AFTER='file://'+path.resolve('after.html'), BEFORE='file://'+path.resolve('before.html');
const out={};const log=(g,ok,msg)=>{const s=(ok?"pass ":"FAIL ")+msg;(out[g]=out[g]||[]).push(s);console.log(g+" "+s);};
const G=process.env.G||'LTCMFA';
async function txt(url){const {browser,page}=await open({reduce:true});await page.goto(url);await page.waitForTimeout(2600);
  const r=await page.evaluate(()=>{const o={};document.querySelectorAll('.ag-scope').forEach(r=>{const c=r.cloneNode(true);c.querySelectorAll('style,script,.ag-vh').forEach(x=>x.remove());o[r.id]=c.textContent.replace(/\s+/g,' ').trim();});return o;});await browser.close();return r;}
async function links(url){const {browser,page}=await open({reduce:true});await page.goto(url);await page.waitForTimeout(400);
  const r=await page.evaluate(()=>[...document.querySelectorAll('.ag-scope a[href]')].map(a=>a.closest('.ag-scope').id+' '+a.getAttribute('href')));await browser.close();return r;}
const ST=`(()=>{const r=document.getElementById('ag-cl04-04');const tabs=[...r.querySelectorAll('.ag-nk__tab')];const sel=tabs.findIndex(t=>t.getAttribute('aria-selected')==='true');
  const on=[...r.querySelectorAll('.ag-nk__panel')].findIndex(p=>p.classList.contains('is-on'));const rot=r.querySelector('.ag-nk__rot');const tr=getComputedStyle(rot).transform;let deg=0;if(tr&&tr!=='none'){const m=new DOMMatrix(tr);deg=Math.atan2(m.b,m.a)*180/Math.PI;}
  return {sel,on,knob:r.getAttribute('data-ag-knob'),inline:rot.style.getPropertyValue('--turn'),deg:+deg.toFixed(1),ask:r.querySelector('[data-ag-ask]').getAttribute('href'),drag:r.querySelector('.ag-nk__knob').classList.contains('is-drag')};})()`;
const IND=(i)=>`(()=>{const l=document.querySelector('#ag-cl04-04 .ag-nk__tabs'),t=document.querySelectorAll('#ag-cl04-04 .ag-nk__tab')[${i}];const cs=getComputedStyle(l,'::before');const m=new DOMMatrix(cs.transform);return {x:m.m41,y:m.m42,w:parseFloat(cs.width),h:parseFloat(cs.height),tx:t.offsetLeft,ty:t.offsetTop,tw:t.offsetWidth,th:t.offsetHeight,bg:getComputedStyle(t).backgroundColor,sh:getComputedStyle(t).boxShadow,c:cs.content};})()`;
const ok=(r)=>Math.abs(r.x-r.tx)<1&&Math.abs(r.y-r.ty)<1&&Math.abs(r.w-r.tw)<1&&Math.abs(r.h-r.th)<1;
async function knobBox(page){await page.evaluate(()=>{const k=document.querySelector('#ag-cl04-04 .ag-nk__knob').getBoundingClientRect();scrollTo(0,scrollY+k.top-innerHeight/2);});await page.waitForTimeout(500);return (await page.$('#ag-cl04-04 .ag-nk__knob')).boundingBox();}
async function mdrag(page,b,dx,steps=10,hold){const cx=b.x+b.width/2,cy=b.y+b.height/2;await page.mouse.move(cx,cy);await page.mouse.down();for(let i=1;i<=steps;i++){await page.mouse.move(cx+dx*i/steps,cy+(i%2));await page.waitForTimeout(16);}const mid=await page.evaluate(ST);if(hold)await hold();await page.mouse.up();await page.waitForTimeout(600);return mid;}
(async()=>{
 if(G.includes('L')) for(const reduce of [false,true]) for(const fontsOff of [false,true]) for(const w of [320,360,390,768,1024,1440,1920]){
   const {browser,page}=await open({w,h:w<700?800:900,reduce,mobile:w<700,touch:w<700});
   if(fontsOff) await page.route('**/fonts.googleapis.com/**',r=>r.abort());
   await page.goto(AFTER);await settle(page);
   const r=await page.evaluate(()=>({ov:document.documentElement.scrollWidth>document.documentElement.clientWidth,h:document.body.scrollHeight}));
   log('L',!r.ov,`${w}px reduce=${reduce} fontsOff=${fontsOff} overflowX=${r.ov} h=${r.h}`);await browser.close();
 }
 if(G.includes('T')){const tb=await txt(BEFORE),ta=await txt(AFTER);
  const EXC={'ag-cl04-01':[['первое групповое занятие для взрослых','первое групповое занятие']],
   'ag-cl04-06':[['Первое групповое занятие для взрослых — бесплатно.','Первое групповое занятие — бесплатно.']],
   'ag-cl04-07':[[' Скопировать адрес','']],
   'ag-cl04-08':[['Первое групповое для взрослых — бесплатно. Условия для сайкла уточните отдельно при записи.','Первое групповое — бесплатно.']]};
  for(const id of Object.keys(tb)){let a=ta[id];(EXC[id]||[]).forEach(([n,o])=>{a=a.split(n).join(o);});a=a.replace(/\s+/g,' ').trim();let i=0;while(i<tb[id].length&&tb[id][i]===a[i])i++;
   log('T',a===tb[id],id+(a===tb[id]?' текст совпадает'+(EXC[id]?' (кроме правок: '+EXC[id].map(x=>'«'+x[0]+'»').join(', ')+')':''):' РАЗНИЦА '+JSON.stringify(tb[id].slice(i-30,i+40))+' → '+JSON.stringify(a.slice(i-30,i+40))));}
  const html=fs.readFileSync('after.html','utf8');const alts=(html.match(/alt="[^"]*"/g)||[]).join(' ')+' '+(html.match(/<figcaption[\s\S]*?<\/figcaption>/g)||[]).join(' ');
  const bad=/гир[яи]|диск|гриф|покрышк|штанг|занятие по растяжке|функциональная тренировка в зале/i;
  const used=['57-1024','50-1024','24-1024','51-1024','48-1024'].map(k=>html.includes(k));
  log('T',!bad.test(alts)&&!html.includes('22-1024x683')&&used.every(Boolean),`кадры: 57/50/24/51/48 на месте, 22 снят; в подписях и alt нет «гири, диски, грифы, покрышки» и старых alt «занятие по растяжке»/«функциональная тренировка»: ${!bad.test(alts)}`);}
 if(G.includes('C')){const lb=await links(BEFORE),la=await links(AFTER);const add=la.filter(x=>!lb.includes(x)),rem=lb.filter(x=>!la.includes(x));
  log('C',rem.length===0&&add.length===0,`ссылки +${add.length} −${rem.length}`);}
 if(G.includes('M')){
  for(const mode of [{name:'js off',js:false},{name:'reduce',reduce:true},{name:'cdn fail',cdn:'fail'},{name:'cdn hang',cdn:'hang'}]){
   const {browser,page}=await open({w:390,h:800,mobile:true,...mode});await page.goto(AFTER,{waitUntil:'domcontentloaded'});await page.waitForTimeout(2700);
   if(mode.js!==false) for(let y=0;y<9000;y+=600){await page.evaluate(y=>scrollTo(0,y),y);await page.waitForTimeout(40);}
   const r=await page.evaluate(()=>{const bad=[];document.querySelectorAll('.ag-scope :is(p,h1,h2,h3,a,li,dt,dd,summary,td,th,figcaption)').forEach(el=>{if(el.closest('[aria-hidden="true"],[hidden],dialog'))return;let n=el,op=1;while(n&&n.nodeType===1){op*=parseFloat(getComputedStyle(n).opacity);n=n.parentElement;}if(getComputedStyle(el).display==='none')return;if(op<0.99&&el.textContent.trim())bad.push(el.textContent.trim().slice(0,30));});
     const p=[...document.querySelectorAll('#ag-cl04-04 .ag-nk__panel')].filter(x=>getComputedStyle(x).visibility==='visible').length;return {bad,m:document.documentElement.getAttribute('data-ag-motion'),p};});
   log('M',r.bad.length===0&&(mode.js===false?r.p===3:r.p===1),`${mode.name}: motion=${r.m} скрытых текстов ${r.bad.length} ${r.bad.slice(0,3).join('|')}; видимых панелей 04: ${r.p}`);await browser.close();}
  const {browser,page}=await open({w:1440});await page.goto(AFTER);await settle(page);
  const r=await page.evaluate(()=>{const o={};document.querySelectorAll('.ag-scope').forEach(root=>{const all=root.querySelectorAll('[data-ag-anim]');o[root.id]=[all.length,[...all].filter(e=>!e.hasAttribute('data-ag-done')).length];});return o;});
  for(const [id,[n,left]] of Object.entries(r)) log('M',left===0,`motion on: ${id} анимаций ${n}, не отсканировано ${left}`);await browser.close();}

 if(G.includes('F')){
  // ---- 04 «Ручка программы крутится»: мышь
  {const {browser,page,errs}=await open({w:1440,h:900});await page.goto(AFTER);await settle(page);
   let b=await knobBox(page);const s0=await page.evaluate(ST);
   const cur=await page.$eval('#ag-cl04-04 .ag-nk__knob',e=>getComputedStyle(e).cursor);
   log('F',s0.sel===1&&s0.knob==='cycle'&&s0.inline===''&&!/direction/.test(s0.ask)&&cur==='grab',`ручка, ПК: в покое — «Сайкл», курсор ${cur}, в ссылке /request направления нет (${s0.ask})`);
   const mid=await mdrag(page,b,80);const s1=await page.evaluate(ST);
   log('F',mid.drag&&mid.sel===2&&mid.deg>29&&s1.sel===2&&s1.on===2&&s1.knob==='stretching'&&s1.inline===''&&!s1.drag&&/direction=stretching-samara/.test(s1.ask)&&Math.abs(s1.deg-58)<1,`ручка, ПК: тянем вправо 80 px — риска за рукой (${mid.deg}°), «Растяжка» включилась вживую; отпустили — фиксатор ${s1.deg}°, инлайн снят, выбор читателя (${s1.ask.split('?')[1]})`);
   b=await knobBox(page);const mid2=await mdrag(page,b,-170);const s2=await page.evaluate(ST);
   log('F',s2.sel===0&&s2.knob==='functional'&&Math.abs(s2.deg+58)<1&&mid2.deg>=-70.1,`ручка, ПК: влево 170 px — через «Сайкл» на «Функциональные», упор не дальше −70° (в жесте ${mid2.deg}°), фиксатор ${s2.deg}°`);
   b=await knobBox(page);await mdrag(page,b,18);const s3=await page.evaluate(ST);
   log('F',s3.sel===0&&Math.abs(s3.deg+58)<1,`ручка, ПК: короткий сдвиг 18 px — сектор не сменился, риска вернулась на фиксатор (${s3.deg}°)`);
   b=await knobBox(page);await page.mouse.click(b.x+b.width*0.25,b.y+b.height/2);await page.waitForTimeout(500);const t0=await page.evaluate(ST);
   await page.mouse.click(b.x+b.width*0.75,b.y+b.height/2);await page.waitForTimeout(500);const t1=await page.evaluate(ST);
   await page.mouse.click(b.x+b.width*0.75,b.y+b.height/2);await page.waitForTimeout(500);await page.mouse.click(b.x+b.width*0.75,b.y+b.height/2);await page.waitForTimeout(500);const t2=await page.evaluate(ST);
   log('F',t0.sel===0&&t1.sel===1&&t2.sel===2,`ручка, ПК: щелчок по левой половине на краю — без изменений (${t0.sel}); по правой — соседняя (${t1.sel}), на краю справа — остаётся (${t2.sel})`);
   // вертикальный жест мышью — не крутит
   b=await knobBox(page);await page.mouse.move(b.x+b.width/2,b.y+b.height/2);await page.mouse.down();for(let i=1;i<=8;i++){await page.mouse.move(b.x+b.width/2+2,b.y+b.height/2+i*8);await page.waitForTimeout(16);}await page.mouse.up();await page.waitForTimeout(400);const v=await page.evaluate(ST);
   // табло → ag:tab не считается выбором для /request (на свежей странице)
   await page.goto(AFTER);await settle(page);await page.evaluate(()=>{const k=document.querySelectorAll('#ag-cl04-04 .ag-nk__tab')[0];k.click();});
   await page.reload();await settle(page);
   await page.evaluate(()=>document.querySelector('#ag-cl04-01 [data-ag-tab]').click());await page.waitForTimeout(700);const e1=await page.evaluate(ST);
   log('F',v.sel===2&&e1.sel===1&&!/direction/.test(e1.ask)&&errs.length===0,`ручка: вертикальный жест не крутит (${v.sel}); ячейка «1» табло открывает «Сайкл» без направления в /request (${e1.ask}); ошибок ${errs.length} ${errs[0]||''}`);
   await browser.close();}
  // ---- подложка F10 на дуге, ПК
  {const {browser,page}=await open({w:1440,h:900});await page.goto(AFTER);await settle(page);await knobBox(page);
   const r1=await page.evaluate(IND(1));
   log('F',ok(r1)&&r1.bg==='rgba(0, 0, 0, 0)'&&r1.sh==='none',`подложка, ПК: под «Сайклом» (${Math.round(r1.x)},${Math.round(r1.y)} ${Math.round(r1.w)}×${Math.round(r1.h)} ↔ ${r1.tx},${r1.ty}), у вкладки фон и тень сняты`);
   await page.click('#ag-cl04-04 .ag-nk__tab >> nth=2');await page.waitForTimeout(110);const m2=await page.evaluate(IND(2));await page.waitForTimeout(420);const r2=await page.evaluate(IND(2));
   log('F',ok(r2)&&m2.x>r1.tx+2&&m2.x<r2.tx-2,`подложка, ПК: «Сайкл» → «Растяжка» — едет (на 110 мс x=${Math.round(m2.x)}, в конце ${Math.round(r2.x)} ↔ ${r2.tx})`);
   await page.click('#ag-cl04-04 .ag-nk__tab >> nth=0');await page.waitForTimeout(30);
   const an=await page.evaluate(()=>document.querySelector('#ag-cl04-04 .ag-nk__tabs').getAnimations({subtree:true}).filter(a=>a.effect&&a.effect.pseudoElement==='::before').length);
   await page.waitForTimeout(160);const m0=await page.evaluate(IND(0));await page.waitForTimeout(400);const r0=await page.evaluate(IND(0));
   log('F',an===1&&ok(r0)&&m0.y<r0.ty-4,`подложка, ПК: «Растяжка» → «Функциональные» — через вершину дуги (WAAPI ${an}, на 190 мс y=${Math.round(m0.y)} выше края ${r0.ty}), в конце на месте`);
   await (await page.$('#ag-cl04-04')).screenshot({path:'shots/knob_1440.png'});
   await page.setViewportSize({width:768,height:900});await page.waitForTimeout(400);const a=await page.evaluate(IND(0));
   await page.setViewportSize({width:767,height:900});await page.waitForTimeout(400);const bq=await page.evaluate(IND(0));
   log('F',ok(a)&&ok(bq),`подложка: 1440 → 768 → 767 — на месте (${Math.round(a.x)},${Math.round(a.y)} / ${Math.round(bq.x)},${Math.round(bq.y)})`);
   await browser.close();}
  // ---- телефон: раскладки, перенос ряда, ручка пальцем, свайп по ручке
  for(const w of [320,360,390,600]){const {browser,page,errs}=await open({w,h:844,mobile:true,touch:true});await page.goto(AFTER);await settle(page);
   const b=await knobBox(page);
   const rows=await page.$$eval('#ag-cl04-04 .ag-nk__tab',x=>x.map(t=>t.offsetTop));
   const tb=await (await page.$$('#ag-cl04-04 .ag-nk__tab'))[2].boundingBox();await page.touchscreen.tap(tb.x+tb.width/2,tb.y+tb.height/2);await page.waitForTimeout(40);
   const an=await page.evaluate(()=>document.querySelector('#ag-cl04-04 .ag-nk__tabs').getAnimations({subtree:true}).filter(a=>a.effect&&a.effect.pseudoElement==='::before').length);
   await page.waitForTimeout(450);const r2=await page.evaluate(IND(2));const wrapRow=rows[2]!==rows[1];
   const ov=await page.evaluate(()=>[...document.querySelectorAll('#ag-cl04-04 .ag-nk__tab span')].some(e=>e.scrollWidth>e.parentElement.clientWidth+1));
   let msg=`ряды вкладок ${[...new Set(rows)].length}; касание «Растяжки» — ${wrapRow?'перенос с проявлением ('+an+')':'едет по ряду'}, подложка на месте (${Math.round(r2.x)},${Math.round(r2.y)} ↔ ${r2.tx},${r2.ty}); подписи не обрезаны`;
   let pass=ok(r2)&&(!wrapRow||an===1)&&!ov;
   if(w===390){
    // палец по горизонтали — смена программы
    const cdp=await page.context().newCDPSession(page);const k=await knobBox(page);const cx=k.x+k.width/2,cy=k.y+k.height/2;
    await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x:cx,y:cy}]});for(let i=1;i<=10;i++){await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:cx-i*9,y:cy}]});await page.waitForTimeout(16);}
    await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await page.waitForTimeout(600);const h1=await page.evaluate(ST);
    // палец по вертикали от ручки — прокрутка, программа та же
    const k2=await knobBox(page);const y0=await page.evaluate(()=>scrollY);const c2x=k2.x+k2.width/2,c2y=k2.y+k2.height/2;
    await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x:c2x,y:c2y}]});for(let i=1;i<=12;i++){await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:c2x+(i%2),y:c2y-i*25}]});await page.waitForTimeout(16);}
    await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await page.waitForTimeout(700);const y1=await page.evaluate(()=>scrollY);const h2=await page.evaluate(ST);
    await (await page.$('#ag-cl04-04')).screenshot({path:'shots/knob_390.png'});
    pass=pass&&h1.sel<2&&h1.inline===''&&/direction=/.test(h1.ask)&&y1-y0>100&&h2.sel===h1.sel&&errs.length===0;
    msg+=`; палец влево 90 px — «${['Функциональные','Сайкл','Растяжка'][h1.sel]}» (выбор читателя); свайп вверх от ручки — прокрутка ${y0}→${y1}, программа та же; ошибок ${errs.length}`;}
   log('F',pass,`телефон ${w}px: ${msg}`);await browser.close();}
  // ---- reduce: жест работает, доводка без перехода; reduce на лету; forced-colors
  {const {browser,page}=await open({w:1440,h:900,reduce:true});await page.goto(AFTER);await settle(page);const b=await knobBox(page);
   await mdrag(page,b,80);await page.waitForTimeout(-500+520);const s=await page.evaluate(ST);
   log('F',s.sel===2&&Math.abs(s.deg-58)<1,`ручка, reduce: жест работает (прямое управление), риска сразу на фиксаторе (${s.deg}°)`);await browser.close();}
  {const {browser,page}=await open({w:1440,h:900});await page.emulateMedia({forcedColors:'active'});await page.goto(AFTER);await settle(page);
   const fc=await page.evaluate(()=>({k:getComputedStyle(document.querySelector('#ag-cl04-04 .ag-nk__knob')).display,b:getComputedStyle(document.querySelector('#ag-cl04-04 .ag-nk__tabs'),'::before').content,sel:getComputedStyle(document.querySelector('#ag-cl04-04 .ag-nk__tab[aria-selected="true"]')).backgroundColor}));
   await page.click('#ag-cl04-04 .ag-nk__tab >> nth=0');await page.waitForTimeout(300);const s=await page.evaluate(ST);
   log('F',fc.k==='none'&&fc.b==='none'&&fc.sel!=='rgba(0, 0, 0, 0)'&&s.sel===0,`forced-colors: ручки нет, подложки нет, выбранная вкладка своей заливкой (${fc.sel}); вкладки работают`);await browser.close();}
  // ---- 07 «Скопировать адрес»
  {const {browser,page,errs}=await open({w:1440,h:900});await page.context().grantPermissions(['clipboard-read','clipboard-write']);
   await page.goto(AFTER);await settle(page);await page.evaluate(()=>document.getElementById('ag-cl04-07').scrollIntoView());await page.waitForTimeout(400);
   const st=await page.evaluate(()=>({copy:!document.querySelector('#ag-cl04-07 [data-ag-ui-copy]').hidden,share:!document.querySelector('#ag-cl04-07 [data-ag-share]').hidden}));
   await page.click('#ag-cl04-07 [data-ag-ui-copy]');await page.waitForTimeout(300);
   const r=await page.evaluate(async()=>{let clip='';try{clip=await Promise.race([navigator.clipboard.readText(),new Promise(r=>setTimeout(()=>r('(нет доступа: тайм-аут)'),1500))]);}catch(e){clip='(нет доступа: '+e.name+')';}return {note:document.querySelector('#ag-cl04-07 [data-ag-ui-copied]').textContent,clip};});
   await page.waitForTimeout(3200);const gone=await page.$eval('#ag-cl04-07 [data-ag-ui-copied]',e=>e.textContent);
   log('F',st.copy&&!st.share&&r.note==='Адрес скопирован'&&r.clip==='Самара, улица Молодогвардейская, 56'&&gone===''&&errs.length===0,`копирование, ПК: кнопка видна, «Поделиться» скрыта; «${r.note}», в буфере «${r.clip}», через 3 с подтверждение ушло`);
   await browser.close();}
  {const {browser,page}=await open({w:390,h:844,mobile:true,touch:true});await page.addInitScript(()=>{navigator.share=()=>Promise.resolve();});await page.goto(AFTER);await settle(page);
   await page.evaluate(()=>document.getElementById('ag-cl04-07').scrollIntoView());await page.waitForTimeout(300);
   const r=await page.evaluate(()=>{const c=document.querySelector('#ag-cl04-07 [data-ag-ui-copy]'),s=document.querySelector('#ag-cl04-07 [data-ag-share]');const a=c.getBoundingClientRect(),b=s.getBoundingClientRect();return {c:!c.hidden,s:!s.hidden,row:Math.abs(a.top-b.top)<2,h:Math.round(a.height)};});
   await (await page.$('#ag-cl04-07')).screenshot({path:'shots/copy_share_390.png'});
   log('F',r.c&&r.s&&r.row&&r.h>=44,`копирование, телефон с Web Share: обе кнопки в один ряд (${r.row}), высота ${r.h}`);await browser.close();}
  // ---- 08 F22 + FAQPage
  {const {browser,page}=await open({w:1440,h:900});await page.goto(AFTER);await settle(page);
   await page.evaluate(()=>document.getElementById('ag-cl04-08').scrollIntoView());await page.waitForTimeout(400);
   const H=n=>page.evaluate(n=>Math.round(document.querySelector('#ag-cl04-08 .ag-fq__item:nth-of-type('+n+')').getBoundingClientRect().height),n);
   const h0=await H(2);await page.click('#ag-cl04-08 .ag-fq__item:nth-of-type(2) summary');await page.waitForTimeout(90);const hm=await H(2);await page.waitForTimeout(450);const h1=await H(2);
   const HA=()=>page.evaluate(()=>[...document.querySelectorAll('#ag-cl04-08 .ag-fq__item')].map(d=>Math.round(d.getBoundingClientRect().height)).join(','));
   await page.click('#ag-cl04-08 .ag-fq__all');await page.waitForTimeout(40);const b1=await HA();await page.waitForTimeout(500);const b2=await HA();
   const st=await page.evaluate(()=>({open:[...document.querySelectorAll('#ag-cl04-08 .ag-fq__item')].filter(d=>d.open).length,n:document.querySelectorAll('#ag-cl04-08 .ag-fq__item').length,bulk:document.getElementById('ag-cl04-08').classList.contains('is-bulk')}));
   log('F',h0<hm&&hm<h1&&b1===b2&&st.open===st.n&&!st.bulk,`FAQ: ответ раскрывается плавно (${h0} → ${hm} на 90 мс → ${h1}), «Раскрыть все» — все ${st.open} сразу без перехода (${b1===b2}), is-bulk снят`);
   const head=JSON.parse(fs.readFileSync('out/HEAD_nofitness_v1.1.html','utf8').match(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/)[1]);
   const faq=head['@graph'].find(n=>n['@type']==='FAQPage').mainEntity;const wp=head['@graph'].find(n=>n['@type']==='WebPage');
   const qs=await page.evaluate(()=>[...document.querySelectorAll('#ag-cl04-08 .ag-fq__item')].map(d=>[d.querySelector('.ag-fq__qt').textContent.replace(/\s+/g,' ').trim(),d.querySelector('.ag-fq__a').textContent.replace(/\s+/g,' ').trim()]));
   const same=qs.length===faq.length&&qs.every(([q,a],i)=>faq[i].name===q&&faq[i].acceptedAnswer.text===a);
   log('F',same&&/Условия первого занятия — при записи\.$/.test(wp.description)&&!/бесплатн/.test(wp.description),`FAQPage в HEAD v1.1 = блок 08 дословно (${qs.length}): ${same}; description WebPage — цель архива без «бесплатно»`);
   await browser.close();}
  // ---- магниты, F23, зерно
  {const {browser,page}=await open({w:1440,h:900});await page.goto(AFTER);await settle(page);
   const mag=await page.$$eval('[data-ag-magnetic]',x=>x.length);log('F',mag===0,`магнитных кнопок: ${mag}`);
   const res=[];
   for(const [sel,inn] of [['#ag-cl04-01 .ag-btn--primary','.ag-btn__in'],['#ag-cl04-04 .ag-btn--primary','.ag-btn__in'],['#ag-cl04-05 .ag-btn--ghost','.ag-btn__in'],['#ag-cl04-06 .ag-btn--primary','.ag-btn__in'],['#ag-cl04-07 .ag-btn--primary','.ag-btn__in'],['#ag-cl04-08 .ag-fq__all','.ag-fq__ain']]){
    const el=await page.$(sel);if(!el){res.push(sel+': нет');continue;}await el.scrollIntoViewIfNeeded();await page.waitForTimeout(250);const b0=await el.boundingBox();
    await page.evaluate(s=>document.querySelector(s).addEventListener('click',e=>e.preventDefault(),{once:true}),sel);
    await page.mouse.move(b0.x+b0.width/2,b0.y+b0.height/2);await page.mouse.down();await page.waitForTimeout(220);
    const t=await page.$eval(sel+' '+inn,e=>getComputedStyle(e).transform);const b1=await el.boundingBox();await page.mouse.up();await page.waitForTimeout(80);
    res.push([sel.split(' ')[0].slice(-2),/matrix\(0\.98/.test(t)&&Math.abs(b1.x-b0.x)<0.5]);}
   log('F',res.every(r=>Array.isArray(r)&&r[1]===true),`F23 нажатие: ${res.map(r=>Array.isArray(r)?r.join(':'):r).join(' ')}`);
   const tabT=await page.$eval('#ag-cl04-04 .ag-nk__tab',e=>getComputedStyle(e).transitionProperty);
   const gr=await page.evaluate(()=>['#ag-cl04-02 .ag-nd','#ag-cl04-06 .ag-np'].map(s=>/svg/.test(getComputedStyle(document.querySelector(s),'::before').backgroundImage)));
   log('F',gr.every(Boolean)&&!/box-shadow/.test(tabT),`зерно бумаги на ПК: 02 ${gr[0]}, 06 ${gr[1]}; у вкладок тень не анимируется (${tabT})`);await browser.close();}
  {const {browser,page}=await open({w:390,h:844,mobile:true,touch:true});await page.goto(AFTER);await settle(page);
   const gr=await page.evaluate(()=>['#ag-cl04-02 .ag-nd','#ag-cl04-06 .ag-np'].map(s=>/svg/.test(getComputedStyle(document.querySelector(s),'::before').backgroundImage)));
   log('F',!gr[0]&&!gr[1],`телефон: зерна нет (02 ${gr[0]}, 06 ${gr[1]})`);await browser.close();}
 }
 if(G.includes('A')){const axeSrc=fs.readFileSync(require.resolve('axe-core/axe.min.js'),'utf8');
  for(const m of [{w:1440},{w:1024},{w:390,mobile:true},{w:390,mobile:true,reduce:true},{w:390,nojs:true}]){
   let o;if(m.nojs){fs.writeFileSync('after_nojs.html',fs.readFileSync('after.html','utf8').replace(/<script>[\s\S]*?<\/script>/g,'').replace(/<!--[\s\S]*?-->/g,'').replace(/<noscript>([\s\S]*?)<\/noscript>/g,'$1'));o=await open({w:390,h:900});await o.page.goto('file://'+path.resolve('after_nojs.html'));await o.page.waitForTimeout(800);}
   else {o=await open({...m,h:900});await o.page.goto(AFTER);await settle(o.page);}
   await o.page.addScriptTag({content:axeSrc});const res=await o.page.evaluate(async()=>(await axe.run(document.getElementById('allrecords'),{resultTypes:['violations']})).violations.map(v=>[v.id,v.impact,v.nodes.length,v.nodes[0].target.join(' ')]));
   const s=res.filter(v=>/serious|critical/.test(v[1]));log('A',res.length===0,`${m.w}${m.reduce?' reduce':''}${m.nojs?' без JS':''}: нарушений ${res.length} (serious/critical ${s.length}) ${res.map(v=>v.join(':')).join(' ; ').slice(0,300)}`);await o.browser.close();}
  {const o=await open({w:1440,h:900});await o.page.goto(AFTER);await settle(o.page);
   const b=await knobBox(o.page);await mdrag(o.page,b,-80);
   await o.page.click('#ag-cl04-08 .ag-fq__all');await o.page.click('#ag-cl04-07 [data-ag-ui-copy]').catch(()=>{});await o.page.waitForTimeout(400);
   await o.page.addScriptTag({content:axeSrc});const res=await o.page.evaluate(async()=>(await axe.run(document.getElementById('allrecords'),{resultTypes:['violations']})).violations.map(v=>[v.id,v.impact,v.nodes[0].target.join(' ')]));
   log('A',res.length===0,`1440, ручка повёрнута на «Функциональные» + FAQ раскрыт + адрес скопирован: нарушений ${res.length} ${res.map(v=>v.join(':')).join(' ; ').slice(0,300)}`);await o.browser.close();}}
 fs.writeFileSync('checks_n_'+G+'.json',JSON.stringify(out,null,1));
 for(const g of Object.keys(out)){console.log('## '+g);out[g].forEach(x=>console.log('  '+x));}
})();
