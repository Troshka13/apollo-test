# -*- coding: utf-8 -*-
"""Проход «дизайн и движение» главной (PROMPT_HOME_DESIGN_MOTION_v2, 30.09.2026).
Идемпотентно: читает src/<блок>_<старая>.html, пишет out/<блок>_<новая>.html.
Каждая замена обязана найтись ровно один раз (или указанное число раз)."""
import re, os, sys, hashlib

SRC = 'src'; OUT = 'out'
os.makedirs(OUT, exist_ok=True)
DATE = '30.09.2026'
EASE_OUT = 'cubic-bezier(.34,1.56,.64,1)'

def rep(t, old, new, n=1):
    c = t.count(old)
    if c != n:
        raise SystemExit('replace count %d != %d for: %r' % (c, n, old[:120]))
    return t.replace(old, new)

def rx(t, pat, new, n=1, flags=re.S):
    t2, c = re.subn(pat, new, t, flags=flags)
    if c != n:
        raise SystemExit('regex count %d != %d for: %r' % (c, n, pat[:120]))
    return t2

def bump(t, old_v, new_v, note):
    t = rep(t, '· %s · ' % old_v, '· %s · ' % new_v)
    # заметка версии — сразу после первого комментария-шапки
    i = t.index('-->') + 3
    return t[:i] + '\n<!-- %s (проход «дизайн и движение», PROMPT_HOME_DESIGN_MOTION_v2, %s):\n     %s -->' % (new_v, DATE, note) + t[i:]

def wrap_inner(t, cls_attr_start, inner_cls, n=1):
    """<a class="X ..." ...>INNER</a> → <a ...><span class="inner_cls">INNER</span></a>"""
    pat = r'(<a class="%s[^"]*"[^>]*>)(.*?)(</a>)' % re.escape(cls_attr_start)
    return rx(t, pat, lambda m: m.group(1) + '<span class="%s">' % inner_cls + m.group(2) + '</span>' + m.group(3), n)

def press_css(root, pairs):
    """F23: неподвижная область, внутренний span сжимается при нажатии."""
    sel_in = ',\n  '.join('%s .%s' % (root, i) for b, i in pairs)
    sel_act = ',\n  '.join('%s .%s:active .%s' % (root, b, i) for b, i in pairs)
    sel_red = ', '.join('%s .%s' % (root, i) for b, i in pairs)
    sel_red_a = ', '.join('%s .%s:active .%s' % (root, b, i) for b, i in pairs)
    return ('''  /* F23 · нажатие: область кнопки неподвижна, сжимается подпись с иконкой */
  %s{display:inline-flex;align-items:center;justify-content:inherit;gap:inherit;flex:1 1 auto;min-width:0;
    transition:transform 260ms %s;}
  %s{transform:scale(.98);transition-duration:140ms;transition-timing-function:cubic-bezier(.22,.61,.36,1);}
  @media (prefers-reduced-motion:reduce){
    %s{transition:none;}
    %s{transform:none;}
  }
''' % (sel_in, EASE_OUT, sel_act, sel_red, sel_red_a))

def navpress_css(root, btn_sel):
    return '''  /* F23 · круглые кнопки: иконка откликается на нажатие (scale — отдельно от transform поворота) */
  %s svg{transition:scale 260ms %s;}
  %s:active svg{scale:.86;transition-duration:140ms;}
  @media (prefers-reduced-motion:reduce){%s svg{transition:none;}%s:active svg{scale:1;}}
''' % (btn_sel, EASE_OUT, btn_sel, btn_sel, btn_sel)

def section_pad(root, sec, top=44, bottom=44):
    return '''  /* G5 · телефон: отступы секции 44 / 44 (было 56 / 56–95) */
  @media (max-width:639.98px){
    %s %s{padding-top:%dpx;padding-bottom:%dpx;}
  }
''' % (root, sec, top, bottom)

def add_css(t, css):
    """дописать правила в конец первого <style> блока"""
    i = t.index('  </style>')
    return t[:i] + '\n  /* ===== v-дизайн и движение (30.09) ===== */\n' + css + t[i:]

def focus3(t, root):
    """G2 · фокус 3 px. Меняются только общие правила фокуса корня."""
    t2, c = re.subn(r'(%s\.ag-scope :is\([^)]*\):focus-visible\{outline:)2px' % re.escape(root), r'\g<1>3px', t)
    if c != 1:
        raise SystemExit('focus rule not found for ' + root)
    t2 = re.sub(r'(%s\.ag-scope :is\([^)]*\):focus-visible\{outline:3px solid [^;]+;outline-offset:)4px' % re.escape(root), r'\g<1>3px', t2)
    return t2

def touch(t):
    """iOS: :active срабатывает только при слушателе касания"""
    return rep(t, '    var tries = 0;\n', '    /* iOS включает :active только при слушателе касания (F23) */\n    root.addEventListener("touchstart", function () {}, { passive: true });\n    var tries = 0;\n')

def st_refresh_fn():
    return ('    /* высота блока изменилась по действию — ScrollTrigger блоков ниже пересчитывает точки */\n'
            '    function stRefresh(delay) {\n'
            '      W.setTimeout(function () {\n'
            '        var M = W.ApolloMotion;\n'
            '        if (M && M.ready && M.ScrollTrigger) M.ScrollTrigger.refresh();\n'
            '      }, delay || 0);\n'
            '    }\n')

def save(name, ver, t):
    p = os.path.join(OUT, '%s_%s.html' % (name, ver))
    open(p, 'w', encoding='utf-8').write(t)
    print('%-12s %-8s %6d байт' % (name, ver, len(t.encode('utf-8'))))

def load(name, ver):
    return open(os.path.join(SRC, '%s_%s.html' % (name, ver)), encoding='utf-8').read()

# ---------------------------------------------------------------- HOME-01
def home01():
    t = load('HOME-01', 'v9.1.0'); R = '#ag-home-01'
    t = bump(t, 'v9.1.0', 'v9.2.0',
             'F01 «рамка ринга»: три каната выходят из правого края кадра к краю экрана (SVG-пути\n'
             '     фиксированной длины, draw движка 600/700/800 мс) и заменяют скобку «угол канатов» от 900 px;\n'
             '     на телефоне остаётся скобка. F23 — нажатие двух кнопок. Фокус 3 px. Телефон: планка фактов\n'
             '     плотнее, бегущая строка при reduce — две колонки. Текст, кадры, свет над рингом — без изменений.')
    t = wrap_inner(t, 'ag-btn ag-btn--primary', 'ag-btn__in')
    t = wrap_inner(t, 'ag-btn ag-btn--ghost', 'ag-btn__in')
    ropes = ('\n          <!-- F01 · канаты ринга: выходят из кадра к краю экрана. Длина пути постоянна (ст. 81),\n'
             '               лишнее обрезает overflow секции. Без JS и при reduce — видны целиком. -->\n'
             '          <svg class="ag-hh__ropes" viewBox="0 0 720 84" preserveAspectRatio="xMinYMid meet" aria-hidden="true" focusable="false">'
             '<path class="ag-hh__rope ag-hh__rope--hot" d="M0 6H720" data-ag-anim="draw" data-ag-dur="600" data-ag-start="top bottom"/>'
             '<path class="ag-hh__rope" d="M0 42H720" data-ag-anim="draw" data-ag-dur="700" data-ag-start="top bottom"/>'
             '<path class="ag-hh__rope" d="M0 78H720" data-ag-anim="draw" data-ag-dur="800" data-ag-start="top bottom"/></svg>\n')
    t = rep(t, '            <figcaption class="ag-hh__cap ag-hh__cap--sm">Зона для борьбы · Чкалова, 72</figcaption>\n          </figure>\n',
            '            <figcaption class="ag-hh__cap ag-hh__cap--sm">Зона для борьбы · Чкалова, 72</figcaption>\n          </figure>' + ropes)
    t = focus3(t, R)
    t = rep(t, '  #ag-home-01 .ag-btn:active{transform:translateY(1px);}\n', '')
    css = press_css(R, [('ag-btn', 'ag-btn__in')])
    css += '''  /* F01 · канаты: от 900 px заменяют скобку «угол канатов» */
  #ag-home-01 .ag-hh__ropes{position:absolute;z-index:4;left:calc(100% - 22px);top:52%;width:720px;height:84px;overflow:visible;pointer-events:none;}
  #ag-home-01 .ag-hh__rope{fill:none;stroke:rgba(244,244,245,.5);stroke-width:2;stroke-linecap:round;}
  #ag-home-01 .ag-hh__rope--hot{stroke:var(--accent);stroke-width:2.5;}
  @media (min-width:900px){
    #ag-home-01 .ag-hh__frame::before{display:none;}
  }
  @media (max-width:899px){
    #ag-home-01 .ag-hh__ropes{display:none;}
  }
  @media (forced-colors:active){
    #ag-home-01 .ag-hh__rope,#ag-home-01 .ag-hh__rope--hot{stroke:CanvasText;}
  }
  @media print{
    #ag-home-01 .ag-hh__ropes{display:none;}
  }
  /* G5 · телефон: планка фактов плотнее */
  @media (max-width:599px){
    #ag-home-01 .ag-hh__stats{margin-top:28px;}
    #ag-home-01 .ag-hh__stats>li{padding:14px 14px 15px;}
    #ag-home-01 .ag-hh__stats b{font-size:30px;}
    #ag-home-01 .ag-hh__stats li>span{margin-top:6px;font-size:12.5px;line-height:1.35;}
    #ag-home-01 .ag-hh__mq{margin-top:28px;}
    #ag-home-01 .ag-hh__marquee{padding:14px 0;}
  }
  /* F24 · reduce на телефоне: неподвижная строка — две колонки, а не столбик в семь строк */
  @media (max-width:599px) and (prefers-reduced-motion:reduce){
    #ag-home-01 .ag-hh__mq-set{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px 16px;}
    #ag-home-01 .ag-marquee__item{white-space:normal;font-size:13px;gap:0;}
    #ag-home-01 .ag-marquee__item::after{display:none;}
  }
'''
    t = add_css(t, css)
    t = touch(t)
    save('HOME-01', 'v9.2.0', t)

# ---------------------------------------------------------------- HOME-02
def home02():
    t = load('HOME-02', 'v19.0.0'); R = '#ag-home-02'
    t = bump(t, 'v19.0.0', 'v19.1.0',
             'Композиция, кадры и ролики — без изменений. Стрелка карточки откликается на нажатие (F23),\n'
             '     фокус 3 px. Телефон: сцена колоды 260 → 210 px, поле под точками меньше, отступы секции 44 / 44.')
    t = focus3(t, R)
    t = rep(t, '    #ag-home-02{--stage-h:260px;}\n', '    #ag-home-02{--stage-h:210px;}\n')
    css = '''  /* F23 · стрелка карточки при нажатии */
  #ag-home-02 .ag-fork__go svg{transition:scale 260ms %s;}
  #ag-home-02 .ag-fork__card:active .ag-fork__go svg{scale:.84;transition-duration:140ms;}
  @media (prefers-reduced-motion:reduce){#ag-home-02 .ag-fork__go svg{transition:none;}#ag-home-02 .ag-fork__card:active .ag-fork__go svg{scale:1;}}
  @media (max-width:600px){
    #ag-home-02 .ag-fork__head{margin-bottom:22px;}
    #ag-home-02 .ag-fork__dots{margin-top:12px;}
    #ag-home-02 .ag-fork__panel{padding:16px 56px 16px 16px;}
  }
''' % EASE_OUT
    css += section_pad(R, '.ag-fork')
    t = add_css(t, css)
    t = touch(t)
    save('HOME-02', 'v19.1.0', t)

# ---------------------------------------------------------------- HOME-03
ROUTES = [
    ('Галактионовская, 81', 'на Галактионовской', 'boxing', 'https://yandex.ru/maps/?text=%D0%A1%D0%B0%D0%BC%D0%B0%D1%80%D0%B0%2C%20%D1%83%D0%BB.%20%D0%93%D0%B0%D0%BB%D0%B0%D0%BA%D1%82%D0%B8%D0%BE%D0%BD%D0%BE%D0%B2%D1%81%D0%BA%D0%B0%D1%8F%2C%2081', 'Зал на Галактионовской'),
    ('Чкалова, 72', 'на Чкалова', 'mma', 'https://yandex.ru/maps/?text=%D0%A1%D0%B0%D0%BC%D0%B0%D1%80%D0%B0%2C%20%D1%83%D0%BB.%20%D0%A7%D0%BA%D0%B0%D0%BB%D0%BE%D0%B2%D0%B0%2C%2072', 'Зал на Чкалова'),
    ('Ново-Садовая, 106Б', 'на Ново-Садовой', 'gym', 'https://yandex.ru/maps/?text=%D0%A1%D0%B0%D0%BC%D0%B0%D1%80%D0%B0%2C%20%D1%83%D0%BB.%20%D0%9D%D0%BE%D0%B2%D0%BE-%D0%A1%D0%B0%D0%B4%D0%BE%D0%B2%D0%B0%D1%8F%2C%20106%D0%91', 'Зал на Ново-Садовой'),
    ('Молодогвардейская, 56', 'на Молодогвардейской', 'nofitness', 'https://yandex.ru/maps/?text=%D0%A1%D0%B0%D0%BC%D0%B0%D1%80%D0%B0%2C%20%D1%83%D0%BB.%20%D0%9C%D0%BE%D0%BB%D0%BE%D0%B4%D0%BE%D0%B3%D0%B2%D0%B0%D1%80%D0%B4%D0%B5%D0%B9%D1%81%D0%BA%D0%B0%D1%8F%2C%2056', 'Зал на Молодогвардейской'),
]

def home03():
    t = load('HOME-03', 'v8.1.0'); R = '#ag-home-03'
    t = bump(t, 'v8.1.0', 'v8.2.0',
             'F20 «клуб и маршрут»: в каждой карточке — ссылка «Построить маршрут» на Яндекс Карты по адресу\n'
             '     (тот же поиск по адресу, что в CONTACTS-02; карточки организаций не сверены — clubs.json\n'
             '     verified_map_links: null). Ссылка — сосед заголовка над растянутой ссылкой карточки.\n'
             '     Смена кадра галереи 420 → 220 мс, иконки кнопок кадра откликаются на нажатие, фокус 3 px.\n'
             '     Телефон: отступы 44 / 44, нижний запас колоды 8 px под рамку фокуса.')
    arrow = '<svg class="ag-glass__go-i" viewBox="0 0 20 20" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M4 10h11M11 5l5 5-5 5"/></svg></span>'
    ext = '<svg class="ag-glass__route-i" viewBox="0 0 20 20" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M10 18s5.5-4.9 5.5-9.2a5.5 5.5 0 0 0-11 0C4.5 13.1 10 18 10 18Z"/><circle cx="10" cy="8.6" r="1.9"/></svg>'
    for short, prep, club, url, go in ROUTES:
        old = '            <span class="ag-glass__go">%s%s\n' % (go, arrow)
        new = ('            <div class="ag-glass__foot">\n'
               '              <span class="ag-glass__go">%s%s\n'
               '              <a class="ag-glass__route" href="%s" target="_blank" rel="noopener" data-ag-track="route_click" data-ag-params=\'{"club":"%s","map":"yandex","from":"clubs"}\'>%s<span class="ag-glass__route-t">Построить маршрут</span><span class="ag-vh"> до зала %s, откроется в новой вкладке</span></a>\n'
               '            </div>\n') % (go, arrow, url, club, ext, prep)
        t = rep(t, old, new)
    t = focus3(t, R)
    t = rep(t, '    transition:opacity 420ms var(--ease);\n', '    transition:opacity 220ms var(--ease);\n')
    t = rep(t, '      padding:22px var(--gut) 6px;\n', '      padding:22px var(--gut) 8px;\n')
    css = '''  #ag-home-03 .ag-vh{position:absolute;width:1px;height:1px;margin:-1px;padding:0;overflow:hidden;clip:rect(0 0 0 0);clip-path:inset(50%);white-space:nowrap;border:0;}
  /* F20 · низ карточки: переход в зал (вся карточка) и маршрут (своя ссылка поверх) */
  #ag-home-03 .ag-glass__foot{margin-top:auto;display:flex;flex-wrap:wrap;align-items:center;gap:0 22px;width:100%;}
  #ag-home-03 .ag-glass__foot .ag-glass__go{margin-top:0;padding:10px 0;}
  #ag-home-03 .ag-glass__route{
    position:relative;z-index:3;display:inline-flex;align-items:center;gap:7px;min-height:44px;padding:0 2px;
    font-size:14px;font-weight:700;line-height:1.2;white-space:nowrap;
    border-bottom:1px solid transparent;transition:color 200ms var(--ease),border-color 200ms var(--ease);
  }
  #ag-home-03.ag-scope .ag-glass__route{color:var(--muted);}
  #ag-home-03 .ag-glass__route-i{width:17px;height:17px;flex:none;color:var(--accent);}
  #ag-home-03 .ag-glass__route-t{border-bottom:1px solid rgba(244,244,245,.28);padding-bottom:1px;}
  @media (hover:hover){
    #ag-home-03.ag-scope .ag-glass__route:hover{color:var(--text);}
    #ag-home-03 .ag-glass__route:hover .ag-glass__route-t{border-bottom-color:var(--accent);}
  }
  @media (max-width:360px){
    #ag-home-03 .ag-glass__foot{gap:0 14px;}
  }
  @media print{#ag-home-03 .ag-glass__route{display:none;}}
'''
    css += navpress_css(R, '#ag-home-03 .ag-glass__nav')
    css += section_pad(R, '.ag-cl')
    t = add_css(t, css)
    t = touch(t)
    save('HOME-03', 'v8.2.0', t)

# ---------------------------------------------------------------- HOME-04
def home04():
    t = load('HOME-04', 'v10.1.0'); R = '#ag-home-04'
    t = bump(t, 'v10.1.0', 'v10.2.0',
             'F10 «плавный индикатор вкладок»: подложка «Единоборства / Для формы» едет под выбранную\n'
             '     вкладку (CSS transform по data-ag-ui-tab, 360 мс), после смены панели — пересчёт ScrollTrigger.\n'
             '     Смена обложки по строке — opacity 220 мс. F23 — нажатие кнопки записи, фокус 3 px.\n'
             '     Телефон: обложка панели 16:10 → 2:1, отступы секции 44 / 44.')
    t = wrap_inner(t, 'ag-dr__btn', 'ag-dr__btnin')
    t = focus3(t, R)
    t = rep(t, '    transition:opacity 420ms var(--ease),transform 900ms var(--ease);\n', '    transition:opacity 220ms var(--ease),transform 900ms var(--ease);\n')
    t = rep(t, '    #ag-home-04 .ag-dr__cover{aspect-ratio:16/10;}\n', '    #ag-home-04 .ag-dr__cover{aspect-ratio:2/1;}\n')
    # JS: подложка и пересчёт
    t = rep(t, '    var current = 0;\n    function select(n, focus) {\n      current = n;\n',
            '    var current = 0;\n' + st_refresh_fn().replace('    ', '    ') +
            '    function select(n, focus) {\n      var was = current;\n      current = n;\n      if (list) list.setAttribute("data-ag-ui-tab", String(n));\n')
    t = rep(t, '      if (focus) tabs[n].focus();\n    }\n', '      if (focus) tabs[n].focus();\n      if (was !== n) stRefresh(60);\n    }\n')
    t = rep(t, '      list.hidden = !narrow;\n', '      list.hidden = !narrow;\n      list.setAttribute("data-ag-ui-tab", String(current));\n')
    css = press_css(R, [('ag-dr__btn', 'ag-dr__btnin')])
    css += '''  /* F10 · подложка вкладок. Вкладки равной ширины (flex:1 1 0), поэтому сдвиг — ровно ширина вкладки + зазор */
  #ag-home-04 .ag-dr__tabs{position:relative;isolation:isolate;}
  #ag-home-04 .ag-dr__tabs::before{
    content:"";position:absolute;z-index:-1;top:4px;bottom:4px;left:4px;width:calc(50% - 6px);
    border-radius:999px;background:var(--accent);
    transition:transform 360ms cubic-bezier(.22,.61,.36,1);
  }
  #ag-home-04 .ag-dr__tabs[data-ag-ui-tab="1"]::before{transform:translateX(calc(100% + 4px));}
  #ag-home-04 .ag-dr__tabs[data-ag-ui-tab] .ag-dr__tab[aria-selected="true"]{background:transparent;}
  #ag-home-04 .ag-dr__tab{transition:color 360ms cubic-bezier(.22,.61,.36,1);}
  @media (prefers-reduced-motion:reduce){
    #ag-home-04 .ag-dr__tabs::before,#ag-home-04 .ag-dr__tab{transition:none;}
  }
  @media (forced-colors:active){
    #ag-home-04 .ag-dr__tabs::before{background:Highlight;}
  }
'''
    css += section_pad(R, '.ag-dr')
    t = add_css(t, css)
    t = touch(t)
    save('HOME-04', 'v10.2.0', t)

# ---------------------------------------------------------------- HOME-05
def home05():
    t = load('HOME-05', 'v2.1.0'); R = '#ag-home-05'
    t = bump(t, 'v2.1.0', 'v2.2.0',
             'F29 «бумага» — как есть, кадр 4:3 сохранён. F23 — нажатие тёмной кнопки, фокус чернилами 3 px.\n'
             '     Телефон: ответы родителю плотнее, отступы секции 44 / 44.')
    t = rx(t, r'(<a class="ag-kd__btn"[^>]*>)(<span>Детские группы и&nbsp;расписание</span><span class="ag-kd__bico" aria-hidden="true"><svg[^>]*><use[^>]*/></svg></span>)(</a>)',
           lambda m: m.group(1) + '<span class="ag-kd__btnin">' + m.group(2) + '</span>' + m.group(3))
    t = focus3(t, R)
    css = press_css(R, [('ag-kd__btn', 'ag-kd__btnin')])
    css += '''  @media (max-width:639.98px){
    #ag-home-05 .ag-kd__grid{row-gap:24px;}
    #ag-home-05 .ag-kd__row{padding:12px 0;}
    #ag-home-05 .ag-kd__a{padding-top:4px;}
    #ag-home-05 .ag-kd__acts{margin-top:20px;}
  }
'''
    css += section_pad(R, '.ag-kd')
    t = add_css(t, css)
    t = touch(t)
    save('HOME-05', 'v2.2.0', t)

# ---------------------------------------------------------------- HOME-06
def home06():
    t = load('HOME-06', 'v7.1.0'); R = '#ag-home-06'
    t = bump(t, 'v7.1.0', 'v7.2.0',
             'F23 — нажатие кнопки «Записаться к тренеру» и стрелок колоды, фокус 3 px.\n'
             '     Телефон: кадр карточки 4:5 → 5:4 — имя, зал и «Ещё в этом зале» в одном экране; отступы 44 / 44.')
    t = wrap_inner(t, 'ag-tr__btn', 'ag-tr__btnin')
    t = focus3(t, R)
    t = rep(t, '    #ag-home-06 .ag-tr__ph{aspect-ratio:4/5;}\n    #ag-home-06 .ag-tr__mono{font-size:clamp(100px,30vw,140px);}\n',
            '    #ag-home-06 .ag-tr__ph{aspect-ratio:5/4;}\n    #ag-home-06 .ag-tr__mono{font-size:clamp(90px,26vw,120px);}\n')
    css = press_css(R, [('ag-tr__btn', 'ag-tr__btnin')])
    css += navpress_css(R, '#ag-home-06 .ag-tr__navbtn')
    css += section_pad(R, '.ag-tr')
    t = add_css(t, css)
    t = touch(t)
    save('HOME-06', 'v7.2.0', t)

# ---------------------------------------------------------------- HOME-07
def home07():
    t = load('HOME-07', 'v4.1.0'); R = '#ag-home-07'
    t = bump(t, 'v4.1.0', 'v4.2.0',
             'F14 — таймлайн как есть (линия draw). F23 — нажатие кнопки «Оставить заявку», фокус 3 px.\n'
             '     Телефон: строки залов 52 → 44 px, карточки шагов плотнее, отступы секции 44 / 44.')
    t = wrap_inner(t, 'ag-st__btn', 'ag-st__btnin')
    t = focus3(t, R)
    css = press_css(R, [('ag-st__btn', 'ag-st__btnin')])
    css += '''  @media (max-width:639.98px){
    #ag-home-07 .ag-st__track{margin-top:28px;}
    #ag-home-07 .ag-st__steps{gap:12px;}
    #ag-home-07 .ag-st__card{gap:8px;}
    #ag-home-07 .ag-st__hall{min-height:44px;padding:5px 2px;}
    #ag-home-07 .ag-st__go{padding:11px 0 4px;}
    #ag-home-07 .ag-st__free{padding:12px 16px;}
  }
'''
    css += section_pad(R, '.ag-st')
    t = add_css(t, css)
    t = touch(t)
    save('HOME-07', 'v4.2.0', t)

# ---------------------------------------------------------------- HOME-08
def home08():
    t = load('HOME-08', 'v4.1.1'); R = '#ag-home-08'
    t = bump(t, 'v4.1.1', 'v4.2.0',
             'Таблица и жёлтая карточка (П9) — как есть, цены не анимируются. F23 — нажатие тёмной кнопки,\n'
             '     фокус чернилами 3 px (ст. 116). Телефон: отступы секции 44 / 44.')
    t = wrap_inner(t, 'ag-pr__btn', 'ag-pr__btnin')
    t = focus3(t, R)
    css = press_css(R, [('ag-pr__btn', 'ag-pr__btnin')])
    css += section_pad(R, '.ag-pr')
    t = add_css(t, css)
    t = touch(t)
    save('HOME-08', 'v4.2.0', t)

# ---------------------------------------------------------------- HOME-09
def home09():
    t = load('HOME-09', 'v2.1.2'); R = '#ag-home-09'
    t = bump(t, 'v2.1.2', 'v2.2.0',
             'Хроника и тексты — как есть. F23 — нажатие кнопки звонка и стрелок ленты, фокус 3 px.\n'
             '     Телефон: кадр турниров 16:9 → 2:1, отступы секции 44 / 44. Лента хроники без JS получает фокус\n'
             '     с клавиатуры (tabindex в разметке; с JS скрипт снимает его, когда прокрутки нет).')
    t = rx(t, r'(<a class="ag-ev__tel"[^>]*>)(.*?)(</a>)', lambda m: m.group(1) + '<span class="ag-ev__telin">' + m.group(2) + '</span>' + m.group(3))
    # без JS лента на телефоне листается вбок — список должен получать фокус (axe scrollable-region-focusable);
    # с JS скрипт блока сам снимает tabindex, когда прокрутки нет
    t = rep(t, 'aria-label="Турниры и выезды 2026 года, которые уже прошли" data-ag-anim', 'aria-label="Турниры и выезды 2026 года, которые уже прошли" tabindex="0" data-ag-anim')
    t = focus3(t, R)
    t = rep(t, '    #ag-home-09 .ag-ev{padding:52px 0;}\n', '    #ag-home-09 .ag-ev{padding:44px 0;}\n')
    t = rep(t, '    #ag-home-09 .ag-ev__card--cup .ag-ev__fig{aspect-ratio:16/9;min-height:0;flex:none;}\n',
            '    #ag-home-09 .ag-ev__card--cup .ag-ev__fig{aspect-ratio:2/1;min-height:0;flex:none;}\n')
    css = press_css(R, [('ag-ev__tel', 'ag-ev__telin')])
    css += navpress_css(R, '#ag-home-09 .ag-ev__navbtn')
    t = add_css(t, css)
    t = touch(t)
    save('HOME-09', 'v2.2.0', t)

# ---------------------------------------------------------------- HOME-10
def home10():
    t = load('HOME-10', 'v3.1.0'); R = '#ag-home-10'
    t = bump(t, 'v3.1.0', 'v3.2.0',
             'Код v3.1.0 восстановлен по снимку страницы: разметка — с сайта, CSS и JS — v3.0.0 (правила\n'
             '     совпали 65/65). F22 уже был. Добавлено: F23 — нажатие кнопки звонка, фокус 3 px, после\n'
             '     раскрытия вопроса — пересчёт ScrollTrigger блоков ниже. Вопросы и ответы не менялись (JSON-LD).\n'
             '     Телефон: отступы секции 44 / 44.')
    t = rx(t, r'(<a class="ag-fq__btn"[^>]*>)(.*?)(</a>)', lambda m: m.group(1) + '<span class="ag-fq__btnin">' + m.group(2) + '</span>' + m.group(3))
    t = focus3(t, R)
    t = rep(t, '    var tries = 0;\n',
            st_refresh_fn() +
            '    Array.prototype.forEach.call(root.querySelectorAll(".ag-fq__item"), function (d) {\n'
            '      d.addEventListener("toggle", function () { stRefresh(380); });\n'
            '    });\n\n    var tries = 0;\n')
    css = press_css(R, [('ag-fq__btn', 'ag-fq__btnin')])
    css += section_pad(R, '.ag-fq')
    t = add_css(t, css)
    t = touch(t)
    save('HOME-10', 'v3.2.0', t)

# ---------------------------------------------------------------- HOME-11
def home11():
    t = load('HOME-11', 'v1.1.0'); R = '#ag-home-11'
    t = bump(t, 'v1.1.0', 'v1.2.0',
             'Код v1.1.0 восстановлен по снимку страницы: разметка — с сайта, CSS и JS — v1.0.0 + правила\n'
             '     v1.1.0 (сверка 61/61). F23: магнитная реакция главной кнопки снята — кнопка «не убегает от\n'
             '     курсора», область нажатия неподвижна, подпись сжимается при нажатии. Фокус 3 px.\n'
             '     Контур APOLLO и заливка по прокрутке (П12) — без изменений.\n'
             '     Телефон: отступ сверху 44, поле под карточкой над словом APOLLO меньше.')
    t = rep(t, ' data-ag-magnetic data-ag-track="request_start"', ' data-ag-track="request_start"')
    t = rx(t, r'(<a class="ag-ct__btn"[^>]*>)(<span>Записаться на тренировку</span><span class="ag-ct__bico" aria-hidden="true"><svg[^>]*><use[^>]*/></svg></span>)(</a>)',
           lambda m: m.group(1) + '<span class="ag-ct__btnin">' + m.group(2) + '</span>' + m.group(3))
    t = rx(t, r'(<a class="ag-ct__tel"[^>]*>)(.*?)(</a>)', lambda m: m.group(1) + '<span class="ag-ct__telin">' + m.group(2) + '</span>' + m.group(3))
    t = focus3(t, R)
    css = press_css(R, [('ag-ct__btn', 'ag-ct__btnin'), ('ag-ct__tel', 'ag-ct__telin')])
    css += section_pad(R, '.ag-ct', 44, 112)
    t = add_css(t, css)
    t = touch(t)
    save('HOME-11', 'v1.2.0', t)

if __name__ == '__main__':
    for f in (home01, home02, home03, home04, home05, home06, home07, home08, home09, home10, home11):
        f()
