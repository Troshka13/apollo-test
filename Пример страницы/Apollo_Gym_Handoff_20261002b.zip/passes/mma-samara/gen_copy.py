# -*- coding: utf-8 -*-
import hashlib, html
B = [
 ('01','rec3988482601','ММА в Самаре','Alt кадра, «для взрослых» в планке, магнит снят, нажатие кнопки','заменить код'),
 ('02','rec3989558801','Зал, в котором идёт ММА','Клетка — настоящий кадр клетки, борцовская зона — рисунок вместо чужого кадра','заменить код'),
 ('03','rec3990674201','Из чего складывается ММА','Фокус 3 px','заменить код'),
 ('04','rec3992216701','С каким опытом приходят в ММА','«Что уже есть — что добрать», черта едет по сетке на телефоне, «для взрослых»','заменить код'),
 ('05','rec3992550201','Кто ведёт ММА на Чкалова','Нажатие кнопки, фокус','заменить код'),
 ('06','rec3992938601','Цены на групповые тренировки по ММА','«для взрослых», зерно бумаги на ПК','заменить код'),
 ('07','rec3992996301','ММА, грэпплинг и ударные единоборства','Фокус 3 px','заменить код'),
 ('08','rec3993056101','Что спрашивают про ММА','Ответ «вырастает» из пузыря, «для взрослых» в первом ответе','заменить код'),
 ('09','rec3993272201','Хотите попробовать в клетке','Магнит снят, нажатие кнопок','заменить код'),
 ('HEAD','—','HEAD страницы v1.1','Ответ про борьбу в FAQPage — «для взрослых», как в блоке 08','заменить целиком'),
]
TITLE=''
DESC='Секция ММА в Самаре на Чкалова, 72: клетка и зона для борьбы. Удары в стойке, переводы, партер и контроль. Разовое 900 ₽, взрослым первое групповое бесплатно.'
cards=[]
for n,rec,name,what,act in B:
    code=open('/home/claude/ms/out/HEAD_mma-samara_v1.1.html' if n=='HEAD' else f'/home/claude/ms/out/DIR04-{n}_v1.1.0.html',encoding='utf-8').read()
    sha=hashlib.sha256(code.encode()).hexdigest()
    must=' is-must' if n=='HEAD' else ''
    cards.append(f'''<article class="blk{must}" id="b{n}">
  <header class="blk__head">
    <p class="blk__num">{"HEAD" if n=="HEAD" else "DIR04-"+n}<span>{"v1.1" if n=="HEAD" else "v1.1.0"}</span></p>
    <h2 class="blk__name">{html.escape(name)}</h2>
    <p class="blk__what">{html.escape(what)}</p>
  </header>
  <dl class="blk__meta">
    <div><dt>{"Где" if n=="HEAD" else "Запись Tilda"}</dt><dd>{"Настройки страницы → Дополнительно → HTML-код внутрь HEAD" if n=="HEAD" else "<code>"+rec+"</code>"}</dd></div>
    <div><dt>Действие</dt><dd class="act">{act}</dd></div>
    <div><dt>Размер</dt><dd>{len(code.encode())//1024} КБ</dd></div>
  </dl>
  <div class="blk__do">
    <button class="btn btn--main" type="button" data-copy="c{n}">Скопировать код</button>
    <span class="blk__state" data-state="c{n}" role="status" aria-live="polite"></span>
  </div>
  <details class="blk__code"><summary>Показать код</summary>
    <label class="vh" for="c{n}">Код {n}</label>
    <textarea id="c{n}" readonly spellcheck="false" data-sha="{sha}">{html.escape(code)}</textarea>
  </details>
</article>''')
page=open('/home/claude/ms/copy_tpl.html',encoding='utf-8').read()
page=page.replace('%%CARDS%%','\n'.join(cards)).replace('%%TITLE%%',html.escape(TITLE)).replace('%%DESC%%',html.escape(DESC)).replace('%%TL%%',str(len(TITLE))).replace('%%DL%%',str(len(DESC)))
open('/home/claude/ms/copy/mma_blocks.html','w',encoding='utf-8').write(page)
print(len(page.encode()))
