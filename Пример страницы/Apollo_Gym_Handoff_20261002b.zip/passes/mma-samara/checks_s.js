// /mma-samara (DIR04) · проверки прохода «дизайн, движение и фишка» (PROMPT_DIR04_DESIGN_MOTION_v2)
const {open,settle}=require('./lib');const fs=require('fs'),path=require('path');
const AFTER='file://'+path.resolve('after.html'), BEFORE='file://'+path.resolve('before.html');
const out={};const log=(g,ok,msg)=>{const s=(ok?"pass ":"FAIL ")+msg;(out[g]=out[g]||[]).push(s);console.log(g+" "+s);};
const G=process.env.G||'LTCMFA';
async function txt(url){const {browser,page}=await open({reduce:true});await page.goto(url);await page.waitForTimeout(2600);
  const r=await page.evaluate(()=>{const o={};document.querySelectorAll('.ag-scope').forEach(r=>{const c=r.cloneNode(true);c.querySelectorAll('style,script,.ag-vh,.ag-fl__lv').forEach(x=>x.remove());o[r.id]=c.textContent.replace(/\s+/g,' ').trim();});return o;});await browser.close();return r;}
async function links(url){const {browser,page}=await open({reduce:true});await page.goto(url);await page.waitForTimeout(400);
  const r=await page.evaluate(()=>[...document.querySelectorAll('.ag-scope a[href]')].map(a=>a.closest('.ag-scope').id+' '+a.getAttribute('href')));await browser.close();return r;}
// 04: знак, черта, панели
const LV=`(()=>{const r=document.getElementById('ag-dir04-04');const lv=r.querySelector('.ag-fl__lv');const pts=[...lv.querySelectorAll('.ag-fl__pt')].map(p=>{const c=getComputedStyle(p).backgroundColor;return !(c.startsWith('rgba')&&c.endsWith(', 0)'));});
  const on=r.querySelector('.ag-fl__panel.is-on');const tx=on.querySelector('.ag-fl__text').getBoundingClientRect();const lb=lv.getBoundingClientRect();
  const bar=r.querySelector('.ag-fl__bar').getBoundingClientRect();const tab=r.querySelector('.ag-fl__tab[aria-selected="true"]').getBoundingClientRect();
  return {tab:r.getAttribute('data-ag-tab'),vis:getComputedStyle(lv).visibility,disp:getComputedStyle(lv).display,up:pts[0],dn:pts[1],gap:Math.round(tx.top-lb.bottom),cell:Math.round(r.querySelector('.ag-fl__panels').getBoundingClientRect().height),
   bar:{x:Math.round(bar.left),y:Math.round(bar.top),w:Math.round(bar.width),h:Math.round(bar.height)},tabr:{x:Math.round(tab.left),y:Math.round(tab.top),w:Math.round(tab.width),h:Math.round(tab.height)}};})()`;
const WANT=[[true,false],[false,true],[false,false],null];
(async()=>{
 if(G.includes('L')) for(const reduce of [false,true]) for(const fontsOff of [false,true]) for(const w of [320,360,390,768,1024,1440,1920]){
   const {browser,page}=await open({w,h:w<700?800:900,reduce,mobile:w<700,touch:w<700});
   if(fontsOff) await page.route('**/fonts.googleapis.com/**',r=>r.abort());
   await page.goto(AFTER);await settle(page);
   const r=await page.evaluate(()=>({ov:document.documentElement.scrollWidth>document.documentElement.clientWidth,h:document.body.scrollHeight}));
   log('L',!r.ov,`${w}px reduce=${reduce} fontsOff=${fontsOff} overflowX=${r.ov} h=${r.h}`);await browser.close();
 }
 if(G.includes('T')){const tb=await txt(BEFORE),ta=await txt(AFTER);
  const EXC={'ag-dir04-01':[['первое групповое занятие для взрослых','первое групповое занятие']],
   'ag-dir04-04':[['Первое групповое занятие для взрослых бесплатное','Первое групповое занятие бесплатное']],
   'ag-dir04-06':[['Первое групповое занятие для взрослых — бесплатно.','Первое групповое занятие — бесплатно.']],
   'ag-dir04-08':[['Первое групповое занятие для взрослых бесплатное.','Первое групповое занятие бесплатное.']]};
  for(const id of Object.keys(tb)){let a=ta[id];(EXC[id]||[]).forEach(([n,o])=>{a=a.split(n).join(o);});a=a.replace(/\s+/g,' ').trim();let i=0;while(i<tb[id].length&&tb[id][i]===a[i])i++;
   log('T',a===tb[id],id+(a===tb[id]?' текст совпадает'+(EXC[id]?' (кроме правки «'+EXC[id][0][0]+'»)':''):' РАЗНИЦА '+JSON.stringify(tb[id].slice(i-40,i+40))+' → '+JSON.stringify(a.slice(i-40,i+40))));}
  const html=fs.readFileSync('after.html','utf8').replace(/<!--[\s\S]*?-->/g,'');
  const fr=html.includes('alt="Мешки у клетки в зале Apollo MMA Gym"')&&/img_5464-scaled\.jpeg" width="1024" height="683" alt="Клетка для ММА в зале Apollo MMA Gym на Чкалова, 72"/.test(html)&&!/src="[^"]*img_5410/.test(html)&&!/src="[^"]*img_5433/.test(html);
  log('T',fr,`кадры: 01 img_5470 alt по кадру; 02 клетка — img_5464; img_5410 (ринг) и img_5433 (мешок у стены) сняты: ${fr}`);}

 if(G.includes('C')){const lb=await links(BEFORE),la=await links(AFTER);const add=la.filter(x=>!lb.includes(x)),rem=lb.filter(x=>!la.includes(x));
  log('C',rem.length===0&&add.length===0,`ссылки +${add.length} −${rem.length}`);}
 if(G.includes('M')){
  for(const mode of [{name:'js off',js:false},{name:'reduce',reduce:true},{name:'cdn fail',cdn:'fail'},{name:'cdn hang',cdn:'hang'}]){
   const {browser,page}=await open({w:390,h:800,mobile:true,...mode});await page.goto(AFTER,{waitUntil:'domcontentloaded'});await page.waitForTimeout(2700);
   if(mode.js!==false) for(let y=0;y<9000;y+=600){await page.evaluate(y=>scrollTo(0,y),y);await page.waitForTimeout(40);}
   const r=await page.evaluate(()=>{const bad=[];document.querySelectorAll('.ag-scope :is(p,h1,h2,h3,a,li,dt,dd,summary,td,th,figcaption)').forEach(el=>{if(el.closest('[aria-hidden="true"],[hidden],dialog'))return;let n=el,op=1;while(n&&n.nodeType===1){op*=parseFloat(getComputedStyle(n).opacity);n=n.parentElement;}if(getComputedStyle(el).display==='none')return;if(getComputedStyle(el).visibility==='hidden')return;if(op<0.99&&el.textContent.trim())bad.push(el.textContent.trim().slice(0,30));});
     const r4=document.getElementById('ag-dir04-04');return {bad,m:document.documentElement.getAttribute('data-ag-motion'),lv:getComputedStyle(r4.querySelector('.ag-fl__lv')).display,panels:[...r4.querySelectorAll('.ag-fl__panel')].filter(c=>getComputedStyle(c).visibility!=='hidden').length};});
   const exp=mode.js===false?{lv:'none',panels:4}:{lv:'grid',panels:1};
   log('M',r.bad.length===0&&r.lv===exp.lv&&r.panels===exp.panels,`${mode.name}: motion=${r.m} скрытых текстов ${r.bad.length} ${r.bad.slice(0,3).join('|')}; 04: знак ${r.lv}, видимых панелей ${r.panels}`);await browser.close();}
  const {browser,page}=await open({w:1440});await page.goto(AFTER);await settle(page);
  const r=await page.evaluate(()=>{const o={};document.querySelectorAll('.ag-scope').forEach(root=>{const all=root.querySelectorAll('[data-ag-anim]');o[root.id]=[all.length,[...all].filter(e=>!e.hasAttribute('data-ag-done')).length];});return o;});
  for(const [id,[n,left]] of Object.entries(r)) log('M',left===0,`motion on: ${id} анимаций ${n}, не отсканировано ${left}`);await browser.close();}


 if(G.includes('F')){
  // ---- 04 «Что уже есть — что добрать» + черта
  for(const w of [1440,768,600,390,360,320]){const {browser,page,errs}=await open({w,h:w<700?844:900,mobile:w<700,touch:w<700});await page.goto(AFTER);await settle(page);
   await page.evaluate(()=>{const s=document.querySelector('#ag-dir04-04 .ag-fl__tabs').getBoundingClientRect();scrollTo(0,scrollY+s.top-80);});await page.waitForTimeout(400);
   const res=[];let cells=new Set(),okAll=true,mid=null;
   for(const i of [0,1,2,3,0,3,2,1]){const t=(await page.$$('#ag-dir04-04 .ag-fl__tab'))[i];if(w<700){const b=await t.boundingBox();await page.touchscreen.tap(b.x+b.width/2,b.y+b.height/2);}else await t.click();
    if(i===3&&!mid){await page.waitForTimeout(150);mid=await page.evaluate(LV);}
    await page.waitForTimeout(500);const s=await page.evaluate(LV);cells.add(s.cell);
    const want=WANT[i];const lvok=want?(s.vis==='visible'&&s.up===want[0]&&s.dn===want[1]&&s.gap>=8):s.vis==='hidden';
    const barok=w<768?(Math.abs(s.bar.x-s.tabr.x)<=1&&Math.abs(s.bar.y-s.tabr.y)<=1&&Math.abs(s.bar.w-s.tabr.w)<=1&&Math.abs(s.bar.h-s.tabr.h)<=1):true;
    if(!(lvok&&barok))okAll=false;res.push(i+(lvok?'':'✗знак')+(barok?'':'✗черта')+(want?'('+s.gap+')':''));}
   const midok=w<768?(mid&&mid.bar.x>0&&!(Math.abs(mid.bar.x-mid.tabr.x)<=1&&Math.abs(mid.bar.y-mid.tabr.y)<=1)):true;
   log('F',okAll&&cells.size===1&&midok&&errs.length===0,`04, ${w}px: знак по вкладкам (стойка/пол: ● ○ · ○ ● · ○ ○ · нет) ${res.join(' ')}; высота ячейки панелей одна (${[...cells].join('/')}); ${w<768?'черта-рамка совпадает с вкладкой, на 150 мс — в пути ('+(mid?mid.bar.x+','+mid.bar.y:'')+')':'черта ПК'}; ошибок ${errs.length}`);
   await browser.close();}
  // 04: смена раскладки — без проезда; reduce; forced; печать
  {const {browser,page}=await open({w:1440,h:900});await page.goto(AFTER);await settle(page);
   await page.click('#ag-dir04-04 .ag-fl__tab >> nth=3');await page.waitForTimeout(500);
   await page.setViewportSize({width:700,height:900});await page.waitForTimeout(60);const s=await page.evaluate(LV);
   const ok1=Math.abs(s.bar.x-s.tabr.x)<=1&&Math.abs(s.bar.y-s.tabr.y)<=1;
   await page.setViewportSize({width:1200,height:900});await page.waitForTimeout(60);const s2=await page.evaluate(()=>{const b=document.querySelector('#ag-dir04-04 .ag-fl__bar').getBoundingClientRect(),t=document.querySelector('#ag-dir04-04 .ag-fl__tab[aria-selected="true"]').getBoundingClientRect();return Math.abs(b.left-t.left)<=1;});
   log('F',ok1&&s2,`04: 1440 → 700 → 1200 — черта встаёт на «Ребёнку» сразу (через 60 мс: ${ok1}/${s2})`);
   await page.emulateMedia({reducedMotion:'reduce'});await page.click('#ag-dir04-04 .ag-fl__tab >> nth=1');await page.waitForTimeout(120);const r=await page.evaluate(LV);
   log('F',r.dn===true&&r.up===false,`04, reduce на лету: знак за 120 мс без перехода («Из борьбы»: пол ●)`);
   await page.emulateMedia({reducedMotion:'no-preference',media:'print'});await page.waitForTimeout(300);
   const pr=await page.evaluate(()=>({lv:getComputedStyle(document.querySelector('#ag-dir04-04 .ag-fl__lv')).display,vis:[...document.querySelectorAll('#ag-dir04-04 .ag-fl__panel')].filter(p=>getComputedStyle(p).visibility==='visible').length}));
   log('F',pr.lv==='none'&&pr.vis===4,`04, печать: знака нет, панелей видно ${pr.vis}/4`);await browser.close();}
  {const {browser,page}=await open({w:390,h:844,mobile:true,touch:true});await page.emulateMedia({forcedColors:'active'});await page.goto(AFTER);await settle(page);
   await page.evaluate(()=>document.getElementById('ag-dir04-04').scrollIntoView());await page.waitForTimeout(300);
   const s=await page.evaluate(LV);const bg=await page.evaluate(()=>getComputedStyle(document.querySelector('#ag-dir04-04 .ag-fl__bar')).backgroundColor);
   await (await page.$('#ag-dir04-04 .ag-fl__wrap')).screenshot({path:'shots/forced_04.png'});
   log('F',s.up&&!s.dn&&/rgba\(\d+, \d+, \d+, 0\)|transparent/.test(bg),`04, forced, телефон: знак (стойка ●) и рамка-черта без заливки (${bg})`);await browser.close();}
  // ---- 02 кадры и рисунок
  {const {browser,page}=await open({w:1440,h:900});await page.goto(AFTER);await settle(page);
   const r=await page.evaluate(()=>{const z=document.getElementById('ag-dir04-02');return {cage:z.querySelector('.ag-fz__pane--cage img').src.includes('img_5464'),matImg:!!z.querySelector('.ag-fz__pane--mat img'),matArt:!!z.querySelector('.ag-fz__pane--mat svg.ag-fz__art'),par:z.querySelectorAll('[data-ag-anim="parallax"]').length,done:[...z.querySelectorAll('[data-ag-anim]')].every(e=>e.hasAttribute('data-ag-done'))};});
   const W0=await page.evaluate(()=>[...document.querySelectorAll('#ag-dir04-02 .ag-fz__pane')].map(p=>Math.round(p.getBoundingClientRect().width)).join(','));
   await page.hover('#ag-dir04-02 .ag-fz__pane--bags');await page.waitForTimeout(600);
   const W1=await page.evaluate(()=>[...document.querySelectorAll('#ag-dir04-02 .ag-fz__pane')].map(p=>Math.round(p.getBoundingClientRect().width)).join(','));
   await (await page.$('#ag-dir04-02 .ag-fz__row')).screenshot({path:'shots/f02_1440.png'});
   log('F',r.cage&&!r.matImg&&r.matArt&&r.par===1&&r.done&&W0===W1,`02: клетка — img_5464; борцовская зона — рисунок, без снимка; parallax только у снимка (${r.par}); наведение не меняет створки (${W0} → ${W1})`);await browser.close();}
  // ---- 08 F22
  {const {browser,page}=await open({w:1440,h:900});await page.goto(AFTER);await settle(page);
   await page.evaluate(()=>document.getElementById('ag-dir04-08').scrollIntoView());await page.waitForTimeout(400);
   await page.click('#ag-dir04-08 .ag-fq__item >> nth=1 >> summary');await page.waitForTimeout(60);
   const a=await page.evaluate(()=>{const x=document.querySelectorAll('#ag-dir04-08 .ag-fq__a')[1];const an=x.getAnimations();return {n:an.length,t:getComputedStyle(x).transform,o:getComputedStyle(x).transformOrigin};});
   await page.waitForTimeout(400);
   await page.click('#ag-dir04-08 .ag-fq__all');await page.waitForTimeout(30);
   const bulk=await page.evaluate(()=>document.getElementById('ag-dir04-08').getAnimations({subtree:true}).filter(x=>!x.transitionProperty).length);
   const st=await page.evaluate(()=>[...document.querySelectorAll('#ag-dir04-08 .ag-fq__item')].filter(d=>d.open).length);
   log('F',a.n===1&&/matrix\(0\.9/.test(a.t)&&/^0px/.test(a.o)&&bulk===0&&st===8,`08: ответ растёт из хвоста (анимаций ${a.n}, на 60 мс ${a.t.slice(0,24)}, origin ${a.o}); «Раскрыть все» — все ${st} без анимации (${bulk})`);
   await page.emulateMedia({reducedMotion:'reduce'});await page.click('#ag-dir04-08 .ag-fq__all');await page.waitForTimeout(100);await page.click('#ag-dir04-08 .ag-fq__item >> nth=2 >> summary');await page.waitForTimeout(30);
   const rn=await page.evaluate(()=>document.querySelectorAll('#ag-dir04-08 .ag-fq__a')[2].getAnimations().length);
   await page.emulateMedia({reducedMotion:'no-preference'});
   await page.keyboard.press('Shift+Tab');await page.keyboard.press('Tab');
   const fr=await page.evaluate(()=>{const e=document.activeElement;const cs=getComputedStyle(e);return [e.className,cs.borderBottomLeftRadius,cs.outlineWidth];});
   log('F',rn===0&&fr[0]==='ag-fq__q'&&fr[1]==='20px'&&fr[2]==='3px',`08: reduce на лету — без анимации (${rn}); фокус вопроса: углы пузыря сохранены (${fr[1]} снизу слева… ${fr[2]})`);
   const head=JSON.parse(fs.readFileSync('out/HEAD_mma-samara_v1.1.html','utf8').match(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/)[1]);
   const oldh=JSON.parse(fs.readFileSync('/home/claude/work/head_test/HEAD_mma-samara.html','utf8').match(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/)[1]);
   const fq=h=>h['@graph'].find(n=>n['@type']==='FAQPage').mainEntity;
   const QA=()=>page.evaluate(()=>[...document.querySelectorAll('#ag-dir04-08 .ag-fq__item')].map(d=>[d.querySelector('.ag-fq__qt').textContent.replace(/\s+/g,' ').trim(),d.querySelector('.ag-fq__a').textContent.replace(/\s+/g,' ').trim()]));
   const qa=await QA();await page.goto(BEFORE);await settle(page);const qb=await QA();
   const dif=(q,f)=>q.map(([n,a],i)=>f[i]&&(f[i].name!==n||f[i].acceptedAnswer.text.replace(/<[^>]+>/g,'').replace(/\s+/g,' ').trim()!==a)?i:null).filter(x=>x!==null);
   const da=dif(qa,fq(head)),db=dif(qb,fq(oldh));
   log('F',JSON.stringify(da)===JSON.stringify(db)&&qa[0][1].includes('для взрослых бесплатное')&&fq(head)[0].acceptedAnswer.text===qa[0][1],`FAQPage HEAD v1.1 = 08: ответ 1 совпадает дословно («для взрослых»); прочие расхождения те же, что у v1.0.0: [${da.join(',')}]`);
   await browser.close();}
  // ---- магниты, параллакс, F23, зерно
  {const {browser,page}=await open({w:1440,h:900});await page.goto(AFTER);await settle(page);
   const mag=await page.$$eval('[data-ag-magnetic]',x=>x.length);const par=await page.$$eval('[data-ag-parallax]',x=>x.map(e=>e.getAttribute('data-ag-parallax')));
   log('F',mag===0&&par.every(v=>parseFloat(v)<=0.08),`магнитных кнопок: ${mag}; параллакс ${par.join(', ')} (≤ 0.08)`);
   const res=[];
   for(const [sel,inn] of [['#ag-dir04-01 .ag-btn--primary','.ag-btn__in'],['#ag-dir04-05 .ag-btn--ghost','.ag-btn__in'],['#ag-dir04-06 .ag-btn--ink','.ag-btn__in'],['#ag-dir04-08 .ag-fq__all','.ag-fq__ain'],['#ag-dir04-09 .ag-btn--primary','.ag-btn__in'],['#ag-dir04-09 .ag-btn--ghost','.ag-btn__in']]){
    const el=await page.$(sel);if(!el){res.push(sel+': нет');continue;}await el.scrollIntoViewIfNeeded();await page.waitForTimeout(250);const b0=await el.boundingBox();
    await page.evaluate(s=>document.querySelector(s).addEventListener('click',e=>e.preventDefault(),{once:true}),sel);
    await page.mouse.move(b0.x+b0.width/2,b0.y+b0.height/2);await page.mouse.down();await page.waitForTimeout(220);
    const t=await page.$eval(sel+' '+inn,e=>getComputedStyle(e).transform);const b1=await el.boundingBox();await page.mouse.up();await page.waitForTimeout(80);
    res.push([sel.slice(8,10),/matrix\(0\.98/.test(t)&&Math.abs(b1.x-b0.x)<0.5]);}
   log('F',res.every(r=>Array.isArray(r)&&r[1]===true),`F23 нажатие: ${res.map(r=>Array.isArray(r)?r.join(':'):r).join(' ')}`);
   const gr=await page.evaluate(()=>['#ag-dir04-04 .ag-fl','#ag-dir04-06 .ag-fp'].map(s=>/svg/.test(getComputedStyle(document.querySelector(s),'::before').backgroundImage)));
   log('F',gr.every(Boolean),`зерно бумаги на ПК: 04 ${gr[0]}, 06 ${gr[1]}`);await browser.close();}
  {const {browser,page}=await open({w:390,h:844,mobile:true,touch:true});await page.goto(AFTER);await settle(page);
   const gr=await page.evaluate(()=>['#ag-dir04-04 .ag-fl','#ag-dir04-06 .ag-fp'].map(s=>/svg/.test(getComputedStyle(document.querySelector(s),'::before').backgroundImage)));
   log('F',!gr[0]&&!gr[1],`телефон: зерна нет (04 ${gr[0]}, 06 ${gr[1]})`);await browser.close();}
  // ---- ссылка из 04 на строку разреза 03 работает
  {const {browser,page}=await open({w:1440,h:900});await page.goto(AFTER);await settle(page);
   await page.evaluate(()=>document.getElementById('ag-dir04-04').scrollIntoView());await page.waitForTimeout(300);
   await page.click('#ag-dir04-04 .ag-fl__term >> nth=0');await page.waitForTimeout(1200);
   const r=await page.evaluate(()=>{const e=document.getElementById('ag-dir04-03-perevody').getBoundingClientRect();return Math.round(e.top);});
   log('F',r>=0&&r<500,`04 → 03: «переводы» ставит строку разреза под шапку (top ${r})`);await browser.close();}
 }
 if(G.includes('A')){const axeSrc=fs.readFileSync(require.resolve('axe-core/axe.min.js'),'utf8');
  for(const m of [{w:1440},{w:1024},{w:390,mobile:true},{w:390,mobile:true,reduce:true},{w:320,mobile:true},{w:390,nojs:true}]){
   let o;if(m.nojs){fs.writeFileSync('after_nojs.html',fs.readFileSync('after.html','utf8').replace(/<script>[\s\S]*?<\/script>/g,'').replace(/<!--[\s\S]*?-->/g,'').replace(/<noscript>([\s\S]*?)<\/noscript>/g,'$1'));o=await open({w:390,h:900});await o.page.goto('file://'+path.resolve('after_nojs.html'));await o.page.waitForTimeout(800);}
   else {o=await open({...m,h:900});await o.page.goto(AFTER);await settle(o.page);}
   await o.page.addScriptTag({content:axeSrc});const res=await o.page.evaluate(async()=>(await axe.run(document.getElementById('allrecords'),{resultTypes:['violations']})).violations.map(v=>[v.id,v.impact,v.nodes.length,v.nodes[0].target.join(' ')]));
   const s=res.filter(v=>/serious|critical/.test(v[1]));log('A',res.length===0,`${m.w}${m.reduce?' reduce':''}${m.nojs?' без JS':''}: нарушений ${res.length} (serious/critical ${s.length}) ${res.map(v=>v.join(':')).join(' ; ').slice(0,300)}`);await o.browser.close();}
  for(const w of [1440,390]){const o=await open({w,h:900,mobile:w<700,touch:w<700});await o.page.goto(AFTER);await settle(o.page);
   await o.page.click('#ag-dir04-04 .ag-fl__tab >> nth=1');await o.page.click('#ag-dir04-08 .ag-fq__all');await o.page.waitForTimeout(500);
   await o.page.addScriptTag({content:axeSrc});const res=await o.page.evaluate(async()=>(await axe.run(document.getElementById('allrecords'),{resultTypes:['violations']})).violations.map(v=>[v.id,v.impact,v.nodes[0].target.join(' ')]));
   log('A',res.length===0,`${w}, «Из борьбы» + FAQ раскрыт: нарушений ${res.length} ${res.map(v=>v.join(':')).join(' ; ').slice(0,300)}`);await o.browser.close();}}
 fs.writeFileSync('checks_s_'+G+'.json',JSON.stringify(out,null,1));
 for(const g of Object.keys(out)){console.log('## '+g);out[g].forEach(x=>console.log('  '+x));}
})();
