# HEAD /mma-samara v1.1: FAQPage ответ 1 = DIR04-08 v1.1.0 (факт № 11 «для взрослых»); остальное — как в HEAD 26.09
import re, json, html
W='/home/claude/work/'
old=open(W+'head_test/HEAD_mma-samara.html',encoding='utf-8').read()
g=json.loads(re.search(r'<script type="application/ld\+json">(.*?)</script>',old,re.S).group(1))
b8=open('out/DIR04-08_v1.1.0.html',encoding='utf-8').read()
items=re.findall(r'<span class="ag-fq__qt">(.*?)</span></summary>\s*<div class="ag-fq__a">(.*?)</div>',b8,re.S)
def clean(s):
    s=re.sub(r'<[^>]+>','',s); s=html.unescape(s).replace(' ',' ')
    return re.sub(r'\s+',' ',s).strip()
OLD_A='Нет. Стойку, передвижения и первые переводы разбирают с начала. Скажите при записи, что занимаетесь впервые, — это передадут тренеру группы. Первое групповое занятие бесплатное.'
NEW_A=clean(items[0][1])
assert NEW_A==OLD_A.replace('занятие бесплатное.','занятие для взрослых бесплатное.'), NEW_A
n=0
for node in g['@graph']:
    if node.get('@type')=='FAQPage':
        q=node['mainEntity'][0]; assert q['acceptedAnswer']['text']==OLD_A and q['name']==clean(items[0][0])
        q['acceptedAnswer']['text']=NEW_A; n+=1
assert n==1
com=('<!-- Apollo Gym · /mma-samara · HEAD v1.1 · 01.10.2026 · Tilda → Настройки страницы → Дополнительно → «HTML-код для вставки внутрь HEAD». '
     'Тестовая копия с адресами apolloboxing.tilda.ws. Заменяет HEAD от 26.09 целиком; старый JSON-LD удалить. '
     'v1.1: FAQPage, ответ «Нужно ли уметь бороться, чтобы прийти?» = DIR04-08 v1.1.0 (факт № 11 «для взрослых»); остальное без изменений. -->\n')
out=com+'<script type="application/ld+json">\n'+json.dumps(g,ensure_ascii=False,indent=1)+'\n</script>\n'
open('out/HEAD_mma-samara_v1.1.html','w',encoding='utf-8').write(out)
print('ok', len(out))
