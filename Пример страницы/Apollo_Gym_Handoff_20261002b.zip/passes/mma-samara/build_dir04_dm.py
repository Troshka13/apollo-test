# -*- coding: utf-8 -*-
"""/mma-samara (DIR04) · проход «дизайн, движение и фишка» (PROMPT_DIR04_DESIGN_MOTION_v2, 01.10.2026).
src/DIR04-0N_v1.0.0.html → out/DIR04-0N_v1.1.0.html. Каждая замена обязана найтись нужное число раз."""
import re, os, sys

sys.path.insert(0, '/home/claude/pr')
from build_prices_dm import rep, rx, focus3, wrap, press_css, touch, GRAIN  # noqa: E402

SRC, OUT = 'src', 'out'
os.makedirs(OUT, exist_ok=True)
DATE = '01.10.2026'
E = 'cubic-bezier(.22,.61,.36,1)'
IMG5464 = 'https://static.tildacdn.pub/tild3334-6462-4835-b461-663439656337/img_5464-scaled.jpeg'
IMG5410 = 'https://static.tildacdn.pub/tild6432-3439-4361-b633-313734343633/img_5410-scaled.jpeg'


def load(n):
    return open('%s/DIR04-0%d_v1.0.0.html' % (SRC, n), encoding='utf-8').read()


def save(n, t):
    p = '%s/DIR04-0%d_v1.1.0.html' % (OUT, n)
    open(p, 'w', encoding='utf-8').write(t)
    print('DIR04-0%d v1.1.0 %6d байт' % (n, len(t.encode('utf-8'))))


def bump(t, n, note):
    t = rx(t, r'(DIR04-0\d · [^\n]*?)· v1\.0\.0 · \d\d\.09\.2026', r'\1· v1.1.0 · 01.10.2026')
    i = t.index('-->') + 3
    return t[:i] + '\n<!-- v1.1.0 (проход «дизайн, движение и фишка», PROMPT_DIR04_DESIGN_MOTION_v2, %s):\n     %s -->' % (DATE, note) + t[i:]


def add_css(t, css):
    i = t.index('  </style>')
    return t[:i] + '\n  /* ===== v1.1.0 · дизайн, движение и фишка (01.10) ===== */\n' + css + t[i:]


def grain_css(root, sec, wrap_cls):
    return '''  /* F29 · зерно бумаги (статично, только ≥ 640 px; forced-colors и печать — без зерна) */
  @media (min-width:640px){
    %(r)s .%(s)s{position:relative;}
    %(r)s .%(s)s::before{content:"";position:absolute;inset:0;z-index:0;pointer-events:none;opacity:.12;background-image:%(g)s;background-size:180px 180px;}
    %(r)s .%(w)s{position:relative;z-index:1;}
  }
  @media (forced-colors:active){%(r)s .%(s)s::before{display:none;}}
  @media print{%(r)s .%(s)s::before{display:none;}}
''' % {'r': root, 's': sec, 'w': wrap_cls, 'g': GRAIN}


# ---------------------------------------------------------------- DIR04-01
def c01():
    t = load(1); R = '#ag-dir04-01'
    t = bump(t, 1, 'Кадр img_5470 сверен глазами 01.10: ряд мешков у клетки; alt по кадру (подпись адресом — как была).\n'
                   '     Факт № 11: «0 ₽ — первое групповое занятие для взрослых». Магнит снят, F23, фокус 3 px.\n'
                   '     Конус света — parallax 0.08 (было 0.14; MOTION: локальный параллакс .05–.08).')
    t = rep(t, 'глазами не сверен — подпись', 'сверен глазами 01.10: ряд мешков у клетки; подпись')
    t = rep(t, 'alt="Зал Apollo MMA Gym на Чкалова, 72" decoding="async" fetchpriority="high"',
            'alt="Мешки у клетки в зале Apollo MMA Gym" decoding="async" fetchpriority="high"')
    t = rep(t, '<b>0&nbsp;₽</b><span class="ag-fh__cap">первое групповое занятие</span>',
            '<b>0&nbsp;₽</b><span class="ag-fh__cap">первое групповое занятие для&nbsp;взрослых</span>')
    t = rep(t, 'data-ag-anim="parallax" data-ag-parallax="0.14"', 'data-ag-anim="parallax" data-ag-parallax="0.08"')
    t = rep(t, ' data-ag-magnetic="0.18"', '')
    t = wrap(t, 'a', 'ag-btn ag-btn--primary', 'ag-btn__in')
    t = focus3(t, R)
    t = add_css(t, press_css(R, [('ag-btn', 'ag-btn__in')]))
    t = touch(t)
    save(1, t)


# ---------------------------------------------------------------- DIR04-02
MAT_OLD = r'<figure class="ag-fz__fig" data-ag-parallax-scope data-ag-slot="DIR04-02-mat" data-ag-ratio="3:2" data-ag-brief="([^"]*)">\s*<span class="ag-fz__media"><span class="ag-fz__imgbox"><img[^>]*img_5433[^>]*></span></span>'
MAT_NEW = '''<figure class="ag-fz__fig agph" data-ag-slot="DIR04-02-mat" data-ag-ratio="3:2" data-ag-brief="\\1">
            <span class="ag-fz__media ag-fz__media--art">
              <svg class="ag-fz__art ag-fz__art--mat" viewBox="0 0 300 220" preserveAspectRatio="xMidYMax meet" aria-hidden="true" focusable="false">
                <path class="ag-fz__rail" d="M8 20H292"/>
                <rect class="ag-fz__body" x="34" y="44" width="66" height="92" rx="8"/>
                <rect class="ag-fz__body ag-fz__body--mid" x="117" y="44" width="66" height="92" rx="8"/>
                <rect class="ag-fz__body" x="200" y="44" width="66" height="92" rx="8"/>
                <path class="ag-fz__mat" d="M30 150H270L292 200H8Z"/>
                <path class="ag-fz__seam" d="M110 150 102 200M190 150 198 200M19 175H281"/>
                <path class="ag-fz__band" d="M30 150H270"/>
                <path class="ag-fz__ground" d="M8 212H292"/>
              </svg>
            </span>'''


def c02():
    t = load(2); R = '#ag-dir04-02'
    t = bump(t, 2, 'Кадры сверены глазами 01.10 (как на /mma, CL02): img_5410 — ринг, не клетка → створка «Клетка для ММА» —\n'
                   '     img_5464 (клетка); img_5433 — мешок у стены с граффити, борцовской зоны на нём нет → створка «Зона с мягким\n'
                   '     покрытием для борьбы» — рисунок-слот в стиле мешков (слот DIR04-02-mat и бриф на месте). Расширение\n'
                   '     створки по наведению снято: снимок в триптихе один, клетка и так шире. Фокус 3 px.')
    t = rep(t, 'src="%s" width="1024" height="683" alt="Клетка для ММА в зале на Чкалова, 72"' % IMG5410,
            'src="%s" width="1024" height="683" alt="Клетка для ММА в зале Apollo MMA Gym на Чкалова, 72"' % IMG5464)
    t = rx(t, MAT_OLD, MAT_NEW)
    t = rep(t, '''  @media (min-width:1024px) and (hover:hover) and (pointer:fine){
    #ag-dir04-02 .ag-fz__row:hover .ag-fz__pane{flex-grow:1;}
    #ag-dir04-02 .ag-fz__row .ag-fz__pane:hover{flex-grow:2.2;}
  }''', '''  /* v1.1.0: расширение створки по наведению снято — снимок в триптихе один */''')
    t = rep(t, '     наведённая мышью створка расширяется (CSS-переход flex-grow, без JS).',
            '     (v1.1.0: расширение створки по наведению снято).')
    t = focus3(t, R)
    css = '''  /* рисунок-слот борцовской зоны: стенные маты и покрытие у линии пола (без плана помещения) */
  #ag-dir04-02 .ag-fz__art--mat{max-width:340px;height:80%;}
  #ag-dir04-02 .ag-fz__body--mid{fill:#2E2E34;}
  #ag-dir04-02 .ag-fz__mat{fill:#26262B;stroke:#3C3C43;stroke-width:2;stroke-linejoin:round;}
  #ag-dir04-02 .ag-fz__seam{fill:none;stroke:#3C3C43;stroke-width:2;}
  @media (forced-colors:active){
    #ag-dir04-02 .ag-fz__mat,#ag-dir04-02 .ag-fz__seam{stroke:CanvasText;}
  }
'''
    t = add_css(t, css)
    save(2, t)


# ---------------------------------------------------------------- DIR04-03
def c03():
    t = load(3); R = '#ag-dir04-03'
    t = bump(t, 3, 'Фокус 3 px. Разрез, подсветка строк по ссылкам и движение — как в v1.0.0.')
    t = focus3(t, R)
    save(3, t)


# ---------------------------------------------------------------- DIR04-04
LV = '''
        <div class="ag-fl__lv" aria-hidden="true">
          <span class="ag-fl__lvr ag-fl__lvr--up"><i class="ag-fl__pt"></i><span>Стойка</span></span>
          <span class="ag-fl__lvl"></span>
          <span class="ag-fl__lvr ag-fl__lvr--dn"><i class="ag-fl__pt"></i><span>Пол</span></span>
        </div>
      </div>
    </div>
  </section>'''

MQ_JS = '''    /* v1.1.0: смена раскладки (ПК ↔ сетка 2×2) — черта встаёт без проезда */
    var mq = W.matchMedia ? W.matchMedia("(max-width: 767px)") : null;
    if (mq) {
      var jump = function () {
        list.classList.add("is-jump");
        W.requestAnimationFrame(function () { W.requestAnimationFrame(function () { list.classList.remove("is-jump"); }); });
      };
      if (mq.addEventListener) mq.addEventListener("change", jump); else if (mq.addListener) mq.addListener(jump);
    }

    /* Подгонка подписей вкладок по самому длинному слову */'''


def c04():
    t = load(4); R = '#ag-dir04-04'
    t = bump(t, 4, 'Ведущая фишка «Что уже есть — что добрать»: знак «линия пола» (как в DIR04-07) над текстом панели —\n'
                   '     точка над жёлтой линией — стойка, под ней — пол; залита — уже есть, пустой кружок — добрать. «Из ударных» —\n'
                   '     стойка есть, пол добрать; «Из борьбы» — наоборот; «Без опыта» — обе пунктиром; «Ребёнку» — знака нет.\n'
                   '     По текстам панелей, aria-hidden; слой в ячейке панелей — высота не растёт. F10 на телефоне: одна рамка\n'
                   '     с жёлтой полосой едет по сетке 2×2 (CSS от data-ag-tab), смена раскладки — без проезда. Факт № 11 в панели\n'
                   '     «Без опыта». F29 зерно бумаги (≥ 640 px), фокус 3 px.')
    t = rep(t, 'Первое групповое занятие бесплатное, дальше', 'Первое групповое занятие для&nbsp;взрослых бесплатное, дальше')
    t = rep(t, '\n      </div>\n    </div>\n  </section>', LV)
    t = rep(t, '    /* Подгонка подписей вкладок по самому длинному слову */', MQ_JS)
    t = rep(t, '  /* < 768: сетка 2×2, у выбранной ячейки своя черта */', '  /* < 768: сетка 2×2 (v1.1.0: одна рамка с чертой едет по сетке — ниже) */')
    t = focus3(t, R)
    css = '''  /* «Что уже есть — что добрать»: знак «линия пола» в ячейке панелей, над текстом панелей 1–3 */
  #ag-dir04-04 .ag-fl__lv{display:none;}
  #ag-dir04-04 .ag-fl__panels.is-js>.ag-fl__lv{
    display:grid;grid-area:1 / 1;align-self:start;justify-self:start;z-index:1;row-gap:7px;width:max-content;pointer-events:none;
    margin:clamp(20px,2.6vw,34px) 0 0 clamp(20px,3vw,40px);
  }
  #ag-dir04-04 .ag-fl__lvr{display:flex;align-items:center;gap:10px;font-family:var(--f-display);font-size:13px;font-weight:600;line-height:1;letter-spacing:.14em;text-transform:uppercase;color:var(--muted);transition:color .38s %(e)s;}
  #ag-dir04-04 .ag-fl__pt{display:block;width:14px;height:14px;border-radius:50%%;border:2px solid var(--ink);background:transparent;transition:background-color .38s %(e)s;}
  #ag-dir04-04 .ag-fl__lvl{display:block;width:112px;height:3px;margin-left:-6px;border-radius:2px;background:var(--accent);box-shadow:0 1px 0 rgba(9,9,10,.35);}
  #ag-dir04-04[data-ag-tab="0"] .ag-fl__lvr--up .ag-fl__pt,
  #ag-dir04-04[data-ag-tab="1"] .ag-fl__lvr--dn .ag-fl__pt{background:var(--ink);}
  #ag-dir04-04[data-ag-tab="0"] .ag-fl__lvr--up,
  #ag-dir04-04[data-ag-tab="1"] .ag-fl__lvr--dn{color:var(--ink);}
  #ag-dir04-04[data-ag-tab="3"] .ag-fl__lv{visibility:hidden;}
  #ag-dir04-04 .ag-fl__panels.is-js :is(#ag-dir04-04-p1,#ag-dir04-04-p2,#ag-dir04-04-p3) .ag-fl__text{margin-top:56px;}
  @media (max-width:599px){
    #ag-dir04-04 .ag-fl__panels.is-js>.ag-fl__lv{margin:16px 0 0 16px;}
    #ag-dir04-04 .ag-fl__panels.is-js :is(#ag-dir04-04-p1,#ag-dir04-04-p2,#ag-dir04-04-p3) .ag-fl__text{margin-top:54px;}
  }
  /* F10 на телефоне: одна рамка с жёлтой чертой едет по сетке 2×2 */
  @media (max-width:767px){
    #ag-dir04-04 .ag-fl__tabs{grid-auto-rows:1fr;}
    #ag-dir04-04 .ag-fl__bar{
      display:block;z-index:2;top:0;left:0;bottom:auto;width:calc(50%% - 4px);height:calc((100%% - 8px) / 2);
      border:1px solid var(--ink);border-radius:6px;background:none;box-shadow:none;
      transform:translate(calc(var(--c,0) * (100%% + 8px)),calc(var(--r,0) * (100%% + 8px)));
    }
    #ag-dir04-04 .ag-fl__bar::after{content:"";position:absolute;left:12px;right:12px;bottom:-1px;height:4px;background:var(--accent);box-shadow:inset 0 -1px 0 rgba(9,9,10,.25);}
    #ag-dir04-04[data-ag-tab="1"] .ag-fl__bar{--c:1;--r:0;}
    #ag-dir04-04[data-ag-tab="2"] .ag-fl__bar{--c:0;--r:1;}
    #ag-dir04-04[data-ag-tab="3"] .ag-fl__bar{--c:1;--r:1;}
    #ag-dir04-04 .ag-fl__tab[aria-selected="true"]{border-color:var(--edge);}
    #ag-dir04-04 .ag-fl__tab[aria-selected="true"]::after{background:transparent;box-shadow:none;}
  }
  #ag-dir04-04 .ag-fl__tabs.is-jump .ag-fl__bar{transition:none;}
  @media (forced-colors:active){
    #ag-dir04-04 .ag-fl__pt{border-color:CanvasText;}
    #ag-dir04-04[data-ag-tab="0"] .ag-fl__lvr--up .ag-fl__pt,
    #ag-dir04-04[data-ag-tab="1"] .ag-fl__lvr--dn .ag-fl__pt{background:CanvasText;}
    #ag-dir04-04 .ag-fl__lvl{background:CanvasText;}
  }
  @media (forced-colors:active) and (max-width:767px){
    #ag-dir04-04 .ag-fl__bar{background:none;border-color:CanvasText;}
    #ag-dir04-04 .ag-fl__bar::after{background:CanvasText;}
  }
  @media print{
    #ag-dir04-04 .ag-fl__lv{display:none !important;}
    #ag-dir04-04 .ag-fl__panels.is-js .ag-fl__panel .ag-fl__text{margin-top:10px !important;}
  }
''' % {'e': E}
    css += grain_css(R, 'ag-fl', 'ag-fl__wrap')
    t = add_css(t, css)
    save(4, t)


# ---------------------------------------------------------------- DIR04-05
def c05():
    t = load(5); R = '#ag-dir04-05'
    t = bump(t, 5, 'F23 — нажатие кнопки, фокус 3 px. Состав и текст — как есть.')
    t = wrap(t, 'a', 'ag-btn ag-btn--ghost', 'ag-btn__in')
    t = focus3(t, R)
    t = add_css(t, press_css(R, [('ag-btn', 'ag-btn__in')]))
    t = touch(t)
    save(5, t)


# ---------------------------------------------------------------- DIR04-06
def c06():
    t = load(6); R = '#ag-dir04-06'
    t = bump(t, 6, 'Факт № 11: «Первое групповое занятие для взрослых — бесплатно.» Цены — как есть. F29 зерно бумаги (≥ 640 px),\n'
                   '     F23, фокус 3 px.')
    t = rep(t, '<p class="ag-fp__text">Первое групповое занятие — бесплатно. ', '<p class="ag-fp__text">Первое групповое занятие для взрослых&nbsp;— бесплатно. ')
    t = wrap(t, 'a', 'ag-btn ag-btn--ink', 'ag-btn__in')
    t = focus3(t, R)
    css = press_css(R, [('ag-btn', 'ag-btn__in')])
    css += grain_css(R, 'ag-fp', 'ag-fp__wrap')
    t = add_css(t, css)
    t = touch(t)
    save(6, t)


# ---------------------------------------------------------------- DIR04-07
def c07():
    t = load(7); R = '#ag-dir04-07'
    t = bump(t, 7, 'Фокус 3 px. Сравнение — как в v1.0.0 (колонка ММА закреплена; выбора нет — F08 без движения).')
    t = focus3(t, R)
    save(7, t)


# ---------------------------------------------------------------- DIR04-08
def c08():
    t = load(8); R = '#ag-dir04-08'
    t = bump(t, 8, 'F22: открытый ответ «вырастает из хвоста» пузыря (translateY + scale .98 → 1 + прозрачность, 260 мс; reduce —\n'
                   '     проверка в момент открытия; без анимации высоты и закрытия; «Раскрыть все» — без анимации). Фокус вопроса\n'
                   '     сохраняет «хвост» пузыря, 3 px. Факт № 11 в ответе «Нужно ли уметь бороться…» (HEAD v1.1 — тот же текст).\n'
                   '     F23 — «Раскрыть все». Исправлено: при «Раскрыть все» ответы анимировались (toggle приходит асинхронно, флаг\n'
                   '     снимается таймером).')
    t = rep(t, 'тренеру группы. Первое групповое занятие бесплатное.</p>', 'тренеру группы. Первое групповое занятие для взрослых бесплатное.</p>')
    t = rep(t, '    var reduce = W.matchMedia && W.matchMedia("(prefers-reduced-motion: reduce)").matches;\n',
            '    var still = W.matchMedia ? W.matchMedia("(prefers-reduced-motion: reduce)") : { matches: false };\n')
    t = rep(t, '''        if (d.open && a && !reduce && a.animate) {
          a.animate([{ opacity: 0.001, transform: "translateY(6px)" }, { opacity: 1, transform: "none" }], { duration: 250, easing: "ease-out" });
        }''', '''        if (d.open && a && !still.matches && a.animate) {
          a.animate([{ opacity: 0.001, transform: "translateY(6px) scale(.98)" }, { opacity: 1, transform: "none" }], { duration: 260, easing: "cubic-bezier(.22,.61,.36,1)" });
        }''')
    t = rep(t, 'Ответ, открытый читателем, проявляется за 250 мс. */', 'Ответ, открытый читателем, «вырастает из хвоста» за 260 мс (v1.1.0). */')
    # «Раскрыть все»: события toggle приходят после клика асинхронно — флаг снимается таймером, иначе ответы анимируются
    t = rep(t, '      items.forEach(function (d) { d.open = open; });\n      busy = false;\n',
            '      items.forEach(function (d) { d.open = open; });\n      W.setTimeout(function () { busy = false; }, 80);\n')
    t = wrap(t, 'button', 'ag-fq__all', 'ag-fq__ain')
    t = focus3(t, R)
    css = press_css(R, [('ag-fq__all', 'ag-fq__ain')])
    css += '''  /* F22 · ответ растёт из хвоста пузыря (левый нижний угол) */
  #ag-dir04-08 .ag-fq__a{transform-origin:0 100%%;}
  /* фокус вопроса — по форме пузыря, с «хвостом» */
  #ag-dir04-08.ag-scope .ag-fq__q:focus-visible{border-radius:20px 20px 4px 20px;outline-offset:4px;}
  @media (max-width:599px){#ag-dir04-08.ag-scope .ag-fq__q:focus-visible{border-radius:16px 16px 4px 16px;}}
''' % {}
    t = add_css(t, css)
    t = touch(t)
    save(8, t)


# ---------------------------------------------------------------- DIR04-09
def c09():
    t = load(9); R = '#ag-dir04-09'
    t = bump(t, 9, 'Магнит снят, F23 — нажатие обеих кнопок, фокус 3 px. Контур «ММА» — parallax 0.08 (было 0.1).')
    t = rep(t, ' data-ag-magnetic="0.2"', '')
    t = rep(t, 'data-ag-anim="parallax" data-ag-parallax="0.1"', 'data-ag-anim="parallax" data-ag-parallax="0.08"')
    t = wrap(t, 'a', 'ag-btn ag-btn--primary', 'ag-btn__in')
    t = wrap(t, 'a', 'ag-btn ag-btn--ghost', 'ag-btn__in')
    t = focus3(t, R)
    t = add_css(t, press_css(R, [('ag-btn', 'ag-btn__in')]))
    t = touch(t)
    save(9, t)


if __name__ == '__main__':
    for f in (c01, c02, c03, c04, c05, c06, c07, c08, c09):
        f()
