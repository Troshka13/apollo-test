# -*- coding: utf-8 -*-
"""/kickboxing-samara (DIR03) · проход «дизайн, движение и фишка» (PROMPT_DIR03_DESIGN_MOTION_v2, 01.10.2026).
src/DIR03-0N_*.html (04, 05 — v1.0.1) → out/DIR03-0N_v1.1.0.html. Каждая замена обязана найтись нужное число раз."""
import re, os, sys

sys.path.insert(0, '/home/claude/pr')
from build_prices_dm import rep, rx, focus3, wrap, press_css, touch, GRAIN  # noqa: E402

SRC, OUT = 'src', 'out'
os.makedirs(OUT, exist_ok=True)
DATE = '01.10.2026'
BASE = {4: 'v1.0.1', 5: 'v1.0.1'}
NUMS = [1, 2, 3, 4, 5, 6, 7, 8]
E = 'cubic-bezier(.22,.61,.36,1)'
OLD = 'rec3987538001, rec3987729701, rec3987840801'


def load(n):
    return open('%s/DIR03-0%d_%s.html' % (SRC, n, BASE.get(n, 'v1.0.0')), encoding='utf-8').read()


def save(n, t):
    p = '%s/DIR03-0%d_v1.1.0.html' % (OUT, n)
    open(p, 'w', encoding='utf-8').write(t)
    print('DIR03-0%d v1.1.0 %6d байт' % (n, len(t.encode('utf-8'))))


def bump(t, n, note):
    base = BASE.get(n, 'v1.0.0')
    t = rx(t, r'(APOLLO GYM · DIR03-0\d[^\n]*?)· %s · \d\d\.09\.2026' % re.escape(base), r'\1· v1.1.0 · 01.10.2026')
    i = t.index('-->') + 3
    return t[:i] + '\n<!-- v1.1.0 (проход «дизайн, движение и фишка», PROMPT_DIR03_DESIGN_MOTION_v2, %s):\n     %s -->' % (DATE, note) + t[i:]


def add_css(t, css):
    i = t.index('  </style>')
    return t[:i] + '\n  /* ===== v1.1.0 · дизайн, движение и фишка (01.10) ===== */\n' + css + t[i:]


def grain_css(root, sec, wrap_cls):
    return '''  /* F29 · зерно бумаги (статично, только ≥ 640 px; forced-colors и печать — без зерна) */
  @media (min-width:640px){
    %(r)s .%(s)s::before{content:"";position:absolute;inset:0;z-index:0;pointer-events:none;opacity:.12;background-image:%(g)s;background-size:180px 180px;}
    %(r)s .%(w)s{position:relative;z-index:1;}
  }
  @media (forced-colors:active){%(r)s .%(s)s::before{display:none;}}
  @media print{%(r)s .%(s)s::before{display:none;}}
''' % {'r': root, 's': sec, 'w': wrap_cls, 'g': GRAIN}


# ---------------------------------------------------------------- DIR03-01
def c01():
    t = load(1); R = '#ag-dir03-01'
    t = bump(t, 1, 'Кадр Zal_3 сверен глазами 01.10: перчатки на углу ринга, ринг на заднем плане (ринг на Галактионовской\n'
                   '     подтверждён кадром Zal_4); alt по кадру. Факт № 11: «0 ₽ — первое групповое занятие для взрослых».\n'
                   '     Магнит снят, F23, фокус 3 px. Parallax кадра (LCP) не менялся.')
    t = rep(t, 'глазами не сверен — подпись только адресом', 'сверен глазами 01.10 — перчатки на углу ринга; alt по кадру')
    t = rep(t, 'alt="Зал Apollo на Галактионовской, 81" decoding="async" fetchpriority="high"',
            'alt="Перчатки на углу ринга в зале Apollo Boxing Gym на Галактионовской, 81" decoding="async" fetchpriority="high"')
    t = rep(t, '<b>0&nbsp;₽</b><span class="ag-kh__cap">первое групповое занятие</span>',
            '<b>0&nbsp;₽</b><span class="ag-kh__cap">первое групповое занятие для&nbsp;взрослых</span>')
    t = rep(t, ' data-ag-magnetic="0.18"', '')
    t = wrap(t, 'a', 'ag-btn ag-btn--primary', 'ag-btn__in')
    t = focus3(t, R)
    t = add_css(t, press_css(R, [('ag-btn', 'ag-btn__in')]))
    t = touch(t)
    save(1, t)


# ---------------------------------------------------------------- DIR03-02
BODY = '''<g fill="#6E6E76" stroke="#6E6E76" stroke-linecap="round" stroke-linejoin="round">
              <circle cx="120" cy="40" r="23" stroke="none"/>
              <path d="M90 84Q120 76 150 84L139 170H101Z" stroke-width="16"/>
              <path d="M96 92 66 140 80 74M144 92 174 140 160 74" fill="none" stroke-width="24"/>
              <path d="M110 172 84 248 86 326M130 172 156 248 154 326" fill="none" stroke-width="24"/>
            </g>
            <g stroke="#0E0E10" stroke-width="5">
              <circle class="ag-cmp__p ag-cmp__p--fists" cx="80" cy="56" r="30" style="fill:var(--p-fists,#3C3C43)"/>
              <circle class="ag-cmp__p ag-cmp__p--fists" cx="160" cy="56" r="30" style="fill:var(--p-fists,#3C3C43)"/>
              <circle class="ag-cmp__p ag-cmp__p--elbows" cx="66" cy="140" r="23" style="fill:var(--p-elbows,#3C3C43)"/>
              <circle class="ag-cmp__p ag-cmp__p--elbows" cx="174" cy="140" r="23" style="fill:var(--p-elbows,#3C3C43)"/>
              <circle class="ag-cmp__p ag-cmp__p--knees" cx="84" cy="248" r="23" style="fill:var(--p-knees,#3C3C43)"/>
              <circle class="ag-cmp__p ag-cmp__p--knees" cx="156" cy="248" r="23" style="fill:var(--p-knees,#3C3C43)"/>
              <circle class="ag-cmp__p ag-cmp__p--shins" cx="86" cy="300" r="23" style="fill:var(--p-shins,#3C3C43)"/>
              <circle class="ag-cmp__p ag-cmp__p--shins" cx="154" cy="300" r="23" style="fill:var(--p-shins,#3C3C43)"/>
            </g>'''


def fig(mod):
    return ('<svg class="ag-cmp__ico ag-cmp__ico--%s" width="60" height="90" viewBox="0 0 240 360" aria-hidden="true" focusable="false">\n'
            '            %s\n          </svg>' % (mod, BODY))


# Отметки «разница на схеме»: где точки есть — сплошная обводка; где их нет — пунктир (оба — нейтральный --text)
MARKS = {
    'boxing': {'solid': [('kick', 'shins')], 'dash': [('boxing', 'shins')]},
    'thai': {'solid': [('thai', 'knees'), ('thai', 'elbows')], 'dash': [('kick', 'knees'), ('kick', 'elbows')]},
}

VS_JS = r'''    /* v1.1.0 · F10: подложка нажатой кнопки «Сравнить с» переезжает (::before у группы, вид нажатой кнопки);
       смена ряда — без проезда; первая установка, RO и шрифты — без перехода. 220 мс, как выделение F08. */
    var pill = { on: false, row: null };
    function placeVs(jump) {
      var b = null;
      keys.forEach(function (k) { if (k.getAttribute("aria-pressed") === "true") b = k; });
      if (!b || !b.offsetWidth) return;
      var row = b.offsetTop, wrapRow = pill.row !== null && Math.abs(row - pill.row) > b.offsetHeight / 2;
      if (!pill.on || jump || wrapRow) group.classList.add("is-jump");
      group.style.setProperty("--ix", b.offsetLeft + "px");
      group.style.setProperty("--iy", row + "px");
      group.style.setProperty("--iw", b.offsetWidth + "px");
      group.style.setProperty("--ih", b.offsetHeight + "px");
      if (!pill.on) { group.classList.add("is-ind"); pill.on = true; }
      pill.row = row;
      if (group.classList.contains("is-jump")) W.requestAnimationFrame(function () { W.requestAnimationFrame(function () { group.classList.remove("is-jump"); }); });
    }
    var running = [];
'''


def c02():
    t = load(2); R = '#ag-dir03-02'
    t = bump(t, 2, 'Ведущая фишка «Разница на схеме» (F08): при выборе «Сравнить с» на схемах шапки обводятся точки, которыми\n'
                   '     дисциплины отличаются по строке «Что бьют»: бокс — голени (у кикбоксинга сплошная обводка, у бокса пунктир),\n'
                   '     тайский — колени и локти (у тайского сплошная, у кикбоксинга пунктир). Цвет нейтральный, без чисел и оценок.\n'
                   '     Схемы шапки — встроенные SVG (viewBox 240×360), кнопки и легенда — <use>. ПК: подсветка выбранной колонки —\n'
                   '     одна полоса, переезжает за 220 мс. F10: подложка «Сравнить с». Телефон 360–819: шапка из thead (схемы\n'
                   '     40×60 + имя), подписи первой строки скрыты визуально; ≤ 359 — как v1.0.0. Въезд выбранной ячейки 220 мс\n'
                   '     вместе со схемой; reduce — проверка в момент нажатия. Печать — вся таблица. Факт № 11 в лиде. Фокус 3 px.')
    for mod in ('kick', 'box', 'thai'):
        t = rep(t, '<svg class="ag-cmp__ico ag-cmp__ico--%s" width="60" height="90" aria-hidden="true" focusable="false"><use href="#ag-dir03-02-i-fig"/></svg>' % mod,
                fig(mod))
    t = rx(t, r'(<span class="ag-cmp__hn">[^<]*</span>(?:<span class="ag-cmp__now" aria-hidden="true">сравниваем</span>)?)(</th>)',
           lambda m: '<span class="ag-cmp__htx">' + m.group(1) + '</span>' + m.group(2), 3)
    t = rep(t, 'первое групповое занятие в любой из них бесплатное.', 'первое групповое занятие для&nbsp;взрослых в любой из них бесплатное.')
    # JS
    t = rep(t, '    var reduce = W.matchMedia && W.matchMedia("(prefers-reduced-motion: reduce)").matches;\n',
            '    var still = W.matchMedia ? W.matchMedia("(prefers-reduced-motion: reduce)") : { matches: false };\n')
    t = rep(t, '    function choose(k, animate) {\n', VS_JS + '    function choose(k, animate) {\n')
    t = rep(t, '''      if (animate && was !== k && !reduce && narrow && narrow.matches) {
        Array.prototype.forEach.call(root.querySelectorAll(".ag-cmp__c--" + k), function (c) {
          if (c.animate) c.animate([{ opacity: 0.001, transform: "translateY(4px)" }, { opacity: 1, transform: "none" }], { duration: 200, easing: "ease-out" });
        });
      }
''', '''      placeVs(!animate);
      if (animate && was !== k && !still.matches && narrow && narrow.matches) {
        running.forEach(function (a) { try { a.cancel(); } catch (e) {} });
        running = [];
        Array.prototype.forEach.call(root.querySelectorAll(".ag-cmp__c--" + k + ", .ag-cmp__h--" + k), function (c) {
          if (c.animate) running.push(c.animate([{ opacity: 0.001, transform: "translateY(4px)" }, { opacity: 1, transform: "none" }], { duration: 220, easing: "cubic-bezier(.22,.61,.36,1)" }));
        });
      }
''')
    t = rep(t, '    root.setAttribute("data-ag-js", "");\n    group.hidden = false;\n    choose(state, false);\n  })();',
            '    root.setAttribute("data-ag-js", "");\n    group.hidden = false;\n    choose(state, false);\n'
            '    if ("ResizeObserver" in W) new W.ResizeObserver(function () { placeVs(true); }).observe(group);\n'
            '    if (D.fonts && D.fonts.ready) D.fonts.ready.then(function () { placeVs(true); });\n  })();')
    t = rep(t, '     На телефоне новая ячейка проявляется animate() 200 мс. */',
            '     На телефоне новая ячейка и схема шапки проявляются animate() 220 мс (v1.1.0). */')
    t = focus3(t, R)
    solid, dash = [], []
    for vs, m in MARKS.items():
        for col, pt in m['solid']:
            solid.append('  #ag-dir03-02[data-ag-vs="%s"] .ag-cmp__h--%s .ag-cmp__p--%s' % (vs, col, pt))
        for col, pt in m['dash']:
            dash.append('  #ag-dir03-02[data-ag-vs="%s"] .ag-cmp__h--%s .ag-cmp__p--%s' % (vs, col, pt))
    css = '''  #ag-dir03-02 .ag-cmp__htx{display:block;min-width:0;}
  /* «Разница на схеме»: обводка отличающихся точек (без колец и масштаба — точки стоят плотно) */
  #ag-dir03-02 .ag-cmp__p{transition:stroke .22s %(e)s,stroke-width .22s %(e)s;}
%(solid)s{stroke:var(--text);stroke-width:10px;}
%(dash)s{stroke:var(--text);stroke-width:7px;stroke-dasharray:8 7;}

  /* ПК (≥ 820): подсветка выбранной колонки — одна полоса, переезжает (F08, 220 мс) */
  @media (min-width:820px){
    #ag-dir03-02[data-ag-js] .ag-cmp__tw{position:relative;}
    #ag-dir03-02[data-ag-js] .ag-cmp__t{position:relative;z-index:1;}
    #ag-dir03-02[data-ag-js] .ag-cmp__tw::before{
      content:"";position:absolute;top:0;bottom:0;left:calc(17%% + 83%% / 3);width:calc(83%% / 3);z-index:0;pointer-events:none;
      background:rgba(255,255,255,.05);border-radius:0;transition:transform .22s %(e)s,border-radius .22s %(e)s;
    }
    #ag-dir03-02[data-ag-vs="thai"] .ag-cmp__tw::before{transform:translateX(100%%);border-radius:0 18px 18px 0;}
    #ag-dir03-02[data-ag-js][data-ag-vs] .ag-cmp__h--boxing,
    #ag-dir03-02[data-ag-js][data-ag-vs] .ag-cmp__c--boxing,
    #ag-dir03-02[data-ag-js][data-ag-vs] .ag-cmp__h--thai,
    #ag-dir03-02[data-ag-js][data-ag-vs] .ag-cmp__c--thai{background:transparent;}
  }
  @media (min-width:820px) and (max-width:959px){
    #ag-dir03-02[data-ag-js] .ag-cmp__tw::before{left:calc(19%% + 81%% / 3);width:calc(81%% / 3);}
  }

  /* F10 · подложка нажатой кнопки «Сравнить с» (вид нажатой кнопки), над фоном кнопок, под подписью */
  #ag-dir03-02 .ag-cmp__vs{position:relative;isolation:isolate;}
  @media not (forced-colors:active){
    #ag-dir03-02 .ag-cmp__vs.is-ind::before{
      content:"";position:absolute;z-index:1;left:0;top:0;width:var(--iw,0px);height:var(--ih,0px);border-radius:var(--r-pill);pointer-events:none;
      border:1.5px solid var(--accent);background:rgba(255,196,0,.12);box-shadow:inset 0 0 0 1px var(--accent);
      transform:translate(var(--ix,0px),var(--iy,0px));transition:transform .22s %(e)s,width .22s %(e)s;
    }
    #ag-dir03-02 .ag-cmp__vs.is-jump::before{transition:none;}
    #ag-dir03-02 .ag-cmp__vs.is-ind .ag-cmp__key>*{position:relative;z-index:2;}
    #ag-dir03-02 .ag-cmp__vs.is-ind .ag-cmp__key[aria-pressed="true"]{background:transparent;border-color:transparent;box-shadow:none;}
  }

  /* Телефон 360–819 с JS: шапка из thead — схемы кикбоксинга и выбранной рядом, над рядами */
  @media (min-width:360px) and (max-width:819px){
    #ag-dir03-02[data-ag-js] .ag-cmp__t thead{display:block;}
    #ag-dir03-02[data-ag-js] .ag-cmp__t thead tr{padding:0 0 10px;border-top:0;}
    #ag-dir03-02[data-ag-js] .ag-cmp__corner{display:none;}
    #ag-dir03-02[data-ag-js] .ag-cmp__h{display:flex;align-items:center;gap:10px;min-width:0;padding:0 2px;border:0;background:none;}
    #ag-dir03-02[data-ag-js] .ag-cmp__h--kick{grid-area:kick;}
    #ag-dir03-02[data-ag-js] .ag-cmp__h--boxing,
    #ag-dir03-02[data-ag-js] .ag-cmp__h--thai{grid-area:other;}
    #ag-dir03-02[data-ag-vs="boxing"] .ag-cmp__h--thai,
    #ag-dir03-02[data-ag-vs="thai"] .ag-cmp__h--boxing{visibility:hidden;}
    #ag-dir03-02[data-ag-js] .ag-cmp__h--kick::before{display:none;}
    #ag-dir03-02[data-ag-js] .ag-cmp__h .ag-cmp__ico{width:40px;height:60px;margin:0;}
    #ag-dir03-02[data-ag-js] .ag-cmp__hn{font-size:15px;line-height:1.15;}
    #ag-dir03-02[data-ag-js] .ag-cmp__now{margin-top:3px;font-size:10.5px;}
    /* подписи дисциплин первой строки повторяют шапку — только для чтения с экрана */
    #ag-dir03-02[data-ag-js] .ag-cmp__t tbody tr:first-child .ag-cmp__who{position:absolute;width:1px;height:1px;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;}
  }
  @media (max-width:819px){
    #ag-dir03-02[data-ag-js] .ag-cmp__t tbody tr{padding:8px 0;}
  }
  @media print{
    #ag-dir03-02 .ag-cmp__p{transition:none !important;stroke:#0E0E10 !important;stroke-width:5px !important;stroke-dasharray:none !important;}
    #ag-dir03-02 .ag-cmp__tw::before,
    #ag-dir03-02 .ag-cmp__vs::before{display:none !important;}
    /* A4 попадает в телефонную сетку: печатаем все три ячейки ряда */
    #ag-dir03-02 .ag-cmp__c--boxing,
    #ag-dir03-02 .ag-cmp__c--thai,
    #ag-dir03-02 .ag-cmp__h{visibility:visible !important;}
    #ag-dir03-02[data-ag-js] .ag-cmp__t tr{display:block !important;}
    #ag-dir03-02[data-ag-js] .ag-cmp__t thead{display:none !important;}
    #ag-dir03-02 .ag-cmp__t tbody tr .ag-cmp__who{position:static !important;width:auto !important;height:auto !important;margin:0 0 4px !important;clip:auto !important;overflow:visible !important;display:block !important;}
    #ag-dir03-02 .ag-cmp__c+.ag-cmp__c{margin-top:8px !important;}
  }
  @media (forced-colors:active){
%(solid_f)s,
%(dash_f)s{stroke:CanvasText;}
  }
''' % {'e': E, 'solid': ',\n'.join(solid), 'dash': ',\n'.join(dash),
       'solid_f': ',\n'.join('  ' + s for s in solid), 'dash_f': ',\n'.join('  ' + s for s in dash)}
    t = add_css(t, css)
    t = touch(t)
    save(2, t)


# ---------------------------------------------------------------- DIR03-03
def c03():
    t = load(3); R = '#ag-dir03-03'
    t = bump(t, 3, 'F14: линия трассы проводится за 700 мс, станции — шагом 50 мс (было 1 400 / 80). Телефон: точки ленты —\n'
                   '     слоты постоянной ширины, текущая вытягивается в пилюлю (ряд не дёргается). Фокус 3 px.')
    t = rep(t, 'data-ag-anim="draw" data-ag-dur="1400"', 'data-ag-anim="draw" data-ag-dur="700"')
    t = rep(t, 'aria-label="Шаги тренировки по кикбоксингу" data-ag-anim="stagger" data-ag-stagger="80"',
            'aria-label="Шаги тренировки по кикбоксингу" data-ag-anim="stagger" data-ag-stagger="50"')
    t = focus3(t, R)
    css = '''  /* F14 · точки ленты: слот постоянной ширины, текущая — пилюля (без scale — ряд не дёргается) */
  @media (max-width:1023px){
    #ag-dir03-03 .ag-kt__dots{gap:4px;}
    #ag-dir03-03 .ag-kt__dot{position:relative;width:20px;height:8px;border-radius:0;background:none;transform:none;}
    #ag-dir03-03 .ag-kt__dot.is-on{background:none;transform:none;}
    #ag-dir03-03 .ag-kt__dot::before{
      content:"";position:absolute;top:0;left:6px;width:8px;height:8px;border-radius:4px;background:rgba(9,9,10,.22);
      transition:left .22s %(e)s,width .22s %(e)s,background-color .2s ease;
    }
    #ag-dir03-03 .ag-kt__dot.is-on::before{left:0;width:20px;background:var(--ink);}
  }
  @media (forced-colors:active){
    #ag-dir03-03 .ag-kt__dot::before{background:CanvasText;}
    #ag-dir03-03 .ag-kt__dot.is-on::before{background:Highlight;}
  }
''' % {'e': E}
    t = add_css(t, css)
    save(3, t)


# ---------------------------------------------------------------- DIR03-04
IND_JS = r'''    /* v1.1.0 · F10: жёлтая подложка выбранной вкладки-карточки переезжает (::before у tablist, над фоном вкладок,
       под подписями; цвет подписи меняется с задержкой 120 мс). Первая установка, RO и шрифты — без перехода. */
    var ind = { on: false, cur: 0, row: null };
    function placeInd(i, jump) {
      var t = tabs[i];
      ind.cur = i;
      if (!t || !t.offsetWidth) return;
      var row = t.offsetTop, wrapRow = ind.row !== null && Math.abs(row - ind.row) > t.offsetHeight / 2;
      if (!ind.on || jump || wrapRow) list.classList.add("is-jump");
      list.style.setProperty("--ix", t.offsetLeft + "px");
      list.style.setProperty("--iy", row + "px");
      list.style.setProperty("--iw", t.offsetWidth + "px");
      list.style.setProperty("--ih", t.offsetHeight + "px");
      if (!ind.on) { list.classList.add("is-ind"); ind.on = true; }
      ind.row = row;
      if (list.classList.contains("is-jump")) W.requestAnimationFrame(function () { W.requestAnimationFrame(function () { list.classList.remove("is-jump"); }); });
    }
'''


def c04():
    t = load(4); R = '#ag-dir03-04'
    t = bump(t, 4, 'От v1.0.1 (на тесте — v1.0.0 с именами в комментарии: заменить). F10: жёлтая подложка выбранной вкладки\n'
                   '     переезжает между карточками. Факт № 11: «Первое групповое занятие для взрослых бесплатное». F23 у кнопки,\n'
                   '     фокус 3 px.')
    t = rep(t, 'Первое групповое занятие бесплатное, дальше', 'Первое групповое занятие для&nbsp;взрослых бесплатное, дальше')
    t = wrap(t, 'a', 'ag-btn ag-btn--primary', 'ag-btn__in')
    t = focus3(t, R)
    t = rep(t, '    function select(i, focus) {\n', IND_JS + '    function select(i, focus) {\n')
    t = rep(t, '      if (focus) tabs[i].focus();\n', '      placeInd(i, false);\n      if (focus) tabs[i].focus();\n')
    t = rep(t, '    select(current(), false);\n\n',
            '    select(current(), false);\n'
            '    if ("ResizeObserver" in W) new W.ResizeObserver(function () { placeInd(ind.cur, true); }).observe(list);\n'
            '    if (D.fonts && D.fonts.ready) D.fonts.ready.then(function () { placeInd(ind.cur, true); });\n\n')
    css = press_css(R, [('ag-btn', 'ag-btn__in')])
    css += '''  /* F10 · подложка выбранной вкладки-карточки */
  #ag-dir03-04 .ag-kf__tabs{position:relative;isolation:isolate;}
  @media not (forced-colors:active){
    #ag-dir03-04 .ag-kf__tabs.is-ind::before{
      content:"";position:absolute;z-index:1;left:0;top:0;width:var(--iw,0px);height:var(--ih,0px);border-radius:18px;background:var(--accent);pointer-events:none;
      transform:translate(var(--ix,0px),var(--iy,0px));
      transition:transform .32s %(e)s,width .32s %(e)s,height .32s %(e)s;
    }
    #ag-dir03-04 .ag-kf__tabs.is-jump::before{transition:none;}
    #ag-dir03-04 .ag-kf__tabs.is-ind .ag-kf__tab>*{position:relative;z-index:2;}
    #ag-dir03-04 .ag-kf__tabs.is-ind .ag-kf__tab[aria-selected="true"]{background:transparent;border-color:transparent;transition:background-color .2s ease,border-color .2s ease,color .2s ease .12s;}
    #ag-dir03-04 .ag-kf__tabs.is-ind .ag-kf__tab .ag-kf__td{transition:color .2s ease .12s;}
    #ag-dir03-04 .ag-kf__tabs.is-ind .ag-kf__tab .ag-kf__pt{transition:background-color .2s ease .12s,border-color .2s ease .12s;}
    @media (max-width:599px){#ag-dir03-04 .ag-kf__tabs.is-ind::before{border-radius:14px;}}
  }
  @media print{#ag-dir03-04 .ag-kf__tabs::before{display:none;}}
''' % {'e': E}
    t = add_css(t, css)
    t = touch(t)
    save(4, t)


# ---------------------------------------------------------------- DIR03-05
def c05():
    t = load(5); R = '#ag-dir03-05'
    t = bump(t, 5, 'От v1.0.1 (на тесте — v1.0.0 с именами в комментарии: заменить). Состав и текст — как есть.\n'
                   '     F23 — нажатие кнопки, фокус 3 px.')
    t = wrap(t, 'a', 'ag-btn ag-btn--ghost', 'ag-btn__in')
    t = focus3(t, R)
    t = add_css(t, press_css(R, [('ag-btn', 'ag-btn__in')]))
    t = touch(t)
    save(5, t)


# ---------------------------------------------------------------- DIR03-06
def c06():
    t = load(6); R = '#ag-dir03-06'
    t = bump(t, 6, 'Факт № 11: «Первое групповое занятие для взрослых — бесплатно.» Цены — как есть. F29 зерно бумаги (≥ 640 px),\n'
                   '     F23, фокус 3 px.')
    t = rep(t, '<span>Первое групповое занятие — бесплатно.</span>', '<span>Первое групповое занятие для взрослых&nbsp;— бесплатно.</span>')
    t = wrap(t, 'a', 'ag-btn ag-btn--dark', 'ag-btn__in')
    t = focus3(t, R)
    css = press_css(R, [('ag-btn', 'ag-btn__in')])
    css += grain_css(R, 'ag-kp', 'ag-kp__wrap')
    t = add_css(t, css)
    t = touch(t)
    save(6, t)


# ---------------------------------------------------------------- DIR03-07
def c07():
    t = load(7); R = '#ag-dir03-07'
    t = bump(t, 7, 'F22: ответ раскрывается плавно (::details-content + interpolate-size, прогрессивно; overflow-clip-margin —\n'
                   '     фокус ссылок в ответе не режется); «Раскрыть все» — без перехода; пересчёт триггеров и по toggle, и по\n'
                   '     окончании перехода высоты. F23 — «Раскрыть все» и кнопка, фокус 3 px.')
    t = wrap(t, 'button', 'ag-kq__all', 'ag-kq__ain')
    t = wrap(t, 'a', 'ag-btn ag-btn--primary', 'ag-btn__in')
    t = focus3(t, R)
    css = press_css(R, [('ag-kq__all', 'ag-kq__ain'), ('ag-btn', 'ag-btn__in')])
    css += '''  /* F22 · плавное раскрытие ответа (Chromium 131+); иначе — мгновенно, как было */
  @supports (interpolate-size:allow-keywords) and selector(::details-content){
    #ag-dir03-07 .ag-kq__list{interpolate-size:allow-keywords;}
    #ag-dir03-07 .ag-kq__item::details-content{
      height:0;overflow:clip;overflow-clip-margin:8px;
      transition:height .32s %(e)s,content-visibility .32s allow-discrete;
    }
    #ag-dir03-07 .ag-kq__item[open]::details-content{height:auto;}
    #ag-dir03-07.is-bulk .ag-kq__item::details-content{transition:none;}
    @media (prefers-reduced-motion:reduce){
      #ag-dir03-07 .ag-kq__item::details-content{transition:none;}
    }
  }
''' % {'e': E}
    t = add_css(t, css)
    t = rx(t, r'(      busy = true;\n)(.*?)(      busy = false;\n)',
           lambda m: m.group(1) + '      root.classList.add("is-bulk");\n' + m.group(2) + m.group(3)
           + '      W.requestAnimationFrame(function () { W.requestAnimationFrame(function () { root.classList.remove("is-bulk"); }); });\n')
    t = rep(t, '      d.addEventListener("toggle", function () { if (!busy) { sync(); refresh(); } });\n    });\n',
            '      d.addEventListener("toggle", function () { if (!busy) { sync(); refresh(); } });\n    });\n'
            '    /* v1.1.0: высота ответа меняется переходом — пересчитать позиции анимаций ниже по окончании */\n'
            '    root.addEventListener("transitionend", function (e) {\n'
            '      if (e.propertyName === "height" && e.pseudoElement === "::details-content") refresh();\n'
            '    });\n')
    t = touch(t)
    save(7, t)


# ---------------------------------------------------------------- DIR03-08
def c08():
    t = load(8); R = '#ag-dir03-08'
    t = bump(t, 8, 'Магнит снят, F23 — нажатие обеих кнопок, фокус 3 px. Напоминание: записи %s\n'
                   '     (старые KICK-09/10/11) на тесте ещё стоят — удалить по поручению владельца.' % OLD)
    t = rep(t, ' data-ag-magnetic="0.2"', '')
    t = wrap(t, 'a', 'ag-btn ag-btn--primary', 'ag-btn__in')
    t = wrap(t, 'a', 'ag-btn ag-btn--ghost', 'ag-btn__in')
    t = focus3(t, R)
    t = add_css(t, press_css(R, [('ag-btn', 'ag-btn__in')]))
    t = touch(t)
    save(8, t)


if __name__ == '__main__':
    for f in (c01, c02, c03, c04, c05, c06, c07, c08):
        f()
