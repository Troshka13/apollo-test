// /kickboxing-samara (DIR03) · проверки прохода «дизайн, движение и фишка» (PROMPT_DIR03_DESIGN_MOTION_v2)
const {open,settle}=require('./lib');const fs=require('fs'),path=require('path');
const AFTER='file://'+path.resolve('after.html'), BEFORE='file://'+path.resolve('before.html');
const out={};const log=(g,ok,msg)=>{const s=(ok?"pass ":"FAIL ")+msg;(out[g]=out[g]||[]).push(s);console.log(g+" "+s);};
const G=process.env.G||'LTCMFA';
async function txt(url){const {browser,page}=await open({reduce:true});await page.goto(url);await page.waitForTimeout(2600);
  const r=await page.evaluate(()=>{const o={};document.querySelectorAll('.ag-scope').forEach(r=>{const c=r.cloneNode(true);c.querySelectorAll('style,script,.ag-vh').forEach(x=>x.remove());o[r.id]=c.textContent.replace(/\s+/g,' ').trim();});return o;});await browser.close();return r;}
async function links(url){const {browser,page}=await open({reduce:true});await page.goto(url);await page.waitForTimeout(400);
  const r=await page.evaluate(()=>[...document.querySelectorAll('.ag-scope a[href]')].map(a=>a.closest('.ag-scope').id+' '+a.getAttribute('href')));await browser.close();return r;}
// состояние сравнения 02: отметки по схемам, горящие точки, полоса, подложка
const S=`(()=>{const r=document.getElementById('ag-dir03-02');const cols=['kick','boxing','thai'];const o={vs:r.getAttribute('data-ag-vs'),marks:{},lit:{}};
  cols.forEach(c=>{const h=r.querySelector('.ag-cmp__h--'+c);o.marks[c]=[];o.lit[c]=[];['fists','elbows','knees','shins'].forEach(p=>{const e=h.querySelector('.ag-cmp__p--'+p);const cs=getComputedStyle(e);
    const w=parseFloat(cs.strokeWidth);if(w>=6.5)o.marks[c].push(p+(cs.strokeDasharray!=='none'?':dash':':solid'));if(/255, 196, 0/.test(cs.fill))o.lit[c].push(p);});});
  const tw=r.querySelector('.ag-cmp__tw');const b=getComputedStyle(tw,'::before');const m=new DOMMatrix(b.transform==='none'?undefined:b.transform);
  const th=r.querySelector('.ag-cmp__h--'+o.vs);o.band={c:b.content,x:parseFloat(b.left)+m.m41,w:parseFloat(b.width),tx:th.offsetLeft,tw:th.offsetWidth};
  const g=r.querySelector('.ag-cmp__vs');const p=getComputedStyle(g,'::before');const pm=new DOMMatrix(p.transform==='none'?undefined:p.transform);const k=[...g.querySelectorAll('.ag-cmp__key')].find(x=>x.getAttribute('aria-pressed')==='true');
  o.pill={c:p.content,x:pm.m41,y:pm.m42,w:parseFloat(p.width),tx:k.offsetLeft,ty:k.offsetTop,tw:k.offsetWidth,bg:getComputedStyle(k).backgroundColor};
  o.thead=getComputedStyle(r.querySelector('.ag-cmp__t thead')).display;o.h=Math.round(r.getBoundingClientRect().height);
  const who=r.querySelector('tbody tr .ag-cmp__who');o.who=who.getBoundingClientRect().width>2;o.sw=document.documentElement.scrollWidth>document.documentElement.clientWidth;return o;})()`;
const IND=(i)=>`(()=>{const l=document.querySelector('#ag-dir03-04 .ag-kf__tabs'),t=document.querySelectorAll('#ag-dir03-04 .ag-kf__tab')[${i}];const cs=getComputedStyle(l,'::before');const m=new DOMMatrix(cs.transform==='none'?undefined:cs.transform);return {x:m.m41,y:m.m42,w:parseFloat(cs.width),h:parseFloat(cs.height),tx:t.offsetLeft,ty:t.offsetTop,tw:t.offsetWidth,th:t.offsetHeight,bg:getComputedStyle(t).backgroundColor,c:cs.content};})()`;
const ok=(r)=>Math.abs(r.x-r.tx)<1&&Math.abs(r.y-r.ty)<1&&Math.abs(r.w-r.tw)<1&&Math.abs(r.h-r.th)<1;
const okP=(p)=>Math.abs(p.x-p.tx)<1&&Math.abs(p.y-p.ty)<1&&Math.abs(p.w-p.tw)<1;
const okB=(b)=>Math.abs(b.x-b.tx)<1.5&&Math.abs(b.w-b.tw)<1.5;
const WANT={boxing:{kick:['shins:solid'],boxing:['shins:dash'],thai:[]},thai:{kick:['elbows:dash','knees:dash'],boxing:[],thai:['elbows:solid','knees:solid']}};
const sameMarks=(s)=>['kick','boxing','thai'].every(c=>JSON.stringify([...s.marks[c]].sort())===JSON.stringify(WANT[s.vs][c]));
// «отмечено = разность наборов горящих точек»
const diffOk=(s)=>{const a=s.lit.kick,b=s.lit[s.vs];const d=[...a.filter(x=>!b.includes(x)),...b.filter(x=>!a.includes(x))].sort();const m=[...new Set([...s.marks.kick,...s.marks[s.vs]].map(x=>x.split(':')[0]))].sort();return JSON.stringify(d)===JSON.stringify(m);};
async function to02(page){await page.evaluate(()=>{const s=document.querySelector('#ag-dir03-02 .ag-cmp__body').getBoundingClientRect();scrollTo(0,scrollY+s.top-60);});await page.waitForTimeout(400);}
(async()=>{
 if(G.includes('L')) for(const reduce of [false,true]) for(const fontsOff of [false,true]) for(const w of [320,360,390,768,1024,1440,1920]){
   const {browser,page}=await open({w,h:w<700?800:900,reduce,mobile:w<700,touch:w<700});
   if(fontsOff) await page.route('**/fonts.googleapis.com/**',r=>r.abort());
   await page.goto(AFTER);await settle(page);
   const r=await page.evaluate(()=>({ov:document.documentElement.scrollWidth>document.documentElement.clientWidth,h:document.body.scrollHeight}));
   log('L',!r.ov,`${w}px reduce=${reduce} fontsOff=${fontsOff} overflowX=${r.ov} h=${r.h}`);await browser.close();
 }
 if(G.includes('T')){const tb=await txt(BEFORE),ta=await txt(AFTER);
  const EXC={'ag-dir03-01':[['первое групповое занятие для взрослых','первое групповое занятие']],
   'ag-dir03-02':[['первое групповое занятие для взрослых в любой','первое групповое занятие в любой']],
   'ag-dir03-04':[['Первое групповое занятие для взрослых бесплатное','Первое групповое занятие бесплатное']],
   'ag-dir03-06':[['Первое групповое занятие для взрослых — бесплатно.','Первое групповое занятие — бесплатно.']]};
  for(const id of Object.keys(tb)){let a=ta[id];(EXC[id]||[]).forEach(([n,o])=>{a=a.split(n).join(o);});a=a.replace(/\s+/g,' ').trim();let i=0;while(i<tb[id].length&&tb[id][i]===a[i])i++;
   log('T',a===tb[id],id+(a===tb[id]?' текст совпадает'+(EXC[id]?' (кроме правки «'+EXC[id][0][0]+'»)':''):' РАЗНИЦА '+JSON.stringify(tb[id].slice(i-40,i+40))+' → '+JSON.stringify(a.slice(i-40,i+40))));}
  const html=fs.readFileSync('after.html','utf8');
  const alt=html.includes('alt="Перчатки на углу ринга в зале Apollo Boxing Gym на Галактионовской, 81"')&&html.includes('Zal_3-1024x683.jpg');
  log('T',alt,`кадр 01: Zal_3 на месте, alt по кадру: ${alt}`);}
 if(G.includes('C')){const lb=await links(BEFORE),la=await links(AFTER);const add=la.filter(x=>!lb.includes(x)),rem=lb.filter(x=>!la.includes(x));
  log('C',rem.length===0&&add.length===0,`ссылки +${add.length} −${rem.length}`);}
 if(G.includes('M')){
  for(const mode of [{name:'js off',js:false},{name:'reduce',reduce:true},{name:'cdn fail',cdn:'fail'},{name:'cdn hang',cdn:'hang'}]){
   const {browser,page}=await open({w:390,h:800,mobile:true,...mode});await page.goto(AFTER,{waitUntil:'domcontentloaded'});await page.waitForTimeout(2700);
   if(mode.js!==false) for(let y=0;y<9000;y+=600){await page.evaluate(y=>scrollTo(0,y),y);await page.waitForTimeout(40);}
   const r=await page.evaluate(()=>{const bad=[];document.querySelectorAll('.ag-scope :is(p,h1,h2,h3,a,li,dt,dd,summary,td,th,figcaption)').forEach(el=>{if(el.closest('[aria-hidden="true"],[hidden],dialog'))return;let n=el,op=1;while(n&&n.nodeType===1){op*=parseFloat(getComputedStyle(n).opacity);n=n.parentElement;}if(getComputedStyle(el).display==='none')return;if(getComputedStyle(el).visibility==='hidden')return;if(op<0.99&&el.textContent.trim())bad.push(el.textContent.trim().slice(0,30));});
     const r2=document.getElementById('ag-dir03-02');return {bad,m:document.documentElement.getAttribute('data-ag-motion'),thead:getComputedStyle(r2.querySelector('thead')).display,cells:[...r2.querySelectorAll('.ag-cmp__c')].filter(c=>getComputedStyle(c).visibility!=='hidden').length};});
   const exp=mode.js===false?{thead:'none',cells:15}:{thead:'block',cells:10};
   log('M',r.bad.length===0&&r.thead===exp.thead&&r.cells===exp.cells,`${mode.name}: motion=${r.m} скрытых текстов ${r.bad.length} ${r.bad.slice(0,3).join('|')}; 02: шапка ${r.thead}, видимых ячеек ${r.cells}`);await browser.close();}
  const {browser,page}=await open({w:1440});await page.goto(AFTER);await settle(page);
  const r=await page.evaluate(()=>{const o={};document.querySelectorAll('.ag-scope').forEach(root=>{const all=root.querySelectorAll('[data-ag-anim]');o[root.id]=[all.length,[...all].filter(e=>!e.hasAttribute('data-ag-done')).length];});return o;});
  for(const [id,[n,left]] of Object.entries(r)) log('M',left===0,`motion on: ${id} анимаций ${n}, не отсканировано ${left}`);await browser.close();}

 if(G.includes('F')){
  // ---- 02 «Разница на схеме», ПК
  {const {browser,page,errs}=await open({w:1440,h:900});await page.goto(AFTER);await settle(page);await to02(page);
   const s0=await page.evaluate(S);
   log('F',s0.vs==='boxing'&&sameMarks(s0)&&diffOk(s0),`02, ПК, «Бокс»: отметки — кикбоксинг ${s0.marks.kick}, бокс ${s0.marks.boxing}, тайский ${s0.marks.thai.length?s0.marks.thai:'—'}; = разность горящих точек (${s0.lit.kick} / ${s0.lit.boxing}): ${diffOk(s0)}`);
   await page.click('#ag-dir03-02 .ag-cmp__key[data-ag-vs="thai"]');await page.waitForTimeout(100);const mid=await page.evaluate(S);await page.waitForTimeout(400);const s1=await page.evaluate(S);
   log('F',s1.vs==='thai'&&sameMarks(s1)&&diffOk(s1),`02, ПК, «Тайский»: отметки — кикбоксинг ${s1.marks.kick}, тайский ${s1.marks.thai}, бокс ${s1.marks.boxing.length?s1.marks.boxing:'—'}; = разность (${s1.lit.kick} / ${s1.lit.thai}): ${diffOk(s1)}`);
   log('F',okB(s0.band)&&okB(s1.band)&&mid.band.x>s0.band.tx+2&&mid.band.x<s1.band.tx-2&&s0.band.c!=='none',`02, ПК: полоса колонки под «Бокс» (${Math.round(s0.band.x)}↔${s0.band.tx}), едет к «Тайский» (на 100 мс x=${Math.round(mid.band.x)}, в конце ${Math.round(s1.band.x)}↔${s1.band.tx}), ширина = колонке`);
   log('F',okP(s0.pill)&&okP(s1.pill)&&mid.pill.x>s0.pill.tx+1&&mid.pill.x<s1.pill.tx-1&&s1.pill.bg==='rgba(0, 0, 0, 0)',`02, ПК: подложка «Сравнить с» под нажатой кнопкой, едет (на 100 мс x=${Math.round(mid.pill.x)} между ${s0.pill.tx} и ${s1.pill.tx}), у кнопки фон снят`);
   for(let i=0;i<10;i++){await page.click(`#ag-dir03-02 .ag-cmp__key[data-ag-vs="${i%2?'thai':'boxing'}"]`);await page.waitForTimeout(30);}
   await page.waitForTimeout(450);const s2=await page.evaluate(S);
   log('F',s2.vs==='thai'&&okP(s2.pill)&&okB(s2.band)&&sameMarks(s2)&&errs.length===0,`02, ПК: десять быстрых переключений — подложка, полоса и отметки на месте; ошибок ${errs.length} ${errs[0]||''}`);
   for(const w of [960,959,820]){await page.setViewportSize({width:w,height:900});await page.waitForTimeout(400);const s=await page.evaluate(S);log('F',okB(s.band)&&okP(s.pill)&&s.thead!=='none',`02, ${w}px: полоса (${Math.round(s.band.x)}↔${s.band.tx}, ${Math.round(s.band.w)}↔${s.band.tw}) и подложка на месте`);}
   await page.setViewportSize({width:1440,height:900});await page.waitForTimeout(300);await to02(page);
   await (await page.$('#ag-dir03-02 .ag-cmp__body')).screenshot({path:'shots/f02_thai_1440.png'});
   await browser.close();}
  // ?vs=thai — сразу, без перехода; ?vs=мусор — бокс
  for(const q of ['thai','zzz']){const {browser,page}=await open({w:1440,h:900});await page.goto(AFTER+'?vs='+q);await page.waitForTimeout(150);
   const an=await page.evaluate(()=>document.getAnimations().filter(a=>a.transitionProperty).map(a=>a.transitionProperty).filter(p=>/transform|stroke/.test(p)).length);const s=await page.evaluate(S);
   log('F',(q==='thai'?s.vs==='thai'&&okB(s.band):s.vs==='boxing')&&sameMarks(s)&&an===0,`02: ?vs=${q} → ${s.vs}, отметки и полоса на месте сразу (переходов ${an})`);await browser.close();}
  // телефон
  for(const w of [320,360,390,600]){const {browser,page,errs}=await open({w,h:844,mobile:true,touch:true});await page.goto(AFTER);await settle(page);await to02(page);
   const a=await page.evaluate(S);const tb=await (await page.$('#ag-dir03-02 .ag-cmp__key[data-ag-vs="thai"]')).boundingBox();
   await page.touchscreen.tap(tb.x+tb.width/2,tb.y+tb.height/2);await page.waitForTimeout(40);
   const an=await page.evaluate(()=>document.getElementById('ag-dir03-02').getAnimations({subtree:true}).filter(x=>!x.transitionProperty).map(x=>x.effect.target.className.split(' ')[1]||x.effect.target.className));
   const sw=await page.evaluate(()=>document.documentElement.scrollWidth>document.documentElement.clientWidth);
   await page.waitForTimeout(450);const b=await page.evaluate(S);
   const head=w>=360?a.thead==='block'&&!a.who:a.thead==='none'&&a.who;
   const th=an.filter(x=>/ag-cmp__h--thai/.test(x)).length;
   if(w===390){await (await page.$('#ag-dir03-02 .ag-cmp__body')).screenshot({path:'shots/f02_thai_390.png'});}
   log('F',head&&sameMarks(b)&&okP(b.pill)&&a.h===b.h&&!sw&&an.length===6&&errs.length===0,`02, телефон ${w}px: шапка со схемами ${a.thead==='block'?'есть':'нет'} (подписи первой строки ${a.who?'видны':'скрыты'}); «Тайский» — въезд ${an.length} элементов (${an.length?an[0]:''}…), отметки ${b.marks.thai}/${b.marks.kick}; высота ${a.h}→${b.h}; гориз. прокрутки ${sw}`);await browser.close();}
  // reduce, forced, печать
  {const {browser,page}=await open({w:390,h:844,mobile:true,touch:true});await page.goto(AFTER);await settle(page);await to02(page);await page.emulateMedia({reducedMotion:'reduce'});
   await page.click('#ag-dir03-02 .ag-cmp__key[data-ag-vs="thai"]');await page.waitForTimeout(30);
   const an=await page.evaluate(()=>document.getElementById('ag-dir03-02').getAnimations({subtree:true}).filter(x=>!x.transitionProperty).length);const s=await page.evaluate(S);
   log('F',an===0&&sameMarks(s)&&okP(s.pill),`02, reduce на лету: въезда нет (${an}), отметки и подложка сразу`);
   await page.emulateMedia({reducedMotion:'no-preference',media:'print'});await page.waitForTimeout(400);
   const pr=await page.evaluate(()=>{const r=document.getElementById('ag-dir03-02');return {cells:[...r.querySelectorAll('.ag-cmp__c')].filter(c=>getComputedStyle(c).visibility!=='hidden'&&c.getBoundingClientRect().height>0).length,who:[...r.querySelectorAll('.ag-cmp__who')].filter(w=>w.getBoundingClientRect().width>2).length,marks:[...r.querySelectorAll('.ag-cmp__p')].filter(p=>parseFloat(getComputedStyle(p).strokeWidth)>6).length,band:getComputedStyle(r.querySelector('.ag-cmp__vs'),'::before').display};});
   log('F',pr.cells===15&&pr.who===15&&pr.marks===0,`02, печать: видимых ячеек ${pr.cells}/15, подписей ${pr.who}/15, отметок ${pr.marks}`);await browser.close();}
  {const {browser,page}=await open({w:1440,h:900});await page.emulateMedia({forcedColors:'active'});await page.goto(AFTER);await settle(page);await to02(page);
   const s=await page.evaluate(S);const st=await page.evaluate(()=>getComputedStyle(document.querySelector('#ag-dir03-02 .ag-cmp__h--kick .ag-cmp__p--shins')).stroke);
   const t4=await page.evaluate(()=>getComputedStyle(document.querySelector('#ag-dir03-04 .ag-kf__tabs'),'::before').content);
   await (await page.$('#ag-dir03-02 .ag-cmp__tw')).screenshot({path:'shots/forced_02.png'});
   log('F',s.pill.c==='none'&&t4==='none'&&sameMarks(s),`forced-colors: подложек нет (02 ${s.pill.c}, 04 ${t4}); отметки на месте (обводка ${st})`);await browser.close();}
  // ---- 03 точки-пилюли
  for(const w of [390,768]){const {browser,page}=await open({w,h:844,mobile:w<700,touch:w<700});await page.goto(AFTER);await settle(page);
   await page.evaluate(()=>document.getElementById('ag-dir03-03').scrollIntoView());await page.waitForTimeout(400);
   const D=()=>page.evaluate(()=>{const n=document.querySelector('#ag-dir03-03 .ag-kt__nav');const d=[...n.querySelectorAll('.ag-kt__dot')];return {nw:Math.round(n.querySelector('.ag-kt__dots').getBoundingClientRect().width),w:d.map(x=>Math.round(x.getBoundingClientRect().width)).join(','),on:d.findIndex(x=>x.classList.contains('is-on')),pw:d.map(x=>Math.round(parseFloat(getComputedStyle(x,'::before').width)))};});
   const a=await D();await page.click('#ag-dir03-03 [data-ag-next]');await page.waitForTimeout(900);const b=await D();
   log('F',a.nw===b.nw&&a.w===b.w&&a.on===0&&b.on===1&&b.pw[1]===20&&b.pw[0]===8,`03, ${w}px: точки — ширина ряда ${a.nw}→${b.nw}, слоты ${b.w}; «вперёд» — пилюля на 2-й (${b.pw.join('/')})`);await browser.close();}
  {const {browser,page}=await open({w:1440,h:900});await page.goto(AFTER);await settle(page);
   const r=await page.evaluate(()=>({nav:getComputedStyle(document.querySelector('#ag-dir03-03 .ag-kt__nav')).display,dur:document.querySelector('#ag-dir03-03 .ag-kt__fill').getAttribute('data-ag-dur'),st:document.querySelector('#ag-dir03-03 .ag-kt__deck').getAttribute('data-ag-stagger'),gr:/svg/.test(getComputedStyle(document.querySelector('#ag-dir03-03 .ag-kt'),'::before').backgroundImage||'')}));
   log('F',r.nav==='none'&&r.dur==='700'&&r.st==='50'&&!r.gr,`03, ПК: навигации нет, линия 700 мс, шаг 50 мс, зерна нет`);await browser.close();}
  // ---- 04 подложка вкладок
  {const {browser,page}=await open({w:1440,h:900});await page.goto(AFTER);await settle(page);
   await page.evaluate(()=>document.getElementById('ag-dir03-04').scrollIntoView());await page.waitForTimeout(500);
   const r0=await page.evaluate(IND(0));await page.click('#ag-dir03-04 .ag-kf__tab >> nth=2');await page.waitForTimeout(110);const m=await page.evaluate(IND(2));await page.waitForTimeout(420);const r2=await page.evaluate(IND(2));
   const col=await page.evaluate(()=>getComputedStyle(document.querySelectorAll('#ag-dir03-04 .ag-kf__tab')[2]).color);
   log('F',ok(r0)&&r0.bg==='rgba(0, 0, 0, 0)'&&ok(r2)&&m.x>r0.tx+2&&m.x<r2.tx-2&&col==='rgb(9, 9, 10)',`подложка форматов, ПК: под «Группа», едет к «Персонально» (на 110 мс x=${Math.round(m.x)}, в конце ${Math.round(r2.x)} ↔ ${r2.tx}); подпись тёмная на жёлтом (${col})`);
   await page.keyboard.press('ArrowLeft');await page.waitForTimeout(450);const k=await page.evaluate(IND(1));
   for(const w of [960,768,600]){await page.setViewportSize({width:w,height:900});await page.waitForTimeout(400);}
   const r3=await page.evaluate(IND(1));log('F',ok(k)&&ok(r3),`подложка форматов: стрелка ← — «Детская»; 1440 → 960 → 768 → 600 — на месте (${Math.round(r3.x)},${Math.round(r3.y)})`);await browser.close();}
  for(const w of [320,390]){const {browser,page}=await open({w,h:844,mobile:true,touch:true});await page.goto(AFTER);await settle(page);
   await page.evaluate(()=>document.getElementById('ag-dir03-04').scrollIntoView());await page.waitForTimeout(400);
   const tb=await (await page.$$('#ag-dir03-04 .ag-kf__tab'))[1].boundingBox();await page.touchscreen.tap(tb.x+tb.width/2,tb.y+tb.height/2);await page.waitForTimeout(450);const r=await page.evaluate(IND(1));
   log('F',ok(r),`подложка форматов, телефон ${w}px: «Детская группа» — на месте (${Math.round(r.x)}, ${Math.round(r.w)} px)`);await browser.close();}
  // ---- 07 F22 + FAQPage = блок 07 (HEAD без изменений)
  {const {browser,page}=await open({w:1440,h:900});await page.goto(AFTER);await settle(page);
   await page.evaluate(()=>document.getElementById('ag-dir03-07').scrollIntoView());await page.waitForTimeout(400);
   const H=n=>page.evaluate(n=>Math.round(document.querySelectorAll('#ag-dir03-07 .ag-kq__item')[n].getBoundingClientRect().height),n);
   const h0=await H(1);await page.click('#ag-dir03-07 .ag-kq__item >> nth=1 >> summary');await page.waitForTimeout(90);const hm=await H(1);await page.waitForTimeout(450);const h1=await H(1);
   const HA=()=>page.evaluate(()=>[...document.querySelectorAll('#ag-dir03-07 .ag-kq__item')].map(d=>Math.round(d.getBoundingClientRect().height)).join(','));
   await page.click('#ag-dir03-07 .ag-kq__all');await page.waitForTimeout(40);const b1=await HA();await page.waitForTimeout(500);const b2=await HA();
   const st=await page.evaluate(()=>({open:[...document.querySelectorAll('#ag-dir03-07 .ag-kq__item')].filter(d=>d.open).length,n:document.querySelectorAll('#ag-dir03-07 .ag-kq__item').length,bulk:document.getElementById('ag-dir03-07').classList.contains('is-bulk')}));
   log('F',h0<hm&&hm<h1&&b1===b2&&st.open===st.n&&!st.bulk,`FAQ: ответ раскрывается плавно (${h0} → ${hm} на 90 мс → ${h1}), «Раскрыть все» — все ${st.open} сразу без перехода, is-bulk снят`);
   // фокус ссылки в открытом ответе не обрезан
   const fr=await page.evaluate(()=>{const a=document.querySelector('#ag-dir03-07 .ag-kq__a a');a.focus();return getComputedStyle(document.querySelector('#ag-dir03-07 .ag-kq__item'),'::details-content').overflowClipMargin;});
   log('F',/8px/.test(fr),`FAQ: overflow-clip-margin ответа ${fr} — фокус ссылок в ответе не режется`);
   const head=JSON.parse(fs.readFileSync('/home/claude/work/head_test/HEAD_kickboxing-samara.html','utf8').match(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/)[1]);
   const faq=head['@graph'].find(n=>n['@type']==='FAQPage').mainEntity;
   const QA=()=>page.evaluate(()=>[...document.querySelectorAll('#ag-dir03-07 .ag-kq__item')].map(d=>[d.querySelector('.ag-kq__qt').textContent.replace(/\s+/g,' ').trim(),d.querySelector('.ag-kq__a').textContent.replace(/\s+/g,' ').trim()]));
   const qs=await QA();await page.goto(BEFORE);await settle(page);const qb=await QA();
   const strip=t=>t.replace(/<[^>]+>/g,'').replace(/\s+/g,' ').trim();
   const dif=q=>q.map(([n,a],i)=>faq[i]&&(faq[i].name!==n||strip(faq[i].acceptedAnswer.text)!==a)?i:null).filter(x=>x!==null);
   const da=dif(qs),db=dif(qb);
   log('F',JSON.stringify(qs)===JSON.stringify(qb)&&qs.length===faq.length&&JSON.stringify(da)===JSON.stringify(db),`FAQPage в HEAD (без изменений): вопросы и ответы 07 v1.1.0 = v1.0.0 (${qs.length}); расхождения HEAD с блоком те же, что у v1.0.0: [${da.join(',')}]`);
   if(da.length) log('F',true,'FAQPage: расхождения v1.0.0 — '+da.map(i=>i+': HEAD «'+strip(faq[i].acceptedAnswer.text).slice(-60)+'» / блок «'+qs[i][1].slice(-60)+'»').join(' || '));
   await browser.close();}
  // ---- магниты, F23, зерно
  {const {browser,page}=await open({w:1440,h:900});await page.goto(AFTER);await settle(page);
   const mag=await page.$$eval('[data-ag-magnetic]',x=>x.length);log('F',mag===0,`магнитных кнопок: ${mag}`);
   const res=[];
   for(const [sel,inn] of [['#ag-dir03-01 .ag-btn--primary','.ag-btn__in'],['#ag-dir03-04 .ag-btn--primary','.ag-btn__in'],['#ag-dir03-05 .ag-btn--ghost','.ag-btn__in'],['#ag-dir03-06 .ag-btn--dark','.ag-btn__in'],['#ag-dir03-07 .ag-kq__all','.ag-kq__ain'],['#ag-dir03-08 .ag-btn--primary','.ag-btn__in'],['#ag-dir03-08 .ag-btn--ghost','.ag-btn__in']]){
    const el=await page.$(sel);if(!el){res.push(sel+': нет');continue;}await el.scrollIntoViewIfNeeded();await page.waitForTimeout(250);const b0=await el.boundingBox();
    await page.evaluate(s=>document.querySelector(s).addEventListener('click',e=>e.preventDefault(),{once:true}),sel);
    await page.mouse.move(b0.x+b0.width/2,b0.y+b0.height/2);await page.mouse.down();await page.waitForTimeout(220);
    const t=await page.$eval(sel+' '+inn,e=>getComputedStyle(e).transform);const b1=await el.boundingBox();await page.mouse.up();await page.waitForTimeout(80);
    res.push([sel.split(' ')[0].slice(-2)+sel.split('--')[1]?.slice(0,1),/matrix\(0\.98/.test(t)&&Math.abs(b1.x-b0.x)<0.5]);}
   log('F',res.every(r=>Array.isArray(r)&&r[1]===true),`F23 нажатие: ${res.map(r=>Array.isArray(r)?r.join(':'):r).join(' ')}`);
   const gr=await page.evaluate(()=>/svg/.test(getComputedStyle(document.querySelector('#ag-dir03-06 .ag-kp'),'::before').backgroundImage));
   log('F',gr,`зерно бумаги на ПК: 06 ${gr}`);await browser.close();}
  {const {browser,page}=await open({w:390,h:844,mobile:true,touch:true});await page.goto(AFTER);await settle(page);
   const gr=await page.evaluate(()=>/svg/.test(getComputedStyle(document.querySelector('#ag-dir03-06 .ag-kp'),'::before').backgroundImage));
   log('F',!gr,`телефон: зерна нет (06 ${gr})`);await browser.close();}
 }
 if(G.includes('A')){const axeSrc=fs.readFileSync(require.resolve('axe-core/axe.min.js'),'utf8');
  for(const m of [{w:1440},{w:1024},{w:390,mobile:true},{w:390,mobile:true,reduce:true},{w:320,mobile:true},{w:390,nojs:true}]){
   let o;if(m.nojs){fs.writeFileSync('after_nojs.html',fs.readFileSync('after.html','utf8').replace(/<script>[\s\S]*?<\/script>/g,'').replace(/<!--[\s\S]*?-->/g,'').replace(/<noscript>([\s\S]*?)<\/noscript>/g,'$1'));o=await open({w:390,h:900});await o.page.goto('file://'+path.resolve('after_nojs.html'));await o.page.waitForTimeout(800);}
   else {o=await open({...m,h:900});await o.page.goto(AFTER);await settle(o.page);}
   await o.page.addScriptTag({content:axeSrc});const res=await o.page.evaluate(async()=>(await axe.run(document.getElementById('allrecords'),{resultTypes:['violations']})).violations.map(v=>[v.id,v.impact,v.nodes.length,v.nodes[0].target.join(' ')]));
   const s=res.filter(v=>/serious|critical/.test(v[1]));log('A',res.length===0,`${m.w}${m.reduce?' reduce':''}${m.nojs?' без JS':''}: нарушений ${res.length} (serious/critical ${s.length}) ${res.map(v=>v.join(':')).join(' ; ').slice(0,300)}`);await o.browser.close();}
  for(const w of [1440,390]){const o=await open({w,h:900,mobile:w<700,touch:w<700});await o.page.goto(AFTER);await settle(o.page);
   await o.page.click('#ag-dir03-02 .ag-cmp__key[data-ag-vs="thai"]');await o.page.click('#ag-dir03-04 .ag-kf__tab >> nth=2');await o.page.click('#ag-dir03-07 .ag-kq__all');await o.page.waitForTimeout(500);
   await o.page.addScriptTag({content:axeSrc});const res=await o.page.evaluate(async()=>(await axe.run(document.getElementById('allrecords'),{resultTypes:['violations']})).violations.map(v=>[v.id,v.impact,v.nodes[0].target.join(' ')]));
   log('A',res.length===0,`${w}, «Тайский» + «Персонально» + FAQ раскрыт: нарушений ${res.length} ${res.map(v=>v.join(':')).join(' ; ').slice(0,300)}`);await o.browser.close();}}
 fs.writeFileSync('checks_k_'+G+'.json',JSON.stringify(out,null,1));
 for(const g of Object.keys(out)){console.log('## '+g);out[g].forEach(x=>console.log('  '+x));}
})();
