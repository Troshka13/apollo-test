# -*- coding: utf-8 -*-
import hashlib, html
B = [
 ('01','rec3980856801','Кикбоксинг в Самаре','Первый экран: alt кадра, «для взрослых» в планке, нажатие кнопки','заменить код'),
 ('02','rec3981112301','Чем кикбоксинг отличается от бокса и тайского','«Разница на схеме», полоса колонки, подложка «Сравнить с», схемы на телефоне','заменить код'),
 ('03','rec3984132601','Как проходит тренировка по кикбоксингу','Точки-пилюли ленты, линия трассы быстрее','заменить код'),
 ('04','rec3984372401','Групповые, детские и персональные занятия','Подложка вкладок едет, «для взрослых»','заменить обязательно'),
 ('05','rec3985964101','Кто ведёт кикбоксинг','Нажатие кнопки, фокус','заменить обязательно'),
 ('06','rec3987028101','Цены на групповые тренировки по кикбоксингу','«для взрослых», зерно бумаги на ПК','заменить код'),
 ('07','rec3987133801','Что спрашивают про кикбоксинг','Плавный FAQ, нажатие кнопок','заменить код'),
 ('08','rec3987367101','Не знаете, в какой зал ехать','Магнит снят, нажатие кнопок','заменить код'),
]
TITLE='Кикбоксинг в Самаре — секция для взрослых и начинающих | Apollo'
DESC='Секция кикбоксинга в Самаре: два зала Apollo — Галактионовская, 81 и Чкалова, 72. Удары руками и ногами, лоу-кик. Разовое 900 ₽, взрослым первое групповое бесплатно.'
cards=[]
for n,rec,name,what,act in B:
    code=open(f'/home/claude/kb/out/DIR03-{n}_v1.1.0.html',encoding='utf-8').read()
    sha=hashlib.sha256(code.encode()).hexdigest()
    must=' is-must' if 'обязательно' in act else ''
    cards.append(f'''<article class="blk{must}" id="b{n}">
  <header class="blk__head">
    <p class="blk__num">DIR03-{n}<span>v1.1.0</span></p>
    <h2 class="blk__name">{html.escape(name)}</h2>
    <p class="blk__what">{html.escape(what)}</p>
  </header>
  <dl class="blk__meta">
    <div><dt>Запись Tilda</dt><dd><code>{rec}</code></dd></div>
    <div><dt>Действие</dt><dd class="act">{act}</dd></div>
    <div><dt>Размер</dt><dd>{len(code.encode())//1024} КБ</dd></div>
  </dl>
  <div class="blk__do">
    <button class="btn btn--main" type="button" data-copy="c{n}">Скопировать код</button>
    <span class="blk__state" data-state="c{n}" role="status" aria-live="polite"></span>
  </div>
  <details class="blk__code"><summary>Показать код</summary>
    <label class="vh" for="c{n}">Код блока DIR03-{n}</label>
    <textarea id="c{n}" readonly spellcheck="false" data-sha="{sha}">{html.escape(code)}</textarea>
  </details>
</article>''')
page=open('/home/claude/kb/copy_tpl.html',encoding='utf-8').read()
page=page.replace('%%CARDS%%','\n'.join(cards)).replace('%%TITLE%%',html.escape(TITLE)).replace('%%DESC%%',html.escape(DESC)).replace('%%TL%%',str(len(TITLE))).replace('%%DL%%',str(len(DESC)))
open('/home/claude/kb/copy/kickboxing_blocks.html','w',encoding='utf-8').write(page)
print(len(page.encode()))
