# -*- coding: utf-8 -*-
import hashlib, html
B = [
 ('01','rec3993475101','Грэпплинг в Самаре','Кадр клетки вместо тренажёров, «для взрослых» в планке, магнит снят, нажатие кнопки','заменить код'),
 ('02','rec3993639201','Как идёт схватка от стойки до партера','«Пройти схватку»: «борец» на ПК, вертикальный профиль на телефоне','заменить код'),
 ('03','rec3993721201','Почему в грэпплинге не бьют','Рисунок «хлопок» вместо кадра с мешком, зерно бумаги','заменить код'),
 ('04','rec3994822601','Зачем приходят на ковёр','Подложка вкладок едет, «для взрослых»','заменить код'),
 ('05','rec3994877701','Кто ведёт занятия на Чкалова','Нажатие кнопки, фокус','заменить код'),
 ('06','rec3995933901','Цены на групповые тренировки по грэпплингу','«для взрослых», зерно бумаги','заменить код'),
 ('07','rec3995997101','Что спрашивают про грэпплинг','Плавный FAQ, «для взрослых» во втором ответе, ответы в печати','заменить код'),
 ('09','rec3996109601','Хотите попробовать на ковре','Магнит снят, нажатие кнопок','заменить код'),
 ('HEAD','—','HEAD страницы v1.1','Ответ про борьбу в FAQPage — «для взрослых», как в блоке 07','заменить целиком'),
]
TITLE=''
DESC='Грэпплинг в Самаре на Чкалова, 72: борьба без ударов. Переводы в партер, контроль, болевые и удушающие. Разовое 900 ₽, взрослым первое групповое бесплатно.'
cards=[]
for n,rec,name,what,act in B:
    code=open('/home/claude/gp/out/HEAD_grappling-samara_v1.1.html' if n=='HEAD' else f'/home/claude/gp/out/DIR05-{n}_v1.1.0.html',encoding='utf-8').read()
    sha=hashlib.sha256(code.encode()).hexdigest()
    must=' is-must' if n=='HEAD' else ''
    cards.append(f'''<article class="blk{must}" id="b{n}">
  <header class="blk__head">
    <p class="blk__num">{"HEAD" if n=="HEAD" else "DIR05-"+n}<span>{"v1.1" if n=="HEAD" else "v1.1.0"}</span></p>
    <h2 class="blk__name">{html.escape(name)}</h2>
    <p class="blk__what">{html.escape(what)}</p>
  </header>
  <dl class="blk__meta">
    <div><dt>{"Где" if n=="HEAD" else "Запись Tilda"}</dt><dd>{"Настройки страницы → Дополнительно → HTML-код внутрь HEAD" if n=="HEAD" else "<code>"+rec+"</code>"}</dd></div>
    <div><dt>Действие</dt><dd class="act">{act}</dd></div>
    <div><dt>Размер</dt><dd>{len(code.encode())//1024} КБ</dd></div>
  </dl>
  <div class="blk__do">
    <button class="btn btn--main" type="button" data-copy="c{n}">Скопировать код</button>
    <span class="blk__state" data-state="c{n}" role="status" aria-live="polite"></span>
  </div>
  <details class="blk__code"><summary>Показать код</summary>
    <label class="vh" for="c{n}">Код {n}</label>
    <textarea id="c{n}" readonly spellcheck="false" data-sha="{sha}">{html.escape(code)}</textarea>
  </details>
</article>''')
page=open('/home/claude/gp/copy_tpl.html',encoding='utf-8').read()
page=page.replace('%%CARDS%%','\n'.join(cards)).replace('%%TITLE%%',html.escape(TITLE)).replace('%%DESC%%',html.escape(DESC)).replace('%%TL%%',str(len(TITLE))).replace('%%DL%%',str(len(DESC)))
open('/home/claude/gp/copy/grappling_blocks.html','w',encoding='utf-8').write(page)
print(len(page.encode()))
