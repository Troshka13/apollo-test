// /grappling-samara (DIR05) · проверки прохода «дизайн, движение и фишка» (PROMPT_DIR05_DESIGN_MOTION_v2)
const {open,settle}=require('./lib');const fs=require('fs'),path=require('path');
const AFTER='file://'+path.resolve('after.html'), BEFORE='file://'+path.resolve('before.html');
const out={};const log=(g,ok,msg)=>{const s=(ok?"pass ":"FAIL ")+msg;(out[g]=out[g]||[]).push(s);console.log(g+" "+s);};
const G=process.env.G||'LTCMFA';
async function txt(url){const {browser,page}=await open({reduce:true});await page.goto(url);await page.waitForTimeout(2600);
  const r=await page.evaluate(()=>{const o={};document.querySelectorAll('.ag-scope').forEach(r=>{const c=r.cloneNode(true);c.querySelectorAll('style,script,.ag-vh,.ag-yp__key,.ag-yp__v').forEach(x=>x.remove());o[r.id]=c.textContent.replace(/\s+/g,' ').trim();});return o;});await browser.close();return r;}
async function links(url){const {browser,page}=await open({reduce:true});await page.goto(url);await page.waitForTimeout(400);
  const r=await page.evaluate(()=>[...document.querySelectorAll('.ag-scope a[href]')].map(a=>a.closest('.ag-scope').id+' '+a.getAttribute('href')));await browser.close();return r;}
const STEP=`(()=>{const r=document.getElementById('ag-dir05-02');const st=[...r.querySelectorAll('.ag-yp__step')];return {done:st.map(s=>s.classList.contains('is-done')?1:0).join(''),cur:st.findIndex(s=>s.classList.contains('is-cur')),js:r.hasAttribute('data-ag-js')};})()`;
(async()=>{
 if(G.includes('L')) for(const reduce of [false,true]) for(const fontsOff of [false,true]) for(const w of [320,360,390,768,1024,1440,1920]){
   const {browser,page}=await open({w,h:w<700?800:900,reduce,mobile:w<700,touch:w<700});
   if(fontsOff) await page.route('**/fonts.googleapis.com/**',r=>r.abort());
   await page.goto(AFTER);await settle(page);
   const r=await page.evaluate(()=>({ov:document.documentElement.scrollWidth>document.documentElement.clientWidth,h:document.body.scrollHeight}));
   log('L',!r.ov,`${w}px reduce=${reduce} fontsOff=${fontsOff} overflowX=${r.ov} h=${r.h}`);await browser.close();
 }
 if(G.includes('T')){const tb=await txt(BEFORE),ta=await txt(AFTER);
  const EXC={'ag-dir05-02':[['в стойке в партере Разминка','в стойке в партере в стойке в партере Разминка']],'ag-dir05-01':[['первое групповое занятие для взрослых','первое групповое занятие']],
   'ag-dir05-04':[['Первое групповое занятие для взрослых бесплатное','Первое групповое занятие бесплатное']],
   'ag-dir05-06':[['Первое групповое занятие для взрослых — бесплатно.','Первое групповое занятие — бесплатно.']],
   'ag-dir05-07':[['Первое групповое занятие для взрослых бесплатное.','Первое групповое занятие бесплатное.']]};
  for(const id of Object.keys(tb)){let a=ta[id];(EXC[id]||[]).forEach(([n,o])=>{a=a.split(n).join(o);});a=a.replace(/\s+/g,' ').trim();let i=0;while(i<tb[id].length&&tb[id][i]===a[i])i++;
   log('T',a===tb[id],id+(a===tb[id]?' текст совпадает'+(EXC[id]?' (кроме правки «'+EXC[id][0][0].slice(0,50)+'»)':''):' РАЗНИЦА '+JSON.stringify(tb[id].slice(i-40,i+40))+' → '+JSON.stringify(a.slice(i-40,i+40))));}
  const html=fs.readFileSync('after.html','utf8').replace(/<!--[\s\S]*?-->/g,'');
  const fr=/img_5464-scaled\.jpeg" width="1024" height="683" alt="Клетка в зале Apollo MMA Gym на Чкалова, 72"/.test(html)&&!/src="[^"]*img_5413/.test(html)&&!/src="[^"]*img_5433/.test(html);
  log('T',fr,`кадры: 01 — img_5464 (клетка), alt по кадру; img_5413 (тренажёры) и img_5433 (мешок) сняты: ${fr}`);}
 if(G.includes('C')){const lb=await links(BEFORE),la=await links(AFTER);const add=la.filter(x=>!lb.includes(x)),rem=lb.filter(x=>!la.includes(x));
  log('C',rem.length===0&&add.length===0,`ссылки +${add.length} −${rem.length}`);}
 if(G.includes('M')){
  for(const mode of [{name:'js off',js:false},{name:'reduce',reduce:true},{name:'cdn fail',cdn:'fail'},{name:'cdn hang',cdn:'hang'}]){
   const {browser,page}=await open({w:390,h:800,mobile:true,...mode});await page.goto(AFTER,{waitUntil:'domcontentloaded'});await page.waitForTimeout(2700);
   if(mode.js!==false) for(let y=0;y<9000;y+=600){await page.evaluate(y=>scrollTo(0,y),y);await page.waitForTimeout(40);}
   const r=await page.evaluate(()=>{const bad=[];document.querySelectorAll('.ag-scope :is(p,h1,h2,h3,a,li,dt,dd,summary,td,th,figcaption)').forEach(el=>{if(el.closest('[aria-hidden="true"],[hidden],dialog'))return;let n=el,op=1;while(n&&n.nodeType===1){op*=parseFloat(getComputedStyle(n).opacity);n=n.parentElement;}if(getComputedStyle(el).display==='none')return;if(getComputedStyle(el).visibility==='hidden')return;if(op<0.99&&el.textContent.trim())bad.push(el.textContent.trim().slice(0,30));});
     const r2=document.getElementById('ag-dir05-02');return {bad,m:document.documentElement.getAttribute('data-ag-motion'),v:getComputedStyle(r2.querySelector('.ag-yp__v')).display,vc:getComputedStyle(r2.querySelector('.ag-yp__vl')).backgroundColor,panels:[...document.querySelectorAll('#ag-dir05-04 .ag-yw__panel')].filter(c=>getComputedStyle(c).visibility!=='hidden').length};});
   const exp=mode.js===false?{panels:4,c:'rgb(255, 196, 0)'}:{panels:1,c:null};
   log('M',r.bad.length===0&&r.v==='block'&&r.panels===exp.panels&&(!exp.c||r.vc===exp.c),`${mode.name}: motion=${r.m} скрытых текстов ${r.bad.length} ${r.bad.slice(0,3).join('|')}; 02: вертикальный профиль ${r.v} (${r.vc}); 04: видимых панелей ${r.panels}`);await browser.close();}
  const {browser,page}=await open({w:1440});await page.goto(AFTER);await settle(page);
  const r=await page.evaluate(()=>{const o={};document.querySelectorAll('.ag-scope').forEach(root=>{const all=root.querySelectorAll('[data-ag-anim]');o[root.id]=[all.length,[...all].filter(e=>!e.hasAttribute('data-ag-done')).length];});return o;});
  for(const [id,[n,left]] of Object.entries(r)) log('M',left===0,`motion on: ${id} анимаций ${n}, не отсканировано ${left}`);await browser.close();}


 if(G.includes('F')){
  const RUN=`(()=>{const r=document.getElementById('ag-dir05-02');const run=r.querySelector('.ag-yp__runner');const m=new DOMMatrix(getComputedStyle(run).transform);const n=[...r.querySelectorAll('.ag-yp__node')];return {x:Math.round(m.e),y:Math.round(m.f),op:getComputedStyle(run).opacity,disp:getComputedStyle(run).display,on:n.findIndex(c=>c.classList.contains('is-on')),hov:[...r.querySelectorAll('.ag-yp__step')].findIndex(s=>s.classList.contains('is-hover')),nodes:n.map(c=>[+c.getAttribute('cx'),+c.getAttribute('cy')]),an:run.getAnimations().length};})()`;
  // ---- 02 ПК: «борец»
  {const {browser,page,errs}=await open({w:1440,h:900});await page.goto(AFTER);await page.waitForTimeout(1500);
   await page.evaluate(()=>{const e=document.getElementById('ag-dir05-02');scrollTo(0,e.getBoundingClientRect().top+scrollY-40);});await page.waitForTimeout(200);
   const st=await page.$$('#ag-dir05-02 .ag-yp__step');const bb=await st[3].boundingBox();await page.mouse.move(bb.x+bb.width/2,bb.y+40);await page.waitForTimeout(50);const early=await page.evaluate(RUN);await page.mouse.move(5,5);
   await page.waitForTimeout(1600);
   const res=[];let ok=true,mid=null;
   for(const i of [2,4,0,1,3]){await st[i].hover();if(i===4){await page.waitForTimeout(150);mid=await page.evaluate(RUN);}await page.waitForTimeout(800);const r=await page.evaluate(RUN);const [nx,ny]=r.nodes[i];const good=Math.abs(r.x-nx)<=1&&Math.abs(r.y-ny)<=1&&r.on===i&&r.hov===i&&r.op==='1';if(!good)ok=false;res.push(i+(good?'':'✗('+r.x+','+r.y+')'));}
   const midok=mid&&mid.an===1&&!(Math.abs(mid.x-mid.nodes[4][0])<=1);
   log('F',early.op==='0'&&ok&&midok&&errs.length===0,`02, ПК: «борец» до конца draw не появляется (opacity ${early.op}); наведение на шаги ${res.join(' ')} — «борец» на узле, узел и засечка шага подсвечены; на 150 мс — в пути (${mid&&mid.x},${mid&&mid.y}); ошибок ${errs.length}`);
   // быстрое проведение по пяти колонкам
   for(const i of [0,1,2,3,4,3,2,1,0,4]){await st[i].hover();await page.waitForTimeout(40);}await page.waitForTimeout(1200);
   const z=await page.evaluate(RUN);const an=await page.evaluate(()=>document.getElementById('ag-dir05-02').getAnimations({subtree:true}).length);
   log('F',z.an===0&&an===0&&Math.abs(z.x-z.nodes[4][0])<=1,`02, ПК: быстрое проведение мышью — через 1,2 с анимаций ${an}, «борец» на последнем узле`);
   await page.emulateMedia({reducedMotion:'reduce'});await st[1].hover();await page.waitForTimeout(30);const rr=await page.evaluate(RUN);
   log('F',rr.an===0&&Math.abs(rr.x-rr.nodes[1][0])<=1,`02, reduce на лету: «борец» сразу на узле (${rr.x},${rr.y})`);
   await (await page.$('#ag-dir05-02 .ag-yp__wrap')).screenshot({path:'shots/f02_1440.png'});
   const mut=await page.evaluate(()=>window.__mut||0);
   await browser.close();}
  {const {browser,page}=await open({w:1280,h:900,touch:true,mobile:true});await page.goto(AFTER);await settle(page);
   const r=await page.evaluate(RUN);const v=await page.evaluate(()=>getComputedStyle(document.querySelector('#ag-dir05-02 .ag-yp__v')).display);
   log('F',r.disp==='none'&&v==='none',`02, сенсорный экран ≥ 1024: «борца» нет (${r.disp}), вертикального профиля нет (${v})`);await browser.close();}
  // ---- 02 < 1024: вертикальный профиль
  for(const w of [320,390,599,600,768,1023]){const {browser,page,errs}=await open({w,h:844,mobile:w<700,touch:w<700});
   await page.addInitScript(()=>{window.__mut=0;document.addEventListener('DOMContentLoaded',()=>{});});
   await page.goto(AFTER);await settle(page);
   await page.evaluate(()=>{const ol=document.querySelector('#ag-dir05-02 .ag-yp__steps');window.__mut=0;new MutationObserver(m=>{m.forEach(x=>{if(x.type==='childList')window.__mut++;});}).observe(document.getElementById('ag-dir05-02'),{childList:true,subtree:true});});
   const geo=await page.evaluate(()=>{const r=document.getElementById('ag-dir05-02');return [...r.querySelectorAll('.ag-yp__step')].map(s=>{const n=s.querySelector('.ag-yp__vn').getBoundingClientRect(),h=s.querySelector('.ag-yp__name').getBoundingClientRect(),l=s.getBoundingClientRect();return {dx:Math.round(n.left+n.width/2-l.left),dy:Math.round((n.top+n.height/2)-(h.top+Math.min(h.height,26)/2)),lane:s.getAttribute('data-ag-lane')};});});
   const lanesOk=geo.every(g=>({down:12,edge:22,up:32})[g.lane]===g.dx)&&geo.every(g=>Math.abs(g.dy)<=5);
   const seq=[];let ok=true;
   for(const i of [0,1,2,3,4,2]){await page.evaluate(i=>{const e=document.querySelectorAll('#ag-dir05-02 .ag-yp__step')[i].getBoundingClientRect();scrollBy(0,e.top+Math.min(e.height,120)/2-innerHeight*0.47);},i);await page.waitForTimeout(450);const s=await page.evaluate(STEP);seq.push(s.cur);if(s.cur!==i||s.done!=='11111'.slice(0,i)+'00000'.slice(i))ok=false;}
   const mut=await page.evaluate(()=>window.__mut);const ow=await page.evaluate(()=>[...document.querySelector('#ag-dir05-02 .ag-yp__steps').children].every(c=>c.tagName==='LI'));
   const sw=await page.evaluate(()=>document.documentElement.scrollWidth>document.documentElement.clientWidth);
   if(w===390) await (await page.$('#ag-dir05-02 .ag-yp__wrap')).screenshot({path:'shots/f02_390.png'});
   log('F',lanesOk&&ok&&mut===0&&ow&&!sw&&errs.length===0,`02, ${w}px: узлы на своей дорожке и на высоте заголовка шага (${geo.map(g=>g.dx+'/'+g.dy).join(' ')}); текущий шаг по прокрутке ${seq.join('→')}, пройденные — жёлтые; вставок узлов ${mut}; в ol только li ${ow}; гориз. прокрутки ${sw}`);
   await browser.close();}
  {const {browser,page}=await open({w:1024,h:900});await page.goto(AFTER);await settle(page);
   const r=await page.evaluate(()=>[getComputedStyle(document.querySelector('#ag-dir05-02 .ag-yp__v')).display,getComputedStyle(document.querySelector('#ag-dir05-02 .ag-yp__chart--wide')).display]);
   await page.emulateMedia({media:'print'});await page.setViewportSize({width:700,height:900});await page.waitForTimeout(300);
   const p=await page.evaluate(()=>[getComputedStyle(document.querySelector('#ag-dir05-02 .ag-yp__v')).display,getComputedStyle(document.querySelector('#ag-dir05-02 .ag-yp__step')).paddingLeft]);
   log('F',r[0]==='none'&&r[1]!=='none'&&p[0]==='none'&&p[1]==='0px',`02: 1024 — профиль ПК (${r.join('/')}); печать — линии нет, поле ${p[1]}`);await browser.close();}
  {const {browser,page}=await open({w:390,h:844,mobile:true,touch:true});await page.emulateMedia({forcedColors:'active'});await page.goto(AFTER);await settle(page);
   await page.evaluate(()=>{const e=document.querySelectorAll('#ag-dir05-02 .ag-yp__step')[1].getBoundingClientRect();scrollBy(0,e.top-innerHeight*0.45);});await page.waitForTimeout(500);
   const c=await page.evaluate(()=>[getComputedStyle(document.querySelector('#ag-dir05-02 .ag-yp__vl')).backgroundColor,getComputedStyle(document.querySelector('#ag-dir05-02 .ag-yp__step.is-cur .ag-yp__vn')||document.body).backgroundColor]);
   await (await page.$('#ag-dir05-02 .ag-yp__wrap')).screenshot({path:'shots/forced_02.png'});
   log('F',!/255, 196/.test(c[0]),`02, forced: линия системным цветом (${c[0]}), текущий узел ${c[1]}`);await browser.close();}
  // ---- 03 рисунок
  {const {browser,page}=await open({w:1440,h:900});await page.goto(AFTER);await settle(page);
   const r=await page.evaluate(()=>{const f=document.querySelector('#ag-dir05-03 .ag-yn__fig');return {img:!!f.querySelector('img'),svg:!!f.querySelector('svg.ag-yn__art'),anim:f.getAttribute('data-ag-anim'),slot:f.getAttribute('data-ag-slot'),agph:f.classList.contains('agph'),grain:/svg/.test(getComputedStyle(document.querySelector('#ag-dir05-03 .ag-yn'),'::before').backgroundImage)};});
   log('F',!r.img&&r.svg&&!r.anim&&r.slot==='DIR05-03-control'&&r.agph&&r.grain,`03: рисунок-слот «хлопок» вместо снимка, scale-in снят, слот на месте, зерно на ПК`);await browser.close();}
  // ---- 04 подложка
  const PL=`(()=>{const l=document.querySelector('#ag-dir05-04 .ag-yw__tabs');const cs=getComputedStyle(l,'::before');const m=new DOMMatrix(cs.transform==='none'?undefined:cs.transform);const lr=l.getBoundingClientRect();const t=l.querySelector('.ag-yw__tab[aria-selected="true"]').getBoundingClientRect();
    return {x:Math.round(lr.left+m.e),y:Math.round(lr.top+m.f),w:Math.round(parseFloat(cs.width)),h:Math.round(parseFloat(cs.height)),tx:Math.round(t.left),ty:Math.round(t.top),tw:Math.round(t.width),th:Math.round(t.height),c:cs.content,bg:getComputedStyle(l.querySelector('.ag-yw__tab[aria-selected="true"]')).backgroundColor};})()`;
  const okp=p=>Math.abs(p.x-p.tx)<=1&&Math.abs(p.y-p.ty)<=1&&Math.abs(p.w-p.tw)<=1&&Math.abs(p.h-p.th)<=1;
  for(const w of [1440,768,390,320]){const {browser,page,errs}=await open({w,h:844,mobile:w<700,touch:w<700});await page.goto(AFTER);await settle(page);
   await page.evaluate(()=>{const s=document.querySelector('#ag-dir05-04 .ag-yw__tabs').getBoundingClientRect();scrollTo(0,scrollY+s.top-80);});await page.waitForTimeout(400);
   const p0=await page.evaluate(PL);const res=[];let ok=okp(p0),mid=null;
   for(const i of [3,1,2,0]){const t=(await page.$$('#ag-dir05-04 .ag-yw__tab'))[i];if(w<700){const b=await t.boundingBox();await page.touchscreen.tap(b.x+b.width/2,b.y+b.height/2);}else await t.click();
    if(i===3){await page.waitForTimeout(120);mid=await page.evaluate(PL);}await page.waitForTimeout(500);const p=await page.evaluate(PL);if(!okp(p)||p.bg!=='rgba(0, 0, 0, 0)')ok=false;res.push(i+(okp(p)?'':'✗'));}
   const midok=mid&&!okp(mid);
   log('F',ok&&midok&&errs.length===0,`04, ${w}px: подложка под выбранной вкладкой (${res.join(' ')}), на 120 мс — в пути; у вкладки фон снят`);await browser.close();}
  // ---- 07 F22 + печать + FAQPage
  {const {browser,page}=await open({w:1440,h:900});await page.goto(AFTER);await settle(page);
   await page.evaluate(()=>document.getElementById('ag-dir05-07').scrollIntoView());await page.waitForTimeout(400);
   const H=n=>page.evaluate(n=>Math.round(document.querySelectorAll('#ag-dir05-07 .ag-yq__item')[n].getBoundingClientRect().height),n);
   const h0=await H(1);await page.click('#ag-dir05-07 .ag-yq__item >> nth=1 >> summary');await page.waitForTimeout(90);const hm=await H(1);await page.waitForTimeout(450);const h1=await H(1);
   const HA=()=>page.evaluate(()=>[...document.querySelectorAll('#ag-dir05-07 .ag-yq__item')].map(d=>Math.round(d.getBoundingClientRect().height)).join(','));
   await page.click('#ag-dir05-07 .ag-yq__all');await page.waitForTimeout(40);const b1=await HA();await page.waitForTimeout(500);const b2=await HA();
   const st=await page.evaluate(()=>({open:[...document.querySelectorAll('#ag-dir05-07 .ag-yq__item')].filter(d=>d.open).length,n:document.querySelectorAll('#ag-dir05-07 .ag-yq__item').length,bulk:document.getElementById('ag-dir05-07').classList.contains('is-bulk'),sticky:getComputedStyle(document.querySelector('#ag-dir05-07 .ag-yq__side')).position}));
   log('F',h0<hm&&hm<h1&&b1===b2&&st.open===st.n&&!st.bulk&&st.sticky==='sticky',`07: ответ раскрывается плавно (${h0} → ${hm} на 90 мс → ${h1}), «Раскрыть все» — все ${st.open} сразу без перехода; колонка прилипает (${st.sticky})`);
   await page.click('#ag-dir05-07 .ag-yq__all');await page.waitForTimeout(400);await page.emulateMedia({media:'print'});await page.waitForTimeout(200);
   const pr=await page.evaluate(()=>[...document.querySelectorAll('#ag-dir05-07 .ag-yq__a')].filter(a=>a.getBoundingClientRect().height>10).length);
   log('F',pr===10,`07, печать: видно ответов ${pr}/10 (все свёрнуты)`);await page.emulateMedia({media:'screen'});
   const head=JSON.parse(fs.readFileSync('out/HEAD_grappling-samara_v1.1.html','utf8').match(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/)[1]);
   const oldh=JSON.parse(fs.readFileSync('/home/claude/work/head_test/HEAD_grappling-samara.html','utf8').match(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/)[1]);
   const fq=h=>h['@graph'].find(n=>n['@type']==='FAQPage').mainEntity;
   const QA=()=>page.evaluate(()=>[...document.querySelectorAll('#ag-dir05-07 .ag-yq__item')].map(d=>[d.querySelector('.ag-yq__qt').textContent.replace(/\s+/g,' ').trim(),d.querySelector('.ag-yq__a').textContent.replace(/\s+/g,' ').trim()]));
   const qa=await QA();await page.goto(BEFORE);await settle(page);const qb=await QA();
   const dif=(q,f)=>q.map(([n,a],i)=>f[i]&&(f[i].name!==n||f[i].acceptedAnswer.text.replace(/<[^>]+>/g,'').replace(/\s+/g,' ').trim()!==a)?i:null).filter(x=>x!==null);
   const da=dif(qa,fq(head)),db=dif(qb,fq(oldh));
   log('F',JSON.stringify(da)===JSON.stringify(db)&&fq(head)[1].acceptedAnswer.text===qa[1][1]&&qa[1][1].includes('для взрослых бесплатное'),`FAQPage HEAD v1.1 = 07: ответ 2 дословно («для взрослых»); прочие расхождения те же, что у v1.0.0: [${da.join(',')}]`);
   await browser.close();}
  // ---- магниты, параллакс, F23, зерно
  {const {browser,page}=await open({w:1440,h:900});await page.goto(AFTER);await settle(page);
   const mag=await page.$$eval('[data-ag-magnetic]',x=>x.length);const par=await page.$$eval('[data-ag-parallax]',x=>x.map(e=>e.getAttribute('data-ag-parallax')));
   log('F',mag===0&&par.every(v=>parseFloat(v)<=0.08),`магнитных кнопок: ${mag}; параллакс ${par.join(', ')} (≤ 0.08)`);
   const res=[];
   for(const [sel,inn] of [['#ag-dir05-01 .ag-btn--primary','.ag-btn__in'],['#ag-dir05-05 .ag-btn--ghost','.ag-btn__in'],['#ag-dir05-06 .ag-btn--ink','.ag-btn__in'],['#ag-dir05-07 .ag-yq__all','.ag-yq__ain'],['#ag-dir05-09 .ag-btn--primary','.ag-btn__in'],['#ag-dir05-09 .ag-btn--ghost','.ag-btn__in']]){
    const el=await page.$(sel);if(!el){res.push(sel+': нет');continue;}await el.scrollIntoViewIfNeeded();await page.waitForTimeout(250);const b0=await el.boundingBox();
    await page.evaluate(s=>document.querySelector(s).addEventListener('click',e=>e.preventDefault(),{once:true}),sel);
    await page.mouse.move(b0.x+b0.width/2,b0.y+b0.height/2);await page.mouse.down();await page.waitForTimeout(220);
    const t=await page.$eval(sel+' '+inn,e=>getComputedStyle(e).transform);const b1=await el.boundingBox();await page.mouse.up();await page.waitForTimeout(80);
    res.push([sel.slice(8,10),/matrix\(0\.98/.test(t)&&Math.abs(b1.x-b0.x)<0.5]);}
   const yb=await page.evaluate(()=>!!document.querySelector('#ag-dir05-07 .ag-yq__btn .ag-yq__bin'));
   log('F',res.every(r=>Array.isArray(r)&&r[1]===true)&&yb,`F23 нажатие: ${res.map(r=>Array.isArray(r)?r.join(':'):r).join(' ')}; «Спросить расписание» обёрнута: ${yb}`);
   const gr=await page.evaluate(()=>['#ag-dir05-03 .ag-yn','#ag-dir05-06 .ag-yr'].map(s=>/svg/.test(getComputedStyle(document.querySelector(s),'::before').backgroundImage)));
   log('F',gr.every(Boolean),`зерно бумаги на ПК: 03 ${gr[0]}, 06 ${gr[1]}`);await browser.close();}
  {const {browser,page}=await open({w:390,h:844,mobile:true,touch:true});await page.goto(AFTER);await settle(page);
   const gr=await page.evaluate(()=>['#ag-dir05-03 .ag-yn','#ag-dir05-06 .ag-yr'].map(s=>/svg/.test(getComputedStyle(document.querySelector(s),'::before').backgroundImage)));
   log('F',!gr[0]&&!gr[1],`телефон: зерна нет (03 ${gr[0]}, 06 ${gr[1]})`);await browser.close();}
 }

 if(G.includes('A')){const axeSrc=fs.readFileSync(require.resolve('axe-core/axe.min.js'),'utf8');
  for(const m of [{w:1440},{w:1024},{w:390,mobile:true},{w:390,mobile:true,reduce:true},{w:320,mobile:true},{w:390,nojs:true}]){
   let o;if(m.nojs){fs.writeFileSync('after_nojs.html',fs.readFileSync('after.html','utf8').replace(/<script>[\s\S]*?<\/script>/g,'').replace(/<!--[\s\S]*?-->/g,'').replace(/<noscript>([\s\S]*?)<\/noscript>/g,'$1'));o=await open({w:390,h:900});await o.page.goto('file://'+path.resolve('after_nojs.html'));await o.page.waitForTimeout(800);}
   else {o=await open({...m,h:900});await o.page.goto(AFTER);await settle(o.page);}
   await o.page.addScriptTag({content:axeSrc});const res=await o.page.evaluate(async()=>(await axe.run(document.getElementById('allrecords'),{resultTypes:['violations']})).violations.map(v=>[v.id,v.impact,v.nodes.length,v.nodes[0].target.join(' ')]));
   const s=res.filter(v=>/serious|critical/.test(v[1]));log('A',res.length===0,`${m.w}${m.reduce?' reduce':''}${m.nojs?' без JS':''}: нарушений ${res.length} (serious/critical ${s.length}) ${res.map(v=>v.join(':')).join(' ; ').slice(0,300)}`);await o.browser.close();}
  for(const w of [1440,390]){const o=await open({w,h:900,mobile:w<700,touch:w<700});await o.page.goto(AFTER);await settle(o.page);
   await o.page.click('#ag-dir05-04 .ag-yw__tab >> nth=1');await o.page.click('#ag-dir05-07 .ag-yq__all');await o.page.waitForTimeout(500);
   await o.page.addScriptTag({content:axeSrc});const res=await o.page.evaluate(async()=>(await axe.run(document.getElementById('allrecords'),{resultTypes:['violations']})).violations.map(v=>[v.id,v.impact,v.nodes[0].target.join(' ')]));
   log('A',res.length===0,`${w}, «Из бокса» + FAQ раскрыт: нарушений ${res.length} ${res.map(v=>v.join(':')).join(' ; ').slice(0,300)}`);await o.browser.close();}}
 fs.writeFileSync('checks_g_'+G+'.json',JSON.stringify(out,null,1));
 for(const g of Object.keys(out)){console.log('## '+g);out[g].forEach(x=>console.log('  '+x));}
})();
