# -*- coding: utf-8 -*-
"""/grappling-samara (DIR05) · проход «дизайн, движение и фишка» (PROMPT_DIR05_DESIGN_MOTION_v2, 01.10.2026).
src/DIR05-0N_v1.0.0.html → out/DIR05-0N_v1.1.0.html. Каждая замена обязана найтись нужное число раз."""
import re, os, sys

sys.path.insert(0, '/home/claude/pr')
from build_prices_dm import rep, rx, focus3, wrap, press_css, touch, GRAIN  # noqa: E402

SRC, OUT = 'src', 'out'
os.makedirs(OUT, exist_ok=True)
DATE = '01.10.2026'
E = 'cubic-bezier(.22,.61,.36,1)'
IMG5413 = 'https://static.tildacdn.pub/tild3230-6538-4465-b332-396231643639/img_5413-scaled-e174.jpeg'
IMG5464 = 'https://static.tildacdn.pub/tild3334-6462-4835-b461-663439656337/img_5464-scaled.jpeg'
IMG5433 = 'https://static.tildacdn.pub/tild3337-6535-4361-a433-653431623337/img_5433-scaled.jpeg'
NUMS = [1, 2, 3, 4, 5, 6, 7, 9]


def load(n):
    return open('%s/DIR05-0%d_v1.0.0.html' % (SRC, n), encoding='utf-8').read()


def save(n, t):
    p = '%s/DIR05-0%d_v1.1.0.html' % (OUT, n)
    open(p, 'w', encoding='utf-8').write(t)
    print('DIR05-0%d v1.1.0 %6d байт' % (n, len(t.encode('utf-8'))))


def bump(t, n, note):
    t = rx(t, r'(DIR05-0\d · [^\n]*?)· v1\.0\.0 · \d\d\.09\.2026', r'\1· v1.1.0 · 01.10.2026')
    i = t.index('-->') + 3
    return t[:i] + '\n<!-- v1.1.0 (проход «дизайн, движение и фишка», PROMPT_DIR05_DESIGN_MOTION_v2, %s):\n     %s -->' % (DATE, note) + t[i:]


def add_css(t, css):
    i = t.index('  </style>')
    return t[:i] + '\n  /* ===== v1.1.0 · дизайн, движение и фишка (01.10) ===== */\n' + css + t[i:]


def grain_css(root, sec, wrap_cls):
    return '''  /* F29 · зерно бумаги (статично, только ≥ 640 px; forced-colors и печать — без зерна) */
  @media (min-width:640px){
    %(r)s .%(s)s{position:relative;}
    %(r)s .%(s)s::before{content:"";position:absolute;inset:0;z-index:0;pointer-events:none;opacity:.12;background-image:%(g)s;background-size:180px 180px;}
    %(r)s .%(w)s{position:relative;z-index:1;}
  }
  @media (forced-colors:active){%(r)s .%(s)s::before{display:none;}}
  @media print{%(r)s .%(s)s::before{display:none;}}
''' % {'r': root, 's': sec, 'w': wrap_cls, 'g': GRAIN}


JUMP_JS = '''    /* v1.1.0: смена раскладки — подложка встаёт без проезда */
    var mqj = W.matchMedia ? W.matchMedia("(max-width: 767px)") : null;
    if (mqj) {
      var jump = function () {
        list.classList.add("is-jump");
        W.requestAnimationFrame(function () { W.requestAnimationFrame(function () { list.classList.remove("is-jump"); }); });
      };
      if (mqj.addEventListener) mqj.addEventListener("change", jump); else if (mqj.addListener) mqj.addListener(jump);
    }
'''


# ---------------------------------------------------------------- DIR05-01
def c01():
    t = load(1); R = '#ag-dir05-01'
    t = bump(t, 1, 'Кадр: img_5413 сверен глазами 01.10 — гребной тренажёр и велосипед, на первом экране грэпплинга не по\n'
                   '     теме → img_5464 (клетка на Чкалова, сверена на /mma); alt по кадру, подпись адресом. Снимок ковра —\n'
                   '     слот DIR05-01-mat (бриф на месте). Факт № 11: «0 ₽ — первое групповое занятие для взрослых».\n'
                   '     Магнит снят, F23, фокус 3 px.')
    t = rep(t, 'src="%s" width="1024" height="683" alt="Зал Apollo MMA Gym на Чкалова, 72"' % IMG5413,
            'src="%s" width="1024" height="683" alt="Клетка в зале Apollo MMA Gym на Чкалова, 72"' % IMG5464)
    t = rep(t, '<span class="ag-yh__cap">первое групповое занятие</span>', '<span class="ag-yh__cap">первое групповое занятие для&nbsp;взрослых</span>')
    t = rep(t, ' data-ag-magnetic="0.18"', '')
    t = wrap(t, 'a', 'ag-btn ag-btn--primary', 'ag-btn__in')
    t = focus3(t, R)
    t = rep(t, '#ag-dir05-01.ag-scope .ag-yh__text:focus-visible{outline:2px', '#ag-dir05-01.ag-scope .ag-yh__text:focus-visible{outline:3px')
    t = add_css(t, press_css(R, [('ag-btn', 'ag-btn__in')]))
    t = touch(t)
    save(1, t)


# ---------------------------------------------------------------- DIR05-02
LANE_X = {'down': 12, 'edge': 22, 'up': 32}
LANES = ['down', 'up', 'edge', 'down', 'down']
HAND = ('<path d="M18 11V6a2 2 0 0 0-4 0v5"/><path d="M14 10V4a2 2 0 0 0-4 0v6"/><path d="M10 10.5V6a2 2 0 0 0-4 0v8"/>'
        '<path d="M18 8a2 2 0 1 1 4 0v6a8 8 0 0 1-8 8h-2c-2.8 0-4.5-.86-6-2.34l-3.6-3.6a2 2 0 0 1 2.83-2.82L7 15"/>')


def vline(i):
    x = LANE_X[LANES[i]]
    knee = ''
    if i:
        px = LANE_X[LANES[i - 1]]
        knee = '<svg class="ag-yp__vk" width="44" height="14" viewBox="0 0 44 14" focusable="false"><path d="M%d 0C%d 8 %d 6 %d 14"/></svg>' % (px, px, x, x)
    hand = ''
    if i == 4:
        hand = '<svg class="ag-yp__vh" width="26" height="26" viewBox="-3 -2 28 28" focusable="false">%s</svg>' % HAND
    return ('<span class="ag-yp__v" aria-hidden="true">%s<i class="ag-yp__vl"></i><i class="ag-yp__vn"></i>%s</span>' % (knee, hand))


RUN_JS = r'''  /* v1.1.0 · «Пройти схватку» (F14). Только классы и transform собственного «борца» — разметку не вставляет,
     путь движка (draw) не трогает.
     < 1024: вертикальный профиль в поле слева от шагов (статичная разметка); текущий шаг — тот, что 180 мс
     держится у середины экрана; пройденное — жёлтое, впереди — приглушённое.
     ≥ 1024, мышь: наведение на шаг — «борец» катится по пути профиля к узлу шага (WAAPI по точкам пути,
     380–700 мс по расстоянию; при перебивании — с текущей точки); reduce — сразу на узел. */
  (function () {
    "use strict";
    var W = window, D = document;
    var root = D.currentScript && D.currentScript.closest(".ag-scope");
    if (!root || root.hasAttribute("data-ag-ui-mounted")) return;
    var steps = Array.prototype.slice.call(root.querySelectorAll(".ag-yp__step"));
    if (steps.length !== 5) return;
    root.setAttribute("data-ag-ui-mounted", "");
    root.setAttribute("data-ag-js", "");
    var still = W.matchMedia ? W.matchMedia("(prefers-reduced-motion: reduce)") : { matches: false };
    var narrow = W.matchMedia ? W.matchMedia("(max-width: 1023px)") : { matches: false };
    var fine = W.matchMedia ? W.matchMedia("(min-width: 1024px) and (hover: hover) and (pointer: fine)") : { matches: false };

    var cur = -1, pend = -1, timer = 0;
    function setCur(i) {
      cur = i;
      steps.forEach(function (s, k) { s.classList.toggle("is-done", k < i); s.classList.toggle("is-cur", k === i); });
    }
    if ("IntersectionObserver" in W) {
      var io = new W.IntersectionObserver(function (es) {
        es.forEach(function (e) {
          if (!e.isIntersecting || !narrow.matches) return;
          pend = steps.indexOf(e.target);
          W.clearTimeout(timer);
          timer = W.setTimeout(function () { if (pend !== cur) setCur(pend); }, 180);
        });
      }, { rootMargin: "-45% 0px -50% 0px" });
      steps.forEach(function (s) { io.observe(s); });
    }

    var svg = root.querySelector(".ag-yp__chart--wide .ag-yp__svg");
    var path = svg && svg.querySelector(".ag-yp__path");
    var run = svg && svg.querySelector(".ag-yp__runner");
    var nodes = svg ? Array.prototype.slice.call(svg.querySelectorAll(".ag-yp__node")) : [];
    if (!path || !run || nodes.length !== 5 || !path.getTotalLength || !run.animate) return;
    var L = path.getTotalLength(), at = [];
    nodes.forEach(function (n) {
      var cx = +n.getAttribute("cx"), cy = +n.getAttribute("cy"), best = 0, bd = 1e9;
      for (var s = 0; s <= L; s += 2) {
        var p = path.getPointAtLength(s), d = (p.x - cx) * (p.x - cx) + (p.y - cy) * (p.y - cy);
        if (d < bd) { bd = d; best = s; }
      }
      at.push(best);
    });
    var pos = 0, anim = null, a0 = 0, a1 = 0, dur = 0, on = -1;
    function xy(s) {
      var p = path.getPointAtLength(Math.max(0, Math.min(L, s)));
      return "translate(" + p.x.toFixed(1) + "px," + p.y.toFixed(1) + "px)";
    }
    function ease(t) { return t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2; }
    function drawn() {
      if (D.documentElement.getAttribute("data-ag-motion") === "off") return true;
      var o = parseFloat(W.getComputedStyle(path).strokeDashoffset) || 0;
      return Math.abs(o) < 1;
    }
    function go(i) {
      if (!fine.matches || !drawn()) return;
      if (on >= 0) nodes[on].classList.remove("is-on");
      on = i;
      nodes[i].classList.add("is-on");
      steps.forEach(function (s, k) { s.classList.toggle("is-hover", k === i); });
      if (anim) {
        var t = Math.min(1, (anim.currentTime || 0) / dur);
        pos = a0 + (a1 - a0) * ease(t);
        anim.cancel();
        anim = null;
      }
      run.classList.add("is-on");
      var to = at[i];
      if (still.matches || Math.abs(to - pos) < 1) { pos = to; run.style.transform = xy(pos); return; }
      a0 = pos; a1 = to;
      dur = Math.round(380 + Math.min(1, Math.abs(a1 - a0) / L) * 320);
      var fr = [];
      for (var k = 0; k <= 24; k++) fr.push({ transform: xy(a0 + (a1 - a0) * ease(k / 24)) });
      run.style.transform = xy(a1);
      pos = a1;
      anim = run.animate(fr, { duration: dur, easing: "linear" });
      anim.onfinish = function () { anim = null; };
    }
    run.style.transform = xy(0);
    steps.forEach(function (s, i) { s.addEventListener("mouseenter", function () { go(i); }); });
  })();

'''


def c02():
    t = load(2); R = '#ag-dir05-02'
    t = bump(t, 2, 'Ведущая фишка «Пройти схватку» (F14). ПК с мышью: наведение на шаг — жёлтый «борец» катится по пути профиля\n'
                   '     к узлу шага, узел подсвечивается. < 1024: полоса-профиль и две колонки сняты — профиль идёт вертикально\n'
                   '     в поле слева от шагов (тоновые дорожки: партер слева, стойка справа; узел шага на своей дорожке, колено\n'
                   '     между дорожками; хлопок в конце; строка-легенда «в партере / в стойке»); текущий шаг — у середины экрана\n'
                   '     (180 мс), пройденное жёлтое, впереди приглушённое; без JS — линия целиком жёлтая. Разметка статичная,\n'
                   '     скрипт меняет только классы и transform «борца». draw пути 800 мс (было 1 800). Фокус 3 px.')
    t = rep(t, '     живого маркера нет — путь рисуется draw (DIR05.md: «линия между\n     шагами — draw»).',
            '     путь рисуется draw (DIR05.md: «линия между шагами — draw»); v1.1.0 — «борец» по наведению на шаг.')
    # полоса < 1024 снята
    t = rx(t, r'\n      <!-- Профиль < 1024[^\n]*-->\n      <div class="ag-yp__chart ag-yp__chart--strip" aria-hidden="true">.*?</svg>\n      </div>\n', '\n')
    # draw 800 мс, хлопок раньше на 800
    t = rep(t, 'data-ag-anim="draw" data-ag-delay="300" data-ag-dur="1800"', 'data-ag-anim="draw" data-ag-delay="300" data-ag-dur="800"')
    for d in (1900, 1950, 2000, 2050, 2500):
        t = rep(t, 'data-ag-delay="%d"' % d, 'data-ag-delay="%d"' % (d - 800))
    # «борец» — после узлов
    t = rep(t, '          <circle class="ag-yp__node" cx="824" cy="120" r="7"/>\n',
            '          <circle class="ag-yp__node" cx="824" cy="120" r="7"/>\n          <circle class="ag-yp__runner" cx="0" cy="0" r="10"/>\n')
    # вертикальный профиль в шагах + легенда
    k = [0]

    def addv(m):
        i = k[0]; k[0] += 1
        return m.group(0) + '\n          ' + vline(i)
    t = rx(t, r'<li class="ag-yp__step" data-ag-lane="(?:down|up|edge)">', addv, 5)
    t = rep(t, '      <ol class="ag-yp__steps"',
            '      <p class="ag-yp__key" aria-hidden="true"><span class="ag-yp__ki ag-yp__ki--down">в партере</span><span class="ag-yp__ki ag-yp__ki--up">в стойке</span></p>\n      <ol class="ag-yp__steps"')
    t = rep(t, '  <script>\n  /* Страховка скана', '  <script>\n' + RUN_JS + '  /* Страховка скана')
    t = focus3(t, R) if re.search(r'%s\.ag-scope :is\([^)]*\):focus-visible\{outline:2px' % re.escape(R), t) else t
    css = '''  /* «Пройти схватку», ПК: «борец» и подсвеченный узел */
  #ag-dir05-02 .ag-yp__runner{fill:var(--accent);stroke:var(--bg);stroke-width:3;opacity:0;transition:opacity .2s ease;pointer-events:none;}
  #ag-dir05-02 .ag-yp__runner.is-on{opacity:1;}
  #ag-dir05-02 .ag-yp__node{transition:fill .3s %(e)s;}
  #ag-dir05-02 .ag-yp__node.is-on{fill:var(--accent);}
  #ag-dir05-02 .ag-yp__step::before{transition:height .3s %(e)s,background-color .3s ease;}
  #ag-dir05-02 .ag-yp__step.is-hover::before{height:26px;background:var(--accent);}
  @media not ((hover:hover) and (pointer:fine)){#ag-dir05-02 .ag-yp__runner{display:none;}}
  /* вертикальный профиль: на ПК не нужен */
  #ag-dir05-02 .ag-yp__v,#ag-dir05-02 .ag-yp__key{display:none;}
  @media (max-width:1023px){
    #ag-dir05-02 .ag-yp__key{display:flex;flex-wrap:wrap;gap:6px 18px;margin-top:clamp(18px,3vw,28px);font-family:var(--f-display);font-size:11px;font-weight:600;letter-spacing:.12em;text-transform:uppercase;color:var(--faint);}
    #ag-dir05-02 .ag-yp__ki{display:inline-flex;align-items:center;gap:8px;}
    #ag-dir05-02 .ag-yp__ki::before{content:"";width:14px;height:14px;border-radius:3px;box-shadow:inset 0 0 0 1px rgba(255,255,255,.12);}
    #ag-dir05-02 .ag-yp__ki--down::before{background:#141417;}
    #ag-dir05-02 .ag-yp__ki--up::before{background:#222226;}
    #ag-dir05-02 .ag-yp__steps{position:relative;grid-template-columns:minmax(0,1fr);margin-top:10px;}
    #ag-dir05-02 .ag-yp__steps::before{content:"";position:absolute;left:0;top:0;bottom:0;width:44px;border-radius:6px;pointer-events:none;
      background:linear-gradient(90deg,#141417 0,#141417 22px,#222226 22px,#222226 44px);}
    #ag-dir05-02 .ag-yp__step{padding:16px 0 18px 58px;--ny:26px;}
    #ag-dir05-02 .ag-yp__step[data-ag-lane="down"]{--x:12px;}
    #ag-dir05-02 .ag-yp__step[data-ag-lane="edge"]{--x:22px;}
    #ag-dir05-02 .ag-yp__step[data-ag-lane="up"]{--x:32px;}
    #ag-dir05-02 .ag-yp__v{display:block;position:absolute;left:0;top:-1px;bottom:0;width:44px;pointer-events:none;--c:var(--accent);}
    #ag-dir05-02 .ag-yp__vk{position:absolute;left:0;top:0;width:44px;height:14px;overflow:visible;}
    #ag-dir05-02 .ag-yp__vk path{fill:none;stroke:var(--c);stroke-width:3;stroke-linecap:round;transition:stroke .38s %(e)s;}
    #ag-dir05-02 .ag-yp__vl{position:absolute;left:calc(var(--x) - 1.5px);top:14px;bottom:0;width:3px;border-radius:2px;background:var(--c);transition:background-color .38s %(e)s;}
    #ag-dir05-02 .ag-yp__step:first-child .ag-yp__vl{top:var(--ny);}
    #ag-dir05-02 .ag-yp__step:last-child .ag-yp__vl{bottom:34px;}
    #ag-dir05-02 .ag-yp__vn{position:absolute;left:calc(var(--x) - 7px);top:calc(var(--ny) - 7px);width:14px;height:14px;border-radius:50%%;background:var(--bg);box-shadow:inset 0 0 0 3px var(--c);
      transition:background-color .38s %(e)s,box-shadow .38s %(e)s,transform .38s %(e)s;}
    #ag-dir05-02 .ag-yp__vh{position:absolute;left:0;bottom:4px;width:26px;height:26px;overflow:visible;}
    #ag-dir05-02 .ag-yp__vh path{fill:none;stroke:var(--accent);stroke-width:1.7;stroke-linecap:round;stroke-linejoin:round;}
    /* с JS: впереди — приглушённо-жёлтое, пройденное и текущее — жёлтое */
    #ag-dir05-02[data-ag-js] .ag-yp__v{--c:rgba(255,196,0,.32);}
    #ag-dir05-02[data-ag-js] .ag-yp__step.is-done .ag-yp__v{--c:var(--accent);}
    #ag-dir05-02[data-ag-js] .ag-yp__step.is-cur .ag-yp__vk path{stroke:var(--accent);}
    #ag-dir05-02[data-ag-js] .ag-yp__step.is-cur .ag-yp__vn{background:var(--accent);box-shadow:inset 0 0 0 3px var(--accent),0 0 0 5px rgba(255,196,0,.22);transform:scale(1.15);}
    #ag-dir05-02[data-ag-js] .ag-yp__step:not(.is-done) .ag-yp__vh path{stroke:rgba(255,196,0,.32);transition:stroke .38s %(e)s;}
    #ag-dir05-02[data-ag-js] .ag-yp__step.is-cur .ag-yp__vh path{stroke:var(--accent);}
  }
  @media (max-width:599px){
    #ag-dir05-02 .ag-yp__step{padding:11px 0 12px 54px;--ny:21px;}
    #ag-dir05-02 .ag-yp__key{margin-top:18px;}
    #ag-dir05-02 .ag-yp__steps{margin-top:8px;}
  }
  @media (max-width:359px){
    #ag-dir05-02 .ag-yp__step{padding-left:50px;}
    #ag-dir05-02 .ag-yp__key{margin-top:14px;gap:4px 14px;}
  }
  @media (forced-colors:active){
    #ag-dir05-02 .ag-yp__runner,#ag-dir05-02 .ag-yp__node.is-on{fill:Highlight;}
    #ag-dir05-02 .ag-yp__v{--c:CanvasText !important;}
    #ag-dir05-02 .ag-yp__vk path,#ag-dir05-02 .ag-yp__vh path{stroke:CanvasText !important;}
    #ag-dir05-02 .ag-yp__step.is-cur .ag-yp__vn{background:Highlight !important;}
    #ag-dir05-02 .ag-yp__steps::before{background:none;border:1px solid CanvasText;}
  }
  @media print{
    #ag-dir05-02 .ag-yp__v,#ag-dir05-02 .ag-yp__key,#ag-dir05-02 .ag-yp__steps::before{display:none !important;}
    #ag-dir05-02 .ag-yp__step{padding-left:0 !important;}
  }
''' % {'e': E}
    # прежние правила полосы и двух колонок < 1024
    t = rep(t, '''    #ag-dir05-02 .ag-yp__chart--strip{display:block;max-width:560px;}
    #ag-dir05-02 .ag-yp__chart--strip .ag-yp__lane{left:clamp(38px,11%,62px);font-size:10.5px;letter-spacing:.1em;}
    #ag-dir05-02 .ag-yp__chart--strip .ag-yp__lane--up{top:8%;}
    #ag-dir05-02 .ag-yp__chart--strip .ag-yp__lane--down{top:83%;}
    #ag-dir05-02 .ag-yp__steps{grid-template-columns:repeat(2,minmax(0,1fr));column-gap:28px;}
''', '')
    t = rep(t, '  #ag-dir05-02 .ag-yp__chart--strip{display:none;}\n', '')
    t = add_css(t, css)
    save(2, t)


# ---------------------------------------------------------------- DIR05-03
ART03 = '''<figure class="ag-yn__fig agph" data-ag-slot="DIR05-03-control" data-ag-ratio="4:5" data-ag-brief="\\1">
          <svg class="ag-yn__art" viewBox="-14 -6 46 36" preserveAspectRatio="xMidYMid meet" aria-hidden="true" focusable="false">
            <g class="ag-yn__hand">%s</g>
            <path class="ag-yn__tick" d="M-5 4-8 1M-6 10H-10M24.5 3l3-3"/>
            <path class="ag-yn__mat" d="M-12 27H30"/>
          </svg>
        </figure>''' % HAND


def c03():
    t = load(3); R = '#ag-dir05-03'
    t = bump(t, 3, 'Кадр img_5433 сверен глазами 01.10: мешок у стены с граффити — ударный снаряд в блоке «почему не бьют»;\n'
                   '     снят. Вместо него рисунок-слот: ладонь «хлопок» (знак сдачи из DIR05-02) чернилами — иллюстрирует второй\n'
                   '     абзац; слот DIR05-03-control и бриф на месте. scale-in с рамки снят, тень мягче. Зерно бумаги (≥ 640 px),\n'
                   '     фокус 3 px.')
    t = rx(t, r'<figure class="ag-yn__fig" data-ag-slot="DIR05-03-control" data-ag-ratio="4:5" data-ag-brief="([^"]*)" data-ag-anim="scale-in" data-ag-delay="120">\s*<img[^>]*img_5433[^>]*>\s*</figure>', ART03)
    t = focus3(t, R)
    css = '''  /* рисунок-слот: ладонь «хлопок» (сдача) чернилами на бумажной рамке, без жёлтого */
  #ag-dir05-03 .ag-yn__fig.agph{box-shadow:0 10px 26px rgba(9,9,10,.08);}
  #ag-dir05-03 .ag-yn__art{display:block;width:100%%;height:100%%;padding:10%% 16%%;}
  #ag-dir05-03 .ag-yn__hand path{fill:none;stroke:#09090A;stroke-width:4px;stroke-linecap:round;stroke-linejoin:round;vector-effect:non-scaling-stroke;}
  #ag-dir05-03 .ag-yn__tick{fill:none;stroke:#6B675F;stroke-width:3px;stroke-linecap:round;vector-effect:non-scaling-stroke;}
  #ag-dir05-03 .ag-yn__mat{fill:none;stroke:#9A9488;stroke-width:2px;stroke-dasharray:2 7;stroke-linecap:round;vector-effect:non-scaling-stroke;}
  @media (max-width:599px){#ag-dir05-03 .ag-yn__fig.agph{aspect-ratio:2/1;}}
  @media (forced-colors:active){#ag-dir05-03 .ag-yn__art path{stroke:CanvasText !important;}}
''' % {}
    css += grain_css(R, 'ag-yn', 'ag-yn__wrap')
    t = add_css(t, css)
    save(3, t)


# ---------------------------------------------------------------- DIR05-04
def c04():
    t = load(4); R = '#ag-dir05-04'
    t = bump(t, 4, 'F10: светлая подложка выбранной вкладки переезжает (::before у tablist, положение — CSS по data-ag-tab;\n'
                   '     ПК — 4 в ряд, телефон — 2×2); цвет новой вкладки темнеет через 180 мс, старая светлеет сразу; смена\n'
                   '     раскладки — без проезда. Факт № 11 в панели «Без ударов по голове». Фокус 3 px (и панели).')
    t = rep(t, 'Первое групповое занятие бесплатное, дальше', 'Первое групповое занятие для&nbsp;взрослых бесплатное, дальше')
    t = rep(t, '        panels[k].classList.toggle("is-on", on);\n      });\n',
            '        panels[k].classList.toggle("is-on", on);\n      });\n      root.setAttribute("data-ag-tab", String(i));\n')
    t = rep(t, '    select(current(), false);\n\n',
            '    select(current(), false);\n    list.classList.add("is-jump", "is-ind");\n'
            '    W.requestAnimationFrame(function () { W.requestAnimationFrame(function () { list.classList.remove("is-jump"); }); });\n' + JUMP_JS + '\n')
    t = focus3(t, R)
    t = rep(t, '#ag-dir05-04 .ag-yw__panel:focus-visible{outline:2px', '#ag-dir05-04 .ag-yw__panel:focus-visible{outline:3px')
    css = '''  /* F10 · светлая подложка выбранной вкладки */
  #ag-dir05-04 .ag-yw__tabs{position:relative;isolation:isolate;}
  @media not (forced-colors:active){
    #ag-dir05-04 .ag-yw__tabs.is-ind::before{
      content:"";position:absolute;z-index:1;left:0;top:0;pointer-events:none;border-radius:8px;background:var(--plate);
      width:calc((100%% - 30px) / 4);height:100%%;
      transform:translate(calc(var(--c,0) * (100%% + 10px)),calc(var(--r,0) * (100%% + 8px)));
      transition:transform .38s %(e)s;
    }
    #ag-dir05-04[data-ag-tab="1"] .ag-yw__tabs{--c:1;}
    #ag-dir05-04[data-ag-tab="2"] .ag-yw__tabs{--c:2;}
    #ag-dir05-04[data-ag-tab="3"] .ag-yw__tabs{--c:3;}
    #ag-dir05-04 .ag-yw__tabs.is-jump::before{transition:none;}
    #ag-dir05-04 .ag-yw__tabs.is-ind .ag-yw__tab{position:relative;}
    #ag-dir05-04 .ag-yw__tabs.is-ind .ag-yw__tab>*{position:relative;z-index:2;}
    #ag-dir05-04 .ag-yw__tabs.is-ind .ag-yw__tab[aria-selected="true"]{background:transparent;border-color:transparent;transition:background-color 0s,border-color .2s ease,color .2s ease .18s;}
    #ag-dir05-04 .ag-yw__tabs.is-ind .ag-yw__tab[aria-selected="false"]{transition:color 0s,border-color .25s ease;}
    @media (max-width:767px){
      #ag-dir05-04 .ag-yw__tabs{grid-auto-rows:1fr;}
      #ag-dir05-04 .ag-yw__tabs.is-ind::before{width:calc(50%% - 4px);height:calc((100%% - 8px) / 2);transform:translate(calc(var(--c,0) * (100%% + 8px)),calc(var(--r,0) * (100%% + 8px)));}
      #ag-dir05-04[data-ag-tab="1"] .ag-yw__tabs{--c:1;--r:0;}
      #ag-dir05-04[data-ag-tab="2"] .ag-yw__tabs{--c:0;--r:1;}
      #ag-dir05-04[data-ag-tab="3"] .ag-yw__tabs{--c:1;--r:1;}
    }
  }
  @media print{#ag-dir05-04 .ag-yw__tabs::before{display:none;}}
''' % {'e': E}
    t = add_css(t, css)
    save(4, t)


# ---------------------------------------------------------------- DIR05-05
def c05():
    t = load(5); R = '#ag-dir05-05'
    t = bump(t, 5, 'F23 — нажатие кнопки, фокус 3 px. Состав и текст — как есть.')
    t = wrap(t, 'a', 'ag-btn ag-btn--ghost', 'ag-btn__in')
    t = focus3(t, R)
    t = add_css(t, press_css(R, [('ag-btn', 'ag-btn__in')]))
    t = touch(t)
    save(5, t)


# ---------------------------------------------------------------- DIR05-06
def c06():
    t = load(6); R = '#ag-dir05-06'
    t = bump(t, 6, 'Факт № 11: «Первое групповое занятие для взрослых — бесплатно.» Цены — как есть. F29 зерно бумаги (≥ 640 px),\n'
                   '     F23, фокус 3 px.')
    t = rep(t, '<p class="ag-yr__text">Первое групповое занятие — бесплатно. ', '<p class="ag-yr__text">Первое групповое занятие для взрослых&nbsp;— бесплатно. ')
    t = wrap(t, 'a', 'ag-btn ag-btn--ink', 'ag-btn__in')
    t = focus3(t, R)
    css = press_css(R, [('ag-btn', 'ag-btn__in')])
    css += grain_css(R, 'ag-yr', 'ag-yr__wrap')
    t = add_css(t, css)
    t = touch(t)
    save(6, t)


# ---------------------------------------------------------------- DIR05-07
def c07():
    t = load(7); R = '#ag-dir05-07'
    t = bump(t, 7, 'F22: ответ раскрывается плавно (::details-content + interpolate-size, прогрессивно; overflow-clip-margin —\n'
                   '     фокус ссылок не режется); «Раскрыть все» — без перехода; пересчёт триггеров и по окончании перехода.\n'
                   '     Прилипающая колонка без transform. Печать — ответы видны. Факт № 11 в ответе «Нужно ли уметь бороться…»\n'
                   '     (HEAD v1.1 — тот же текст). F23 — «Раскрыть все» и «Спросить расписание», фокус 3 px.')
    t = rep(t, 'тренеру группы. Первое групповое занятие бесплатное.</p>', 'тренеру группы. Первое групповое занятие для взрослых бесплатное.</p>')
    t = wrap(t, 'button', 'ag-yq__all', 'ag-yq__ain')
    t = wrap(t, 'a', 'ag-yq__btn', 'ag-yq__bin')
    t = focus3(t, R)
    css = press_css(R, [('ag-yq__all', 'ag-yq__ain'), ('ag-yq__btn', 'ag-yq__bin')])
    css += '''  /* F22 · плавное раскрытие ответа (Chromium 131+); иначе — мгновенно, как было */
  @supports (interpolate-size:allow-keywords) and selector(::details-content){
    #ag-dir05-07 .ag-yq__list{interpolate-size:allow-keywords;}
    #ag-dir05-07 .ag-yq__item::details-content{
      height:0;overflow:clip;overflow-clip-margin:8px;
      transition:height .32s %(e)s,content-visibility .32s allow-discrete;
    }
    #ag-dir05-07 .ag-yq__item[open]::details-content{height:auto;}
    #ag-dir05-07.is-bulk .ag-yq__item::details-content{transition:none;}
    @media (prefers-reduced-motion:reduce){
      #ag-dir05-07 .ag-yq__item::details-content{transition:none;}
    }
  }
  @media print{
    #ag-dir05-07 .ag-yq__item::details-content{height:auto !important;content-visibility:visible !important;}
    #ag-dir05-07 .ag-yq__a{display:block !important;}
  }
''' % {'e': E}
    t = add_css(t, css)
    t = rx(t, r'(      busy = true;\n)(.*?)(      busy = false;\n)',
           lambda m: m.group(1) + '      root.classList.add("is-bulk");\n' + m.group(2) + m.group(3)
           + '      W.requestAnimationFrame(function () { W.requestAnimationFrame(function () { root.classList.remove("is-bulk"); }); });\n')
    t = rep(t, '      d.addEventListener("toggle", function () { if (!busy) { sync(); refresh(); } });\n    });\n',
            '      d.addEventListener("toggle", function () { if (!busy) { sync(); refresh(); } });\n    });\n'
            '    /* v1.1.0: высота ответа меняется переходом — пересчитать позиции анимаций ниже по окончании */\n'
            '    root.addEventListener("transitionend", function (e) {\n'
            '      if (e.propertyName === "height" && e.pseudoElement === "::details-content") refresh();\n'
            '    });\n')
    t = touch(t)
    save(7, t)


# ---------------------------------------------------------------- DIR05-09
def c09():
    t = load(9); R = '#ag-dir05-09'
    t = bump(t, 9, 'Магнит снят, F23 — нажатие обеих кнопок, фокус 3 px. Напоминание: записи rec3996496801, rec3997932901\n'
                   '     (старые GRAP-10/11) на тесте ещё стоят — удалить по поручению владельца.')
    t = rep(t, ' data-ag-magnetic="0.2"', '')
    t = wrap(t, 'a', 'ag-btn ag-btn--primary', 'ag-btn__in')
    t = wrap(t, 'a', 'ag-btn ag-btn--ghost', 'ag-btn__in')
    t = focus3(t, R)
    t = add_css(t, press_css(R, [('ag-btn', 'ag-btn__in')]))
    t = touch(t)
    save(9, t)


if __name__ == '__main__':
    for f in (c01, c02, c03, c04, c05, c06, c07, c09):
        f()
