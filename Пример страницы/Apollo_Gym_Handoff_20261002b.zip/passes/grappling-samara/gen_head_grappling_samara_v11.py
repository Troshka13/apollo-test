# HEAD /grappling-samara v1.1: FAQPage ответ 1 = DIR05-07 v1.1.0 (факт № 11 «для взрослых»); остальное — как в HEAD 27.09
import re, json, html
W='/home/claude/work/'
old=open(W+'head_test/HEAD_grappling-samara.html',encoding='utf-8').read()
g=json.loads(re.search(r'<script type="application/ld\+json">(.*?)</script>',old,re.S).group(1))
b8=open('out/DIR05-07_v1.1.0.html',encoding='utf-8').read()
items=re.findall(r'<span class="ag-yq__qt">(.*?)</span></summary>\s*<div class="ag-yq__a">(.*?)</div>',b8,re.S)
def clean(s):
    s=re.sub(r'<[^>]+>','',s); s=html.unescape(s).replace(' ',' ')
    return re.sub(r'\s+',' ',s).strip()
IDX=1
OLD_A=None
NEW_A=clean(items[IDX][1])
n=0
for node in g['@graph']:
    if node.get('@type')=='FAQPage':
        q=node['mainEntity'][IDX]; OLD_A=q['acceptedAnswer']['text']; assert q['name']==clean(items[IDX][0]); assert NEW_A==OLD_A.replace('занятие бесплатное.','занятие для взрослых бесплатное.'), (OLD_A,NEW_A)
        q['acceptedAnswer']['text']=NEW_A; n+=1
assert n==1
com=('<!-- Apollo Gym · /grappling-samara · HEAD v1.1 · 01.10.2026 · Tilda → Настройки страницы → Дополнительно → «HTML-код для вставки внутрь HEAD». '
     'Тестовая копия с адресами apolloboxing.tilda.ws. Заменяет HEAD от 27.09 целиком; старый JSON-LD удалить. '
     'v1.1: FAQPage, ответ «Нужно ли уметь бороться, чтобы прийти?» = DIR05-07 v1.1.0 (факт № 11 «для взрослых»); остальное без изменений. -->\n')
out=com+'<script type="application/ld+json">\n'+json.dumps(g,ensure_ascii=False,indent=1)+'\n</script>\n'
open('out/HEAD_grappling-samara_v1.1.html','w',encoding='utf-8').write(out)
print('ok', len(out))
