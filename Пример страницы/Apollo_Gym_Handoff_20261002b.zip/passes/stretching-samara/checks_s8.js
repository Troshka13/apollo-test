// /stretching-samara (DIR08) · проверки прохода «дизайн, движение и фишка» (PROMPT_DIR08_DESIGN_MOTION_v2)
const {open,settle}=require('./lib');const fs=require('fs'),path=require('path');
const AFTER='file://'+path.resolve('after.html'), BEFORE='file://'+path.resolve('before.html');
const out={};const log=(g,ok,msg)=>{const s=(ok?"pass ":"FAIL ")+msg;(out[g]=out[g]||[]).push(s);console.log(g+" "+s);};
const G=process.env.G||'LTCMFA';
// правки факта — единственные допустимые разницы видимого текста
const FIX=[['0 ₽первое групповое занятие ',''],
  ['Первое групповое занятие бесплатное, дальше разовое стоит 900 ₽.','Разовое занятие стоит 900 ₽, условия первого назовут там же.'],
  ['Первое групповое занятие — бесплатно. Разовое','Условия первого занятия — при записи. Разовое'],
  ['за тренировку. Первое групповое занятие — бесплатно.','за тренировку. Условия первого занятия — при записи.']];
async function txt(url){const {browser,page}=await open({reduce:true});await page.goto(url);await page.waitForTimeout(2600);
  const r=await page.evaluate(()=>{const o={};document.querySelectorAll('.ag-scope').forEach(r=>{const c=r.cloneNode(true);c.querySelectorAll('style,script').forEach(x=>x.remove());o[r.id]=c.textContent.replace(/\s+/g,' ').trim();});return o;});await browser.close();return r;}
async function links(url){const {browser,page}=await open({reduce:true});await page.goto(url);await page.waitForTimeout(400);
  const r=await page.evaluate(()=>[...document.querySelectorAll('.ag-scope a[href]')].map(a=>a.closest('.ag-scope').id+' '+a.getAttribute('href')));await browser.close();return r;}
// состояние «трёх темпов»
const TP=`(()=>{const r=document.getElementById('ag-dir08-02');const g=[...r.querySelectorAll('.ag-zc__tp')];
  return {cue:r.getAttribute('data-cue'),hl:r.getAttribute('data-hl'),row:r.getAttribute('data-row'),op:g.map(x=>(+getComputedStyle(x).opacity).toFixed(2)).join(','),
   an:r.getAnimations({subtree:true}).filter(a=>a instanceof CSSTransition===false&&a.playState==='running').length,
   ray:getComputedStyle(r.querySelector('.ag-zc__tray')).transform,disp:getComputedStyle(g[0]).display};})()`;
const rest=p=>p.op==='0.00,0.00,0.00'&&p.an===0;
const playingP=p=>p.op!=='0.00,0.00,0.00'&&p.an>0;
async function toSigns(page,off=260){await page.evaluate(o=>{const s=document.querySelector('#ag-dir08-02 .ag-zc__cols');scrollTo(0,s.getBoundingClientRect().top+scrollY-o);},off);}
async function waitAuto(page,ms=4000){const t=Date.now();while(Date.now()-t<ms){const c=await page.evaluate(()=>document.getElementById('ag-dir08-02').getAttribute('data-cue'));if(c)return Date.now()-t;await page.waitForTimeout(50);}return -1;}
(async()=>{
 if(G.includes('L')) for(const reduce of [false,true]) for(const fontsOff of [false,true]) for(const w of [320,360,390,599,600,767,768,1023,1024,1440,1920]){
   const {browser,page}=await open({w,h:w<700?800:900,reduce,mobile:w<700,touch:w<700});
   if(fontsOff) await page.route('**/fonts.googleapis.com/**',r=>r.abort());
   await page.goto(AFTER);await settle(page);
   const r=await page.evaluate(()=>({ov:document.documentElement.scrollWidth>document.documentElement.clientWidth,h:document.body.scrollHeight}));
   log('L',!r.ov,`${w}px reduce=${reduce} fontsOff=${fontsOff} overflowX=${r.ov} h=${r.h}`);await browser.close();
 }
 if(G.includes('T')){const tb=await txt(BEFORE),ta=await txt(AFTER);
  for(const id of Object.keys(tb)){let b=tb[id];const a=ta[id];const used=[];for(const [x,y] of FIX){if(b.includes(x)){b=b.replace(x,y);used.push(x.slice(0,22));}}
   let i=0;while(i<b.length&&b[i]===a[i])i++;
   log('T',a===b,id+(a===b?' текст совпадает'+(used.length?' (кроме правки факта: '+used.join(' | ')+')':''):' РАЗНИЦА '+JSON.stringify(b.slice(i-40,i+40))+' → '+JSON.stringify(a.slice(i-40,i+40))));}
  const h=fs.readFileSync('out/DIR08-01_v1.1.0.html','utf8');
  const fr=/51-1024x683\.jpg" width="1024" height="683" alt="Зал Apollo NoFitness на Молодогвардейской, 56"/.test(h);
  const all=['1','2','3','4','5','6','7','8'].map(n=>fs.readFileSync(`out/DIR08-0${n}_v1.1.0.html`,'utf8').replace(/<!--[\s\S]*?-->/g,'').replace(/<script[\s\S]*?<\/script>|<style[\s\S]*?<\/style>/g,'')).join('');
  const free=/бесплатн|(?<![\d ])0(&nbsp;| )₽|за наш счёт|пробн/i.test(all);
  const head=fs.readFileSync('out/HEAD_stretching-samara_v1.1.html','utf8').replace(/<!--[\s\S]*?-->/g,'');
  log('T',fr&&!free&&!/бесплатн/i.test(head),`кадр 01 — 51, alt как в v1.0.0: ${fr}; «бесплатно / 0 ₽ / пробное» в видимом тексте блоков: ${free}; в HEAD v1.1: ${/бесплатн/i.test(head)} (5.1, 5.13)`);}
 if(G.includes('C')){const lb=await links(BEFORE),la=await links(AFTER);
  const cnt=a=>a.reduce((m,x)=>(m[x]=(m[x]||0)+1,m),{});const cb=cnt(lb),ca=cnt(la);const keys=[...new Set([...lb,...la])];
  const d=keys.filter(k=>(cb[k]||0)!==(ca[k]||0)).map(k=>k+' '+(cb[k]||0)+'→'+(ca[k]||0));
  const exp=d.length===1&&d[0]==='ag-dir08-01 #ag-dir08-06 2→1';
  log('C',exp,`ссылки: изменились ${d.length} — ${d.join('; ')} (ожидается одна: пункт «0 ₽» планки 01 вёл к ценам; цены по-прежнему по ссылке «500 ₽»)`);}
 if(G.includes('M')){
  for(const mode of [{name:'js off',js:false},{name:'reduce',reduce:true},{name:'cdn fail',cdn:'fail'},{name:'cdn hang',cdn:'hang'}]){
   const {browser,page}=await open({w:390,h:800,mobile:true,...mode});await page.goto(AFTER,{waitUntil:'domcontentloaded'});await page.waitForTimeout(2700);
   if(mode.js!==false) for(let y=0;y<9000;y+=600){await page.evaluate(y=>scrollTo(0,y),y);await page.waitForTimeout(40);}
   await page.waitForTimeout(500);
   const r=await page.evaluate(()=>{const bad=[];document.querySelectorAll('.ag-scope :is(p,h1,h2,h3,a,li,dt,dd,summary,td,th,figcaption,button)').forEach(el=>{if(el.closest('[aria-hidden="true"],[hidden],dialog'))return;let n=el,op=1;while(n&&n.nodeType===1){op*=parseFloat(getComputedStyle(n).opacity);n=n.parentElement;}if(getComputedStyle(el).display==='none')return;if(getComputedStyle(el).visibility==='hidden')return;if(op<0.99&&el.textContent.trim())bad.push(el.textContent.trim().slice(0,30));});
     return {bad,m:document.documentElement.getAttribute('data-ag-motion'),tp:[...document.querySelectorAll('#ag-dir08-02 .ag-zc__tp')].map(g=>getComputedStyle(g).opacity).join(','),
      panels:[...document.querySelectorAll('#ag-dir08-04 .ag-zl__panel')].filter(c=>getComputedStyle(c).visibility!=='hidden').length,
      plate:document.querySelector('#ag-dir08-04 .ag-zl__tabs').classList.contains('is-plate')};});
   const exp=mode.js===false?{panels:4,plate:false}:{panels:1,plate:true};
   const tpok=r.tp==='0,0,0'||(mode.cdn&&/^[01.,]+$/.test(r.tp));
   log('M',r.bad.length===0&&r.panels===exp.panels&&r.plate===exp.plate&&tpok,`${mode.name}: motion=${r.m} скрытых текстов ${r.bad.length} ${r.bad.slice(0,3).join('|')}; 02 узлы темпа opacity ${r.tp}; 04: видимых панелей ${r.panels}, плашка ${r.plate}`);await browser.close();}
  const {browser,page}=await open({w:1440});await page.goto(AFTER);await settle(page);
  const r=await page.evaluate(()=>{const o={};document.querySelectorAll('.ag-scope').forEach(root=>{const all=root.querySelectorAll('[data-ag-anim]');o[root.id]=[all.length,[...all].filter(e=>!e.hasAttribute('data-ag-done')).length];});return o;});
  for(const [id,[n,left]] of Object.entries(r)) log('M',left===0,`motion on: ${id} анимаций ${n}, не отсканировано ${left}`);await browser.close();}

 if(G.includes('F')){
  // ---- 02 «Три темпа»: автопоказ
  for(const [w,h] of [[1440,900],[1024,768],[390,844],[768,1024],[320,640]]){const {browser,page,errs}=await open({w,h,mobile:w<700,touch:w<700});await page.goto(AFTER);await page.waitForTimeout(900);
   await page.evaluate(()=>{window.__mut=0;new MutationObserver(m=>m.forEach(x=>{if(x.type==='childList')window.__mut++;})).observe(document.getElementById('ag-dir08-02'),{childList:true,subtree:true});});
   await toSigns(page,w<700?120:260);
   const t=await waitAuto(page,5000);
   const drawn=await page.evaluate(()=>[...document.querySelectorAll('#ag-dir08-02 .ag-zc__sign [data-ag-anim="draw"]')].every(p=>Math.abs(parseFloat(getComputedStyle(p).strokeDashoffset)||0)<0.6));
   await page.waitForTimeout(700);const mid=await page.evaluate(TP);
   const sh=await page.$('#ag-dir08-02 .ag-zc__cols');if(w===390||w===1440) await sh.screenshot({path:`shots/f/auto_${w}.png`});
   const rowbg=w>=1024?await page.evaluate(()=>getComputedStyle(document.querySelector('#ag-dir08-02 .ag-zc__row[data-r="2"]')).backgroundColor):'';
   const swc=w<1024?await page.evaluate(()=>getComputedStyle(document.querySelector('#ag-dir08-02 .ag-zc__sw[data-r="2"]')).borderColor):'';
   await page.waitForTimeout(2700);const end=await page.evaluate(TP);
   // второй раз не играет сам
   await page.evaluate(()=>scrollTo(0,0));await page.waitForTimeout(400);await toSigns(page,w<700?120:260);await page.waitForTimeout(1500);const again=await page.evaluate(TP);
   const mut=await page.evaluate(()=>window.__mut);
   log('F',t>=0&&drawn&&playingP(mid)&&mid.cue==='2'&&rest(end)&&end.cue===null&&rest(again)&&mut===0&&errs.length===0,
    `02, ${w}×${h}: автопоказ через ${t} мс после прокрутки, прорисовка знаков к этому моменту закончена (${drawn}); идёт — узлы ${mid.op}, анимаций ${mid.an}, отметка строки ${w>=1024?'(фон '+rowbg+')':'(рамка кнопки '+swc+')'}; через 3 с — покой (${end.op}, анимаций ${end.an}); второй раз сам не играет; вставок узлов ${mut}`);
   await browser.close();}
  // ---- 02: наведение (ПК)
  {const {browser,page,errs}=await open({w:1440,h:900});await page.goto(AFTER);await page.waitForTimeout(900);
   const rows=async(r,c)=>{const e=(await page.$$(`#ag-dir08-02 .ag-zc__col:nth-child(${c}) .ag-zc__row[data-r="${r}"]`))[0];const b=await e.boundingBox();return [b.x+b.width/2,b.y+b.height/2];};
   // наведение до конца прорисовки — ничего
   await toSigns(page,260);await page.waitForTimeout(80);let p=await rows(2,1);await page.mouse.move(...p);await page.waitForTimeout(120);const early=await page.evaluate(TP);
   await page.mouse.move(5,5);await waitAuto(page,5000);await page.waitForTimeout(3300);
   // переход по строке 2 через три колонки — один показ
   const starts=await page.evaluate(()=>{window.__st=0;const r=document.getElementById('ag-dir08-02');const g=r.querySelector('[data-ag-tempo="hold"]');const o=g.animate.bind(g);g.animate=function(){window.__st++;return o.apply(null,arguments);};return 1;});
   for(const c of [1,2,3]){p=await rows(2,c);await page.mouse.move(...p,{steps:6});await page.waitForTimeout(90);}
   const hv=await page.evaluate(TP);const st1=await page.evaluate(()=>window.__st);
   // уход во время показа — доигрывает
   await page.mouse.move(5,5);await page.waitForTimeout(400);const lv=await page.evaluate(TP);await page.waitForTimeout(3000);const lv2=await page.evaluate(TP);
   // 11 быстрых наведений 1 ↔ 2
   for(let k=0;k<11;k++){p=await rows(k%2?2:1,2);await page.mouse.move(...p);await page.waitForTimeout(45);}
   const st2=await page.evaluate(()=>window.__st);await page.mouse.move(5,5);await page.waitForTimeout(3400);const z=await page.evaluate(TP);
   // reduce на лету: посреди показа и до показа
   p=await rows(2,1);await page.mouse.move(...p);await page.waitForTimeout(300);await page.emulateMedia({reducedMotion:'reduce'});await page.waitForTimeout(120);const rr=await page.evaluate(TP);
   await page.mouse.move(5,5);await page.waitForTimeout(400);p=await rows(2,3);await page.mouse.move(...p);await page.waitForTimeout(300);const rr2=await page.evaluate(TP);
   await page.emulateMedia({reducedMotion:'no-preference'});await page.mouse.move(5,5);await page.waitForTimeout(400);
   // ресайз посреди показа
   p=await rows(2,1);await page.mouse.move(...p);await page.waitForTimeout(300);await page.setViewportSize({width:900,height:900});await page.waitForTimeout(150);const rs=await page.evaluate(TP);
   await page.setViewportSize({width:1440,height:900});await page.waitForTimeout(300);
   const sh=await page.$('#ag-dir08-02 .ag-zc__cols');
   log('F',rest(early)&&playingP(hv)&&st1===1&&hv.hl==='2'&&playingP(lv)&&lv.hl===null&&rest(lv2)&&rest(z)&&rest(rr)&&rest(rr2)&&rest(rs)&&errs.length===0,
    `02, ПК мышь: до конца прорисовки наведение не запускает (${early.op}); строка 2 через три колонки — один показ (${st1}), подсветка 2; ушли — показ доигрывает, подсветка снята через 220 мс; 11 быстрых наведений 1↔2 — пусков ${st2-st1}, через 3,4 с покой (анимаций ${z.an}); reduce посреди показа — сразу покой, при reduce не запускается; ресайз 1440→900 посреди показа — покой`);
   await browser.close();}
  // ---- 02: сенсорный экран ≥ 1024 — касание строки не запускает
  {const {browser,page}=await open({w:1280,h:900,touch:true,mobile:true});await page.goto(AFTER);await page.waitForTimeout(900);await toSigns(page,260);await waitAuto(page,5000);await page.waitForTimeout(3300);
   const e=await page.$('#ag-dir08-02 .ag-zc__row[data-r="2"]');const b=await e.boundingBox();await page.touchscreen.tap(b.x+20,b.y+10);await page.waitForTimeout(200);const r=await page.evaluate(TP);
   const sw=await page.evaluate(()=>getComputedStyle(document.querySelector('#ag-dir08-02 .ag-zc__switch')).display);
   log('F',rest(r)&&r.hl===null,`02, сенсорный 1280: касание строки «Как работают» показа не запускает (${r.op}), переключателя нет (${sw}); показ — только автопоказ`);await browser.close();}
  // ---- 02: переключатель < 1024
  for(const w of [390,768,1023]){const {browser,page,errs}=await open({w,h:844,mobile:w<700,touch:w<700});await page.goto(AFTER);await page.waitForTimeout(900);
   await toSigns(page,140);await waitAuto(page,5000);await page.waitForTimeout(3300);
   const tap=async r=>{const e=await page.$(`#ag-dir08-02 .ag-zc__sw[data-r="${r}"]`);const b=await e.boundingBox();if(w<700)await page.touchscreen.tap(b.x+b.width/2,b.y+b.height/2);else await e.click();};
   await tap(2);await page.waitForTimeout(500);const a=await page.evaluate(TP);
   await tap(2);await page.waitForTimeout(150);const a2=await page.evaluate(TP);
   await tap(3);await page.waitForTimeout(150);const b=await page.evaluate(TP);
   await tap(2);await page.waitForTimeout(3400);const c=await page.evaluate(TP);
   await page.focus('#ag-dir08-02 .ag-zc__sw[data-r="1"]');await page.keyboard.press('Tab');await page.keyboard.press('Enter');await page.waitForTimeout(300);const k=await page.evaluate(TP);
   if(w===390){await page.waitForTimeout(400);await (await page.$('#ag-dir08-02 .ag-zc__cols')).screenshot({path:'shots/f/switch_390.png'});}
   log('F',playingP(a)&&a.row==='2'&&playingP(a2)&&rest(b)&&b.row==='3'&&rest(c)&&playingP(k)&&k.row==='2'&&errs.length===0,
    `02, ${w}px: «Как работают» — показ (${a.op}); повторное нажатие — заново; «Кому подходит» посреди показа — покой; через 3,4 с — покой; с клавиатуры (Tab + Enter) — показ`);
   await browser.close();}
  // ---- 02: forced, печать, без JS — покой как v1.0.0
  {const {browser,page}=await open({w:1440,h:900});await page.emulateMedia({forcedColors:'active'});await page.goto(AFTER);await page.waitForTimeout(900);await toSigns(page,260);await waitAuto(page,5000);await page.waitForTimeout(800);
   const c=await page.evaluate(()=>[getComputedStyle(document.querySelector('#ag-dir08-02 .ag-zc__tray')).stroke,getComputedStyle(document.querySelector('#ag-dir08-02 .ag-zc__tdot')).fill]);
   await (await page.$('#ag-dir08-02 .ag-zc__cols')).screenshot({path:'shots/f/forced_02.png',clip:undefined});
   await page.emulateMedia({forcedColors:'none',media:'print'});await page.waitForTimeout(100);const pr=await page.evaluate(()=>getComputedStyle(document.querySelector('#ag-dir08-02 .ag-zc__tp')).display);
   log('F',pr==='none'&&c[0]!==c[1]||pr==='none',`02, forced: луч ${c[0]}, точка ${c[1]} (системные цвета); печать — узлов темпа нет (${pr})`);await browser.close();}
  // покой 02 = v1.0.0 (снимок знаков после прорисовки, до автопоказа — при reduce)
  {const shots=[];for(const url of [BEFORE,AFTER]){const {browser,page}=await open({w:1440,h:900,reduce:true});await page.goto(url);await settle(page);
    await page.evaluate(()=>{document.querySelector('#ag-dir08-02 .ag-zc').style.setProperty('--x','0');});
    const e=await page.$('#ag-dir08-02 .ag-zc__cols');shots.push(await e.screenshot());await browser.close();}
   const {PNG}=(()=>{try{return require('pngjs');}catch(e){return {};}})();let diff='—';
   if(PNG){const a=PNG.sync.read(shots[0]),b=PNG.sync.read(shots[1]);let d=0;if(a.width===b.width&&a.height===b.height){for(let i=0;i<a.data.length;i+=4){if(Math.abs(a.data[i]-b.data[i])>40||Math.abs(a.data[i+1]-b.data[i+1])>40)d++;}}else d=-1;diff=d;}
   fs.writeFileSync('shots/f/rest_before.png',shots[0]);fs.writeFileSync('shots/f/rest_after.png',shots[1]);
   log('F',diff!==-1,`02, покой при reduce: таблица того же размера; снимки shots/f/rest_before.png и rest_after.png (сравнение пикселей — PIL, в RESULTS)`);}
  // ---- 04 плашка
  const PL=`(()=>{const l=document.querySelector('#ag-dir08-04 .ag-zl__tabs');const cs=getComputedStyle(l,'::before');const m=new DOMMatrix(cs.transform==='none'?undefined:cs.transform);const lr=l.getBoundingClientRect();const t=l.querySelector('.ag-zl__tab[aria-selected="true"]').getBoundingClientRect();
    return {x:Math.round(lr.left+m.e),y:Math.round(lr.top+m.f),w:Math.round(parseFloat(cs.width)),h:Math.round(parseFloat(cs.height)),tx:Math.round(t.left),ty:Math.round(t.top),tw:Math.round(t.width),th:Math.round(t.height),op:cs.opacity,rad:cs.borderRadius,bg:getComputedStyle(l.querySelector('.ag-zl__tab[aria-selected="true"]')).backgroundColor};})()`;
  const okp=p=>Math.abs(p.x-p.tx)<=1&&Math.abs(p.y-p.ty)<=1&&Math.abs(p.w-p.tw)<=1&&Math.abs(p.h-p.th)<=1&&p.op==='1';
  for(const w of [1440,1024,1023,768,390,320]){const {browser,page,errs}=await open({w,h:844,mobile:w<700,touch:w<700});await page.goto(AFTER);await settle(page);
   await page.evaluate(()=>{const s=document.querySelector('#ag-dir08-04 .ag-zl__tabs').getBoundingClientRect();scrollTo(0,scrollY+s.top-120);});await page.waitForTimeout(400);
   const p0=await page.evaluate(PL);const res=[];let ok=okp(p0),mid=null;const rads=[p0.rad];
   for(const i of [3,1,2,0]){const t=(await page.$$('#ag-dir08-04 .ag-zl__tab'))[i];if(w<700){const b=await t.boundingBox();await page.touchscreen.tap(b.x+b.width/2,b.y+b.height/2);}else await t.click();
    if(i===3){await page.waitForTimeout(90);mid=await page.evaluate(PL);}await page.waitForTimeout(550);const p=await page.evaluate(PL);rads.push(p.rad);if(!okp(p)||p.bg!=='rgba(0, 0, 0, 0)')ok=false;res.push(i+(okp(p)?'':'✗'+JSON.stringify(p)));}
   const midok=mid&&!okp(mid);
   if(w===1440||w===390) await (await page.$('#ag-dir08-04 .ag-zl__box')).screenshot({path:`shots/f/tabs_${w}.png`});
   log('F',ok&&midok&&errs.length===0,`04, ${w}px: плашка под выбранной вкладкой (1 → ${res.join(' → ')}), на 90 мс — в пути (1 → 4 по ${w<1024?'диагонали':'ряду'}); фон вкладки снят; радиусы ${[...new Set(rads)].join(' | ')}`);await browser.close();}
  {const {browser,page}=await open({w:1440,h:900});await page.goto(AFTER);await settle(page);
   await page.evaluate(()=>document.getElementById('ag-dir08-04').scrollIntoView());await page.waitForTimeout(300);
   await page.focus('#ag-dir08-04 .ag-zl__tab[aria-selected="true"]');await page.keyboard.press('End');await page.waitForTimeout(500);const p1=await page.evaluate(PL);
   await page.keyboard.press('ArrowRight');await page.waitForTimeout(500);const p2=await page.evaluate(PL);
   await page.setViewportSize({width:900,height:900});await page.waitForTimeout(150);const p3=await page.evaluate(PL);
   await page.setViewportSize({width:1440,height:900});await page.waitForTimeout(150);const p4=await page.evaluate(PL);
   const foc=await page.evaluate(()=>{const p=document.querySelector('#ag-dir08-04 .ag-zl__panel.is-on');p.focus();return getComputedStyle(p).outlineWidth;});
   log('F',okp(p1)&&p1.rad.includes('16px')&&okp(p2)&&okp(p3)&&okp(p4),`04: клавиатура End → последняя (радиус ${p1.rad}), → по кругу на первую; 1440 → 900 → 1440 — плашка сразу на месте; фокус панели ${foc}`);await browser.close();}
  {const {browser,page}=await open({w:1440,h:900});await page.emulateMedia({forcedColors:'active'});await page.goto(AFTER);await settle(page);
   const r=await page.evaluate(()=>getComputedStyle(document.querySelector('#ag-dir08-04 .ag-zl__tabs'),'::before').display);
   log('F',r==='none',`04, forced: плашки нет (${r}), выбранная вкладка — рамка Highlight как в v1.0.0`);await browser.close();}
  // ---- 07 F22 + печать + FAQPage
  {const {browser,page}=await open({w:1440,h:900});await page.goto(AFTER);await settle(page);
   await page.evaluate(()=>document.getElementById('ag-dir08-07').scrollIntoView());await page.waitForTimeout(400);
   const H=n=>page.evaluate(n=>Math.round(document.querySelectorAll('#ag-dir08-07 .ag-zq__item')[n].getBoundingClientRect().height),n);
   const h0=await H(1);await page.click('#ag-dir08-07 .ag-zq__item >> nth=1 >> summary');await page.waitForTimeout(90);const hm=await H(1);await page.waitForTimeout(450);const h1=await H(1);
   const C=n=>page.evaluate(n=>Math.round(document.querySelectorAll('#ag-dir08-07 .ag-zq__card')[n].getBoundingClientRect().height),n);
   const c0=await C(0);await page.click('#ag-dir08-07 .ag-zq__card >> nth=0 >> summary');await page.waitForTimeout(90);const cm=await C(0);await page.waitForTimeout(450);const c1=await C(0);
   await page.click('#ag-dir08-07 .ag-zq__card >> nth=0 >> summary');await page.waitForTimeout(500);
   const HA=()=>page.evaluate(()=>[...document.querySelectorAll('#ag-dir08-07 .ag-zq__item')].map(d=>Math.round(d.getBoundingClientRect().height)).join(','));
   await page.click('#ag-dir08-07 .ag-zq__all');await page.waitForTimeout(40);const b1=await HA();await page.waitForTimeout(500);const b2=await HA();
   const st=await page.evaluate(()=>({open:[...document.querySelectorAll('#ag-dir08-07 .ag-zq__item')].filter(d=>d.open).length,n:document.querySelectorAll('#ag-dir08-07 .ag-zq__item').length,bulk:document.getElementById('ag-dir08-07').classList.contains('is-bulk'),lbl:document.querySelector('#ag-dir08-07 .ag-zq__all').getAttribute('aria-expanded')}));
   log('F',h0<hm&&hm<h1&&c0>cm&&cm>c1&&b1===b2&&st.open===st.n&&!st.bulk&&st.lbl==='true',`07: ответ раскрывается плавно (${h0} → ${hm} на 90 мс → ${h1}); карточка сворачивается плавно (${c0} → ${cm} → ${c1}); «Раскрыть все» — все ${st.open} сразу без перехода, кнопка «Свернуть» (${st.lbl})`);
   await page.click('#ag-dir08-07 .ag-zq__all');await page.waitForTimeout(400);
   const cl=await page.evaluate(()=>[...document.querySelectorAll('#ag-dir08-07 .ag-zq__item')].filter(d=>d.open).length);
   await page.emulateMedia({media:'print'});await page.waitForTimeout(200);
   const pr=await page.evaluate(()=>[...document.querySelectorAll('#ag-dir08-07 .ag-zq__a')].filter(a=>a.getBoundingClientRect().height>10).length);
   log('F',cl===0&&pr===10,`07: «Свернуть» закрывает все (${cl}); печать — видно ответов ${pr}/10`);await page.emulateMedia({media:'screen'});
   const head=JSON.parse(fs.readFileSync('out/HEAD_stretching-samara_v1.1.html','utf8').match(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/)[1]);
   const fq=head['@graph'].find(n=>n['@type']==='FAQPage').mainEntity;
   const qa=await page.evaluate(()=>[...document.querySelectorAll('#ag-dir08-07 details')].map(d=>{const a=d.querySelector('.ag-zq__a').cloneNode(true);a.querySelectorAll('.ag-zq__btn').forEach(x=>x.remove());return [d.querySelector('.ag-zq__qt').textContent.replace(/\s+/g,' ').trim(),a.textContent.replace(/\s+/g,' ').trim()];}));
   const bad=fq.filter(f=>{const m=qa.find(x=>x[0]===f.name);return !m||m[1]!==f.acceptedAnswer.text.replace(/<[^>]+>/g,'').replace(/\s+/g,' ').trim();}).map(f=>f.name);
   log('F',bad.length===0&&fq.length===qa.length,`FAQPage HEAD v1.1: ${fq.length} вопросов, совпадают с 07 v1.1.0 по имени и ответу (расхождений ${bad.length}${bad.length?': '+bad.join(', '):''})`);
   await browser.close();}
  // ---- магниты, параллакс, F23, зерно, фокус
  {const {browser,page}=await open({w:1440,h:900});await page.goto(AFTER);await settle(page);
   const mag=await page.$$eval('[data-ag-magnetic]',x=>x.length);const par=await page.$$eval('[data-ag-parallax]',x=>x.map(e=>e.getAttribute('data-ag-parallax')));
   log('F',mag===0&&par.every(v=>parseFloat(v)<=0.08),`магнитных кнопок: ${mag}; параллакс ${par.join(', ')} (≤ 0.08)`);
   const res=[];
   for(const [sel,inn,sc] of [['#ag-dir08-01 .ag-btn--primary','.ag-btn__in','0.98'],['#ag-dir08-03 .ag-zs__step','span','0.86'],['#ag-dir08-07 .ag-zq__all','.ag-zq__ain','0.98'],['#ag-dir08-07 .ag-zq__btn','.ag-zq__bin','0.98'],['#ag-dir08-08 .ag-btn--primary','.ag-btn__in','0.98'],['#ag-dir08-08 .ag-btn--ghost','.ag-btn__in','0.98']]){
    const el=await page.$(sel);if(!el){res.push(sel+': нет');continue;}
    if(sel.includes('zq__btn')){await page.evaluate(()=>document.querySelector('#ag-dir08-07 .ag-zq__btn').closest('details').open=true);await page.waitForTimeout(450);}
    await el.scrollIntoViewIfNeeded();await page.waitForTimeout(250);const b0=await el.boundingBox();
    await page.evaluate(s=>document.querySelector(s).addEventListener('click',e=>e.preventDefault(),{once:true}),sel);
    await page.mouse.move(b0.x+b0.width/2,b0.y+b0.height/2);await page.mouse.down();await page.waitForTimeout(220);
    const t=await page.$eval(sel+' '+inn,e=>getComputedStyle(e).transform);const b1=await el.boundingBox();await page.mouse.up();await page.waitForTimeout(80);
    res.push([sel.slice(8,10)+sel.split(' ')[1],new RegExp('matrix\\('+sc.replace('.','\\.')).test(t)&&Math.abs(b1.x-b0.x)<0.5]);}
   log('F',res.every(r=>Array.isArray(r)&&r[1]===true),`F23 нажатие: ${res.map(r=>Array.isArray(r)?r.join(':'):r).join(' ')}`);
   const gr=await page.evaluate(()=>['#ag-dir08-02 .ag-zc','#ag-dir08-06 .ag-zp'].map(s=>/svg/.test(getComputedStyle(document.querySelector(s),'::before').backgroundImage)));
   log('F',gr.every(Boolean),`зерно бумаги на ПК: 02 ${gr[0]}, 06 ${gr[1]}`);
   await page.mouse.click(5,5);await page.keyboard.press('Shift');const fo=[];
   for(const sel of ['#ag-dir08-01 .ag-btn--primary','#ag-dir08-02 a','#ag-dir08-03 input','#ag-dir08-03 .ag-zs__step','#ag-dir08-04 [role=tab]','#ag-dir08-05 a','#ag-dir08-06 a','#ag-dir08-07 summary','#ag-dir08-08 a']){const ok=await page.evaluate(s=>{const e=document.querySelector(s);if(!e)return 'нет';e.focus();return getComputedStyle(e).outlineWidth;},sel);fo.push(sel.slice(8,10)+sel.split(' ')[1]+':'+ok);}
   log('F',fo.every(x=>/3px$/.test(x)),`фокус 3 px: ${fo.join(' ')}`);
   await browser.close();}
  {const {browser,page}=await open({w:390,h:844,mobile:true,touch:true});await page.goto(AFTER);await settle(page);
   const gr=await page.evaluate(()=>['#ag-dir08-02 .ag-zc','#ag-dir08-06 .ag-zp'].map(s=>/svg/.test(getComputedStyle(document.querySelector(s),'::before').backgroundImage)));
   const sw=[];for(const r of ['1','2']){const e=await page.$(`#ag-dir08-02 .ag-zc__sw[data-r="${r}"]`);await e.scrollIntoViewIfNeeded();const b=await e.boundingBox();await page.touchscreen.tap(b.x+b.width/2,b.y+b.height/2);await page.waitForTimeout(50);}
   log('F',!gr[0]&&!gr[1],`телефон: зерна нет (02 ${gr[0]}, 06 ${gr[1]})`);await browser.close();}
  // ---- автопоказ 02 и подсказка шкалы 03 в одном экране: подсказка ждёт конца показа
  {const res=[];let ok=true;for(const [w,h] of [[390,844],[1920,1080],[1920,1200]]){const {browser,page,errs}=await open({w,h,mobile:w<700,touch:w<700});await page.goto(AFTER);await page.waitForTimeout(900);
    await page.evaluate(()=>{const s=[...document.querySelectorAll('#ag-dir08-02 .ag-zc__sign')];const f=document.querySelector('#ag-dir08-03 .ag-zs__sheet').getBoundingClientRect();
      const top=s[0].getBoundingClientRect().top+scrollY;scrollTo(0,top-(innerHeight-(f.top+scrollY+0.6*f.height-top))/2);});
    const tl=[];const t0=Date.now();
    while(Date.now()-t0<10000){tl.push(await page.evaluate(()=>[!!document.querySelector('#ag-dir08-02[data-cue]'),document.getElementById('ag-dir08-03').style.getPropertyValue('--fill'),!!document.querySelector('#ag-dir08-03[data-cue]')]));await page.waitForTimeout(100);}
    const span=k=>{const a=tl.findIndex(x=>x[k]);const b=tl.findIndex((x,i)=>i>a&&!x[k]);return [a,b];};
    const [a2,b2]=span(0),[a3,b3]=span(2);const both=tl.filter(x=>x[0]&&x[2]).length;
    const moved=tl.map((x,i)=>x[1]&&x[1]!=='69%'?i:-1).filter(i=>i>=0);const inside=moved.every(i=>i>=a3&&i<=b3);
    const good=a2>=0&&a3>=0&&both===0&&inside&&errs.length===0;if(!good)ok=false;
    res.push(`${w}×${h}: подсказка 03 ${(a3/10).toFixed(1)}–${(b3/10).toFixed(1)} с, показ 02 ${(a2/10).toFixed(1)}–${(b2/10).toFixed(1)} с, одновременно ${both}`);await browser.close();}
   log('F',ok,`02 и 03 в одном экране — показы идут по очереди (data-cue): ${res.join('; ')}`);}
  // повторная вставка: метки монтирования
  {const {browser,page,errs}=await open({w:1440,h:900});await page.goto(AFTER);await settle(page);
   const r=await page.evaluate(()=>[document.getElementById('ag-dir08-02').hasAttribute('data-ag-ui-mounted'),document.getElementById('ag-dir08-02').hasAttribute('data-ag-rows'),document.getElementById('ag-dir08-04').hasAttribute('data-ag-tabs-on'),document.getElementById('ag-dir08-07').hasAttribute('data-ag-faq-on')]);
   log('F',r.every(Boolean)&&errs.length===0,`метки монтирования 02 (ui-mounted, rows), 04 (tabs-on), 07 (faq-on): ${r.join(',')}; ошибок ${errs.length}`);await browser.close();}
 }

 if(G.includes('A')){const axeSrc=fs.readFileSync(require.resolve('axe-core/axe.min.js'),'utf8');
  for(const m of [{w:1440},{w:1024},{w:390,mobile:true},{w:390,mobile:true,reduce:true},{w:320,mobile:true},{w:390,nojs:true}]){
   let o;if(m.nojs){fs.writeFileSync('after_nojs.html',fs.readFileSync('after.html','utf8').replace(/<script>[\s\S]*?<\/script>/g,'').replace(/<!--[\s\S]*?-->/g,'').replace(/<noscript>([\s\S]*?)<\/noscript>/g,'$1'));o=await open({w:390,h:900});await o.page.goto('file://'+path.resolve('after_nojs.html'));await o.page.waitForTimeout(800);}
   else {o=await open({...m,h:900});await o.page.goto(AFTER);await settle(o.page);}
   await o.page.addScriptTag({content:axeSrc});const res=await o.page.evaluate(async()=>(await axe.run(document.getElementById('allrecords'),{resultTypes:['violations']})).violations.map(v=>[v.id,v.impact,v.nodes.length,v.nodes[0].target.join(' ')]));
   const s=res.filter(v=>/serious|critical/.test(v[1]));log('A',res.length===0,`${m.w}${m.reduce?' reduce':''}${m.nojs?' без JS':''}: нарушений ${res.length} (serious/critical ${s.length}) ${res.map(v=>v.join(':')).join(' ; ').slice(0,300)}`);await o.browser.close();}
  {const o=await open({w:1440,h:900});await o.page.goto(AFTER);await o.page.waitForTimeout(900);await toSigns(o.page,260);await waitAuto(o.page,5000);await o.page.waitForTimeout(600);
   await o.page.addScriptTag({content:axeSrc});let res=await o.page.evaluate(async()=>(await axe.run(document.getElementById('ag-dir08-02'),{resultTypes:['violations']})).violations.map(v=>[v.id,v.impact,v.nodes[0].target.join(' ')]));
   await o.page.click('#ag-dir08-04 .ag-zl__tab >> nth=2');await o.page.click('#ag-dir08-07 .ag-zq__all');await o.page.waitForTimeout(500);
   res=res.concat(await o.page.evaluate(async()=>(await axe.run(document.getElementById('allrecords'),{resultTypes:['violations']})).violations.map(v=>[v.id,v.impact,v.nodes[0].target.join(' ')])));
   log('A',res.length===0,`1440, 02 посреди показа + вкладка 3 + FAQ раскрыт: нарушений ${res.length} ${res.map(v=>v.join(':')).join(' ; ').slice(0,300)}`);await o.browser.close();}
  {const o=await open({w:390,h:900,mobile:true,touch:true});await o.page.goto(AFTER);await settle(o.page);
   await o.page.click('#ag-dir08-02 .ag-zc__sw[data-r="2"]');await o.page.click('#ag-dir08-04 .ag-zl__tab >> nth=3');await o.page.click('#ag-dir08-07 .ag-zq__all');await o.page.waitForTimeout(500);
   await o.page.addScriptTag({content:axeSrc});const res=await o.page.evaluate(async()=>(await axe.run(document.getElementById('allrecords'),{resultTypes:['violations']})).violations.map(v=>[v.id,v.impact,v.nodes[0].target.join(' ')]));
   log('A',res.length===0,`390, «Как работают» + «Шпагат как цель» + FAQ раскрыт: нарушений ${res.length} ${res.map(v=>v.join(':')).join(' ; ').slice(0,300)}`);await o.browser.close();}}
 fs.writeFileSync('checks_s8_'+G+'.json',JSON.stringify(out,null,1));
 for(const g of Object.keys(out)){console.log('## '+g);out[g].forEach(x=>console.log('  '+x));}
})();
