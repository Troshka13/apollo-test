# -*- coding: utf-8 -*-
"""/stretching-samara (DIR08) · проход «дизайн, движение и фишка» (PROMPT_DIR08_DESIGN_MOTION_v2, 02.10.2026).
src/DIR08-0N_v1.0.0.html → out/DIR08-0N_v1.1.0.html. Каждая замена обязана найтись нужное число раз."""
import os, re, sys

sys.path.insert(0, '/home/claude/hp/pack/tools')
from dm_helpers import rep, rx, focus3, wrap, press_css, touch, TOUCH, GRAIN, EASE_OUT  # noqa: E402

SRC, OUT = 'src', 'out'
os.makedirs(OUT, exist_ok=True)
DATE = '02.10.2026'
E = 'cubic-bezier(.22,.61,.36,1)'
REC = {1: 'rec4006241401', 2: 'rec4006402501', 3: 'rec4006422401', 4: 'rec4007063701',
       5: 'rec4007138901', 6: 'rec4007255401', 7: 'rec4007364101', 8: 'rec4007385601'}


def load(n):
    return open('%s/DIR08-0%d_v1.0.0.html' % (SRC, n), encoding='utf-8').read()


def save(n, t):
    p = '%s/DIR08-0%d_v1.1.0.html' % (OUT, n)
    open(p, 'w', encoding='utf-8').write(t)
    print('DIR08-0%d v1.1.0 %6d байт' % (n, len(t.encode('utf-8'))))


def bump(t, n, note):
    t = rx(t, r'(DIR08-0\d · [^\n]*?)· v1\.0\.0 · \d\d\.09\.2026', r'\1· v1.1.0 · ' + DATE)
    i = t.index('-->') + 3
    return (t[:i] + '\n<!-- v1.1.0 (проход «дизайн, движение и фишка», PROMPT_DIR08_DESIGN_MOTION_v2, %s):\n'
            '     Запись Tilda %s — заменить v1.0.0 этим блоком целиком.\n'
            '     %s -->' % (DATE, REC[n], note) + t[i:])


def add_css(t, css):
    i = t.index('  </style>')
    return t[:i] + '\n  /* ===== v1.1.0 · дизайн, движение и фишка (%s) ===== */\n' % DATE + css + t[i:]


def add_js(t, js):
    """Свой скрипт — перед «Страховкой скана» (тот же <script>, currentScript доступен)."""
    k = t.index('  /* Страховка скана')
    return t[:k] + js + '\n' + t[k:]


def grain_css(root, sec, wrap_cls):
    return '''  /* F29 · зерно бумаги (статично, только ≥ 640 px; forced-colors и печать — без зерна) */
  @media (min-width:640px){
    %(r)s .%(s)s{position:relative;}
    %(r)s .%(s)s::before{content:"";position:absolute;inset:0;z-index:0;pointer-events:none;opacity:.12;background-image:%(g)s;background-size:180px 180px;}
    %(r)s .%(w)s{position:relative;z-index:1;}
  }
  @media (forced-colors:active){%(r)s .%(s)s::before{display:none;}}
  @media print{%(r)s .%(s)s::before{display:none;}}
''' % {'r': root, 's': sec, 'w': wrap_cls, 'g': GRAIN}



def print_fix(t, root):
    """Печать до прокрутки: движок уже поставил узлам inline opacity:0 (fromTo ждёт триггера) — в печати показать всё."""
    css = ('  /* Печать: узлы движка, ещё не показанные прокруткой, печатаются видимыми (inline opacity:0 от движка) */\n'
           '  @media print{\n'
           '    %(r)s [data-ag-anim],\n'
           '    %(r)s [data-ag-anim] *{opacity:1 !important;}\n'
           '    %(r)s [data-ag-anim]{transform:none !important;}\n'
           '  }\n') % {'r': root}
    return add_css(t, css)

FREE_NOTE = 'Факт 5.1/5.13: бесплатное первое занятие по растяжке не подтверждено — обещание убрано («Условия первого занятия — при записи»).'


# ---------------------------------------------------------------- DIR08-01
def c01():
    t = load(1); R = '#ag-dir08-01'
    t = bump(t, 1, 'Кадр 51 сверен глазами 02.10: общий вид зала (ринг, флаги); адрес — каталог владельца (тот же кадр в CL04-04),\n'
                   '     alt и подпись верны. ' + FREE_NOTE + '\n'
                   '     Планка — два факта: пункт «0 ₽ · первое групповое занятие» удалён (ПК — две колонки). Магнит снят, параллакс\n'
                   '     веера 0,1 → 0,08, F23 — нажатие кнопки записи, фокус 3 px. Остальной текст без изменений.')
    # пункт «0 ₽» целиком
    t = rx(t, r'\n          <li><a class="ag-zh__fact" href="#ag-dir08-06"[^\n]*?<b>0&nbsp;₽</b>.*?</a></li>', '')
    t = rep(t, 'grid-template-columns:minmax(150px,1fr) minmax(112px,.78fr) minmax(0,1.3fr);',
            'grid-template-columns:minmax(150px,1fr) minmax(0,1.6fr);')
    t = rx(t, r' data-ag-magnetic="0\.\d+"', '')
    t = rep(t, 'data-ag-anim="parallax" data-ag-parallax="0.1">', 'data-ag-anim="parallax" data-ag-parallax="0.08">')
    t = wrap(t, 'a', 'ag-btn ag-btn--primary', 'ag-btn__in')
    t = focus3(t, R)
    t = add_css(t, press_css(R, [('ag-btn', 'ag-btn__in')]))
    t = touch(t)
    t = print_fix(t, R)
    save(1, t)


# ---------------------------------------------------------------- DIR08-02
TEMPO_HOLD = '''
              <g class="ag-zc__tp" data-ag-tempo="hold">
                <path class="ag-zc__tray" d="M14 38L60 15"/>
                <circle class="ag-zc__tc" cx="22" cy="44" r="2.6"/>
                <circle class="ag-zc__tc" cx="30" cy="44" r="2.6"/>
                <circle class="ag-zc__tc" cx="38" cy="44" r="2.6"/>
              </g>'''
TEMPO_LOOP = '''
              <g class="ag-zc__tp" data-ag-tempo="loop">
                <g class="ag-zc__trot">
                  <path class="ag-zc__trad" d="M36 24L46.6 13.4"/>
                  <circle class="ag-zc__tdot" cx="46.6" cy="13.4" r="2.8"/>
                </g>
              </g>'''
TEMPO_GLIDE = '''
              <g class="ag-zc__tp" data-ag-tempo="glide">
                <circle class="ag-zc__tdot ag-zc__tglide" cx="0" cy="0" r="2.8"/>
              </g>'''

C02_JS = '''  /* v1.1.0 · «Три темпа на знаке» (F08 + предмет): строка «Как работают» показана движением — три знака играют
     свой темп одновременно, один раз, ~3 с: растяжка — луч поднимается от базовой линии до нарисованного угла
     (не дальше), держит под счёт трёх точек и опускается; подвижность суставов — точка обходит круг туда и обратно
     дважды; восстановление — точка медленно проходит волну. Узлы заранее в разметке (aria-hidden svg, без
     data-ag-anim), в покое скрыты CSS; draw-пути только читаются. Пуски: один автопоказ, когда три знака видны
     (≥ 60 %, 400 мс), их прорисовка закончена и на странице не идёт показ другого блока (его корень с
     data-cue); data-cue="2" на время показа отмечает строку / кнопку; мышь ≥ 1024 — переход
     подсветки на строку 2 (data-hl); < 1024 — выбор «Как работают» (повторное нажатие — заново, уход — покой).
     reduce — не играет (и останавливает на лету). Скрипт меняет только атрибуты; WAAPI, одна анимация на узел. */
  (function () {
    "use strict";
    var W = window, D = document;
    var root = D.currentScript && D.currentScript.closest(".ag-scope");
    if (!root || root.hasAttribute("data-ag-ui-mounted")) return;
    function all(sel) { return Array.prototype.slice.call(root.querySelectorAll(sel)); }
    var signs = all(".ag-zc__sign");
    var hold = root.querySelector('[data-ag-tempo="hold"]');
    var loop = root.querySelector('[data-ag-tempo="loop"]');
    var glide = root.querySelector('[data-ag-tempo="glide"]');
    if (signs.length !== 3 || !hold || !loop || !glide || !hold.animate || !W.MutationObserver) return;
    var ray = hold.querySelector(".ag-zc__tray"), dots = all('[data-ag-tempo="hold"] .ag-zc__tc');
    var rot = loop.querySelector(".ag-zc__trot"), gdot = glide.querySelector(".ag-zc__tglide");
    var wave = signs[2].querySelector('path[data-ag-anim="draw"]');
    var draws = all('.ag-zc__sign [data-ag-anim="draw"]'), cols = all(".ag-zc__col");
    if (!ray || dots.length !== 3 || !rot || !gdot) return;
    root.setAttribute("data-ag-ui-mounted", "");
    function mq(q) { return W.matchMedia ? W.matchMedia(q) : { matches: false }; }
    var still = mq("(prefers-reduced-motion: reduce)");
    var fine = mq("(min-width: 1024px) and (hover: hover) and (pointer: fine)");
    var narrow = mq("(max-width: 1023px)");
    var T = 3000, EASE = "cubic-bezier(.22,.61,.36,1)", A0 = "rotate(26.57deg)", A1 = "rotate(0deg)";
    var anims = [], endT = 0, autoDone = false, seen = 0, dwellT = 0, tryT = 0;

    /* 29 точек волны: по самому пути (только чтение), иначе — по формуле кривой */
    var PTS = [];
    (function () {
      var k, L = 0;
      try { L = wave && wave.getTotalLength ? wave.getTotalLength() : 0; } catch (e) { L = 0; }
      for (k = 0; k <= 28; k++) {
        if (L) { var p = wave.getPointAtLength(L * k / 28); PTS.push([p.x, p.y]); }
        else { var x = 6 + 56 * k / 28; PTS.push([x, 26.5 - 3.5 * Math.cos((x - 6) * Math.PI / 14)]); }
      }
    })();
    function tr(p) { return "translate(" + p[0].toFixed(2) + "px," + p[1].toFixed(2) + "px)"; }
    function ready() {
      var m = D.documentElement.getAttribute("data-ag-motion");
      if (m === "off") return true;
      if (m !== "on") return false;
      for (var k = 0; k < draws.length; k++) {
        if (!draws[k].hasAttribute("data-ag-done")) return false;
        if (Math.abs(parseFloat(W.getComputedStyle(draws[k]).strokeDashoffset) || 0) > 0.5) return false;
      }
      for (var c = 0; c < cols.length; c++) if (parseFloat(W.getComputedStyle(cols[c]).opacity) < 0.99) return false;
      return true;
    }
    function stop() {
      W.clearTimeout(endT);
      anims.forEach(function (a) { a.cancel(); });
      anims = [];
      root.removeAttribute("data-cue");
    }
    function playing() { return anims.length > 0; }
    function play(cue) {
      if (still.matches || !ready()) return false;
      stop();
      autoDone = true;
      var env = [{ opacity: 0 }, { opacity: 1, offset: 0.06 }, { opacity: 1, offset: 0.93 }, { opacity: 0 }];
      [hold, loop, glide].forEach(function (g) { anims.push(g.animate(env, { duration: T })); });
      anims.push(ray.animate([
        { transform: A0, easing: EASE }, { transform: A1, offset: 0.2 },
        { transform: A1, offset: 0.7, easing: EASE }, { transform: A0, offset: 0.9 }, { transform: A0 }
      ], { duration: T }));
      dots.forEach(function (d, k) {
        var on = (600 + 500 * k) / T;
        anims.push(d.animate([{ opacity: 0.25 }, { opacity: 0.25, offset: on }, { opacity: 1, offset: on + 0.03 },
          { opacity: 1, offset: 0.88 }, { opacity: 0.25, offset: 0.92 }, { opacity: 0.25 }], { duration: T }));
      });
      var R = [];
      for (var k = 0; k <= 4; k++) R.push({ transform: "rotate(" + (k % 2 ? 360 : 0) + "deg)", offset: k / 4, easing: "ease-in-out" });
      anims.push(rot.animate(R, { duration: T }));
      var G = PTS.map(function (p, k) {
        var f = k / 28;
        return { transform: tr(p), offset: 0.03 + 0.9 * (f < 0.5 ? 2 * f * f : 1 - Math.pow(-2 * f + 2, 2) / 2) };
      });
      G.unshift({ transform: tr(PTS[0]), offset: 0 });
      G.push({ transform: tr(PTS[28]), offset: 1 });
      anims.push(gdot.animate(G, { duration: T }));
      if (cue) root.setAttribute("data-cue", "2");
      endT = W.setTimeout(function () { anims = []; root.removeAttribute("data-cue"); }, T + 40);
      return true;
    }

    /* Автопоказ — один раз, когда три знака видны и прорисованы */
    if ("IntersectionObserver" in W) {
      var vis = [0, 0, 0];
      var io = new IntersectionObserver(function (en) {
        en.forEach(function (e) { vis[signs.indexOf(e.target)] = e.intersectionRatio >= 0.6 ? 1 : 0; });
        seen = vis[0] && vis[1] && vis[2];
        W.clearTimeout(dwellT);
        if (seen && !autoDone) dwellT = W.setTimeout(tryAuto, 400);
      }, { threshold: [0, 0.6, 1] });
      signs.forEach(function (s) { io.observe(s); });
      var tryAuto = function () {
        W.clearTimeout(tryT);
        if (autoDone) { io.disconnect(); return; }
        if (!seen || still.matches || D.hidden) return;
        var other = D.querySelector(".ag-scope[data-cue]");
        if (!(other && other !== root) && play(true)) { io.disconnect(); return; }
        tryT = W.setTimeout(tryAuto, 300);
      };
    }
    /* Наведение (ПК) и переключатель (< 1024) — через атрибуты корня, которые ставит скрипт строк */
    new MutationObserver(function (list) {
      list.forEach(function (m) {
        var v = root.getAttribute(m.attributeName), old = m.oldValue;
        if (m.attributeName === "data-hl") {
          if (v === "2" && old !== "2" && fine.matches && !playing()) play(false);
        } else if (m.attributeName === "data-row" && narrow.matches) {
          if (v === "2") play(false);
          else if (old === "2") stop();
        }
      });
    }).observe(root, { attributes: true, attributeOldValue: true, attributeFilter: ["data-hl", "data-row"] });
    [still, fine, narrow].forEach(function (q) {
      if (q.addEventListener) q.addEventListener("change", stop); else if (q.addListener) q.addListener(stop);
    });
    D.addEventListener("visibilitychange", function () { if (D.hidden) stop(); });
  })();
'''


def c02():
    t = load(2); R = '#ag-dir08-02'
    t = bump(t, 2, '«Три темпа на знаке» (F08 + предмет): строка «Как работают» показана движением — растяжка держит под счёт,\n'
                   '     подвижность суставов повторяет круг туда и обратно, восстановление идёт медленно. Новые узлы в знаках (без\n'
                   '     data-ag-anim), WAAPI; автопоказ один раз, наведение на строку 2 (ПК), выбор «Как работают» (< 1024).\n'
                   '     Подсветка строки 0,22 с и снимается через 220 мс (переход по строке не мигает). F23 — кнопки переключателя.\n'
                   '     Зерно бумаги (≥ 640), фокус 3 px. Текст без изменений. Фишка страницы теперь здесь (не в 03).')
    # узлы темпа — последними в каждом знаке
    signs = list(re.finditer(r'(<svg class="ag-zc__sign"[^>]*>)(.*?)(\n            </svg>)', t, re.S))
    assert len(signs) == 3, len(signs)
    parts, last = [], 0
    for m, add in zip(signs, (TEMPO_HOLD, TEMPO_LOOP, TEMPO_GLIDE)):
        parts.append(t[last:m.end(2)] + add)
        last = m.end(2)
    t = ''.join(parts) + t[last:]
    # F23 у кнопок переключателя
    t = rx(t, r'(<button type="button" class="ag-zc__sw"[^>]*>)([^<]*)(</button>)',
           lambda m: m.group(1) + '<span class="ag-zc__swin">' + m.group(2) + '</span>' + m.group(3), 4)
    t = rep(t, 'border-bottom:1px solid var(--rule);transition:background-color .35s ease;}',
            'border-bottom:1px solid var(--rule);transition:background-color .22s ease;}')
    # снятие подсветки — с задержкой; события указателя проверяются в момент события
    t = rep(t, '''    if (W.matchMedia && W.matchMedia("(hover:hover) and (pointer:fine)").matches) {
      Array.prototype.forEach.call(root.querySelectorAll(".ag-zc__row"), function (row) {
        row.addEventListener("mouseenter", function () {
          var r = row.getAttribute("data-r");
          if (ALLOWED[r] && W.innerWidth >= 1024) root.setAttribute("data-hl", r);
        });
        row.addEventListener("mouseleave", function () { root.removeAttribute("data-hl"); });
      });
    }
''', '''    /* v1.1.0: подсветка строки мышью ≥ 1024; снимается через 220 мс — переход по строке через колонки не мигает */
    var hlT = 0;
    function fineNow() { return !!(W.matchMedia && W.matchMedia("(min-width:1024px) and (hover:hover) and (pointer:fine)").matches); }
    Array.prototype.forEach.call(root.querySelectorAll(".ag-zc__row"), function (row) {
      row.addEventListener("pointerenter", function (e) {
        var r = row.getAttribute("data-r");
        if (e.pointerType !== "mouse" || !ALLOWED[r] || !fineNow()) return;
        W.clearTimeout(hlT);
        root.setAttribute("data-hl", r);
      });
      row.addEventListener("pointerleave", function (e) {
        if (e.pointerType !== "mouse") return;
        W.clearTimeout(hlT);
        hlT = W.setTimeout(function () { root.removeAttribute("data-hl"); }, 220);
      });
    });
''')
    t = add_js(t, C02_JS)
    t = focus3(t, R)
    css = press_css(R, [('ag-zc__sw', 'ag-zc__swin')])
    css += '''  /* «Три темпа на знаке»: в покое скрыто — знак как в v1.0.0 */
  %(r)s .ag-zc__tp{opacity:0;pointer-events:none;}
  %(r)s .ag-zc__sign .ag-zc__tray{stroke:var(--ochre);stroke-width:3.2;transform-box:view-box;transform-origin:14px 38px;transform:rotate(26.57deg);}
  %(r)s .ag-zc__sign .ag-zc__tc{fill:var(--ochre);stroke:none;opacity:.25;}
  %(r)s .ag-zc__trot{transform-box:view-box;transform-origin:36px 24px;}
  %(r)s .ag-zc__sign .ag-zc__trad{stroke:var(--ochre);stroke-width:2.2;}
  %(r)s .ag-zc__sign .ag-zc__tdot{fill:var(--accent);stroke:var(--ink);stroke-width:1.3;}
  %(r)s .ag-zc__tglide{transform-box:view-box;transform-origin:0 0;transform:translate(6px,30px);}
  /* автопоказ отмечает строку «Как работают» (ПК) или её кнопку (< 1024) */
  @media (min-width:1024px){
    %(r)s[data-cue="2"]:not([data-hl]) .ag-zc__row[data-r="2"]{background:var(--hl);}
    %(r)s[data-cue="2"]:not([data-hl]) .ag-zc__row[data-r="2"] dt{color:var(--ochre);}
  }
  @media (max-width:1023px){
    %(r)s[data-cue="2"] .ag-zc__sw[data-r="2"][aria-pressed="false"]{border-color:var(--ochre);color:var(--ink);}
  }
  @media (forced-colors:active){
    %(r)s .ag-zc__sign .ag-zc__tray,
    %(r)s .ag-zc__sign .ag-zc__trad{stroke:Highlight;}
    %(r)s .ag-zc__sign .ag-zc__tc,
    %(r)s .ag-zc__sign .ag-zc__tdot{fill:Highlight;stroke:CanvasText;}
  }
  @media print{
    %(r)s .ag-zc__tp{display:none !important;}
  }
''' % {'r': R}
    css += grain_css(R, 'ag-zc', 'ag-zc__wrap')
    t = add_css(t, css)
    t = touch(t)
    t = print_fix(t, R)
    save(2, t)


# ---------------------------------------------------------------- DIR08-03
def c03():
    t = load(3); R = '#ag-dir08-03'
    t = bump(t, 3, 'F23 — нажатие «−» и «+» (сжимается знак, кнопка неподвижна), фокус 3 px. Шкала глубины — как в v1.0.0;\n'
                   '     подсказка шкалы ждёт, пока на странице идёт показ другого блока (корень с data-cue — «Три темпа» DIR08-02),\n'
                   '     и сама на время показа ставит data-cue="hint" — два показа не идут в одном экране. Ведущая фишка страницы с v1.1.0 — в DIR08-02. Текст без изменений.')
    t = focus3(t, R)
    t = rep(t, '''        if (touched) return;
        var seq = [62, 55, 50, 55, 62, 69];
        seq.forEach(function (v, i) {
          hintTimers.push(W.setTimeout(function () { if (!touched) apply(v); }, 700 + i * 320));
        });
''', '''        if (touched) return;
        var waited = 0;
        (function go() {
          /* v1.1.0: пока на странице идёт показ другого блока (атрибут data-cue у его корня, DIR08-02) — ждём, до 4 с */
          var other = D.querySelector(".ag-scope[data-cue]");
          if (other && other !== root && waited < 4000) { waited += 250; hintTimers.push(W.setTimeout(go, 250)); return; }
          var seq = [62, 55, 50, 55, 62, 69];
          root.setAttribute("data-cue", "hint");
          seq.forEach(function (v, i) {
            hintTimers.push(W.setTimeout(function () { if (!touched) apply(v); }, 700 + i * 320));
          });
          hintTimers.push(W.setTimeout(function () { root.removeAttribute("data-cue"); }, 700 + 5 * 320 + 450));
        })();
''')
    t = rep(t, '''    function stopHint() {
      hintTimers.forEach(function (id) { W.clearTimeout(id); });
      hintTimers = [];
''', '''    function stopHint() {
      hintTimers.forEach(function (id) { W.clearTimeout(id); });
      hintTimers = [];
      root.removeAttribute("data-cue");
''')
    css = '''  /* F23 · нажатие «−» / «+»: круг неподвижен, сжимается знак */
  %(r)s .ag-zs__step>span{display:block;transition:transform 260ms %(eo)s;}
  %(r)s .ag-zs__step:active>span{transform:scale(.86);transition-duration:140ms;transition-timing-function:%(e)s;}
  @media (prefers-reduced-motion:reduce){
    %(r)s .ag-zs__step>span{transition:none;}
    %(r)s .ag-zs__step:active>span{transform:none;}
  }
''' % {'r': R, 'e': E, 'eo': EASE_OUT}
    t = add_css(t, css)
    t = touch(t)
    t = print_fix(t, R)
    save(3, t)


# ---------------------------------------------------------------- DIR08-04
def c04():
    t = load(4); R = '#ag-dir08-04'
    t = bump(t, 4, 'F10: плашка выбранной вкладки переезжает (ПК — ряд под панелью, крайние со скруглением 16 px; < 1024 — сетка\n'
                   '     2 × 2); точка и луч к панели (ПК) и жёлтая полоса (< 1024) появляются после плашки. Замер offset* при выборе,\n'
                   '     ResizeObserver на списке, смене раскладки — без проезда. ' + FREE_NOTE + '\n'
                   '     Фокус 3 px (и панели). Остальной текст без изменений.')
    t = rep(t, 'Первое групповое занятие бесплатное, дальше разовое стоит <span class="ag-nw">900&nbsp;₽.</span>',
            'Разовое занятие стоит <span class="ag-nw">900&nbsp;₽,</span> условия первого назовут там же.')
    t = focus3(t, R)
    t = rep(t, '#ag-dir08-04.ag-scope .ag-zl__panel:focus-visible{outline:2px', '#ag-dir08-04.ag-scope .ag-zl__panel:focus-visible{outline:3px')
    t = rep(t, '    box.classList.add("is-js");\n    wrap.classList.add("is-js");\n    list.hidden = false;\n',
            '    box.classList.add("is-js");\n    wrap.classList.add("is-js");\n    list.hidden = false;\n'
            '    /* v1.1.0 · F10: плашка выбранной вкладки — ::before у списка по --px/--py/--pw/--ph, нижние радиусы --pbl/--pbr */\n'
            '    var placed = false, jumpT = 0;\n'
            '    function place(jump) {\n'
            '      var i = current(), t = tabs[i];\n'
            '      if (!t) return;\n'
            '      if (jump) { W.clearTimeout(jumpT); list.classList.add("is-jump"); }\n'
            '      list.style.setProperty("--px", t.offsetLeft + "px");\n'
            '      list.style.setProperty("--py", t.offsetTop + "px");\n'
            '      list.style.setProperty("--pw", t.offsetWidth + "px");\n'
            '      list.style.setProperty("--ph", t.offsetHeight + "px");\n'
            '      list.style.setProperty("--pbl", i === 0 ? "16px" : "0px");\n'
            '      list.style.setProperty("--pbr", i === tabs.length - 1 ? "16px" : "0px");\n'
            '      list.classList.add("is-plate");\n'
            '      if (jump) jumpT = W.setTimeout(function () { list.classList.remove("is-jump"); }, 60);\n'
            '    }\n'
            '    if (W.ResizeObserver) new W.ResizeObserver(function () { place(true); }).observe(list);\n'
            '    else W.addEventListener("resize", function () { place(true); });\n'
            '    if (W.matchMedia) {\n'
            '      var lay = W.matchMedia("(min-width: 1024px)");\n'
            '      var relay = function () { place(true); };\n'
            '      if (lay.addEventListener) lay.addEventListener("change", relay); else if (lay.addListener) lay.addListener(relay);\n'
            '    }\n')
    t = rep(t, '      if (focus) tabs[i].focus();\n      if (was !== i && !reduce',
            '      if (focus) tabs[i].focus();\n      place(!placed);\n      placed = true;\n      if (was !== i && !reduce')
    css = '''  /* F10 · плашка выбранной вкладки едет; точка, луч и полоса — после неё */
  %(r)s .ag-zl__tabs{isolation:isolate;}
  %(r)s .ag-zl__tabs::before{
    content:"";position:absolute;left:0;top:0;z-index:-1;width:var(--pw,0px);height:var(--ph,0px);
    transform:translate(var(--px,0px),var(--py,0px));background:var(--tab-on);pointer-events:none;opacity:0;
    border-radius:0 0 var(--pbr,0px) var(--pbl,0px);
    transition:transform .32s %(e)s,width .32s %(e)s,height .32s %(e)s,border-radius .32s %(e)s;
  }
  %(r)s .ag-zl__tabs.is-plate::before{opacity:1;}
  %(r)s .ag-zl__tabs.is-jump::before{transition:none;}
  %(r)s .ag-zl__tabs.is-plate .ag-zl__tab[aria-selected="true"]{background:transparent;}
  %(r)s .ag-zl__tab[aria-selected="true"]::before{transition-delay:.22s;}
  %(r)s .ag-zl__tab[aria-selected="true"]::after{transition-delay:.4s;}
  @media (max-width:1023px){
    %(r)s .ag-zl__tabs::before{border:1px solid rgba(255,196,0,.5);border-radius:10px;}
    %(r)s .ag-zl__tabs.is-plate .ag-zl__tab[aria-selected="true"]{border-color:transparent;}
  }
  @media (forced-colors:active){
    %(r)s .ag-zl__tabs::before{display:none;}
  }
''' % {'r': R, 'e': E}
    t = add_css(t, css)
    t = touch(t)
    t = print_fix(t, R)
    save(4, t)


# ---------------------------------------------------------------- DIR08-05
def c05():
    t = load(5); R = '#ag-dir08-05'
    t = bump(t, 5, 'Фокус 3 px. Состав, текст и раскладка — как в v1.0.0 (второго кадра тренера нет — F12 не берётся).')
    t = focus3(t, R)
    t = print_fix(t, R)
    save(5, t)


# ---------------------------------------------------------------- DIR08-06
def c06():
    t = load(6); R = '#ag-dir08-06'
    t = bump(t, 6, FREE_NOTE + '\n'
                   '     Первое предложение «Сбоку» заменено, остальное дословно. F29 зерно бумаги (≥ 640 px), фокус 3 px. Прайс — как есть.')
    t = rep(t, '<b>Первое групповое занятие — бесплатно.</b>', '<b>Условия первого занятия — при записи.</b>')
    t = focus3(t, R)
    t = add_css(t, grain_css(R, 'ag-zp', 'ag-zp__wrap'))
    t = print_fix(t, R)
    save(6, t)


# ---------------------------------------------------------------- DIR08-07
def c07():
    t = load(7); R = '#ag-dir08-07'
    t = bump(t, 7, 'F22: ответ раскрывается плавно (::details-content + interpolate-size, прогрессивно; overflow-clip-margin);\n'
                   '     «Раскрыть все» — без перехода (флаг снимается таймером: toggle приходит асинхронно); пересчёт триггеров\n'
                   '     соседних блоков по окончании перехода. Печать — ответы видны. F23 — «Раскрыть все» и «Спросить\n'
                   '     расписание», фокус 3 px. ' + FREE_NOTE + '\n'
                   '     Остальной текст без изменений (FAQPage в HEAD v1.1 = этот блок).')
    t = rep(t, 'это <span class="ag-nw">500 ₽</span> за тренировку. Первое групповое занятие — бесплатно.</p>',
            'это <span class="ag-nw">500 ₽</span> за тренировку. Условия первого занятия — при записи.</p>')
    t = wrap(t, 'button', 'ag-zq__all', 'ag-zq__ain')
    t = wrap(t, 'a', 'ag-zq__btn', 'ag-zq__bin')
    t = focus3(t, R)
    css = press_css(R, [('ag-zq__all', 'ag-zq__ain'), ('ag-zq__btn', 'ag-zq__bin')])
    css += '''  /* F22 · плавное раскрытие ответа (Chromium 131+); иначе — мгновенно, как было */
  @supports (interpolate-size:allow-keywords) and selector(::details-content){
    %(r)s .ag-zq{interpolate-size:allow-keywords;}
    %(r)s :is(.ag-zq__card,.ag-zq__item)::details-content{
      height:0;overflow:clip;overflow-clip-margin:8px;
      transition:height .32s %(e)s,content-visibility .32s allow-discrete;
    }
    %(r)s :is(.ag-zq__card,.ag-zq__item)[open]::details-content{height:auto;}
    %(r)s.is-bulk .ag-zq__item::details-content{transition:none;}
    @media (prefers-reduced-motion:reduce){
      %(r)s :is(.ag-zq__card,.ag-zq__item)::details-content{transition:none;}
    }
  }
  @media print{
    %(r)s :is(.ag-zq__card,.ag-zq__item)::details-content{height:auto !important;content-visibility:visible !important;}
    %(r)s .ag-zq__a{display:block !important;}
  }
''' % {'r': R, 'e': E}
    t = add_css(t, css)
    t = rx(t, r'(      busy = true;\n)(.*?)(      busy = false;\n)',
           lambda m: m.group(1) + '      root.classList.add("is-bulk");\n' + m.group(2)
           + '      W.setTimeout(function () { busy = false; root.classList.remove("is-bulk"); }, 80);\n')
    t = rep(t, '    cards.forEach(function (d) { d.addEventListener("toggle", refresh); });\n',
            '    cards.forEach(function (d) { d.addEventListener("toggle", refresh); });\n'
            '    /* v1.1.0: высота ответа меняется переходом — пересчитать позиции анимаций ниже по окончании */\n'
            '    root.addEventListener("transitionend", function (e) {\n'
            '      if (e.propertyName === "height" && e.pseudoElement === "::details-content") refresh();\n'
            '    });\n')
    t = rep(t, '    btn.hidden = false;\n', '    btn.hidden = false;\n' + TOUCH)
    save(7, t)


# ---------------------------------------------------------------- DIR08-08
def c08():
    t = load(8); R = '#ag-dir08-08'
    t = bump(t, 8, 'Магнит снят; параллакс букв «РАСТЯЖКА» ≤ 0,08 (0,01 · 0,03 · 0,055 · 0,08 · 0,08 · 0,055 · 0,03 · 0,01 —\n'
                   '     дуга сохранена); F23 — нажатие обеих кнопок, фокус 3 px. Текст без изменений.')
    t = rx(t, r' data-ag-magnetic="0\.\d+"', '')
    vals = iter(['0.01', '0.03', '0.055', '0.08', '0.08', '0.055', '0.03', '0.01'])
    t = rx(t, r'(<span class="ag-zw__l" data-ag-anim="parallax" data-ag-parallax=")0\.\d+(")',
           lambda m: m.group(1) + next(vals) + m.group(2), 8)
    t = wrap(t, 'a', 'ag-btn ag-btn--primary', 'ag-btn__in')
    t = wrap(t, 'a', 'ag-btn ag-btn--ghost', 'ag-btn__in')
    t = focus3(t, R)
    t = add_css(t, press_css(R, [('ag-btn', 'ag-btn__in')]))
    t = touch(t)
    t = print_fix(t, R)
    save(8, t)


if __name__ == '__main__':
    for f in (c01, c02, c03, c04, c05, c06, c07, c08):
        f()
