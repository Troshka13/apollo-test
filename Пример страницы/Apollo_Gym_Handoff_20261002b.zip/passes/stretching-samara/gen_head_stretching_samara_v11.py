# HEAD /stretching-samara v1.1: FAQPage, ответ «Сколько стоит растяжка?» = DIR08-07 v1.1.0 (факт 5.1/5.13); остальное — как в HEAD 27.09
import re, json, html
old=open('HEAD_stretching-samara.html',encoding='utf-8').read()
g=json.loads(re.search(r'<script type="application/ld\+json">(.*?)</script>',old,re.S).group(1))
b=open('out/DIR08-07_v1.1.0.html',encoding='utf-8').read()
items=re.findall(r'<span class="ag-zq__qt">(.*?)</span>.*?<div class="ag-zq__a">(.*?)</div>\s*</details>',b,re.S)
def clean(s):
    s=re.sub(r'<a class="ag-zq__btn".*?</a>','',s,flags=re.S)  # кнопка «Спросить расписание» — не текст ответа
    s=re.sub(r'<[^>]+>','',s); s=html.unescape(s).replace('\xa0',' ')
    return re.sub(r'\s+',' ',s).strip()
QA={clean(q):clean(a) for q,a in items}
assert len(QA)==10, len(QA)
Q='Сколько стоит растяжка?'
n=0
for node in g['@graph']:
    if node.get('@type')=='FAQPage':
        for x in node['mainEntity']:
            name=clean(x['name']); assert name in QA, name
            A=x['acceptedAnswer']['text']
            if name==Q:
                assert QA[name]==A.replace('Первое групповое занятие — бесплатно.','Условия первого занятия — при записи.') and QA[name]!=A, (A,QA[name])
                x['acceptedAnswer']['text']=QA[name]; n+=1
            else:
                assert clean(A)==QA[name], name
assert n==1
s=json.dumps(g,ensure_ascii=False,indent=1)
assert 'бесплатн' not in s.lower()
com=('<!-- Apollo Gym · /stretching-samara · HEAD v1.1 · 02.10.2026 · Tilda → Настройки страницы → Дополнительно → «HTML-код для вставки внутрь HEAD». '
     'Тестовая копия с адресами apolloboxing.tilda.ws. Заменяет HEAD от 27.09 целиком; старый JSON-LD удалить. '
     'v1.1: FAQPage, ответ «Сколько стоит растяжка?» = DIR08-07 v1.1.0 (факт 5.1/5.13: бесплатное первое не подтверждено); остальное без изменений. -->\n')
out=com+'<script type="application/ld+json">\n'+s+'\n</script>\n'
open('out/HEAD_stretching-samara_v1.1.html','w',encoding='utf-8').write(out)
print('ok', len(out))
