// /functional-training (DIR06) · проверки прохода «дизайн, движение и фишка» (PROMPT_DIR06_DESIGN_MOTION_v2)
const {open,settle}=require('./lib');const fs=require('fs'),path=require('path');
const AFTER='file://'+path.resolve('after.html'), BEFORE='file://'+path.resolve('before.html');
const out={};const log=(g,ok,msg)=>{const s=(ok?"pass ":"FAIL ")+msg;(out[g]=out[g]||[]).push(s);console.log(g+" "+s);};
const G=process.env.G||'LTCMFA';
async function txt(url){const {browser,page}=await open({reduce:true});await page.goto(url);await page.waitForTimeout(2600);
  const r=await page.evaluate(()=>{const o={};document.querySelectorAll('.ag-scope').forEach(r=>{const c=r.cloneNode(true);c.querySelectorAll('style,script,.ag-vh,.ag-uz__tabs,.ag-uz__panel:not(:first-child)').forEach(x=>x.remove());o[r.id]=c.textContent.replace(/\s+/g,' ').trim();});return o;});await browser.close();return r;}
async function links(url){const {browser,page}=await open({reduce:true});await page.goto(url);await page.waitForTimeout(400);
  const r=await page.evaluate(()=>[...document.querySelectorAll('.ag-scope a[href]')].map(a=>a.closest('.ag-scope').id+' '+a.getAttribute('href')));await browser.close();return r;}
const Z=`(()=>{const r=document.getElementById('ag-dir06-04');const tabs=[...r.querySelectorAll('.ag-uz__tab')];const ps=[...r.querySelectorAll('.ag-uz__panel')];
  const vis=ps.map(p=>getComputedStyle(p).visibility==='visible'&&parseFloat(getComputedStyle(p).opacity)>0.99?1:0).join('');
  const sel=tabs.findIndex(t=>t.getAttribute('aria-selected')==='true');const ind=r.querySelector('.ag-uz__ind').getBoundingClientRect();const t=tabs[sel].getBoundingClientRect();
  const on=ps.find(p=>p.classList.contains('is-on'));
  return {vis,sel,zone:r.getAttribute('data-ag-zone'),ti:tabs.map(t=>t.getAttribute('tabindex')).join(','),dx:Math.round(ind.left-t.left),dw:Math.round(ind.width-t.width),dy:Math.round(ind.top-t.top),
    src:on&&on.querySelector('img').getAttribute('src').replace(/^.*\\//,''),cap:on&&on.querySelector('figcaption').textContent.trim(),alt:on&&on.querySelector('img').alt,
    fa:document.activeElement&&document.activeElement.id,mh:Math.round(r.querySelector('.ag-uz__panels').getBoundingClientRect().height),an:r.getAnimations({subtree:true}).length};})()`;
const ZEXP=[['57-1024x683.jpg','Зона со свободными весами'],['51-1024x683.jpg','Общий вид зала'],['22-1024x683.jpg','Отдельная сайкл-студия']];
(async()=>{
 if(G.includes('L')) for(const reduce of [false,true]) for(const fontsOff of [false,true]) for(const w of [320,360,390,768,1024,1440,1920]){
   const {browser,page}=await open({w,h:w<700?800:900,reduce,mobile:w<700,touch:w<700});
   if(fontsOff) await page.route('**/fonts.googleapis.com/**',r=>r.abort());
   await page.goto(AFTER);await settle(page);
   const r=await page.evaluate(()=>({ov:document.documentElement.scrollWidth>document.documentElement.clientWidth,h:document.body.scrollHeight}));
   log('L',!r.ov,`${w}px reduce=${reduce} fontsOff=${fontsOff} overflowX=${r.ov} h=${r.h}`);await browser.close();
 }
 if(G.includes('T')){const tb=await txt(BEFORE),ta=await txt(AFTER);
  const EXC={'ag-dir06-01':[['первое групповое занятие для взрослых','первое групповое занятие']],
   'ag-dir06-06':[['Первое групповое занятие для взрослых — бесплатно.','Первое групповое занятие — бесплатно.']],
   'ag-dir06-07':[['Первое групповое занятие для взрослых — бесплатно.','Первое групповое занятие — бесплатно.']]};
  for(const id of Object.keys(tb)){let a=ta[id];(EXC[id]||[]).forEach(([n,o])=>{a=a.split(n).join(o);});a=a.replace(/\s+/g,' ').trim();let i=0;while(i<tb[id].length&&tb[id][i]===a[i])i++;
   log('T',a===tb[id],id+(a===tb[id]?' текст совпадает'+(EXC[id]?' (кроме правки «'+EXC[id][0][0].slice(0,50)+'»)':''):' РАЗНИЦА '+JSON.stringify(tb[id].slice(i-40,i+40))+' → '+JSON.stringify(a.slice(i-40,i+40))));}
  const html=fs.readFileSync('after.html','utf8').replace(/<!--[\s\S]*?-->/g,'');
  const h01=fs.readFileSync('out/DIR06-01_v1.1.0.html','utf8').replace(/<!--[\s\S]*?-->/g,'');
  const fr=/48-1024x683\.jpg" width="1024" height="683" alt="Зал Apollo NoFitness на Молодогвардейской, 56"/.test(h01)&&!/22-1024x683/.test(h01)&&!/src="[^"]*\/50-1024x683/.test(html);
  log('T',fr,`кадры: 01 — 48 (общий вид зала), alt по кадру; сайкл-студия (22) в 01 снята; рама (50) не стоит без подтверждения: ${fr}`);
  const caps=[...fs.readFileSync('out/DIR06-04_v1.1.0.html','utf8').matchAll(/<figcaption class="ag-uz__label">[\s\S]*?<span>([^<]*)<\/span><\/figcaption>/g)].map(m=>m[1]);
  log('T',JSON.stringify(caps)===JSON.stringify(ZEXP.map(z=>z[1])),`04: подписи кадров по кадрам — ${caps.join(' / ')} (новые: «Общий вид зала», «Отдельная сайкл-студия»; вкладки «Свободные веса / Весь зал / Сайкл-студия» — закон 10)`);}
 if(G.includes('C')){const lb=await links(BEFORE),la=await links(AFTER);const add=la.filter(x=>!lb.includes(x)),rem=lb.filter(x=>!la.includes(x));
  log('C',rem.length===0&&add.length===0,`ссылки +${add.length} −${rem.length}`);}
 if(G.includes('M')){
  for(const mode of [{name:'js off',js:false},{name:'reduce',reduce:true},{name:'cdn fail',cdn:'fail'},{name:'cdn hang',cdn:'hang'}]){
   const {browser,page}=await open({w:390,h:800,mobile:true,...mode});await page.goto(AFTER,{waitUntil:'domcontentloaded'});await page.waitForTimeout(2700);
   if(mode.js!==false) for(let y=0;y<9000;y+=600){await page.evaluate(y=>scrollTo(0,y),y);await page.waitForTimeout(40);}
   const r=await page.evaluate(()=>{const bad=[];document.querySelectorAll('.ag-scope :is(p,h1,h2,h3,a,li,dt,dd,summary,td,th,figcaption)').forEach(el=>{if(el.closest('[aria-hidden="true"],[hidden],dialog'))return;if(el.closest('.ag-uz__panel:not(.is-on)')&&el.closest('.is-js'))return;let n=el,op=1;while(n&&n.nodeType===1){op*=parseFloat(getComputedStyle(n).opacity);n=n.parentElement;}if(getComputedStyle(el).display==='none')return;if(getComputedStyle(el).visibility==='hidden')return;if(op<0.99&&el.textContent.trim())bad.push(el.textContent.trim().slice(0,30));});
     const r4=document.getElementById('ag-dir06-04');return {bad,m:document.documentElement.getAttribute('data-ag-motion'),tabs:getComputedStyle(r4.querySelector('.ag-uz__tabs')).display,
       panels:[...r4.querySelectorAll('.ag-uz__panel')].filter(c=>getComputedStyle(c).visibility!=='hidden'&&c.getBoundingClientRect().height>50).length,
       dirpanels:[...document.querySelectorAll('#ag-dir06-03 [role=tabpanel], #ag-dir06-03 .ag-uw__panel')].filter(c=>getComputedStyle(c).visibility!=='hidden'&&getComputedStyle(c).display!=='none').length};});
   const exp=mode.js===false?{panels:3,tabs:'none'}:{panels:1,tabs:'grid'};
   log('M',r.bad.length===0&&r.panels===exp.panels&&r.tabs===exp.tabs,`${mode.name}: motion=${r.m} скрытых текстов ${r.bad.length} ${r.bad.slice(0,3).join('|')}; 04: вкладки ${r.tabs}, видимых кадров ${r.panels}; 03: видимых панелей ${r.dirpanels}`);
   if(mode.js===false) await (await page.$('#ag-dir06-04 .ag-uz__media')).screenshot({path:'shots/m04_nojs_390.png'});
   await browser.close();}
  const {browser,page}=await open({w:1440});await page.goto(AFTER);await settle(page);
  const r=await page.evaluate(()=>{const o={};document.querySelectorAll('.ag-scope').forEach(root=>{const all=root.querySelectorAll('[data-ag-anim]');o[root.id]=[all.length,[...all].filter(e=>!e.hasAttribute('data-ag-done')).length];});return o;});
  for(const [id,[n,left]] of Object.entries(r)) log('M',left===0,`motion on: ${id} анимаций ${n}, не отсканировано ${left}`);await browser.close();}

 if(G.includes('F')){
  // ---- 04 «Зоны зала»
  for(const w of [1920,1440,1024,1023,768,600,390,360,320]){const {browser,page,errs}=await open({w,h:w<700?844:900,mobile:w<700,touch:w<700});await page.goto(AFTER);await settle(page);
   await page.evaluate(()=>{window.__mut=0;new MutationObserver(m=>{m.forEach(x=>{if(x.type==='childList')window.__mut++;});}).observe(document.getElementById('ag-dir06-04'),{childList:true,subtree:true});});
   await page.evaluate(()=>{const s=document.querySelector('#ag-dir06-04 .ag-uz__media').getBoundingClientRect();scrollTo(0,scrollY+s.top-80);});await page.waitForTimeout(900);
   const z0=await page.evaluate(Z);const res=[];let ok=z0.vis==='100'&&z0.sel===0&&Math.abs(z0.dx)<=1&&Math.abs(z0.dw)<=1&&z0.src===ZEXP[0][0];let mid=null;const hs=[z0.mh];
   for(const i of [2,1,0,2]){const t=(await page.$$('#ag-dir06-04 .ag-uz__tab'))[i];if(w<700){const b=await t.boundingBox();await page.touchscreen.tap(b.x+b.width/2,b.y+b.height/2);}else await t.click();
    if(i===2&&!mid){await page.waitForTimeout(110);mid=await page.evaluate(Z);}await page.waitForTimeout(450);const z=await page.evaluate(Z);hs.push(z.mh);
    const good=z.vis==='001'.split('').map((_,k)=>k===i?1:0).join('')&&z.sel===i&&z.zone===String(i)&&Math.abs(z.dx)<=1&&Math.abs(z.dw)<=1&&Math.abs(z.dy)<=1&&z.src===ZEXP[i][0]&&z.cap===ZEXP[i][1]&&z.ti===[0,1,2].map(k=>k===i?'0':'-1').join(',');
    if(!good)ok=false;res.push(i+(good?'':'✗'+JSON.stringify(z)));}
   const midok=mid&&Math.abs(mid.dx)>2;const same=hs.every(h=>h===hs[0]);
   const mut=await page.evaluate(()=>window.__mut);
   const sw=await page.evaluate(()=>document.documentElement.scrollWidth>document.documentElement.clientWidth);
   if([1440,390,320].includes(w)) await (await page.$('#ag-dir06-04 .ag-uz__media')).screenshot({path:`shots/f04_${w}.png`});
   log('F',ok&&midok&&same&&mut===0&&!sw&&errs.length===0,`04, ${w}px: начально «Свободные веса»; ${w<700?'касание':'клик'} ${res.join(' ')} — видна одна панель, кадр и подпись по зоне, подложка под вкладкой (на 110 мс — в пути, dx ${mid&&mid.dx}); высота рамки постоянна (${[...new Set(hs)].join('/')}); вставок узлов ${mut}; ошибок ${errs.length}`);
   await browser.close();}
  // клавиатура
  {const {browser,page}=await open({w:1440,h:900});await page.goto(AFTER);await settle(page);
   await page.evaluate(()=>document.querySelector('#ag-dir06-04 .ag-uz__more').focus());
   const seq=[];
   // Tab из ссылки карточки ведёт во вкладки (кадр справа идёт после карточки)
   await page.keyboard.press('Tab');seq.push(await page.evaluate(()=>document.activeElement.id));
   for(const k of ['ArrowRight','ArrowRight','ArrowRight','ArrowLeft','End','Home','ArrowDown','ArrowUp']){await page.keyboard.press(k);await page.waitForTimeout(60);const z=await page.evaluate(Z);seq.push(k+':'+z.sel+(z.fa===`ag-dir06-04-z${z.sel+1}`?'':'✗'));}
   await page.keyboard.press('Tab');const fp=await page.evaluate(()=>document.activeElement.id);
   const oc=await page.evaluate(()=>getComputedStyle(document.activeElement).outlineWidth);
   await page.keyboard.press('Tab');const nx=await page.evaluate(()=>document.activeElement.closest('.ag-scope')&&document.activeElement.closest('.ag-scope').id);
   const exp=['ag-dir06-04-z1','ArrowRight:1','ArrowRight:2','ArrowRight:0','ArrowLeft:2','End:2','Home:0','ArrowDown:1','ArrowUp:0'];
   log('F',JSON.stringify(seq)===JSON.stringify(exp)&&fp==='ag-dir06-04-zp1'&&oc==='3px'&&nx!=='ag-dir06-04',`04, клавиатура: ${seq.join(' ')}; Tab → панель ${fp} (фокус ${oc}) → дальше из блока (${nx}); невыбранные вкладки вне Tab`);
   // быстрые клики
   const tabs=await page.$$('#ag-dir06-04 .ag-uz__tab');for(const i of [1,2,0,2,1,0,1,2,1]){await tabs[i].click({delay:0});await page.waitForTimeout(25);}
   await page.waitForTimeout(600);const z=await page.evaluate(Z);
   log('F',z.sel===1&&z.vis==='010'&&z.an===0&&Math.abs(z.dx)<=1,`04: девять быстрых кликов — итог «Весь зал», одна панель, анимаций через 0,6 с: ${z.an}`);
   // reduce на лету
   await page.emulateMedia({reducedMotion:'reduce'});await page.waitForTimeout(120);await tabs[2].click();await page.waitForTimeout(40);const zr=await page.evaluate(Z);
   log('F',zr.vis==='001'&&Math.abs(zr.dx)<=1,`04, reduce на лету: кадр и подложка сразу (${zr.vis}, sel ${zr.sel}, dx ${zr.dx})`);
   // смена раскладки 1024 → 1023: подложка встаёт без проезда
   await page.emulateMedia({reducedMotion:'no-preference'});await page.setViewportSize({width:1023,height:900});await page.waitForTimeout(60);const zj=await page.evaluate(Z);await page.waitForTimeout(400);const zj2=await page.evaluate(Z);
   const pos=await page.evaluate(()=>getComputedStyle(document.querySelector('#ag-dir06-04 .ag-uz__tabs')).position);
   log('F',Math.abs(zj.dx)<=1&&Math.abs(zj2.dx)<=1&&pos==='relative',`04: 1440 → 1023 — ряд над кадром (${pos}), подложка сразу на месте (dx ${zj.dx})`);
   // печать
   await page.setViewportSize({width:1440,height:900});await page.emulateMedia({media:'print'});await page.waitForTimeout(200);
   const pm=await page.evaluate(()=>getComputedStyle(document.querySelector('#ag-dir06-04 .ag-uz__media')).display);
   log('F',pm==='none',`04, печать: кадр и вкладки скрыты, как в v1.0.0 (${pm})`);
   await browser.close();}
  {const {browser,page}=await open({w:1440,h:900});await page.emulateMedia({forcedColors:'active'});await page.goto(AFTER);await settle(page);
   const r=await page.evaluate(()=>{const s=document.querySelector('#ag-dir06-04 .ag-uz__tab[aria-selected="true"]');return [getComputedStyle(document.querySelector('#ag-dir06-04 .ag-uz__ind')).display,getComputedStyle(s).outlineStyle];});
   await (await page.$('#ag-dir06-04 .ag-uz__media')).screenshot({path:'shots/forced_04.png'});
   log('F',r[0]==='none'&&r[1]==='solid',`04, forced: подложки нет, выбранная вкладка обведена (${r.join('/')})`);await browser.close();}
  // 01 → 04
  {const {browser,page}=await open({w:390,h:844,mobile:true,touch:true});await page.goto(AFTER);await settle(page);
   await page.click('#ag-dir06-01 a.ag-uh__fact[href="#ag-dir06-04"]');await page.waitForTimeout(1200);
   const r=await page.evaluate(()=>{const e=document.getElementById('ag-dir06-04');const b=e.querySelector('.ag-uz__tabs').getBoundingClientRect();return {top:Math.round(e.getBoundingClientRect().top),sm:parseFloat(getComputedStyle(e).scrollMarginTop)||0,tabs:b.top>=0&&b.bottom<=innerHeight};});
   log('F',Math.abs(r.top-r.sm)<=2&&r.tabs,`01 → «1 зал с зоной свободных весов» ведёт к 04 (top ${r.top} = scroll-margin ${r.sm}, как в v1.0.0), вкладки зон на экране`);await browser.close();}
  // ---- 07 F22 + печать + FAQPage
  {const {browser,page}=await open({w:1440,h:900});await page.goto(AFTER);await settle(page);
   await page.evaluate(()=>document.getElementById('ag-dir06-07').scrollIntoView());await page.waitForTimeout(400);
   const H=n=>page.evaluate(n=>Math.round(document.querySelectorAll('#ag-dir06-07 .ag-uq__item')[n].getBoundingClientRect().height),n);
   const h0=await H(1);await page.click('#ag-dir06-07 .ag-uq__item >> nth=1 >> summary');await page.waitForTimeout(90);const hm=await H(1);await page.waitForTimeout(450);const h1=await H(1);
   const HA=()=>page.evaluate(()=>[...document.querySelectorAll('#ag-dir06-07 .ag-uq__item')].map(d=>Math.round(d.getBoundingClientRect().height)).join(','));
   await page.click('#ag-dir06-07 .ag-uq__all');await page.waitForTimeout(40);const b1=await HA();await page.waitForTimeout(500);const b2=await HA();
   const st=await page.evaluate(()=>({open:[...document.querySelectorAll('#ag-dir06-07 .ag-uq__item')].filter(d=>d.open).length,n:document.querySelectorAll('#ag-dir06-07 .ag-uq__item').length,bulk:document.getElementById('ag-dir06-07').classList.contains('is-bulk'),sticky:getComputedStyle(document.querySelector('#ag-dir06-07 .ag-uq__side')).position,lbl:document.querySelector('#ag-dir06-07 .ag-uq__all').getAttribute('aria-expanded')}));
   log('F',h0<hm&&hm<h1&&b1===b2&&st.open===st.n&&!st.bulk&&st.sticky==='sticky'&&st.lbl==='true',`07: ответ раскрывается плавно (${h0} → ${hm} на 90 мс → ${h1}), «Раскрыть все» — все ${st.open} сразу без перехода, кнопка «Свернуть» (${st.lbl}); колонка прилипает (${st.sticky})`);
   await page.click('#ag-dir06-07 .ag-uq__all');await page.waitForTimeout(400);
   const cl=await page.evaluate(()=>[...document.querySelectorAll('#ag-dir06-07 .ag-uq__item')].filter(d=>d.open).length);
   await page.click('#ag-dir06-07 .ag-uq__item >> nth=3 >> summary');await page.waitForTimeout(450);
   const one=await page.evaluate(()=>document.querySelector('#ag-dir06-07 .ag-uq__all').getAttribute('aria-expanded'));
   await page.click('#ag-dir06-07 .ag-uq__item >> nth=3 >> summary');await page.waitForTimeout(450);
   log('F',cl===0&&one==='false',`07: «Свернуть» закрывает все (${cl}); после одного ответа кнопка снова «Раскрыть все» (${one})`);
   await page.emulateMedia({media:'print'});await page.waitForTimeout(200);
   const pr=await page.evaluate(()=>[...document.querySelectorAll('#ag-dir06-07 .ag-uq__a')].filter(a=>a.getBoundingClientRect().height>10).length);
   log('F',pr===10,`07, печать: видно ответов ${pr}/10 (все свёрнуты)`);await page.emulateMedia({media:'screen'});
   const head=JSON.parse(fs.readFileSync('out/HEAD_functional-training_v1.1.html','utf8').match(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/)[1]);
   const oldh=JSON.parse(fs.readFileSync('/home/claude/work/head_test/HEAD_functional-training.html','utf8').match(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/)[1]);
   const fq=h=>h['@graph'].find(n=>n['@type']==='FAQPage').mainEntity;
   const QA=()=>page.evaluate(()=>[...document.querySelectorAll('#ag-dir06-07 .ag-uq__item')].map(d=>{const a=d.querySelector('.ag-uq__a').cloneNode(true);a.querySelectorAll('.ag-uq__btn').forEach(x=>x.remove());return [d.querySelector('.ag-uq__qt').textContent.replace(/\s+/g,' ').trim(),a.textContent.replace(/\s+/g,' ').trim()];}));
   const qa=await QA();await page.goto(BEFORE);await settle(page);const qb=await QA();
   const dif=(q,f)=>q.map(([n,a],i)=>f[i]&&(f[i].name!==n||f[i].acceptedAnswer.text.replace(/<[^>]+>/g,'').replace(/\s+/g,' ').trim()!==a)?i:null).filter(x=>x!==null);
   const da=dif(qa,fq(head)),db=dif(qb,fq(oldh));const ix=qa.findIndex(x=>x[0]==='Сколько стоит?');
   log('F',da.length===0&&db.length===0&&fq(head).length===qa.length&&fq(head)[ix].acceptedAnswer.text===qa[ix][1]&&qa[ix][1].includes('для взрослых — бесплатно'),`FAQPage HEAD v1.1 = 07: все ${qa.length} вопросов и ответов дословно; «Сколько стоит?» (№ ${ix+1}) — «для взрослых»; у стоящего HEAD с v1.0.0 тоже совпадало [${db.join(',')}]`);
   await browser.close();}
  {const {browser,page}=await open({w:390,h:844,mobile:true,touch:true});await page.goto(AFTER);await settle(page);
   await page.evaluate(()=>document.getElementById('ag-dir06-07').scrollIntoView());await page.waitForTimeout(400);
   const it=await page.$$('#ag-dir06-07 .ag-uq__item summary');await it[7].evaluate(e=>e.scrollIntoView({block:'center'}));await page.waitForTimeout(300);const b=await it[7].boundingBox();await page.touchscreen.tap(b.x+20,b.y+b.height/2);await page.waitForTimeout(500);
   const r=await page.evaluate(()=>{const d=document.querySelectorAll('#ag-dir06-07 .ag-uq__item')[7];const a=d.querySelector('.ag-uq__a').getBoundingClientRect();return {open:d.open,h:Math.round(a.height),t:d.querySelector('.ag-uq__a').textContent.includes('для взрослых')};});
   const sw=await page.evaluate(()=>document.documentElement.scrollWidth>document.documentElement.clientWidth);
   log('F',r.open&&r.h>20&&r.t&&!sw,`07, 390: касание «Сколько стоит?» — ответ открыт (${r.h} px), «для взрослых» на месте (${JSON.stringify(r)} sw ${sw})`);await browser.close();}
  // ---- магниты, параллакс, F23, зерно
  {const {browser,page}=await open({w:1440,h:900});await page.goto(AFTER);await settle(page);
   const mag=await page.$$eval('[data-ag-magnetic]',x=>x.length);const par=await page.$$eval('[data-ag-parallax]',x=>x.map(e=>e.getAttribute('data-ag-parallax')));
   log('F',mag===0&&par.every(v=>parseFloat(v)<=0.08),`магнитных кнопок: ${mag}; параллакс ${par.join(', ')} (≤ 0.08)`);
   const res=[];
   for(const [sel,inn] of [['#ag-dir06-01 .ag-btn--primary','.ag-btn__in'],['#ag-dir06-05 .ag-btn--ghost','.ag-btn__in'],['#ag-dir06-06 .ag-btn--ink','.ag-btn__in'],['#ag-dir06-07 .ag-uq__all','.ag-uq__ain'],['#ag-dir06-08 .ag-btn--primary','.ag-btn__in'],['#ag-dir06-08 .ag-btn--ghost','.ag-btn__in']]){
    const el=await page.$(sel);if(!el){res.push(sel+': нет');continue;}await el.scrollIntoViewIfNeeded();await page.waitForTimeout(250);const b0=await el.boundingBox();
    await page.evaluate(s=>document.querySelector(s).addEventListener('click',e=>e.preventDefault(),{once:true}),sel);
    await page.mouse.move(b0.x+b0.width/2,b0.y+b0.height/2);await page.mouse.down();await page.waitForTimeout(220);
    const t=await page.$eval(sel+' '+inn,e=>getComputedStyle(e).transform);const b1=await el.boundingBox();await page.mouse.up();await page.waitForTimeout(80);
    res.push([sel.slice(8,12)+sel.slice(13).split(' ')[0].replace(/^\./,''),/matrix\(0\.98/.test(t)&&Math.abs(b1.x-b0.x)<0.5]);}
   const yb=await page.evaluate(()=>!!document.querySelector('#ag-dir06-07 .ag-uq__btn .ag-uq__bin'));
   log('F',res.every(r=>Array.isArray(r)&&r[1]===true)&&yb,`F23 нажатие: ${res.map(r=>Array.isArray(r)?r.join(':'):r).join(' ')}; «Спросить расписание» обёрнута: ${yb}`);
   const gr=await page.evaluate(()=>['#ag-dir06-04 .ag-uz','#ag-dir06-06 .ag-up'].map(s=>/svg/.test(getComputedStyle(document.querySelector(s),'::before').backgroundImage)));
   log('F',gr.every(Boolean),`зерно бумаги на ПК: 04 ${gr[0]}, 06 ${gr[1]}`);
   await page.mouse.click(5,5);await page.keyboard.press('Shift');const fo=[];for(const sel of ['#ag-dir06-02 a','#ag-dir06-03 [role=tab]','#ag-dir06-05 a','#ag-dir06-08 a']){const ok=await page.evaluate(s=>{const e=document.querySelector(s);if(!e)return 'нет';e.focus();return getComputedStyle(e).outlineWidth;},sel);fo.push(sel.slice(8,12)+':'+ok);}
   log('F',fo.every(x=>/3px$/.test(x)),`фокус 3 px: ${fo.join(' ')}`);
   await browser.close();}
  {const {browser,page}=await open({w:390,h:844,mobile:true,touch:true});await page.goto(AFTER);await settle(page);
   const gr=await page.evaluate(()=>['#ag-dir06-04 .ag-uz','#ag-dir06-06 .ag-up'].map(s=>/svg/.test(getComputedStyle(document.querySelector(s),'::before').backgroundImage)));
   log('F',!gr[0]&&!gr[1],`телефон: зерна нет (04 ${gr[0]}, 06 ${gr[1]})`);await browser.close();}
 }

 if(G.includes('A')){const axeSrc=fs.readFileSync(require.resolve('axe-core/axe.min.js'),'utf8');
  for(const m of [{w:1440},{w:1024},{w:390,mobile:true},{w:390,mobile:true,reduce:true},{w:320,mobile:true},{w:390,nojs:true}]){
   let o;if(m.nojs){fs.writeFileSync('after_nojs.html',fs.readFileSync('after.html','utf8').replace(/<script>[\s\S]*?<\/script>/g,'').replace(/<!--[\s\S]*?-->/g,'').replace(/<noscript>([\s\S]*?)<\/noscript>/g,'$1'));o=await open({w:390,h:900});await o.page.goto('file://'+path.resolve('after_nojs.html'));await o.page.waitForTimeout(800);}
   else {o=await open({...m,h:900});await o.page.goto(AFTER);await settle(o.page);}
   await o.page.addScriptTag({content:axeSrc});const res=await o.page.evaluate(async()=>(await axe.run(document.getElementById('allrecords'),{resultTypes:['violations']})).violations.map(v=>[v.id,v.impact,v.nodes.length,v.nodes[0].target.join(' ')]));
   const s=res.filter(v=>/serious|critical/.test(v[1]));log('A',res.length===0,`${m.w}${m.reduce?' reduce':''}${m.nojs?' без JS':''}: нарушений ${res.length} (serious/critical ${s.length}) ${res.map(v=>v.join(':')).join(' ; ').slice(0,300)}`);await o.browser.close();}
  for(const w of [1440,390]){const o=await open({w,h:900,mobile:w<700,touch:w<700});await o.page.goto(AFTER);await settle(o.page);
   await o.page.click('#ag-dir06-04 .ag-uz__tab >> nth=2');await o.page.click('#ag-dir06-07 .ag-uq__all');await o.page.waitForTimeout(500);
   await o.page.addScriptTag({content:axeSrc});const res=await o.page.evaluate(async()=>(await axe.run(document.getElementById('allrecords'),{resultTypes:['violations']})).violations.map(v=>[v.id,v.impact,v.nodes[0].target.join(' ')]));
   log('A',res.length===0,`${w}, «Сайкл-студия» + FAQ раскрыт: нарушений ${res.length} ${res.map(v=>v.join(':')).join(' ; ').slice(0,300)}`);await o.browser.close();}}
 fs.writeFileSync('checks_f_'+G+'.json',JSON.stringify(out,null,1));
 for(const g of Object.keys(out)){console.log('## '+g);out[g].forEach(x=>console.log('  '+x));}
})();
