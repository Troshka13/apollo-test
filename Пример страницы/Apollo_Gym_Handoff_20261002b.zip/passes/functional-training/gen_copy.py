# -*- coding: utf-8 -*-
import hashlib, html
B = [
 ('01','rec3998045601','Функциональные тренировки в Самаре','Кадр зала вместо сайкл-студии, «для взрослых» в планке, магнит снят, нажатие кнопки','заменить код'),
 ('02','rec3998406401','Две группы упражнений на занятии','Фокус 3 px','заменить код'),
 ('03','rec3998442301','Что закрывает функциональная тренировка','Фокус 3 px (и панели)','заменить код'),
 ('04','rec3998485801','Где идут функциональные тренировки','«Зоны зала»: вкладки «Свободные веса / Весь зал / Сайкл-студия» меняют кадр и подпись, зерно бумаги','заменить код'),
 ('05','новый блок','Кто ведёт функциональные тренировки','На тесте нет. Нажатие кнопки, фокус','новый T123 между rec3998485801 и rec3998527201 — по вашему решению'),
 ('06','rec3998527201','Цены на групповые тренировки','«для взрослых», зерно бумаги, нажатие кнопки','заменить код'),
 ('07','rec3998570801','Что спрашивают про функциональные тренировки','Плавный FAQ, «для взрослых» в ответе «Сколько стоит?», ответы в печати','заменить код'),
 ('08','rec3998615701','Не знаете, с какой нагрузки начать','Магнит снят, нажатие кнопок','заменить код'),
 ('HEAD','—','HEAD страницы v1.1','Ответ «Сколько стоит?» в FAQPage — «для взрослых», как в блоке 07','заменить целиком'),
]
TITLE=''
DESC='Функциональные тренировки в Самаре на Молодогвардейской, 56: свободные веса, собственный вес, круговые серии. Взрослым первое групповое занятие бесплатно.'
cards=[]
for n,rec,name,what,act in B:
    code=open('/home/claude/ft/out/HEAD_functional-training_v1.1.html' if n=='HEAD' else f'/home/claude/ft/out/DIR06-{n}_v1.1.0.html',encoding='utf-8').read()
    sha=hashlib.sha256(code.encode()).hexdigest()
    must=' is-must' if n=='HEAD' else ''
    cards.append(f'''<article class="blk{must}" id="b{n}">
  <header class="blk__head">
    <p class="blk__num">{"HEAD" if n=="HEAD" else "DIR06-"+n}<span>{"v1.1" if n=="HEAD" else "v1.1.0"}</span></p>
    <h2 class="blk__name">{html.escape(name)}</h2>
    <p class="blk__what">{html.escape(what)}</p>
  </header>
  <dl class="blk__meta">
    <div><dt>{"Где" if n=="HEAD" else "Запись Tilda"}</dt><dd>{"Настройки страницы → Дополнительно → HTML-код внутрь HEAD" if n=="HEAD" else ("<code>"+rec+"</code>" if rec.startswith("rec") else rec)}</dd></div>
    <div><dt>Действие</dt><dd class="act">{act}</dd></div>
    <div><dt>Размер</dt><dd>{len(code.encode())//1024} КБ</dd></div>
  </dl>
  <div class="blk__do">
    <button class="btn btn--main" type="button" data-copy="c{n}">Скопировать код</button>
    <span class="blk__state" data-state="c{n}" role="status" aria-live="polite"></span>
  </div>
  <details class="blk__code"><summary>Показать код</summary>
    <label class="vh" for="c{n}">Код {n}</label>
    <textarea id="c{n}" readonly spellcheck="false" data-sha="{sha}">{html.escape(code)}</textarea>
  </details>
</article>''')
page=open('/home/claude/ft/copy_tpl.html',encoding='utf-8').read()
page=page.replace('%%CARDS%%','\n'.join(cards)).replace('%%TITLE%%',html.escape(TITLE)).replace('%%DESC%%',html.escape(DESC)).replace('%%TL%%',str(len(TITLE))).replace('%%DL%%',str(len(DESC)))
open('/home/claude/ft/copy/functional_blocks.html','w',encoding='utf-8').write(page)
print(len(page.encode()))
