# HEAD /functional-training v1.1: FAQPage ответ «Сколько стоит?» = DIR06-07 v1.1.0 (факт № 11 «для взрослых»); остальное — как в HEAD 27.09
import re, json, html
W='/home/claude/work/'
old=open(W+'head_test/HEAD_functional-training.html',encoding='utf-8').read()
g=json.loads(re.search(r'<script type="application/ld\+json">(.*?)</script>',old,re.S).group(1))
b=open('out/DIR06-07_v1.1.0.html',encoding='utf-8').read()
items=re.findall(r'<span class="ag-uq__qt">(.*?)</span></summary>\s*<div class="ag-uq__a">(.*?)</div>',b,re.S)
def clean(s):
    s=re.sub(r'<[^>]+>','',s); s=html.unescape(s).replace(' ',' ')
    return re.sub(r'\s+',' ',s).strip()
Q='Сколько стоит?'
IDX=[clean(q) for q,a in items].index(Q)
NEW_A=clean(items[IDX][1])
n=0
for node in g['@graph']:
    if node.get('@type')=='FAQPage':
        names=[clean(x['name']) for x in node['mainEntity']]
        assert names==[clean(q) for q,a in items], (names,)
        q=node['mainEntity'][IDX]; OLD_A=q['acceptedAnswer']['text']
        assert NEW_A==OLD_A.replace('Первое групповое занятие — бесплатно.','Первое групповое занятие для взрослых — бесплатно.'), (OLD_A,NEW_A)
        assert NEW_A!=OLD_A
        q['acceptedAnswer']['text']=NEW_A; n+=1
        # остальные ответы совпадают с блоком
        for i,x in enumerate(node['mainEntity']):
            assert clean(x['acceptedAnswer']['text'])==clean(re.sub(r'<a class="ag-uq__btn".*?</a>','',items[i][1],flags=re.S)), i  # кнопка «Спросить расписание» не текст ответа
assert n==1
com=('<!-- Apollo Gym · /functional-training · HEAD v1.1 · 01.10.2026 · Tilda → Настройки страницы → Дополнительно → «HTML-код для вставки внутрь HEAD». '
     'Тестовая копия с адресами apolloboxing.tilda.ws. Заменяет HEAD от 27.09 целиком; старый JSON-LD удалить. '
     'v1.1: FAQPage, ответ «Сколько стоит?» = DIR06-07 v1.1.0 (факт № 11 «для взрослых»); остальное без изменений. -->\n')
out=com+'<script type="application/ld+json">\n'+json.dumps(g,ensure_ascii=False,indent=1)+'\n</script>\n'
open('out/HEAD_functional-training_v1.1.html','w',encoding='utf-8').write(out)
print('ok', IDX, len(out))
