# -*- coding: utf-8 -*-
"""/functional-training (DIR06) · проход «дизайн, движение и фишка» (PROMPT_DIR06_DESIGN_MOTION_v2, 01.10.2026).
src/DIR06-0N_v1.0.0.html → out/DIR06-0N_v1.1.0.html. Каждая замена обязана найтись нужное число раз."""
import re, os, sys

sys.path.insert(0, '/home/claude/pr')
from build_prices_dm import TOUCH, rep, rx, focus3, wrap, press_css, touch, GRAIN  # noqa: E402

SRC, OUT = 'src', 'out'
os.makedirs(OUT, exist_ok=True)
DATE = '01.10.2026'
E = 'cubic-bezier(.22,.61,.36,1)'
CDN = 'https://static.tildacdn.pub/'
IMG = {
    '22': CDN + 'tild3961-6563-4163-a135-366239333639/22-1024x683.jpg',
    '48': CDN + 'tild6635-6631-4937-a137-363162623738/48-1024x683.jpg',
    '50': CDN + 'tild3138-6263-4139-a231-383132386437/50-1024x683.jpg',
    '51': CDN + 'tild6464-3663-4266-a161-383031663236/51-1024x683.jpg',
    '57': CDN + 'tild3436-6332-4330-a164-623465663263/57-1024x683.jpg',
}
# фактические записи теста на 01.10 (инвентарь расходится: DIR06-05 на тесте нет, 06–08 сдвинуты)
REC = {5: (None, 'rec3998527201'), 6: ('rec3998527201', 'rec3998570801'), 7: ('rec3998570801', 'rec3998615701'), 8: ('rec3998615701', 'rec3998684901')}


def load(n):
    return open('%s/DIR06-0%d_v1.0.0.html' % (SRC, n), encoding='utf-8').read()


def save(n, t):
    p = '%s/DIR06-0%d_v1.1.0.html' % (OUT, n)
    open(p, 'w', encoding='utf-8').write(t)
    print('DIR06-0%d v1.1.0 %6d байт' % (n, len(t.encode('utf-8'))))


def bump(t, n, note):
    t = rx(t, r'(DIR06-0\d · [^\n]*?)· v1\.0\.0 · \d\d\.09\.2026', r'\1· v1.1.0 · 01.10.2026')
    if n in REC:
        real, inv = REC[n]
        if real:
            t = rep(t, 'Ставится в запись %s' % inv, 'Ставится в запись %s (тест 01.10; по инвентарю — %s)' % (real, inv))
        else:
            t = rep(t, 'Ставится в запись %s' % inv, 'Ставится новым блоком T123 между rec3998485801 и rec3998527201 (на тесте 01.10\n     блока нет; по инвентарю — %s)' % inv)
    i = t.index('-->') + 3
    return t[:i] + '\n<!-- v1.1.0 (проход «дизайн, движение и фишка», PROMPT_DIR06_DESIGN_MOTION_v2, %s):\n     %s -->' % (DATE, note) + t[i:]


def add_css(t, css):
    i = t.index('  </style>')
    return t[:i] + '\n  /* ===== v1.1.0 · дизайн, движение и фишка (01.10) ===== */\n' + css + t[i:]


def grain_css(root, sec, wrap_cls):
    return '''  /* F29 · зерно бумаги (статично, только ≥ 640 px; forced-colors и печать — без зерна) */
  @media (min-width:640px){
    %(r)s .%(s)s{position:relative;}
    %(r)s .%(s)s::before{content:"";position:absolute;inset:0;z-index:0;pointer-events:none;opacity:.12;background-image:%(g)s;background-size:180px 180px;}
    %(r)s .%(w)s{position:relative;z-index:1;}
  }
  @media (forced-colors:active){%(r)s .%(s)s::before{display:none;}}
  @media print{%(r)s .%(s)s::before{display:none;}}
''' % {'r': root, 's': sec, 'w': wrap_cls, 'g': GRAIN}


# ---------------------------------------------------------------- DIR06-01
def c01():
    t = load(1); R = '#ag-dir06-01'
    t = bump(t, 1, 'Кадр: 22 сверен глазами 01.10 — сайкл-студия, на первом экране функциональных не по теме → 48 (общий вид\n'
                   '     зала на Молодогвардейской, сверен на /nofitness); alt по кадру, подпись адресом; слот DIR06-01-floor — задание\n'
                   '     на съёмку. Факт № 11: «0 ₽ — первое групповое занятие для взрослых». Магнит снят, F23, фокус 3 px.')
    t = rep(t, 'src="%s" width="1024" height="683" alt="Функциональная тренировка в Apollo NoFitness на Молодогвардейской, 56"' % IMG['22'],
            'src="%s" width="1024" height="683" alt="Зал Apollo NoFitness на Молодогвардейской, 56"' % IMG['48'])
    t = rep(t, '<span class="ag-uh__cap">первое групповое занятие</span>', '<span class="ag-uh__cap">первое групповое занятие для&nbsp;взрослых</span>')
    t = rep(t, ' data-ag-magnetic="0.18"', '')
    t = wrap(t, 'a', 'ag-btn ag-btn--primary', 'ag-btn__in')
    t = focus3(t, R)
    t = rep(t, '#ag-dir06-01.ag-scope .ag-uh__text:focus-visible{outline:2px', '#ag-dir06-01.ag-scope .ag-uh__text:focus-visible{outline:3px')
    t = add_css(t, press_css(R, [('ag-btn', 'ag-btn__in')]))
    t = touch(t)
    save(1, t)


# ---------------------------------------------------------------- DIR06-02, 03, 05
def c02():
    t = load(2); R = '#ag-dir06-02'
    t = bump(t, 2, 'Фокус 3 px. «Стопка корешков» и текст — как в v1.0.0.')
    t = focus3(t, R)
    save(2, t)


def c03():
    t = load(3); R = '#ag-dir06-03'
    t = bump(t, 3, 'Фокус 3 px (корешки и панели). Корешки папок — без F10: подложка сломала бы метафору «корешок сливается\n'
                   '     с карточкой».')
    t = focus3(t, R)
    t = rep(t, '#ag-dir06-03 .ag-uw__panel:focus-visible{outline:2px', '#ag-dir06-03 .ag-uw__panel:focus-visible{outline:3px')
    save(3, t)


def c05():
    t = load(5); R = '#ag-dir06-05'
    t = bump(t, 5, 'На тесте 01.10 блока нет — ставится новым T123 между 04 и 06 по решению владельца (без него две бумажные\n'
                   '     секции 04 и 06 стоят подряд). F23 — нажатие кнопки, фокус 3 px. Состав и текст — как есть.')
    t = wrap(t, 'a', 'ag-btn ag-btn--ghost', 'ag-btn__in')
    t = focus3(t, R)
    t = add_css(t, press_css(R, [('ag-btn', 'ag-btn__in')]))
    t = touch(t)
    save(5, t)


# ---------------------------------------------------------------- DIR06-04 «Зоны зала»
FIG_OLD = r'        <figure class="ag-uz__fig" data-ag-slot="DIR06-04-weights" data-ag-ratio="4:5" data-ag-brief="([^"]*)" data-ag-anim="scale-in" data-ag-delay="80">\s*<img[^>]*50-1024x683[^>]*>\s*<figcaption class="ag-uz__label">.*?</figcaption>\s*</figure>'

ZONES = [
    ('Свободные веса', 'DIR06-04-weights', '4:5', None, IMG['57'], 'Зона со свободными весами в Apollo NoFitness на Молодогвардейской, 56', 'Зона со свободными весами'),
    ('Весь зал', 'DIR06-04-hall', '3:2', 'Общий вид зала на Молодогвардейской, 56, широкий план', IMG['51'], 'Общий вид зала Apollo NoFitness на Молодогвардейской, 56', 'Общий вид зала'),
    ('Сайкл-студия', 'DIR06-04-cycle', '3:2', 'Отдельная сайкл-студия на Молодогвардейской, 56', IMG['22'], 'Сайкл-студия в зале Apollo NoFitness на Молодогвардейской, 56', 'Отдельная сайкл-студия'),
]


def zones_html(brief1):
    tabs, panels = [], []
    for i, (tab, slot, ratio, brief, src, alt, cap) in enumerate(ZONES, 1):
        sel = 'true' if i == 1 else 'false'
        ti = '' if i == 1 else ' tabindex="-1"'
        tabs.append('            <button class="ag-uz__tab" type="button" role="tab" id="ag-dir06-04-z%d" aria-controls="ag-dir06-04-zp%d" aria-selected="%s"%s><span>%s</span></button>' % (i, i, sel, ti, tab))
        panels.append('''            <div class="ag-uz__panel%s" id="ag-dir06-04-zp%d" role="group" aria-label="%s">
              <figure class="ag-uz__fig" data-ag-slot="%s" data-ag-ratio="%s" data-ag-brief="%s">
                <img class="ag-uz__img" src="%s" width="1024" height="683" alt="%s" loading="lazy" decoding="async">
                <figcaption class="ag-uz__label"><span class="ag-uz__dot" aria-hidden="true"></span><span>%s</span></figcaption>
              </figure>
            </div>''' % (' is-on' if i == 1 else '', i, cap, slot, ratio, brief or brief1, src, alt, cap))
    return '''        <div class="ag-uz__media">
          <div class="ag-uz__tabs" role="tablist" aria-label="Зоны зала на Молодогвардейской, 56" data-ag-tablist hidden>
%s
            <span class="ag-uz__ind" aria-hidden="true"></span>
          </div>
          <div class="ag-uz__panels" data-ag-anim="scale-in" data-ag-delay="80">
%s
          </div>
        </div>''' % ('\n'.join(tabs), '\n'.join(panels))


ZONE_JS = r'''  /* v1.1.0 · F04 «Зоны зала»: вкладки меняют кадр (проявление 180 мс) и подпись; подложка вкладок едет 320 мс
     (CSS от data-ag-zone корня). Без JS вкладок нет — три кадра с подписями столбцом. Скрипт меняет только
     атрибуты и классы; ничего не вставляет. Стрелки, Home/End, автоматическая активация. */
  (function () {
    "use strict";
    var W = window, D = document;
    var root = D.currentScript && D.currentScript.closest(".ag-scope");
    if (!root || root.hasAttribute("data-ag-ui-mounted")) return;
    var list = root.querySelector("[data-ag-tablist]");
    var box = root.querySelector(".ag-uz__panels");
    if (!list || !box) return;
    var tabs = Array.prototype.slice.call(list.querySelectorAll('[role="tab"]'));
    var panels = tabs.map(function (t) { return D.getElementById(t.getAttribute("aria-controls")); });
    if (tabs.length !== 3 || panels.some(function (p) { return !p; })) return;
    root.setAttribute("data-ag-ui-mounted", "");
    panels.forEach(function (p, i) {
      p.setAttribute("role", "tabpanel");
      p.setAttribute("aria-labelledby", tabs[i].id);
      p.removeAttribute("aria-label");
    });
    box.classList.add("is-js");
    list.hidden = false;
    function select(i, focus) {
      tabs.forEach(function (t, k) {
        var on = k === i;
        t.setAttribute("aria-selected", on ? "true" : "false");
        t.setAttribute("tabindex", on ? "0" : "-1");
        panels[k].classList.toggle("is-on", on);
        panels[k].setAttribute("tabindex", on ? "0" : "-1");
      });
      root.setAttribute("data-ag-zone", String(i));
      if (focus) tabs[i].focus();
    }
    tabs.forEach(function (t, i) { t.addEventListener("click", function () { select(i, false); }); });
    list.addEventListener("keydown", function (e) {
      var i = tabs.indexOf(D.activeElement);
      if (i < 0) return;
      var n = tabs.length, to = -1;
      if (e.key === "ArrowRight" || e.key === "ArrowDown") to = (i + 1) % n;
      else if (e.key === "ArrowLeft" || e.key === "ArrowUp") to = (i - 1 + n) % n;
      else if (e.key === "Home") to = 0;
      else if (e.key === "End") to = n - 1;
      if (to < 0) return;
      e.preventDefault();
      select(to, true);
    });
    select(0, false);
    list.classList.add("is-jump");
    W.requestAnimationFrame(function () { W.requestAnimationFrame(function () { list.classList.remove("is-jump"); }); });
    var mq = W.matchMedia ? W.matchMedia("(max-width: 1023px)") : null;
    if (mq) {
      var jump = function () {
        list.classList.add("is-jump");
        W.requestAnimationFrame(function () { W.requestAnimationFrame(function () { list.classList.remove("is-jump"); }); });
      };
      if (mq.addEventListener) mq.addEventListener("change", jump); else if (mq.addListener) mq.addListener(jump);
    }
  })();

'''


def c04():
    t = load(4); R = '#ag-dir06-04'
    t = bump(t, 4, 'Ведущая фишка — F04 «Зоны зала». Кадры сверены глазами 01.10: прежний кадр 50 — рама с турниками, а не «зона\n'
                   '     со свободными весами». Теперь три вкладки-зоны: «Свободные веса» (кадр 57, подпись «Зона со свободными\n'
                   '     весами» — теперь правда), «Весь зал» (51, общий вид), «Сайкл-студия» (22, «Отдельная сайкл-студия» — словами\n'
                   '     абзаца; без условий и цен). Кадр 50 (рама) — после ответа владельца. Смена кадра — проявление 180 мс, подложка\n'
                   '     вкладок — 320 мс; ПК — стеклянный ряд поверх верхней кромки кадра, < 1024 — ряд над кадром. Без JS — три\n'
                   '     кадра столбцом. scale-in — только у кадров (рамка с вкладками не масштабируется). Зерно бумаги, фокус 3 px.\n'
                   '     Нельзя: раму как место занятий, состав свободных весов (I071), условия сайкла.')
    t = rx(t, FIG_OLD, lambda m: zones_html(m.group(1)))
    t = rep(t, '  <script>\n  /* Страховка скана', '  <script>\n' + ZONE_JS + '  /* Страховка скана')
    t = rep(t, '''  #ag-dir06-04 .ag-uz__fig{
    grid-column:1 / 7;grid-row:1;position:relative;z-index:2;margin-top:48px;
    aspect-ratio:3/2;overflow:hidden;border-radius:18px;background:#E0DACD;
    box-shadow:0 30px 60px rgba(9,9,10,.22),0 2px 0 rgba(9,9,10,.06);
  }''', '''  #ag-dir06-04 .ag-uz__media{grid-column:1 / 7;grid-row:1;position:relative;z-index:2;margin-top:48px;min-width:0;}
  #ag-dir06-04 .ag-uz__fig{
    position:relative;margin:0;
    aspect-ratio:3/2;overflow:hidden;border-radius:18px;background:#E0DACD;
    box-shadow:0 30px 60px rgba(9,9,10,.22),0 2px 0 rgba(9,9,10,.06);
  }''')
    t = rep(t, '    #ag-dir06-04 .ag-uz__fig{order:1;margin-top:0;width:100%;max-width:760px;}',
            '    #ag-dir06-04 .ag-uz__media{order:1;margin-top:0;width:100%;max-width:760px;}')
    t = rep(t, '    #ag-dir06-04 .ag-uz__fig{display:none !important;}', '    #ag-dir06-04 .ag-uz__media{display:none !important;}')
    t = focus3(t, R)
    css = '''  /* F04 · «Зоны зала» */
  #ag-dir06-04 .ag-uz__panels{display:grid;gap:14px;}
  #ag-dir06-04 .ag-uz__panels.is-js{gap:0;}
  #ag-dir06-04 .ag-uz__panels.is-js>.ag-uz__panel{grid-area:1 / 1;opacity:0;visibility:hidden;transition:opacity .18s ease,visibility 0s linear .18s;}
  #ag-dir06-04 .ag-uz__panels.is-js>.ag-uz__panel.is-on{opacity:1;visibility:visible;transition:opacity .18s ease,visibility 0s;}
  #ag-dir06-04 .ag-uz__tabs{position:relative;display:grid;grid-template-columns:repeat(3,minmax(0,1fr));padding:4px;border-radius:var(--r-pill);isolation:isolate;}
  #ag-dir06-04 .ag-uz__tabs[hidden]{display:none;}
  #ag-dir06-04 .ag-uz__tab{
    position:relative;z-index:2;display:flex;align-items:center;justify-content:center;min-width:0;min-height:44px;margin:0;padding:6px 10px;
    border:0;border-radius:var(--r-pill);background:transparent;cursor:pointer;text-align:center;
    font-family:var(--f-display);font-size:13px;font-weight:600;line-height:1.15;letter-spacing:.06em;text-transform:uppercase;
    -webkit-tap-highlight-color:transparent;transition:color .2s ease .1s;
  }
  #ag-dir06-04 .ag-uz__tab[aria-selected="true"]{color:#09090A;}
  #ag-dir06-04 .ag-uz__ind{position:absolute;z-index:1;left:4px;top:4px;bottom:4px;width:calc((100%% - 8px) / 3);border-radius:var(--r-pill);background:var(--accent);pointer-events:none;
    transform:translateX(calc(var(--i,0) * 100%%));transition:transform .32s %(e)s;}
  #ag-dir06-04[data-ag-zone="1"] .ag-uz__ind{--i:1;}
  #ag-dir06-04[data-ag-zone="2"] .ag-uz__ind{--i:2;}
  #ag-dir06-04 .ag-uz__tabs.is-jump .ag-uz__ind{transition:none;}
  #ag-dir06-04.ag-scope .ag-uz__tab:focus-visible{outline:3px solid var(--accent);outline-offset:2px;border-radius:var(--r-pill);}
  /* ПК: стеклянный ряд поверх верхней кромки кадра */
  @media (min-width:1024px){
    #ag-dir06-04 .ag-uz__tabs{position:absolute;z-index:3;left:clamp(14px,1.6vw,20px);right:clamp(14px,1.6vw,20px);top:clamp(14px,1.6vw,20px);
      border:1px solid rgba(255,255,255,.26);background:rgba(9,9,10,.62);-webkit-backdrop-filter:blur(10px);backdrop-filter:blur(10px);}
    #ag-dir06-04 .ag-uz__tab{color:#F4F4F5;}
    #ag-dir06-04 .ag-uz__tab[aria-selected="true"]{color:#09090A;}
  }
  /* < 1024: ряд над кадром, на бумаге */
  @media (max-width:1023px){
    #ag-dir06-04 .ag-uz__tabs{margin-bottom:10px;border:1px solid var(--edge);background:var(--card);}
    #ag-dir06-04 .ag-uz__tab{color:var(--ink);font-size:12px;letter-spacing:.03em;padding:6px 4px;white-space:nowrap;}
    #ag-dir06-04.ag-scope .ag-uz__tab:focus-visible{outline-color:#171719;}
  }
  #ag-dir06-04.ag-scope .ag-uz__panel:focus-visible{outline:3px solid var(--ink);outline-offset:3px;border-radius:18px;}
  @media (max-width:374px){#ag-dir06-04 .ag-uz__tab{font-size:11.5px;letter-spacing:.02em;white-space:normal;text-wrap:balance;}}
  @media (forced-colors:active){
    #ag-dir06-04 .ag-uz__ind{display:none;}
    #ag-dir06-04 .ag-uz__tabs{border:1px solid CanvasText;}
    #ag-dir06-04 .ag-uz__tab[aria-selected="true"]{outline:2px solid CanvasText;outline-offset:-4px;}
  }
''' % {'e': E}
    css += grain_css(R, 'ag-uz', 'ag-uz__wrap')
    t = add_css(t, css)
    save(4, t)


# ---------------------------------------------------------------- DIR06-06
def c06():
    t = load(6); R = '#ag-dir06-06'
    t = bump(t, 6, 'Факт № 11: «Первое групповое занятие для взрослых — бесплатно.» Цены — как есть. F29 зерно бумаги (≥ 640 px),\n'
                   '     F23, фокус 3 px.')
    t = rep(t, '<p class="ag-up__text">Первое групповое занятие — бесплатно. ', '<p class="ag-up__text">Первое групповое занятие для взрослых&nbsp;— бесплатно. ')
    t = wrap(t, 'a', 'ag-btn ag-btn--ink', 'ag-btn__in')
    t = focus3(t, R)
    css = press_css(R, [('ag-btn', 'ag-btn__in')])
    css += grain_css(R, 'ag-up', 'ag-up__wrap')
    t = add_css(t, css)
    t = touch(t)
    save(6, t)


# ---------------------------------------------------------------- DIR06-07
def c07():
    t = load(7); R = '#ag-dir06-07'
    t = bump(t, 7, 'F22: ответ раскрывается плавно (::details-content + interpolate-size, прогрессивно; overflow-clip-margin);\n'
                   '     «Раскрыть все» — без перехода (флаг снимается таймером: toggle приходит асинхронно); пересчёт триггеров\n'
                   '     по окончании перехода. Прилипающая колонка без transform. Печать — ответы видны. Факт № 11 в ответе\n'
                   '     «Сколько стоит?» (HEAD v1.1 — тот же текст). F23 — «Раскрыть все» и «Спросить расписание», фокус 3 px.')
    t = rep(t, 'за тренировку. Первое групповое занятие — бесплатно.', 'за тренировку. Первое групповое занятие для взрослых&nbsp;— бесплатно.')
    t = wrap(t, 'button', 'ag-uq__all', 'ag-uq__ain')
    t = wrap(t, 'a', 'ag-uq__btn', 'ag-uq__bin')
    t = focus3(t, R)
    css = press_css(R, [('ag-uq__all', 'ag-uq__ain'), ('ag-uq__btn', 'ag-uq__bin')])
    css += '''  /* F22 · плавное раскрытие ответа (Chromium 131+); иначе — мгновенно, как было */
  @supports (interpolate-size:allow-keywords) and selector(::details-content){
    #ag-dir06-07 .ag-uq__list{interpolate-size:allow-keywords;}
    #ag-dir06-07 .ag-uq__item::details-content{
      height:0;overflow:clip;overflow-clip-margin:8px;
      transition:height .32s %(e)s,content-visibility .32s allow-discrete;
    }
    #ag-dir06-07 .ag-uq__item[open]::details-content{height:auto;}
    #ag-dir06-07.is-bulk .ag-uq__item::details-content{transition:none;}
    @media (prefers-reduced-motion:reduce){
      #ag-dir06-07 .ag-uq__item::details-content{transition:none;}
    }
  }
  @media print{
    #ag-dir06-07 .ag-uq__item::details-content{height:auto !important;content-visibility:visible !important;}
    #ag-dir06-07 .ag-uq__a{display:block !important;}
  }
''' % {'e': E}
    t = add_css(t, css)
    t = rx(t, r'(      busy = true;\n)(.*?)(      busy = false;\n)',
           lambda m: m.group(1) + '      root.classList.add("is-bulk");\n' + m.group(2)
           + '      W.setTimeout(function () { busy = false; root.classList.remove("is-bulk"); }, 80);\n')
    t = rep(t, '      d.addEventListener("toggle", function () { if (!busy) { sync(); refresh(); } });\n    });\n',
            '      d.addEventListener("toggle", function () { if (!busy) { sync(); refresh(); } });\n    });\n'
            '    /* v1.1.0: высота ответа меняется переходом — пересчитать позиции анимаций ниже по окончании */\n'
            '    root.addEventListener("transitionend", function (e) {\n'
            '      if (e.propertyName === "height" && e.pseudoElement === "::details-content") refresh();\n'
            '    });\n')
    t = rep(t, '    btn.hidden = false;\n', '    btn.hidden = false;\n' + TOUCH)
    save(7, t)


# ---------------------------------------------------------------- DIR06-08
def c08():
    t = load(8); R = '#ag-dir06-08'
    t = bump(t, 8, 'Магнит снят, F23 — нажатие обеих кнопок, фокус 3 px. Контур «ФУНКЦИОНАЛЬНЫЕ» — как в v1.0.0.')
    t = rx(t, r' data-ag-magnetic="0\.\d+"', '')
    t = wrap(t, 'a', 'ag-btn ag-btn--primary', 'ag-btn__in')
    t = wrap(t, 'a', 'ag-btn ag-btn--ghost', 'ag-btn__in')
    t = focus3(t, R)
    t = add_css(t, press_css(R, [('ag-btn', 'ag-btn__in')]))
    t = touch(t)
    save(8, t)


if __name__ == '__main__':
    for f in (c01, c02, c03, c04, c05, c06, c07, c08):
        f()
