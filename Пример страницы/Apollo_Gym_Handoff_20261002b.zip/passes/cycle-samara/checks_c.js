// /cycle-samara (DIR07) · проверки прохода «дизайн, движение и фишка» (PROMPT_DIR07_DESIGN_MOTION_v2)
const {open,settle}=require('./lib');const fs=require('fs'),path=require('path');
const AFTER='file://'+path.resolve('after.html'), BEFORE='file://'+path.resolve('before.html');
const out={};const log=(g,ok,msg)=>{const s=(ok?"pass ":"FAIL ")+msg;(out[g]=out[g]||[]).push(s);console.log(g+" "+s);};
const G=process.env.G||'LTCMFA';
async function txt(url){const {browser,page}=await open({reduce:true});await page.goto(url);await page.waitForTimeout(2600);
  const r=await page.evaluate(()=>{const o={};document.querySelectorAll('.ag-scope').forEach(r=>{const c=r.cloneNode(true);c.querySelectorAll('style,script,.ag-vh').forEach(x=>x.remove());o[r.id]=c.textContent.replace(/\s+/g,' ').trim();});return o;});await browser.close();return r;}
async function links(url){const {browser,page}=await open({reduce:true});await page.goto(url);await page.waitForTimeout(400);
  const r=await page.evaluate(()=>[...document.querySelectorAll('.ag-scope a[href]')].map(a=>a.closest('.ag-scope').id+' '+a.getAttribute('href')));await browser.close();return r;}
// состояние «педали»
const PED=`(()=>{const r=document.getElementById('ag-dir07-03');const p=r.querySelector('.ag-xr__ped');const m=new DOMMatrix(getComputedStyle(p).transform);
  const on=[...r.querySelectorAll('.ag-xr__svg [data-ag-seg].is-on')].map(e=>e.getAttribute('data-ag-seg'));
  return {x:Math.round(m.e),y:Math.round(m.f),op:getComputedStyle(p).opacity,disp:getComputedStyle(p).display,an:p.getAnimations().length,
   focus:r.querySelector('.ag-xr__fig').classList.contains('is-focus'),seg:[...new Set(on)].join(','),
   lbl:[...r.querySelectorAll('.ag-xr__nl.is-on')].map(e=>e.getAttribute('data-ag-seg')).join(','),
   hov:[...r.querySelectorAll('.ag-xr__step')].findIndex(s=>s.classList.contains('is-hover')),
   sop:[...r.querySelectorAll('.ag-xr__svg [data-ag-seg]')].map(e=>getComputedStyle(e).strokeOpacity).join(',')};})()`;
const END=[[258,50],[350,194],[176,206],[253,50],[504,50]], START=[[16,50],[267,50],[343,206],[170,194],[262,50]];
const near=(p,q,d=3)=>Math.abs(p.x-q[0])<=d&&Math.abs(p.y-q[1])<=d;
const ang=p=>{let a=Math.atan2(p.y-150,p.x-260)*180/Math.PI;return a;};
(async()=>{
 if(G.includes('L')) for(const reduce of [false,true]) for(const fontsOff of [false,true]) for(const w of [320,360,390,768,1024,1440,1920]){
   const {browser,page}=await open({w,h:w<700?800:900,reduce,mobile:w<700,touch:w<700});
   if(fontsOff) await page.route('**/fonts.googleapis.com/**',r=>r.abort());
   await page.goto(AFTER);await settle(page);
   const r=await page.evaluate(()=>({ov:document.documentElement.scrollWidth>document.documentElement.clientWidth,h:document.body.scrollHeight}));
   log('L',!r.ov,`${w}px reduce=${reduce} fontsOff=${fontsOff} overflowX=${r.ov} h=${r.h}`);await browser.close();
 }
 if(G.includes('T')){const tb=await txt(BEFORE),ta=await txt(AFTER);
  for(const id of Object.keys(tb)){const a=ta[id];let i=0;while(i<tb[id].length&&tb[id][i]===a[i])i++;
   log('T',a===tb[id],id+(a===tb[id]?' текст совпадает':' РАЗНИЦА '+JSON.stringify(tb[id].slice(i-40,i+40))+' → '+JSON.stringify(a.slice(i-40,i+40))));}
  const h=fs.readFileSync('out/DIR07-01_v1.1.0.html','utf8');
  const fr=/24-1024x683\.jpg" width="1024" height="683" alt="Сайкл-студия Apollo NoFitness на Молодогвардейской, 56"/.test(h);
  const all=['1','2','3','4','5','6','7','8'].map(n=>fs.readFileSync(`out/DIR07-0${n}_v1.1.0.html`,'utf8').replace(/<!--[\s\S]*?-->/g,'')).join('');
  const free=/бесплатн/i.test(all.replace(/<script[\s\S]*?<\/script>|<style[\s\S]*?<\/style>/g,''));
  log('T',fr&&!free,`кадр 01 — 24 (сайкл-студия), alt как в v1.0.0: ${fr}; «бесплатно» в видимом тексте блоков: ${free} (5.4 — не наследуется)`);}
 if(G.includes('C')){const lb=await links(BEFORE),la=await links(AFTER);const add=la.filter(x=>!lb.includes(x)),rem=lb.filter(x=>!la.includes(x));
  log('C',rem.length===0&&add.length===0,`ссылки +${add.length} −${rem.length}`);}
 if(G.includes('M')){
  for(const mode of [{name:'js off',js:false},{name:'reduce',reduce:true},{name:'cdn fail',cdn:'fail'},{name:'cdn hang',cdn:'hang'}]){
   const {browser,page}=await open({w:390,h:800,mobile:true,...mode});await page.goto(AFTER,{waitUntil:'domcontentloaded'});await page.waitForTimeout(2700);
   if(mode.js!==false) for(let y=0;y<9000;y+=600){await page.evaluate(y=>scrollTo(0,y),y);await page.waitForTimeout(40);}
   const r=await page.evaluate(()=>{const bad=[];document.querySelectorAll('.ag-scope :is(p,h1,h2,h3,a,li,dt,dd,summary,td,th,figcaption)').forEach(el=>{if(el.closest('[aria-hidden="true"],[hidden],dialog'))return;let n=el,op=1;while(n&&n.nodeType===1){op*=parseFloat(getComputedStyle(n).opacity);n=n.parentElement;}if(getComputedStyle(el).display==='none')return;if(getComputedStyle(el).visibility==='hidden')return;if(op<0.99&&el.textContent.trim())bad.push(el.textContent.trim().slice(0,30));});
     return {bad,m:document.documentElement.getAttribute('data-ag-motion'),wheels:[...document.querySelectorAll('#ag-dir07-03 .ag-xr__w')].filter(w=>getComputedStyle(w).display!=='none').length,
      ped:getComputedStyle(document.querySelector('#ag-dir07-03 .ag-xr__ped')).display,
      panels:[...document.querySelectorAll('#ag-dir07-04 .ag-xw__panel')].filter(c=>getComputedStyle(c).visibility!=='hidden').length,
      plate:document.querySelector('#ag-dir07-04 .ag-xw__tabs').classList.contains('is-plate')};});
   const exp=mode.js===false?{panels:4,plate:false}:{panels:1,plate:true};
   log('M',r.bad.length===0&&r.wheels===5&&r.ped==='none'&&r.panels===exp.panels&&r.plate===exp.plate,`${mode.name}: motion=${r.m} скрытых текстов ${r.bad.length} ${r.bad.slice(0,3).join('|')}; 03: маховиков ${r.wheels}, педали нет (${r.ped}); 04: видимых панелей ${r.panels}, плашка ${r.plate}`);await browser.close();}
  const {browser,page}=await open({w:1440});await page.goto(AFTER);await settle(page);
  const r=await page.evaluate(()=>{const o={};document.querySelectorAll('.ag-scope').forEach(root=>{const all=root.querySelectorAll('[data-ag-anim]');o[root.id]=[all.length,[...all].filter(e=>!e.hasAttribute('data-ag-done')).length];});return o;});
  for(const [id,[n,left]] of Object.entries(r)) log('M',left===0,`motion on: ${id} анимаций ${n}, не отсканировано ${left}`);await browser.close();}

 if(G.includes('F')){
  // ---- 03 ПК: «педаль по кругу»
  for(const w of [1440,1024]){const {browser,page,errs}=await open({w,h:w===1024?768:900});await page.goto(AFTER);await page.waitForTimeout(1500);
   await page.evaluate(()=>{window.__mut=0;new MutationObserver(m=>{m.forEach(x=>{if(x.type==='childList')window.__mut++;});}).observe(document.getElementById('ag-dir07-03'),{childList:true,subtree:true});});
   await page.evaluate(()=>{const e=document.querySelector('#ag-dir07-03 .ag-xr__body');scrollTo(0,e.getBoundingClientRect().top+scrollY-40);});await page.waitForTimeout(150);
   const st=await page.$$('#ag-dir07-03 .ag-xr__step');
   const hov=async i=>{const b=await st[i].boundingBox();await page.mouse.move(b.x+80,b.y+Math.min(30,b.height/2));};
   await hov(1);await page.waitForTimeout(60);const early=await page.evaluate(PED);await page.mouse.move(5,5);await page.waitForTimeout(1500);
   // по ходу круга: 0 → 1 → 2 → 3 → 1 → 4
   const seq=[];let ok=true;const angs=[];
   for(const i of [0,1,2,3,1,4]){await hov(i);
     if(i===2){for(let k=0;k<6;k++){await page.waitForTimeout(70);angs.push(ang(await page.evaluate(PED)));}}
     await page.waitForTimeout(800);const p=await page.evaluate(PED);
     const good=near(p,END[i])&&p.op==='1'&&p.seg===String(i)&&p.lbl===String(i)&&p.hov===i&&p.focus&&p.an===0;
     if(!good)ok=false;seq.push(i+(good?'':'✗'+JSON.stringify(p)));}
   const cw=angs.every((a,k)=>k===0||a>=angs[k-1]-0.5)&&angs[angs.length-1]>angs[0];
   // вне хода: 4 → 0 (гаснет и начинает сначала), 2 → 1
   await hov(0);await page.waitForTimeout(60);const f1=await page.evaluate(PED);await page.waitForTimeout(150);const f2=await page.evaluate(PED);await page.waitForTimeout(800);const f3=await page.evaluate(PED);
   const fadeok=f1.op!=='1'&&f2.x<120&&Math.abs(f2.y-50)<=3&&near(f3,END[0]);
   const shot=await page.$('#ag-dir07-03 .ag-xr__body');if(w===1440) await shot.screenshot({path:'shots/f03_1440.png'});
   // быстрые проходы
   for(const i of [0,1,2,3,4,3,2,1,0,1,2]){await hov(i);await page.waitForTimeout(35);}await page.waitForTimeout(1300);
   const z=await page.evaluate(PED);if(z.op!=='1')console.log('Z',JSON.stringify(z));const an=await page.evaluate(()=>document.getElementById('ag-dir07-03').getAnimations({subtree:true}).length);
   // уход со списка
   await page.mouse.move(5,5);await page.waitForTimeout(400);const lv=await page.evaluate(PED);
   // reduce на лету
   await page.emulateMedia({reducedMotion:'reduce'});await page.waitForTimeout(100);await hov(3);await page.waitForTimeout(30);const rr=await page.evaluate(PED);
   await page.emulateMedia({reducedMotion:'no-preference'});
   // 1024×768: при наведении на 5-й шаг схема видна
   let vis='—';if(w===1024){await page.evaluate(()=>{const s=document.querySelectorAll('#ag-dir07-03 .ag-xr__step')[4].getBoundingClientRect();scrollBy(0,s.top+s.height-innerHeight+20);});await page.waitForTimeout(200);
     vis=await page.evaluate(()=>{const f=document.querySelector('#ag-dir07-03 .ag-xr__plate').getBoundingClientRect();return Math.round(f.top)+'…'+Math.round(f.bottom);});}
   const mut=await page.evaluate(()=>window.__mut);
   log('F',early.op==='0'&&ok&&cw&&fadeok&&z.an===0&&an===0&&near(z,END[2])&&z.op==='1'&&!lv.focus&&lv.op==='1'&&rr.an===0&&near(rr,END[3])&&mut===0&&errs.length===0,
    `03, ${w}px: до конца draw педали нет (opacity ${early.op}); по ходу ${seq.join(' → ')} — педаль в конце отрезка, отрезок и подпись светятся, шаг отмечен; угол только растёт (${angs.map(a=>Math.round(a)).join(',')}); Заминка → Разогрев — гаснет и начинает сначала; 11 быстрых наведений — анимаций ${an}, педаль на «Ускорении»; ушли со списка — приглушение снято, педаль на месте; reduce на лету — сразу в конце; вставок узлов ${mut}${w===1024?'; 1024×768, 5-й шаг у низа экрана — схема по высоте '+vis:''}`);
   await browser.close();}
  {const {browser,page}=await open({w:1280,h:900,touch:true,mobile:true});await page.goto(AFTER);await settle(page);
   const r=await page.evaluate(PED);log('F',r.disp==='none',`03, сенсорный экран ≥ 1024: педали нет (${r.disp})`);await browser.close();}
  // ---- 03 < 1024: мини-маховики
  for(const w of [320,360,390,599,600,768,1023,1024,1440]){const {browser,page,errs}=await open({w,h:844,mobile:w<700,touch:w<700});await page.goto(AFTER);await settle(page);
   const r=await page.evaluate(()=>{const r=document.getElementById('ag-dir07-03');const st=[...r.querySelectorAll('.ag-xr__step')];
     return {disp:st.map(s=>getComputedStyle(s.querySelector('.ag-xr__w')).display),me:st.map(s=>[...s.querySelectorAll('.ag-xr__w path')].findIndex(p=>p.classList.contains('is-me'))),
      pl:st.map(s=>getComputedStyle(s).paddingLeft),dot:getComputedStyle(st[0],'::before').display,h:Math.round(r.getBoundingClientRect().height),
      sw:document.documentElement.scrollWidth>document.documentElement.clientWidth};});
   const narrow=w<1024;const ok=r.disp.every(d=>d===(narrow?'block':'none'))&&JSON.stringify(r.me)==='[0,1,2,3,4]'&&(narrow?r.pl.every(p=>p==='0px')&&r.dot==='none':r.dot!=='none')&&!r.sw&&errs.length===0;
   log('F',ok,`03, ${w}px: ${narrow?'маховики у шагов (свой отрезок у каждого), поле слева снято':'маховиков нет, маркер шага на месте'}; высота блока ${r.h}`);await browser.close();}
  {const {browser,page}=await open({w:390,h:844,mobile:true,touch:true});await page.emulateMedia({forcedColors:'active'});await page.goto(AFTER);await settle(page);
   const c=await page.evaluate(()=>[...document.querySelectorAll('#ag-dir07-03 .ag-xr__step')[1].querySelectorAll('.ag-xr__w path')].map(p=>getComputedStyle(p).stroke));
   await (await page.$('#ag-dir07-03 .ag-xr__steps')).screenshot({path:'shots/forced_03.png'});
   log('F',c[1]!==c[0],`03, forced: свой отрезок маховика выделен системным цветом (${c[1]} / ${c[0]})`);
   await page.emulateMedia({forcedColors:'none',media:'print'});await page.waitForTimeout(100);
   const pr=await page.evaluate(()=>[getComputedStyle(document.querySelector('#ag-dir07-03 .ag-xr__w')).display,getComputedStyle(document.querySelector('#ag-dir07-03 .ag-xr__fig')).display]);
   log('F',pr[0]==='none'&&pr[1]==='none',`03, печать: схемы и маховиков нет, шаги текстом (${pr.join('/')})`);await browser.close();}
  // ---- 02 «Деталь на чертеже»
  {const {browser,page,errs}=await open({w:1440,h:900});await page.goto(AFTER);await page.waitForTimeout(1200);
   const P=`(()=>{const r=document.getElementById('ag-dir07-02');const p=r.getAttribute('data-ag-part');const ld=p&&r.querySelector('.ag-xs__ld[data-ag-part="'+p+'"], .ag-xs__mk[data-ag-part="'+p+'"]');const co=p&&r.querySelector('.ag-xs__co[data-ag-part="'+p+'"]');
     return {p,ld:ld&&getComputedStyle(ld).stroke,co:co&&getComputedStyle(co).backgroundColor,other:[...r.querySelectorAll('.ag-xs__co')].filter(c=>c!==co&&getComputedStyle(c).backgroundColor!=='rgba(0, 0, 0, 0)').length};})()`;
   await page.evaluate(()=>{const e=document.getElementById('ag-dir07-02');scrollTo(0,e.getBoundingClientRect().top+scrollY);});await page.waitForTimeout(200);
   const m=await page.$$('#ag-dir07-02 .ag-xs__m');let b=await m[0].boundingBox();await page.mouse.move(b.x+8,b.y+8);await page.waitForTimeout(80);const early=await page.evaluate(P);await page.mouse.move(5,5);
   await page.waitForTimeout(2600);const res=[];let ok=true;
   for(const [k,part] of [[0,'saddle'],[1,'bar'],[2,'pedal'],[3,'knob']]){b=await m[k].boundingBox();await page.mouse.move(b.x+8,b.y+8);await page.waitForTimeout(250);const r=await page.evaluate(P);
     const good=r.p===part&&r.ld==='rgb(9, 9, 10)'&&r.co==='rgb(255, 196, 0)'&&r.other===0;if(!good)ok=false;res.push(part+(good?'':'✗'+JSON.stringify(r)));}
   await page.mouse.move(5,5);await page.waitForTimeout(300);const lv=await page.evaluate(P);
   log('F',early.p===null&&ok&&lv.p===null&&errs.length===0,`02, ПК: до показа подписей подсветки нет; наведение на термины — ${res.join(' ')}: выноска и кольцо чернилами, подпись на жёлтом, остальные без подсветки; ушли — снято`);
   await browser.close();}
  {const {browser,page}=await open({w:1280,h:900,touch:true,mobile:true});await page.goto(AFTER);await settle(page);
   await page.evaluate(()=>document.getElementById('ag-dir07-02').scrollIntoView());await page.waitForTimeout(400);
   const m=await page.$$('#ag-dir07-02 .ag-xs__m');const b=await m[1].boundingBox();await page.touchscreen.tap(b.x+8,b.y+8);await page.waitForTimeout(200);
   const p=await page.evaluate(()=>document.getElementById('ag-dir07-02').getAttribute('data-ag-part'));
   log('F',p===null,`02, касание термина на сенсорном экране — подсветки нет (${p})`);await browser.close();}
  // ---- 04 плашка
  const PL=`(()=>{const l=document.querySelector('#ag-dir07-04 .ag-xw__tabs');const cs=getComputedStyle(l,'::before');const m=new DOMMatrix(cs.transform==='none'?undefined:cs.transform);const lr=l.getBoundingClientRect();const t=l.querySelector('.ag-xw__tab[aria-selected="true"]').getBoundingClientRect();
    return {x:Math.round(lr.left+m.e),y:Math.round(lr.top+m.f),w:Math.round(parseFloat(cs.width)),h:Math.round(parseFloat(cs.height)),tx:Math.round(t.left),ty:Math.round(t.top),tw:Math.round(t.width),th:Math.round(t.height),op:cs.opacity,bg:getComputedStyle(l.querySelector('.ag-xw__tab[aria-selected="true"]')).backgroundColor};})()`;
  const okp=p=>Math.abs(p.x-p.tx)<=1&&Math.abs(p.y-p.ty)<=1&&Math.abs(p.w-p.tw)<=1&&Math.abs(p.h-p.th)<=1&&p.op==='1';
  for(const w of [1440,1024,768,390,320]){const {browser,page,errs}=await open({w,h:844,mobile:w<700,touch:w<700});await page.goto(AFTER);await settle(page);
   await page.evaluate(()=>{const s=document.querySelector('#ag-dir07-04 .ag-xw__tabs').getBoundingClientRect();scrollTo(0,scrollY+s.top-80);});await page.waitForTimeout(400);
   const p0=await page.evaluate(PL);const res=[];let ok=okp(p0),mid=null;
   for(const i of [3,1,2,0]){const t=(await page.$$('#ag-dir07-04 .ag-xw__tab'))[i];if(w<700){const b=await t.boundingBox();await page.touchscreen.tap(b.x+b.width/2,b.y+b.height/2);}else await t.click();
    if(i===3){await page.waitForTimeout(90);mid=await page.evaluate(PL);}await page.waitForTimeout(550);const p=await page.evaluate(PL);if(!okp(p)||p.bg!=='rgba(0, 0, 0, 0)')ok=false;res.push(i+(okp(p)?'':'✗'+JSON.stringify(p)));}
   const midok=mid&&!okp(mid);
   const ld=await page.evaluate(()=>getComputedStyle(document.querySelector('#ag-dir07-04 .ag-xw__tab[aria-selected="true"]'),'::before').transitionDelay);
   log('F',ok&&midok&&errs.length===0,`04, ${w}px: плашка под выбранной вкладкой (${res.join(' ')}), на 90 мс — в пути; у вкладки фон снят; линия к панели с задержкой ${ld}`);await browser.close();}
  {const {browser,page}=await open({w:1440,h:900});await page.goto(AFTER);await settle(page);
   await page.click('#ag-dir07-01 a.ag-xh__fact[data-ag-tab="together"]');await page.waitForTimeout(1300);const p=await page.evaluate(PL);
   const sel=await page.evaluate(()=>document.querySelector('#ag-dir07-04 .ag-xw__tab[aria-selected="true"]').getAttribute('data-ag-key'));
   await page.focus('#ag-dir07-04 .ag-xw__tab[aria-selected="true"]');await page.keyboard.press('ArrowUp');await page.waitForTimeout(500);const p2=await page.evaluate(PL);
   const sel2=await page.evaluate(()=>document.activeElement.getAttribute('data-ag-key'));
   await page.setViewportSize({width:900,height:900});await page.waitForTimeout(120);const p3=await page.evaluate(PL);
   log('F',sel==='together'&&okp(p)&&sel2==='combat'&&okp(p2)&&okp(p3),`04: «3 направления» в 01 открывает «Вместе с…», плашка там; стрелка ↑ — «К единоборствам»; 1440 → 900 — плашка сразу на месте`);
   await browser.close();}
  {const {browser,page}=await open({w:1440,h:900});await page.emulateMedia({forcedColors:'active'});await page.goto(AFTER);await settle(page);
   const r=await page.evaluate(()=>[getComputedStyle(document.querySelector('#ag-dir07-04 .ag-xw__tabs'),'::before').display,getComputedStyle(document.querySelector('#ag-dir07-04 .ag-xw__tab[aria-selected="true"]')).outlineStyle]);
   log('F',r[0]==='none'&&r[1]==='solid',`04, forced: плашки нет, выбранная вкладка обведена (${r.join('/')})`);await browser.close();}
  // ---- 07 F22 + печать + FAQPage
  {const {browser,page}=await open({w:1440,h:900});await page.goto(AFTER);await settle(page);
   await page.evaluate(()=>document.getElementById('ag-dir07-07').scrollIntoView());await page.waitForTimeout(400);
   const H=n=>page.evaluate(n=>Math.round(document.querySelectorAll('#ag-dir07-07 .ag-xq__item')[n].getBoundingClientRect().height),n);
   const h0=await H(1);await page.click('#ag-dir07-07 .ag-xq__item >> nth=1 >> summary');await page.waitForTimeout(90);const hm=await H(1);await page.waitForTimeout(450);const h1=await H(1);
   const HA=()=>page.evaluate(()=>[...document.querySelectorAll('#ag-dir07-07 .ag-xq__item')].map(d=>Math.round(d.getBoundingClientRect().height)).join(','));
   await page.click('#ag-dir07-07 .ag-xq__all');await page.waitForTimeout(40);const b1=await HA();await page.waitForTimeout(500);const b2=await HA();
   const st=await page.evaluate(()=>({open:[...document.querySelectorAll('#ag-dir07-07 .ag-xq__item')].filter(d=>d.open).length,n:document.querySelectorAll('#ag-dir07-07 .ag-xq__item').length,bulk:document.getElementById('ag-dir07-07').classList.contains('is-bulk'),lbl:document.querySelector('#ag-dir07-07 .ag-xq__all').getAttribute('aria-expanded')}));
   log('F',h0<hm&&hm<h1&&b1===b2&&st.open===st.n&&!st.bulk&&st.lbl==='true',`07: ответ раскрывается плавно (${h0} → ${hm} на 90 мс → ${h1}), «Раскрыть все» — все ${st.open} сразу без перехода, кнопка «Свернуть» (${st.lbl})`);
   await page.click('#ag-dir07-07 .ag-xq__all');await page.waitForTimeout(400);
   const cl=await page.evaluate(()=>[...document.querySelectorAll('#ag-dir07-07 .ag-xq__item')].filter(d=>d.open).length);
   await page.emulateMedia({media:'print'});await page.waitForTimeout(200);
   const pr=await page.evaluate(()=>[...document.querySelectorAll('#ag-dir07-07 .ag-xq__a')].filter(a=>a.getBoundingClientRect().height>10).length);
   log('F',cl===0&&pr===11,`07: «Свернуть» закрывает все (${cl}); печать — видно ответов ${pr}/11`);await page.emulateMedia({media:'screen'});
   const head=JSON.parse(fs.readFileSync('/home/claude/work/head_test/HEAD_cycle-samara.html','utf8').match(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/)[1]);
   const fq=head['@graph'].find(n=>n['@type']==='FAQPage').mainEntity;
   const QA=()=>page.evaluate(()=>[...document.querySelectorAll('#ag-dir07-07 .ag-xq__item')].map(d=>{const a=d.querySelector('.ag-xq__a').cloneNode(true);a.querySelectorAll('.ag-xq__btn').forEach(x=>x.remove());return [d.querySelector('.ag-xq__qt').textContent.replace(/\s+/g,' ').trim(),a.textContent.replace(/\s+/g,' ').trim()];}));
   const qa=await QA();await page.goto(BEFORE);await settle(page);const qb=await QA();
   const dif=q=>fq.filter(f=>{const m=q.find(x=>x[0]===f.name);return !m||m[1]!==f.acceptedAnswer.text.replace(/<[^>]+>/g,'').replace(/\s+/g,' ').trim();}).map(f=>f.name);
   const da=dif(qa),db=dif(qb);const miss=qa.filter(x=>!fq.find(f=>f.name===x[0])).map(x=>x[0]);
   log('F',JSON.stringify(qa)===JSON.stringify(qb)&&da.length===0&&db.length===0,`FAQPage HEAD (без изменений): все ${fq.length} вопросов совпадают с 07 v1.1.0 по имени и ответу, как с v1.0.0; в разметку не входит: ${miss.join(', ')}`);
   await browser.close();}
  // ---- магниты, параллакс, F23, зерно, фокус
  {const {browser,page}=await open({w:1440,h:900});await page.goto(AFTER);await settle(page);
   const mag=await page.$$eval('[data-ag-magnetic]',x=>x.length);const par=await page.$$eval('[data-ag-parallax]',x=>x.map(e=>e.getAttribute('data-ag-parallax')));
   log('F',mag===0&&par.every(v=>parseFloat(v)<=0.08),`магнитных кнопок: ${mag}; параллакс ${par.join(', ')} (≤ 0.08)`);
   const res=[];
   for(const [sel,inn] of [['#ag-dir07-01 .ag-btn--primary','.ag-btn__in'],['#ag-dir07-05 .ag-btn--ghost','.ag-btn__in'],['#ag-dir07-06 .ag-btn--ink','.ag-btn__in'],['#ag-dir07-07 .ag-xq__all','.ag-xq__ain'],['#ag-dir07-07 .ag-xq__btn','.ag-xq__bin'],['#ag-dir07-08 .ag-btn--primary','.ag-btn__in'],['#ag-dir07-08 .ag-btn--ghost','.ag-btn__in']]){
    const el=await page.$(sel);if(!el){res.push(sel+': нет');continue;}
    if(sel.includes('xq__btn')){await page.evaluate(()=>document.querySelector('#ag-dir07-07 .ag-xq__btn').closest('details').open=true);await page.waitForTimeout(450);}
    await el.scrollIntoViewIfNeeded();await page.waitForTimeout(250);const b0=await el.boundingBox();
    await page.evaluate(s=>document.querySelector(s).addEventListener('click',e=>e.preventDefault(),{once:true}),sel);
    await page.mouse.move(b0.x+b0.width/2,b0.y+b0.height/2);await page.mouse.down();await page.waitForTimeout(220);
    const t=await page.$eval(sel+' '+inn,e=>getComputedStyle(e).transform);const b1=await el.boundingBox();await page.mouse.up();await page.waitForTimeout(80);
    res.push([sel.slice(8,10)+sel.split(' ')[1],/matrix\(0\.98/.test(t)&&Math.abs(b1.x-b0.x)<0.5]);}
   log('F',res.every(r=>Array.isArray(r)&&r[1]===true),`F23 нажатие: ${res.map(r=>Array.isArray(r)?r.join(':'):r).join(' ')}`);
   const gr=await page.evaluate(()=>['#ag-dir07-02 .ag-xs','#ag-dir07-06 .ag-xp'].map(s=>/svg/.test(getComputedStyle(document.querySelector(s),'::before').backgroundImage)));
   const sheet=await page.evaluate(()=>getComputedStyle(document.querySelector('#ag-dir07-02 .ag-xs__sheet'),'::before').content);
   log('F',gr.every(Boolean)&&(sheet==='none'||sheet==='normal'),`зерно бумаги на ПК: 02 ${gr[0]} (лист миллиметровки без зерна), 06 ${gr[1]}`);
   await page.mouse.click(5,5);await page.keyboard.press('Shift');const fo=[];
   for(const sel of ['#ag-dir07-01 .ag-btn--primary','#ag-dir07-02 a','#ag-dir07-04 [role=tab]','#ag-dir07-05 a','#ag-dir07-06 a','#ag-dir07-07 summary','#ag-dir07-08 a']){const ok=await page.evaluate(s=>{const e=document.querySelector(s);if(!e)return 'нет';e.focus();return getComputedStyle(e).outlineWidth;},sel);fo.push(sel.slice(8,12)+':'+ok);}
   log('F',fo.every(x=>/3px$/.test(x)),`фокус 3 px: ${fo.join(' ')}`);
   await browser.close();}
  {const {browser,page}=await open({w:390,h:844,mobile:true,touch:true});await page.goto(AFTER);await settle(page);
   const gr=await page.evaluate(()=>['#ag-dir07-02 .ag-xs','#ag-dir07-06 .ag-xp'].map(s=>/svg/.test(getComputedStyle(document.querySelector(s),'::before').backgroundImage)));
   log('F',!gr[0]&&!gr[1],`телефон: зерна нет (02 ${gr[0]}, 06 ${gr[1]})`);await browser.close();}
  // повторная вставка блоков 02, 03, 04 — скрипты не дублируются
  {const {browser,page,errs}=await open({w:1440,h:900});const html=fs.readFileSync('after.html','utf8');
   const dup=html.replace('<!-- /dup -->','');fs.writeFileSync('after_dup.html',html);
   await page.goto(AFTER);await settle(page);
   const r=await page.evaluate(()=>['02','03','04'].map(n=>document.getElementById('ag-dir07-'+n).hasAttribute(n==='04'?'data-ag-tabs-on':'data-ag-ui-mounted')));
   log('F',r.every(Boolean)&&errs.length===0,`метки монтирования (02, 03 — data-ag-ui-mounted; 04 — data-ag-tabs-on): ${r.join(',')}; ошибок ${errs.length}`);await browser.close();}
 }

 if(G.includes('A')){const axeSrc=fs.readFileSync(require.resolve('axe-core/axe.min.js'),'utf8');
  for(const m of [{w:1440},{w:1024},{w:390,mobile:true},{w:390,mobile:true,reduce:true},{w:320,mobile:true},{w:390,nojs:true}]){
   let o;if(m.nojs){fs.writeFileSync('after_nojs.html',fs.readFileSync('after.html','utf8').replace(/<script>[\s\S]*?<\/script>/g,'').replace(/<!--[\s\S]*?-->/g,'').replace(/<noscript>([\s\S]*?)<\/noscript>/g,'$1'));o=await open({w:390,h:900});await o.page.goto('file://'+path.resolve('after_nojs.html'));await o.page.waitForTimeout(800);}
   else {o=await open({...m,h:900});await o.page.goto(AFTER);await settle(o.page);}
   await o.page.addScriptTag({content:axeSrc});const res=await o.page.evaluate(async()=>(await axe.run(document.getElementById('allrecords'),{resultTypes:['violations']})).violations.map(v=>[v.id,v.impact,v.nodes.length,v.nodes[0].target.join(' ')]));
   const s=res.filter(v=>/serious|critical/.test(v[1]));log('A',res.length===0,`${m.w}${m.reduce?' reduce':''}${m.nojs?' без JS':''}: нарушений ${res.length} (serious/critical ${s.length}) ${res.map(v=>v.join(':')).join(' ; ').slice(0,300)}`);await o.browser.close();}
  {const o=await open({w:1440,h:900});await o.page.goto(AFTER);await settle(o.page);
   const st=await o.page.$$('#ag-dir07-03 .ag-xr__step');const b=await st[2].boundingBox();await o.page.mouse.move(b.x+60,b.y+20);await o.page.waitForTimeout(900);
   const m=await o.page.$$('#ag-dir07-02 .ag-xs__m');
   await o.page.click('#ag-dir07-04 .ag-xw__tab >> nth=2');await o.page.click('#ag-dir07-07 .ag-xq__all');await o.page.waitForTimeout(500);
   await o.page.addScriptTag({content:axeSrc});const res=await o.page.evaluate(async()=>(await axe.run(document.getElementById('allrecords'),{resultTypes:['violations']})).violations.map(v=>[v.id,v.impact,v.nodes[0].target.join(' ')]));
   log('A',res.length===0,`1440, педаль на «Ускорении» + «К единоборствам» + FAQ раскрыт: нарушений ${res.length} ${res.map(v=>v.join(':')).join(' ; ').slice(0,300)}`);await o.browser.close();}
  {const o=await open({w:390,h:900,mobile:true,touch:true});await o.page.goto(AFTER);await settle(o.page);
   await o.page.click('#ag-dir07-04 .ag-xw__tab >> nth=3');await o.page.click('#ag-dir07-07 .ag-xq__all');await o.page.waitForTimeout(500);
   await o.page.addScriptTag({content:axeSrc});const res=await o.page.evaluate(async()=>(await axe.run(document.getElementById('allrecords'),{resultTypes:['violations']})).violations.map(v=>[v.id,v.impact,v.nodes[0].target.join(' ')]));
   log('A',res.length===0,`390, «Вместе с…» + FAQ раскрыт: нарушений ${res.length} ${res.map(v=>v.join(':')).join(' ; ').slice(0,300)}`);await o.browser.close();}}
 fs.writeFileSync('checks_c_'+G+'.json',JSON.stringify(out,null,1));
 for(const g of Object.keys(out)){console.log('## '+g);out[g].forEach(x=>console.log('  '+x));}
})();
