# -*- coding: utf-8 -*-
"""/cycle-samara (DIR07) · проход «дизайн, движение и фишка» (PROMPT_DIR07_DESIGN_MOTION_v2, 01.10.2026).
src/DIR07-0N_v1.0.0.html → out/DIR07-0N_v1.1.0.html. Каждая замена обязана найтись нужное число раз."""
import re, os, sys

sys.path.insert(0, '/home/claude/pr')
from build_prices_dm import TOUCH, rep, rx, focus3, wrap, press_css, touch, GRAIN  # noqa: E402

SRC, OUT = 'src', 'out'
os.makedirs(OUT, exist_ok=True)
DATE = '01.10.2026'
E = 'cubic-bezier(.22,.61,.36,1)'
CL = {1: 'CL04-01', 2: 'CL04-02', 3: 'CL04-03', 4: 'CL04-04', 5: 'CL04-05', 6: 'CL04-06', 7: 'CL04-07', 8: 'CL04-08'}


def load(n):
    return open('%s/DIR07-0%d_v1.0.0.html' % (SRC, n), encoding='utf-8').read()


def save(n, t):
    p = '%s/DIR07-0%d_v1.1.0.html' % (OUT, n)
    open(p, 'w', encoding='utf-8').write(t)
    print('DIR07-0%d v1.1.0 %6d байт' % (n, len(t.encode('utf-8'))))


def bump(t, n, note):
    t = rx(t, r'(DIR07-0\d · [^\n]*?)· v1\.0\.0 · \d\d\.09\.2026', r'\1· v1.1.0 · 01.10.2026')
    i = t.index('-->') + 3
    return (t[:i] + '\n<!-- v1.1.0 (проход «дизайн, движение и фишка», PROMPT_DIR07_DESIGN_MOTION_v2, %s):\n'
            '     На тесте 01.10 в этой записи стоит %s v1.1.0 со страницы /nofitness — заменить этим блоком.\n'
            '     %s -->' % (DATE, CL[n], note) + t[i:])


def add_css(t, css):
    i = t.index('  </style>')
    return t[:i] + '\n  /* ===== v1.1.0 · дизайн, движение и фишка (01.10) ===== */\n' + css + t[i:]


def add_js(t, js):
    """Свой скрипт — перед «Страховкой скана» (первый <script> блока)."""
    k = t.index('  /* Страховка скана')
    return t[:k] + js + '\n' + t[k:]


def grain_css(root, sec, wrap_cls):
    return '''  /* F29 · зерно бумаги (статично, только ≥ 640 px; forced-colors и печать — без зерна) */
  @media (min-width:640px){
    %(r)s .%(s)s{position:relative;}
    %(r)s .%(s)s::before{content:"";position:absolute;inset:0;z-index:0;pointer-events:none;opacity:.12;background-image:%(g)s;background-size:180px 180px;}
    %(r)s .%(w)s{position:relative;z-index:1;}
  }
  @media (forced-colors:active){%(r)s .%(s)s::before{display:none;}}
  @media print{%(r)s .%(s)s::before{display:none;}}
''' % {'r': root, 's': sec, 'w': wrap_cls, 'g': GRAIN}


# ---------------------------------------------------------------- DIR07-01
def c01():
    t = load(1); R = '#ag-dir07-01'
    t = bump(t, 1, 'Кадр 24 сверен глазами 01.10 — сайкл-студия (ряды велотренажёров), alt и подпись верны. Магнит снят,\n'
                   '     F23 — нажатие кнопки записи, фокус 3 px (и текстовой колонки). Текст без изменений.')
    t = rx(t, r' data-ag-magnetic="0\.\d+"', '')
    t = wrap(t, 'a', 'ag-btn ag-btn--primary', 'ag-btn__in')
    t = focus3(t, R)
    t = rep(t, '#ag-dir07-01.ag-scope .ag-xh__text:focus-visible{outline:2px', '#ag-dir07-01.ag-scope .ag-xh__text:focus-visible{outline:3px')
    t = add_css(t, press_css(R, [('ag-btn', 'ag-btn__in')]))
    t = touch(t)
    save(1, t)


# ---------------------------------------------------------------- DIR07-02
PARTS = [('Седло', 'saddle'), ('Руль', 'bar'), ('педали', 'pedal'), ('рукоятка сопротивления', 'knob')]

C02_JS = '''  /* v1.1.0 · «Деталь на чертеже»: наведение мышью на термин в тексте подсвечивает его выноску, точку и подпись на
     чертеже (атрибут data-ag-part у корня). Только (min-width:1024px) and (hover:hover) and (pointer:fine) и только
     после того, как подписи чертежа показаны. Термины не интерактивны: без tabindex и ролей, текст виден весь.
     Скрипт меняет только атрибут корня. */
  (function () {
    "use strict";
    var W = window, D = document;
    var root = D.currentScript && D.currentScript.closest(".ag-scope");
    if (!root || root.hasAttribute("data-ag-ui-mounted")) return;
    var terms = Array.prototype.slice.call(root.querySelectorAll(".ag-xs__m[data-ag-part]"));
    var cos = root.querySelectorAll(".ag-xs__co");
    if (terms.length !== 4 || !cos.length) return;
    root.setAttribute("data-ag-ui-mounted", "");
    var fine = W.matchMedia ? W.matchMedia("(min-width: 1024px) and (hover: hover) and (pointer: fine)") : { matches: false };
    var timer = 0;
    function shown() {
      if (D.documentElement.getAttribute("data-ag-motion") === "off") return true;
      return parseFloat(W.getComputedStyle(cos[cos.length - 1]).opacity) > 0.99;
    }
    function off() { W.clearTimeout(timer); root.removeAttribute("data-ag-part"); }
    terms.forEach(function (m) {
      m.addEventListener("pointerenter", function (e) {
        if (e.pointerType !== "mouse" || !fine.matches || !shown()) return;
        W.clearTimeout(timer);
        root.setAttribute("data-ag-part", m.getAttribute("data-ag-part"));
      });
      m.addEventListener("pointerleave", function () {
        W.clearTimeout(timer);
        timer = W.setTimeout(off, 150);
      });
    });
    if (fine.addEventListener) fine.addEventListener("change", off); else if (fine.addListener) fine.addListener(off);
  })();
'''


def c02():
    t = load(2); R = '#ag-dir07-02'
    t = bump(t, 2, '«Деталь на чертеже»: наведение мышью на термин (Седло, Руль, педали, рукоятка сопротивления) подсвечивает\n'
                   '     выноску, точку и подпись детали — только ПК, только наведение (термины не интерактивны). Чертёж, draw и\n'
                   '     текст — как в v1.0.0. F29 зерно на фоне секции (≥ 640 px, не на листе), фокус 3 px.')
    for word, part in PARTS:
        t = rep(t, '<mark class="ag-xs__m">%s</mark>' % word, '<mark class="ag-xs__m" data-ag-part="%s">%s</mark>' % (part, word))
    for d, part in (('M214 160L168 126', 'saddle'), ('M482 122L500 104', 'bar'), ('M390 286V436', 'knob'), ('M268 362L264 438', 'pedal')):
        t = rep(t, '<path class="ag-xs__ld" d="%s"/>' % d, '<path class="ag-xs__ld" d="%s" data-ag-part="%s"/>' % (d, part))
    for cx, cy, part in (('214', '160', 'saddle'), ('482', '122', 'bar'), ('268', '360', 'pedal')):
        t = rep(t, '<circle class="ag-xs__dot" cx="%s" cy="%s" r="3.2"/>' % (cx, cy),
                '<circle class="ag-xs__dot" cx="%s" cy="%s" r="3.2" data-ag-part="%s"/>' % (cx, cy, part))
    t = rep(t, '<path class="ag-xs__mk" d="M375 271A15 15 0 1 0 405 271A15 15 0 1 0 375 271"/>',
            '<path class="ag-xs__mk" d="M375 271A15 15 0 1 0 405 271A15 15 0 1 0 375 271" data-ag-part="knob"/>')
    for cls, part in (('saddle', 'saddle'), ('bar', 'bar'), ('knob', 'knob'), ('pedal', 'pedal')):
        t = rx(t, r'<span class="ag-xs__co ag-xs__co--%s">' % cls, '<span class="ag-xs__co ag-xs__co--%s" data-ag-part="%s">' % (cls, part))
    t = focus3(t, R)
    css = '''  /* «Деталь на чертеже» — только мышь на ПК. Не трогаем opacity/transform/dash у узлов движка: подписи —
     дети stagger, поэтому у них меняются только фон и цвет; линии — stroke и толщина. */
  @media (min-width:1024px) and (hover:hover) and (pointer:fine){
    #ag-dir07-02 .ag-xs__m[data-ag-part]{transition:background-size .18s ease;}
    #ag-dir07-02 .ag-xs__m[data-ag-part]:hover{background:linear-gradient(transparent 58%%,rgba(255,196,0,.9) 58%%);}
    #ag-dir07-02 .ag-xs__svg [data-ag-part]{transition:stroke .18s ease,stroke-width .18s ease,fill .18s ease,transform .18s ease;}
    #ag-dir07-02 .ag-xs__dot[data-ag-part]{transform-box:fill-box;transform-origin:center;}
    #ag-dir07-02 .ag-xs__co[data-ag-part]{border-radius:2px;transition:background-color .18s ease,box-shadow .18s ease,color .18s ease;}
%(rules)s
  }
  @media (forced-colors:active){
    #ag-dir07-02[data-ag-part] .ag-xs__co[data-ag-part]{background:none !important;box-shadow:none !important;}
  }
''' % {'rules': '\n'.join(
        '    %(r)s[data-ag-part="%(p)s"] .ag-xs__ld[data-ag-part="%(p)s"],%(r)s[data-ag-part="%(p)s"] .ag-xs__mk[data-ag-part="%(p)s"]{stroke:var(--ink);stroke-width:2.4;}\n'
        '    %(r)s[data-ag-part="%(p)s"] .ag-xs__dot[data-ag-part="%(p)s"]{fill:var(--ink);transform:scale(1.7);}\n'
        '    %(r)s[data-ag-part="%(p)s"] .ag-xs__co[data-ag-part="%(p)s"]{background:var(--accent);box-shadow:0 0 0 4px var(--accent);color:var(--ink);}'
        % {'r': R, 'p': p} for _, p in PARTS)}
    css += grain_css(R, 'ag-xs', 'ag-xs__wrap')
    t = add_css(t, css)
    t = add_js(t, C02_JS)
    save(2, t)


# ---------------------------------------------------------------- DIR07-03
# мини-маховик: круг r 7 с центром (12,13), дороги по касательной сверху, три дуги с теми же углами, что и схема
W_IN, W_OUT = 'M1 6H11.4', 'M12.6 6H23'
W_ARC = ['M12.49 6.02A7 7 0 0 1 18.29 16.07', 'M17.80 16.91A7 7 0 0 1 6.20 16.91', 'M5.71 16.07A7 7 0 0 1 11.51 6.02']


def wheel(seg):
    ps = [('ag-xr__wr', W_IN, 0)] + [('ag-xr__wl', d, k + 1) for k, d in enumerate(W_ARC)] + [('ag-xr__wr', W_OUT, 4)]
    body = ''.join('<path class="%s%s" d="%s"/>' % (c, ' is-me' if k == seg else '', d) for c, d, k in ps)
    return '<svg class="ag-xr__w" width="24" height="22" viewBox="0 0 24 22" aria-hidden="true" focusable="false">%s</svg>' % body


C03_JS = '''  /* v1.1.0 · «Педаль по кругу» (F30 + F14). ПК, мышь: наведение на шаг — жёлтая педаль проезжает его отрезок схемы
     от начала до наконечника (450–650 мс), отрезок светится, остальные приглушены (stroke-opacity — не opacity:
     движок пишет её inline). Если шаг следующий по ходу круга (Разогрев → Подъём → Ускорение → Восстановление →
     Подъём / Заминка), педаль едет дальше с текущего места; иначе гаснет на 120 мс и начинает отрезок сначала.
     Маршрут считается аналитически: петля — центр (260,150), r 100, угол только растёт; дороги — прямая y = 50.
     Сам круг не вращается. Педаль — статичный <circle> в разметке; скрипт меняет только классы и transform педали.
     До конца draw педали нет. < 1024, сенсорный экран и reduce на ПК — см. CSS и проверки в момент события. */
  (function () {
    "use strict";
    var W = window, D = document;
    var root = D.currentScript && D.currentScript.closest(".ag-scope");
    if (!root || root.hasAttribute("data-ag-ui-mounted")) return;
    var fig = root.querySelector(".ag-xr__fig");
    var svg = fig && fig.querySelector(".ag-xr__svg");
    var ped = svg && svg.querySelector(".ag-xr__ped");
    var exit = svg && svg.querySelector('.ag-xr__road[data-ag-seg="4"]');
    var list = root.querySelector(".ag-xr__steps");
    var steps = list ? Array.prototype.slice.call(list.querySelectorAll(".ag-xr__step")) : [];
    if (!ped || !exit || steps.length !== 5 || !ped.animate) return;
    root.setAttribute("data-ag-ui-mounted", "");
    var marks = Array.prototype.slice.call(fig.querySelectorAll("[data-ag-seg]"));
    function mq(q) { return W.matchMedia ? W.matchMedia(q) : { matches: false }; }
    var still = mq("(prefers-reduced-motion: reduce)");
    var fine = mq("(min-width: 1024px) and (hover: hover) and (pointer: fine)");
    var CX = 260, CY = 150, R = 100, RAD = Math.PI / 180;
    var SEG = [{ l: [16, 258] }, { a: [-86, 26] }, { a: [34, 146] }, { a: [154, 266] }, { l: [262, 504] }];
    var BRIDGE = {
      "0>1": [{ l: [258, 260] }, { a: [-90, -86] }], "1>2": [{ a: [26, 34] }], "2>3": [{ a: [146, 154] }],
      "3>1": [{ a: [266, 274] }], "3>4": [{ a: [266, 270] }, { l: [260, 262] }]
    };
    function len(p) { return p.l ? Math.abs(p.l[1] - p.l[0]) : Math.abs(p.a[1] - p.a[0]) * RAD * R; }
    function at(p, f) {
      if (p.l) return [p.l[0] + (p.l[1] - p.l[0]) * f, 50];
      var a = (p.a[0] + (p.a[1] - p.a[0]) * f) * RAD;
      return [CX + R * Math.cos(a), CY + R * Math.sin(a)];
    }
    function total(r) { var s = 0; for (var k = 0; k < r.length; k++) s += len(r[k]); return s; }
    function point(r, s) {
      for (var k = 0; k < r.length; k++) {
        var L = len(r[k]);
        if (s <= L || k === r.length - 1) return at(r[k], L ? Math.max(0, Math.min(1, s / L)) : 1);
        s -= L;
      }
      return [0, 0];
    }
    function rest(r, s) {
      var out = [];
      for (var k = 0; k < r.length; k++) {
        var L = len(r[k]), p = r[k];
        if (s >= L) { s -= L; continue; }
        if (s > 0) {
          var f = s / L;
          p = p.l ? { l: [p.l[0] + (p.l[1] - p.l[0]) * f, p.l[1]] } : { a: [p.a[0] + (p.a[1] - p.a[0]) * f, p.a[1]] };
        }
        out.push(p); s = 0;
      }
      return out;
    }
    function ease(t) { return t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2; }
    function tr(p) { return "translate(" + p[0].toFixed(1) + "px," + p[1].toFixed(1) + "px)"; }
    function drawn() {
      if (D.documentElement.getAttribute("data-ag-motion") === "off") return true;
      return Math.abs(parseFloat(W.getComputedStyle(exit).strokeDashoffset) || 0) < 1;
    }

    var cur = -1, route = null, anim = null, dur = 0, fadeT = 0, leaveT = 0;
    function nowS() {
      if (!route) return 0;
      if (!anim) return total(route);
      return ease(Math.min(1, (anim.currentTime || 0) / dur)) * total(route);
    }
    function stop() { if (anim) { anim.cancel(); anim = null; } }
    function ride(r) {
      route = r;
      var L = total(r);
      dur = Math.round(450 + Math.min(1, L / 420) * 200);
      var fr = [];
      for (var k = 0; k <= 28; k++) fr.push({ transform: tr(point(r, ease(k / 28) * L)) });
      ped.style.transform = tr(point(r, L));
      anim = ped.animate(fr, { duration: dur, easing: "linear" });
      anim.onfinish = function () { anim = null; };
    }
    function light(i) {
      W.clearTimeout(leaveT);
      fig.classList.add("is-focus");
      marks.forEach(function (m) { m.classList.toggle("is-on", +m.getAttribute("data-ag-seg") === i); });
      steps.forEach(function (s, k) { s.classList.toggle("is-hover", k === i); });
    }
    function go(i) {
      if (!fine.matches || !drawn()) return;
      light(i);
      if (i === cur) return;
      var key = cur + ">" + i, seg = i === 1 && cur === 3 ? { a: [274, 386] } : SEG[i];
      var fading = ped.classList.contains("is-off");
      var cont = ped.classList.contains("is-on") && !fading && !!BRIDGE[key];
      var s = nowS(), old = route;
      stop();
      W.clearTimeout(fadeT);
      cur = i;
      if (still.matches) {
        route = [seg]; ped.style.transform = tr(at(seg, 1)); ped.classList.remove("is-off"); ped.classList.add("is-on");
        return;
      }
      if (cont) { ride(rest(old || [], s).concat(BRIDGE[key], [seg])); return; }
      if (ped.classList.contains("is-on")) {
        ped.classList.add("is-off");
        fadeT = W.setTimeout(function () {
          ped.style.transform = tr(at(seg, 0));
          ped.classList.remove("is-off");
          ride([seg]);
        }, 120);
        return;
      }
      ped.style.transform = tr(at(seg, 0));
      ped.classList.add("is-on");
      ride([seg]);
    }
    function calm() {
      fig.classList.remove("is-focus");
      marks.forEach(function (m) { m.classList.remove("is-on"); });
      steps.forEach(function (s) { s.classList.remove("is-hover"); });
    }
    function reset() {
      stop(); W.clearTimeout(fadeT); W.clearTimeout(leaveT);
      calm(); cur = -1; route = null;
      ped.classList.remove("is-on", "is-off");
    }
    steps.forEach(function (s, i) {
      s.addEventListener("pointerenter", function (e) { if (e.pointerType === "mouse") go(i); });
    });
    list.addEventListener("pointerleave", function () { W.clearTimeout(leaveT); leaveT = W.setTimeout(calm, 250); });
    if (fine.addEventListener) fine.addEventListener("change", reset); else if (fine.addListener) fine.addListener(reset);
  })();
'''


def c03():
    t = load(3); R = '#ag-dir07-03'
    t = bump(t, 3, '«Педаль по кругу» (F30 + F14): на ПК наведение на шаг — педаль проезжает его отрезок схемы, отрезок светится;\n'
                   '     < 1024 — у каждого шага мини-маховик с его отрезком (статичный SVG). draw схемы короче (500 → 900 мс,\n'
                   '     порядок прежний). Текст без изменений.')
    # схема: привязка путей и подписей к шагам; длительности draw
    segs = [
        ('<path class="ag-xr__road" d="M16 50H258" data-ag-anim="draw" data-ag-dur="700"/>', 0, '500'),
        ('<path class="ag-xr__loop" d="M267.0 50.2A100 100 0 0 1 349.9 193.8" data-ag-anim="draw" data-ag-dur="1000"/>', 1, '600'),
        ('<path class="ag-xr__loop" d="M359.2 187.3L349.9 193.8L349.3 182.4" data-ag-anim="draw" data-ag-dur="1000"/>', 1, '600'),
        ('<path class="ag-xr__loop" d="M342.9 205.9A100 100 0 0 1 177.1 205.9" data-ag-anim="draw" data-ag-dur="1300"/>', 2, '700'),
        ('<path class="ag-xr__loop" d="M178.1 217.3L177.1 205.9L187.2 211.1" data-ag-anim="draw" data-ag-dur="1300"/>', 2, '700'),
        ('<path class="ag-xr__loop" d="M170.1 193.8A100 100 0 0 1 253.0 50.2" data-ag-anim="draw" data-ag-dur="1600"/>', 3, '800'),
        ('<path class="ag-xr__loop" d="M242.7 45.5L253.0 50.2L243.4 56.4" data-ag-anim="draw" data-ag-dur="1600"/>', 3, '800'),
        ('<path class="ag-xr__road" d="M262 50H504" data-ag-anim="draw" data-ag-dur="1900"/>', 4, '900'),
        ('<path class="ag-xr__road" d="M494 44L504 50L494 56" data-ag-anim="draw" data-ag-dur="1900"/>', 4, '900'),
    ]
    for old, seg, dur in segs:
        new = re.sub(r'data-ag-dur="\d+"', 'data-ag-dur="%s"' % dur, old).replace('<path ', '<path data-ag-seg="%d" ' % seg)
        t = rep(t, old, new)
    t = rep(t, '            </svg>\n            <span class="ag-xr__nl ag-xr__nl--in">',
            '              <circle class="ag-xr__ped" cx="0" cy="0" r="7"/>\n            </svg>\n            <span class="ag-xr__nl ag-xr__nl--in">')
    for cls, seg in (('in', 0), ('up', 1), ('sprint', 2), ('rest', 3), ('out', 4)):
        t = rx(t, r'<span class="ag-xr__nl ag-xr__nl--%s">' % cls, '<span class="ag-xr__nl ag-xr__nl--%s" data-ag-seg="%d">' % (cls, seg))
    # мини-маховики в строке названия (< 1024)
    names = ['Разогрев', 'Подъём', 'Ускорение', 'Восстановление', 'Заминка и растяжка']
    for k, nm in enumerate(names):
        t = rep(t, '<h3 class="ag-xr__name">%s</h3>' % nm, '<h3 class="ag-xr__name">%s<span class="ag-xr__nt">%s</span></h3>' % (wheel(k), nm))
    t = focus3(t, R) if '#ag-dir07-03.ag-scope :is(' in t else t
    css = '''  /* «Педаль по кругу» — подсветка отрезка: stroke-opacity, толщина и цвет (opacity путей пишет движок) */
  #ag-dir07-03 .ag-xr__svg [data-ag-seg]{transition:stroke-opacity .2s ease,stroke-width .2s ease,stroke .2s ease;}
  #ag-dir07-03 .ag-xr__nl{transition:color .2s ease;}
  #ag-dir07-03 .ag-xr__fig.is-focus .ag-xr__svg [data-ag-seg]{stroke-opacity:.3;}
  #ag-dir07-03 .ag-xr__fig.is-focus .ag-xr__svg [data-ag-seg].is-on{stroke-opacity:1;}
  #ag-dir07-03 .ag-xr__fig.is-focus .ag-xr__road.is-on{stroke:var(--text);}
  #ag-dir07-03 .ag-xr__fig.is-focus .ag-xr__loop.is-on{stroke-width:5.5;}
  #ag-dir07-03 .ag-xr__fig.is-focus .ag-xr__nl{color:var(--faint);}
  #ag-dir07-03 .ag-xr__fig.is-focus .ag-xr__nl.is-on{color:var(--accent);}
  #ag-dir07-03 .ag-xr__ped{fill:var(--accent);stroke:var(--bg);stroke-width:3;opacity:0;transition:opacity .12s ease;pointer-events:none;}
  #ag-dir07-03 .ag-xr__ped.is-on{opacity:1;}
  #ag-dir07-03 .ag-xr__ped.is-on.is-off{opacity:0;}
  #ag-dir07-03 .ag-xr__step::before{transition:background-color .2s ease,box-shadow .2s ease;}
  #ag-dir07-03 .ag-xr__step.is-hover::before{background:var(--text);box-shadow:inset 0 0 0 2px var(--text);}
  #ag-dir07-03 .ag-xr__step--loop.is-hover::before{background:var(--accent);box-shadow:inset 0 0 0 2px var(--accent);}
  @media (max-width:1023px),(hover:none),(pointer:coarse){#ag-dir07-03 .ag-xr__ped{display:none;}}
  /* мини-маховик у шага: только < 1024 (на ПК схема рядом со списком) */
  #ag-dir07-03 .ag-xr__w{display:none;}
  #ag-dir07-03 .ag-xr__w path{fill:none;stroke-linecap:round;}
  #ag-dir07-03 .ag-xr__wr{stroke:rgba(244,244,245,.28);stroke-width:1.6;}
  #ag-dir07-03 .ag-xr__wl{stroke:rgba(255,196,0,.3);stroke-width:1.8;}
  #ag-dir07-03 .ag-xr__wr.is-me{stroke:var(--text);stroke-width:2.4;}
  #ag-dir07-03 .ag-xr__wl.is-me{stroke:var(--accent);stroke-width:2.8;}
  @media (max-width:1023px){
    #ag-dir07-03 .ag-xr__step{padding-left:0;}
    #ag-dir07-03 .ag-xr__step::before{display:none;}
    #ag-dir07-03 .ag-xr__name{display:flex;align-items:center;gap:10px;}
    #ag-dir07-03 .ag-xr__w{display:block;flex:none;width:30px;height:27.5px;margin:-4px 0;overflow:visible;}
  }
  @media (max-width:599px){
    #ag-dir07-03 .ag-xr__step{padding-left:0;}
  }
  @media (forced-colors:active){
    #ag-dir07-03 .ag-xr__ped{fill:Highlight;stroke:Canvas;}
    #ag-dir07-03 .ag-xr__fig.is-focus .ag-xr__svg [data-ag-seg]{stroke:GrayText;stroke-opacity:1;}
    #ag-dir07-03 .ag-xr__fig.is-focus .ag-xr__svg [data-ag-seg].is-on{stroke:Highlight;}
    #ag-dir07-03 .ag-xr__w path{stroke:GrayText;}
    #ag-dir07-03 .ag-xr__w path.is-me{stroke:Highlight;}
  }
  @media print{#ag-dir07-03 .ag-xr__w{display:none !important;}}
'''
    t = add_css(t, css)
    t = add_js(t, C03_JS)
    save(3, t)


# ---------------------------------------------------------------- DIR07-04
def c04():
    t = load(4); R = '#ag-dir07-04'
    t = bump(t, 4, 'F10: плашка выбранной вкладки переезжает (ПК — по столбцу, < 1024 — по сетке 2 × 2; замер offset* при\n'
                   '     выборе, ResizeObserver, смене раскладки — без проезда); выносная линия выбранной вкладки появляется после\n'
                   '     плашки. Фокус 3 px (и панели). Текст без изменений.')
    t = focus3(t, R)
    t = rep(t, '#ag-dir07-04 .ag-xw__panel:focus-visible{outline:2px', '#ag-dir07-04 .ag-xw__panel:focus-visible{outline:3px')
    t = rep(t, '    box.classList.add("is-js");\n    list.hidden = false;\n',
            '    box.classList.add("is-js");\n    list.hidden = false;\n'
            '    /* v1.1.0 · F10: плашка выбранной вкладки — ::before у списка по --px/--py/--pw/--ph */\n'
            '    var placed = false, jumpT = 0;\n'
            '    function place(jump) {\n'
            '      var t = tabs[current()];\n'
            '      if (!t) return;\n'
            '      if (jump) { W.clearTimeout(jumpT); list.classList.add("is-jump"); }\n'
            '      list.style.setProperty("--px", t.offsetLeft + "px");\n'
            '      list.style.setProperty("--py", t.offsetTop + "px");\n'
            '      list.style.setProperty("--pw", t.offsetWidth + "px");\n'
            '      list.style.setProperty("--ph", t.offsetHeight + "px");\n'
            '      list.classList.add("is-plate");\n'
            '      if (jump) jumpT = W.setTimeout(function () { list.classList.remove("is-jump"); }, 60);\n'
            '    }\n'
            '    if (W.ResizeObserver) new W.ResizeObserver(function () { place(true); }).observe(list);\n'
            '    else W.addEventListener("resize", function () { place(true); });\n')
    t = rep(t, '      if (focus) tabs[i].focus();\n      if (was !== i && !reduce',
            '      if (focus) tabs[i].focus();\n      place(!placed);\n      placed = true;\n      if (was !== i && !reduce')
    css = '''  /* F10 · плашка выбранной вкладки едет; линия к панели — после неё */
  #ag-dir07-04 .ag-xw__tabs{position:relative;isolation:isolate;}
  #ag-dir07-04 .ag-xw__tabs::before{
    content:"";position:absolute;left:0;top:0;z-index:-1;width:var(--pw,0px);height:var(--ph,0px);
    transform:translate(var(--px,0px),var(--py,0px));background:var(--tab-on);pointer-events:none;opacity:0;
    transition:transform .32s %(e)s,width .32s %(e)s,height .32s %(e)s;
  }
  #ag-dir07-04 .ag-xw__tabs.is-plate::before{opacity:1;}
  #ag-dir07-04 .ag-xw__tabs.is-jump::before{transition:none;}
  #ag-dir07-04 .ag-xw__tabs.is-plate .ag-xw__tab[aria-selected="true"]{background:transparent;}
  #ag-dir07-04 .ag-xw__tab[aria-selected="true"]::before{transition-delay:.22s;}
  #ag-dir07-04 .ag-xw__tab[aria-selected="true"]::after{transition-delay:.4s;}
  @media (max-width:1023px){
    #ag-dir07-04 .ag-xw__tabs::before{border:1px solid rgba(255,196,0,.5);border-radius:12px;}
    #ag-dir07-04 .ag-xw__tabs.is-plate .ag-xw__tab[aria-selected="true"]{border-color:transparent;}
  }
  @media (forced-colors:active){
    #ag-dir07-04 .ag-xw__tabs::before{display:none;}
  }
''' % {'e': E}
    t = add_css(t, css)
    t = touch(t)
    save(4, t)


# ---------------------------------------------------------------- DIR07-05
def c05():
    t = load(5); R = '#ag-dir07-05'
    t = bump(t, 5, 'F23 — нажатие кнопки «Все тренеры Apollo», фокус 3 px. Состав и текст — как есть.')
    t = wrap(t, 'a', 'ag-btn ag-btn--ghost', 'ag-btn__in')
    t = focus3(t, R)
    t = add_css(t, press_css(R, [('ag-btn', 'ag-btn__in')]))
    t = touch(t)
    save(5, t)


# ---------------------------------------------------------------- DIR07-06
def c06():
    t = load(6); R = '#ag-dir07-06'
    t = bump(t, 6, 'F29 зерно бумаги (≥ 640 px), F23, фокус 3 px. Условия сайкла и прайс — как есть (цена и бесплатное первое\n'
                   '     занятие для сайкла не наследуются, 5.4).')
    t = wrap(t, 'a', 'ag-btn ag-btn--ink', 'ag-btn__in')
    t = focus3(t, R)
    css = press_css(R, [('ag-btn', 'ag-btn__in')])
    css += grain_css(R, 'ag-xp', 'ag-xp__wrap')
    t = add_css(t, css)
    t = touch(t)
    save(6, t)


# ---------------------------------------------------------------- DIR07-07
def c07():
    t = load(7); R = '#ag-dir07-07'
    t = bump(t, 7, 'F22: ответ раскрывается плавно (::details-content + interpolate-size, прогрессивно; overflow-clip-margin);\n'
                   '     «Раскрыть все» — без перехода (флаг снимается таймером: toggle приходит асинхронно); пересчёт триггеров\n'
                   '     по окончании перехода. Печать — ответы видны. F23 — «Раскрыть все» и «Спросить расписание», фокус 3 px.\n'
                   '     Текст без изменений (FAQPage в HEAD совпадает).')
    t = wrap(t, 'button', 'ag-xq__all', 'ag-xq__ain')
    t = wrap(t, 'a', 'ag-xq__btn', 'ag-xq__bin')
    t = focus3(t, R)
    css = press_css(R, [('ag-xq__all', 'ag-xq__ain'), ('ag-xq__btn', 'ag-xq__bin')])
    css += '''  /* F22 · плавное раскрытие ответа (Chromium 131+); иначе — мгновенно, как было */
  @supports (interpolate-size:allow-keywords) and selector(::details-content){
    #ag-dir07-07 .ag-xq__list{interpolate-size:allow-keywords;}
    #ag-dir07-07 .ag-xq__item::details-content{
      height:0;overflow:clip;overflow-clip-margin:8px;
      transition:height .32s %(e)s,content-visibility .32s allow-discrete;
    }
    #ag-dir07-07 .ag-xq__item[open]::details-content{height:auto;}
    #ag-dir07-07.is-bulk .ag-xq__item::details-content{transition:none;}
    @media (prefers-reduced-motion:reduce){
      #ag-dir07-07 .ag-xq__item::details-content{transition:none;}
    }
  }
  @media print{
    #ag-dir07-07 .ag-xq__item::details-content{height:auto !important;content-visibility:visible !important;}
    #ag-dir07-07 .ag-xq__a{display:block !important;}
  }
''' % {'e': E}
    t = add_css(t, css)
    t = rx(t, r'(      busy = true;\n)(.*?)(      busy = false;\n)',
           lambda m: m.group(1) + '      root.classList.add("is-bulk");\n' + m.group(2)
           + '      W.setTimeout(function () { busy = false; root.classList.remove("is-bulk"); }, 80);\n')
    t = rep(t, '      d.addEventListener("toggle", function () { if (!busy) { sync(); refresh(); } });\n    });\n',
            '      d.addEventListener("toggle", function () { if (!busy) { sync(); refresh(); } });\n    });\n'
            '    /* v1.1.0: высота ответа меняется переходом — пересчитать позиции анимаций ниже по окончании */\n'
            '    root.addEventListener("transitionend", function (e) {\n'
            '      if (e.propertyName === "height" && e.pseudoElement === "::details-content") refresh();\n'
            '    });\n')
    t = rep(t, '    btn.hidden = false;\n', '    btn.hidden = false;\n' + TOUCH)
    save(7, t)


# ---------------------------------------------------------------- DIR07-08
def c08():
    t = load(8); R = '#ag-dir07-08'
    t = bump(t, 8, 'Магнит снят, F23 — нажатие обеих кнопок, фокус 3 px. Контур «САЙКЛ» и его параллакс 0,08 — как в v1.0.0.')
    t = rx(t, r' data-ag-magnetic="0\.\d+"', '')
    t = wrap(t, 'a', 'ag-btn ag-btn--primary', 'ag-btn__in')
    t = wrap(t, 'a', 'ag-btn ag-btn--ghost', 'ag-btn__in')
    t = focus3(t, R)
    t = add_css(t, press_css(R, [('ag-btn', 'ag-btn__in')]))
    t = touch(t)
    save(8, t)


if __name__ == '__main__':
    for f in (c01, c02, c03, c04, c05, c06, c07, c08):
        f()
