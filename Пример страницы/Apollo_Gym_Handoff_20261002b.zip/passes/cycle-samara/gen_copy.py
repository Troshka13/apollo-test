# -*- coding: utf-8 -*-
import hashlib, html
B = [
 ('01','rec4002221001','Сайкл в Самаре','Магнит снят, нажатие кнопки, фокус','заменить код','CL04-01 · «Сайкл и функциональные тренировки на Молодогвардейской, 56»'),
 ('02','rec4002337501','Как настроить велотренажёр','«Деталь на чертеже»: термин в тексте подсвечивает деталь (ПК), зерно бумаги','заменить код','CL04-02 · «Три направления в двух зонах»'),
 ('03','rec4003190901','Из каких отрезков собирают занятие на сайкле','«Педаль по кругу» на ПК, мини-маховики у шагов на телефоне','заменить код','CL04-03 · «Из чего состоит функциональная тренировка»'),
 ('04','rec4003457501','Зачем берут сайкл','Плашка вкладок едет, линия к панели — после неё','заменить код','CL04-04 · «Что делают на каждом занятии»'),
 ('05','rec4003564301','Кто ведёт сайкл','Нажатие кнопки, фокус','заменить код','CL04-05 · «Кто ведёт группы на Молодогвардейской»'),
 ('06','rec4003665901','Цены на групповые тренировки Apollo','Зерно бумаги, нажатие кнопки','заменить код','CL04-06 · «Сколько стоит ходить на Молодогвардейскую»'),
 ('07','rec4004373401','Что спрашивают про сайкл','Плавный FAQ, ответы в печати','заменить код','CL04-07 · «Как добраться до Молодогвардейской, 56»'),
 ('08','rec4005325801','Хотите занять велотренажёр в студии','Магнит снят, нажатие кнопок','заменить код','CL04-08 · «Что спрашивают про зал на Молодогвардейской»'),
]
TITLE=''
DESC='Сайкл (сайклинг) в Самаре на Молодогвардейской, 56: групповые тренировки на велотренажёрах, настройка посадки, отрезки. Условия первого занятия — при записи.'
cards=[]
for n,rec,name,what,act,now in B:
    code=open('/dev/null' if n=='HEAD' else f'/home/claude/cy/out/DIR07-{n}_v1.1.0.html',encoding='utf-8').read()
    sha=hashlib.sha256(code.encode()).hexdigest()
    must=' is-must' if n=='HEAD' else ''
    cards.append(f'''<article class="blk{must}" id="b{n}">
  <header class="blk__head">
    <p class="blk__num">{"HEAD" if n=="HEAD" else "DIR07-"+n}<span>{"v1.1" if n=="HEAD" else "v1.1.0"}</span></p>
    <h2 class="blk__name">{html.escape(name)}</h2>
    <p class="blk__what">{html.escape(what)}</p>
  </header>
  <dl class="blk__meta">
    <div><dt>{"Где" if n=="HEAD" else "Запись Tilda"}</dt><dd>{"Настройки страницы → Дополнительно → HTML-код внутрь HEAD" if n=="HEAD" else ("<code>"+rec+"</code>" if rec.startswith("rec") else rec)}</dd></div>
    <div><dt>Сейчас там</dt><dd>{html.escape(now)}</dd></div>
    <div><dt>Действие</dt><dd class="act">{act}</dd></div>
    <div><dt>Проверка</dt><dd>заголовок «{html.escape(name)}»</dd></div>
    <div><dt>Размер</dt><dd>{len(code.encode())//1024} КБ</dd></div>
  </dl>
  <div class="blk__do">
    <button class="btn btn--main" type="button" data-copy="c{n}">Скопировать код</button>
    <span class="blk__state" data-state="c{n}" role="status" aria-live="polite"></span>
  </div>
  <details class="blk__code"><summary>Показать код</summary>
    <label class="vh" for="c{n}">Код {n}</label>
    <textarea id="c{n}" readonly spellcheck="false" data-sha="{sha}">{html.escape(code)}</textarea>
  </details>
</article>''')
page=open('/home/claude/cy/copy_tpl.html',encoding='utf-8').read()
page=page.replace('%%CARDS%%','\n'.join(cards)).replace('%%TITLE%%',html.escape(TITLE)).replace('%%DESC%%',html.escape(DESC)).replace('%%TL%%',str(len(TITLE))).replace('%%DL%%',str(len(DESC)))
open('/home/claude/cy/copy/cycle_blocks.html','w',encoding='utf-8').write(page)
print(len(page.encode()))
