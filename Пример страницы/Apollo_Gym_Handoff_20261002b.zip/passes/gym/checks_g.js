// /gym (CL03) · проверки прохода «дизайн, движение и фишка» (PROMPT_CL03_DESIGN_MOTION_v2)
const {open,settle}=require('./lib');const fs=require('fs'),path=require('path');
const AFTER='file://'+path.resolve('after.html'), BEFORE='file://'+path.resolve('before.html');
const out={};const log=(g,ok,msg)=>{const s=(ok?"pass ":"FAIL ")+msg;(out[g]=out[g]||[]).push(s);console.log(g+" "+s);};
const G=process.env.G||'LTCMFA';
async function txt(url){const {browser,page}=await open({reduce:true});await page.goto(url);await page.waitForTimeout(2600);
  const r=await page.evaluate(()=>{const o={};document.querySelectorAll('.ag-scope').forEach(r=>{const c=r.cloneNode(true);c.querySelectorAll('style,script,.ag-vh').forEach(x=>x.remove());
    if(r.id==='ag-cl03-06'){o['ag-cl03-06 подписи']=[...c.querySelectorAll('.ag-gg__cap')].map(x=>x.textContent.replace(/\s+/g,' ').trim()).join(' | ');c.querySelectorAll('.ag-gg__list,[data-ag-now],dialog').forEach(x=>x.remove());}
    o[r.id]=c.textContent.replace(/\s+/g,' ').trim();});return o;});await browser.close();return r;}
async function links(url){const {browser,page}=await open({reduce:true});await page.goto(url);await page.waitForTimeout(400);
  const r=await page.evaluate(()=>[...document.querySelectorAll('.ag-scope a[href]')].map(a=>a.closest('.ag-scope').id+' '+a.getAttribute('href')));await browser.close();return r;}
// счётчик кадров мешка (функция swingFrame в скрипте «Тяжёлый мешок»)
const RAF=`window.__rafF=0;const __r=window.requestAnimationFrame.bind(window);window.requestAnimationFrame=function(f){if(f&&f.name==='swingFrame')window.__rafF++;return __r(f);};`;
const BAG=`(()=>{const r=document.getElementById('ag-cl03-01');const s=r.querySelector('.ag-gh__swing');const tr=getComputedStyle(s).transform;let deg=0;if(tr&&tr!=='none'){const m=new DOMMatrix(tr);deg=Math.atan2(m.b,m.a)*180/Math.PI;}
  return {deg:+deg.toFixed(3),inline:s.style.transform,raf:window.__rafF||0,attr:r.hasAttribute('data-ag-ui-bag'),dent:!!r.querySelector('.ag-gh__dent'),floor:r.querySelector('.ag-gh__floor').style.transform};})()`;
// точка на кадре мешка: доля ширины fx и высоты fy
async function bagPt(page,fx,fy){return page.evaluate(([fx,fy])=>{const f=document.querySelector('#ag-cl03-01 .ag-gh__frame').getBoundingClientRect();return {x:f.left+f.width*fx,y:f.top+f.height*fy};},[fx,fy]);}
async function peakDeg(page,ms){return page.evaluate(ms=>new Promise(res=>{const s=document.querySelector('#ag-cl03-01 .ag-gh__swing');let mx=0,mn=0;const t0=performance.now();(function f(){const tr=getComputedStyle(s).transform;if(tr!=='none'){const m=new DOMMatrix(tr);const d=Math.atan2(m.b,m.a)*180/Math.PI;mx=Math.max(mx,d);mn=Math.min(mn,d);}if(performance.now()-t0<ms)requestAnimationFrame(f);else res([+mn.toFixed(2),+mx.toFixed(2)]);})();}),ms);}
(async()=>{
 if(G.includes('L')) for(const reduce of [false,true]) for(const fontsOff of [false,true]) for(const w of [320,360,390,768,1024,1440,1920]){
   const {browser,page}=await open({w,h:w<700?800:900,reduce,mobile:w<700,touch:w<700});
   if(fontsOff) await page.route('**/fonts.googleapis.com/**',r=>r.abort());
   await page.goto(AFTER);await settle(page);
   const r=await page.evaluate(()=>({ov:document.documentElement.scrollWidth>document.documentElement.clientWidth,h:document.body.scrollHeight}));
   log('L',!r.ov,`${w}px reduce=${reduce} fontsOff=${fontsOff} overflowX=${r.ov} h=${r.h}`);await browser.close();
 }
 if(G.includes('T')){const tb=await txt(BEFORE),ta=await txt(AFTER);
  const EXC={'ag-cl03-01':[['первое групповое занятие для взрослых','первое групповое занятие']],
   'ag-cl03-02':[['Зона с покрытием','Работа в парах']],
   'ag-cl03-05':[['Первое групповое занятие для взрослых — бесплатно.','Первое групповое занятие — бесплатно.']],
   'ag-cl03-07':[[' Скопировать адрес','']],
   'ag-cl03-08':[['Первое групповое занятие для взрослых — бесплатно.','Первое групповое занятие — бесплатно.']]};
  for(const id of Object.keys(tb)){if(/подписи/.test(id))continue;let a=ta[id];(EXC[id]||[]).forEach(([n,o])=>{a=a.split(n).join(o);});a=a.replace(/\s+/g,' ').trim();let i=0;while(i<tb[id].length&&tb[id][i]===a[i])i++;
   log('T',a===tb[id],id+(a===tb[id]?' текст совпадает'+(EXC[id]?' (кроме правок: '+EXC[id].map(x=>'«'+x[0]+'»').join(', ')+')':(id==='ag-cl03-06'?' (кроме подписей кадров)':'')):' РАЗНИЦА '+JSON.stringify(tb[id].slice(i-30,i+40))+' → '+JSON.stringify(a.slice(i-30,i+40))));}
  log('T',true,`06 подписи кадров: было «${tb['ag-cl03-06 подписи']}» → стало «${ta['ag-cl03-06 подписи']}»`);
  const bad=/ринг|душ|пояс|чемпион|автограф|магазин|мини-груп|небольш\w* групп/i;const caps=ta['ag-cl03-06 подписи']+' '+ta['ag-cl03-02'].slice(0,0);
  const alts=fs.readFileSync('after.html','utf8').match(/alt="[^"]*"|data-ag-ui-alt="[^"]*"|>(Зона с покрытием|Роспись на[^<]*|Витрина[^<]*|Раздевалка)</g).join(' ');
  log('T',!bad.test(caps)&&!bad.test(alts),`подписи и alt кадров без слов «ринг, душ, пояс, чемпион, автограф, магазин, мини-/небольшая группа»: ${!bad.test(caps)&&!bad.test(alts)}`);}
 if(G.includes('C')){const lb=await links(BEFORE),la=await links(AFTER);const add=la.filter(x=>!lb.includes(x)),rem=lb.filter(x=>!la.includes(x));
  const okAdd=add.every(x=>/^ag-cl03-06 https:\/\/static\.tildacdn\.pub\/.*\.jpe?g$/.test(x));
  log('C',rem.length===0&&add.length===3&&okAdd,`ссылки +${add.length} −${rem.length} (добавлены — файлы трёх кадров галереи: ${okAdd})`);}
 if(G.includes('M')){
  for(const mode of [{name:'js off',js:false},{name:'reduce',reduce:true},{name:'cdn fail',cdn:'fail'},{name:'cdn hang',cdn:'hang'}]){
   const {browser,page}=await open({w:390,h:800,mobile:true,...mode});await page.goto(AFTER,{waitUntil:'domcontentloaded'});await page.waitForTimeout(2700);
   if(mode.js!==false) for(let y=0;y<9000;y+=600){await page.evaluate(y=>scrollTo(0,y),y);await page.waitForTimeout(40);}
   const r=await page.evaluate(()=>{const bad=[];document.querySelectorAll('.ag-scope :is(p,h1,h2,h3,a,li,dt,dd,summary,td,th,figcaption)').forEach(el=>{if(el.closest('[aria-hidden="true"],[hidden],dialog'))return;let n=el,op=1;while(n&&n.nodeType===1){op*=parseFloat(getComputedStyle(n).opacity);n=n.parentElement;}if(getComputedStyle(el).display==='none')return;if(op<0.99&&el.textContent.trim())bad.push(el.textContent.trim().slice(0,30));});
     const s=document.querySelector('#ag-cl03-01 .ag-gh__swing');return {bad,m:document.documentElement.getAttribute('data-ag-motion'),tr:getComputedStyle(s).transform};});
   log('M',r.bad.length===0&&(r.tr==='none'),`${mode.name}: motion=${r.m} скрытых текстов ${r.bad.length} ${r.bad.slice(0,3).join('|')}; мешок в покое (${r.tr})`);await browser.close();}
  const {browser,page}=await open({w:1440});await page.goto(AFTER);await settle(page);
  const r=await page.evaluate(()=>{const o={};document.querySelectorAll('.ag-scope').forEach(root=>{const all=root.querySelectorAll('[data-ag-anim]');o[root.id]=[all.length,[...all].filter(e=>!e.hasAttribute('data-ag-done')).length];});return o;});
  for(const [id,[n,left]] of Object.entries(r)) log('M',left===0,`motion on: ${id} анимаций ${n}, не отсканировано ${left}`);await browser.close();}

 if(G.includes('F')){
  // ---- 01 «Тяжёлый мешок»: мышь
  {const {browser,page,errs}=await open({w:1440,h:900});await page.addInitScript(RAF);await page.goto(AFTER);await settle(page);
   const b0=await page.evaluate(BAG);
   log('F',b0.attr&&b0.inline===''&&b0.deg===0&&b0.raf===0,`мешок, ПК: до действия — покой (transform «${b0.inline}», кадров ${b0.raf}), фишка включена (data-ag-ui-bag)`);
   let p=await bagPt(page,0.15,0.75);await page.mouse.move(p.x,p.y);await page.waitForTimeout(2100);  // толчок наведения прошёл
   await page.waitForTimeout(1500);
   p=await bagPt(page,0.15,0.75);await page.mouse.down();await page.mouse.up();
   const [mnL,mxL]=await peakDeg(page,420);const bl=await page.evaluate(BAG);
   await page.waitForTimeout(4200);const s1=await page.evaluate(BAG);await page.waitForTimeout(800);const s2=await page.evaluate(BAG);
   log('F',mnL< -0.4&&mnL>=-3.05&&bl.dent&&/translateX\(\d/.test(bl.floor)||false,`мешок, ПК: удар слева-снизу — мешок уходит вправо (угол до ${mnL}°), вмятина есть, тень за низом (${bl.floor.slice(0,24)})`);
   log('F',s1.inline===''&&s2.raf===s1.raf&&s1.deg===0,`мешок, ПК: через 4,2 с — покой (transform «${s1.inline}»), кадров за 0,8 с после остановки: ${s2.raf-s1.raf}`);
   p=await bagPt(page,0.85,0.75);await page.mouse.move(p.x,p.y);await page.waitForTimeout(2200);await page.waitForTimeout(3500);
   p=await bagPt(page,0.85,0.75);await page.mouse.down();await page.mouse.up();const [mnR,mxR]=await peakDeg(page,420);
   log('F',mxR>0.4&&mxR<=3.05,`мешок, ПК: удар справа — уходит влево (угол до ${mxR}°)`);
   await page.waitForTimeout(4500);
   // серия ударов — потолок угла
   p=await bagPt(page,0.05,0.95);for(let k=0;k<12;k++){await page.mouse.down();await page.mouse.up();await page.waitForTimeout(60);}
   const [mn2,mx2]=await peakDeg(page,900);
   const ov=await page.evaluate(()=>{const t=document.querySelector('#ag-cl03-01 .ag-gh__text').getBoundingClientRect(),f=document.querySelector('#ag-cl03-01 .ag-gh__frame').getBoundingClientRect();return {hit:f.left<t.right-1,ox:document.documentElement.scrollWidth>document.documentElement.clientWidth};});
   log('F',Math.max(-mn2,mx2)<=3.05&&!ov.ox,`мешок, ПК: 12 ударов подряд — угол не больше потолка 3° (${mn2}…${mx2}), горизонтальной прокрутки нет`);
   await page.waitForTimeout(4500);
   // наведение — один лёгкий толчок, не чаще раза в 2 с
   const a0=(await page.evaluate(BAG)).raf;p=await bagPt(page,0.3,0.3);await page.mouse.move(p.x-400,p.y);await page.waitForTimeout(100);await page.mouse.move(p.x,p.y,{steps:4});
   const [hn,hx]=await peakDeg(page,500);const a1=(await page.evaluate(BAG)).raf;
   await page.mouse.move(p.x-400,p.y,{steps:3});await page.mouse.move(p.x,p.y,{steps:3});const [hn2,hx2]=await peakDeg(page,300);
   log('F',a1>a0&&Math.max(-hn,hx)<=0.65&&Math.max(-hn,hx)>0.05,`мешок, ПК: наведение — лёгкий толчок (до ${Math.max(-hn,hx)}°), повторное через 0,5 с не добавляет толчка (${Math.max(-hn2,hx2)}°)`);
   await page.waitForTimeout(3500);
   // параллакс кадра работает и после удара
   const im0=await page.$eval('#ag-cl03-01 .ag-gh__img',e=>getComputedStyle(e).transform);await page.evaluate(()=>scrollTo(0,300));await page.waitForTimeout(500);
   const im1=await page.$eval('#ag-cl03-01 .ag-gh__img',e=>getComputedStyle(e).transform);await page.evaluate(()=>scrollTo(0,0));await page.waitForTimeout(400);
   // вне экрана — стоп
   p=await bagPt(page,0.1,0.8);await page.mouse.move(p.x,p.y);await page.mouse.down();await page.mouse.up();await page.evaluate(()=>scrollTo(0,3000));await page.waitForTimeout(300);
   const g0=await page.evaluate(BAG);await page.waitForTimeout(500);const g1=await page.evaluate(BAG);
   log('F',im0!==im1&&g1.raf===g0.raf&&g0.inline==='',`мешок: параллакс кадра после удара работает (${im0.slice(0,30)} → ${im1.slice(0,30)}); удар и сразу прокрутка вниз — покой, кадров вне экрана ${g1.raf-g0.raf}`);
   // reduce на лету
   await page.evaluate(()=>scrollTo(0,0));await page.waitForTimeout(300);p=await bagPt(page,0.1,0.8);await page.mouse.move(p.x,p.y);await page.mouse.down();await page.mouse.up();await page.waitForTimeout(120);
   await page.emulateMedia({reducedMotion:'reduce'});await page.waitForTimeout(120);const rr=await page.evaluate(BAG);
   await page.mouse.down();await page.mouse.up();await page.waitForTimeout(200);const rr2=await page.evaluate(BAG);
   log('F',rr.inline===''&&!rr.attr&&rr2.inline===''&&rr2.deg===0&&errs.length===0,`мешок: reduce на лету — сразу покой, фишка выключена, удар ничего не делает; ошибок ${errs.length} ${errs[0]||''}`);
   await browser.close();}
  // кадр удара — для глаза
  {const {browser,page}=await open({w:1440,h:900});await page.goto(AFTER);await settle(page);const p=await bagPt(page,0.12,0.8);
   await page.mouse.move(p.x,p.y);await page.waitForTimeout(2300);await page.waitForTimeout(3000);await page.mouse.down();await page.mouse.up();await page.waitForTimeout(330);
   await page.screenshot({path:'shots/bag_hit_1440.png',clip:{x:700,y:0,width:740,height:780}});await browser.close();}
  // ширины 960 и 1024: мешок на максимальном угле не налезает на текст
  for(const w of [960,1024]){const {browser,page}=await open({w,h:900});await page.goto(AFTER);await settle(page);
   const p=await bagPt(page,0.97,0.97);await page.mouse.move(p.x,p.y);await page.waitForTimeout(2300);
   let worst=-1e9;for(let k=0;k<12;k++){await page.mouse.down();await page.mouse.up();await page.waitForTimeout(50);}
   for(let k=0;k<30;k++){const d=await page.evaluate(()=>{const t=document.querySelector('#ag-cl03-01 .ag-gh__text').getBoundingClientRect();const fr=document.querySelector('#ag-cl03-01 .ag-gh__frame').getBoundingClientRect();return t.right-fr.left;});worst=Math.max(worst,d);await page.waitForTimeout(30);}
   const ox=await page.evaluate(()=>document.documentElement.scrollWidth>document.documentElement.clientWidth);
   log('F',worst<=0&&!ox,`мешок ${w}px: при максимальном угле рамка не заходит на колонку текста (запас ${(-worst).toFixed(0)} px), overflowX ${ox}`);await browser.close();}
  // ---- 01: телефон — касание = удар; свайп от мешка — прокрутка без удара
  {const {browser,page,errs}=await open({w:390,h:844,mobile:true,touch:true});await page.addInitScript(RAF);await page.goto(AFTER);await settle(page);
   await page.evaluate(()=>{const f=document.querySelector('#ag-cl03-01 .ag-gh__frame').getBoundingClientRect();scrollTo(0,scrollY+f.top-200);});await page.waitForTimeout(400);
   let p=await bagPt(page,0.5,0.4);
   const cdp=await page.context().newCDPSession(page);const y0=await page.evaluate(()=>scrollY);
   await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x:p.x,y:p.y}]});
   for(let i=1;i<=12;i++){await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:p.x,y:p.y-i*25}]});await page.waitForTimeout(16);}
   await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await page.waitForTimeout(600);
   const y1=await page.evaluate(()=>scrollY);const s1=await page.evaluate(BAG);
   log('F',y1-y0>100&&s1.raf===0,`мешок, телефон: свайп от мешка прокручивает страницу (${y0}→${y1}), удара нет (кадров ${s1.raf})`);
   await page.evaluate(y=>scrollTo(0,y),y0);await page.waitForTimeout(400);p=await bagPt(page,0.2,0.8);
   await page.touchscreen.tap(p.x,p.y);const [mn,mx]=await peakDeg(page,420);const t1=await page.evaluate(BAG);
   await page.waitForTimeout(4200);const t2=await page.evaluate(BAG);await page.waitForTimeout(600);const t3=await page.evaluate(BAG);
   log('F',mn< -0.3&&Math.max(-mn,mx)<=2.05&&t3.raf===t2.raf&&t2.inline===''&&errs.length===0,`мешок, телефон: касание слева — мешок уходит вправо (до ${mn}°, потолок 2°), потом покой, кадров после остановки ${t3.raf-t2.raf}; ошибок ${errs.length}`);
   await page.screenshot({path:'shots/bag_390.png',clip:{x:0,y:0,width:390,height:844}});
   await browser.close();}
  // ---- 01: reduce и forced-colors — удар ничего не делает
  for(const md of [{reduce:true,n:'reduce'},{forced:true,n:'forced-colors'}]){
   const {browser,page}=await open({w:1440,h:900,reduce:!!md.reduce});if(md.forced)await page.emulateMedia({forcedColors:'active'});await page.addInitScript(RAF);await page.goto(AFTER);await settle(page);
   const p=await bagPt(page,0.1,0.8);await page.mouse.move(p.x,p.y,{steps:4});await page.mouse.down();await page.mouse.up();await page.waitForTimeout(300);const r=await page.evaluate(BAG);
   log('F',r.raf===0&&r.deg===0&&!r.attr,`мешок, ${md.n}: наведение и удар — покой, кадров ${r.raf}, фишка выключена`);await browser.close();}
  // ---- 06 F07 «кадр целиком» + просмотрщик
  {const {browser,page,errs}=await open({w:1440,h:900});await page.goto(AFTER);await settle(page);
   await page.evaluate(()=>document.getElementById('ag-cl03-06').scrollIntoView());await page.waitForTimeout(500);
   const n=await page.$$eval('#ag-cl03-06 .ag-gg__item',x=>x.length);const nt=await page.$$eval('#ag-cl03-06 .ag-gg__thumb',x=>x.length);
   const op=await page.$$('#ag-cl03-06 .ag-gg__open');
   await op[0].focus();await page.keyboard.press('Enter');await page.waitForTimeout(250);
   const d1=await page.evaluate(()=>{const d=document.querySelector('#ag-cl03-06 dialog');return {open:d.open,modal:d.matches(':modal'),src:d.querySelector('img').getAttribute('src'),alt:d.querySelector('img').alt,cap:d.querySelector('[data-ag-ui-cap]').textContent,ov:document.documentElement.style.overflow};});
   const h0=await op[0].getAttribute('href');
   await page.keyboard.press('ArrowRight');await page.waitForTimeout(120);
   const d2=await page.evaluate(()=>({cap:document.querySelector('#ag-cl03-06 [data-ag-ui-cap]').textContent,pressed:[...document.querySelectorAll('#ag-cl03-06 .ag-gg__thumb')].map(b=>b.getAttribute('aria-pressed')).join(','),on:[...document.querySelectorAll('#ag-cl03-06 .ag-gg__item')].findIndex(li=>li.classList.contains('is-on'))}));
   await page.screenshot({path:'shots/dialog_1440.png'});
   await page.keyboard.press('Escape');await page.waitForTimeout(150);
   const d3=await page.evaluate(()=>({open:document.querySelector('#ag-cl03-06 dialog').open,f:(document.activeElement.getAttribute('data-ag-params')||''),on:[...document.querySelectorAll('#ag-cl03-06 .ag-gg__item')].findIndex(li=>li.classList.contains('is-on')),ov:document.documentElement.style.overflow}));
   log('F',n===3&&nt===3&&d1.open&&d1.modal&&d1.src===h0&&d1.cap==='Кадр 1 из 3 · Роспись на стене зала'&&/Стойка администратора/.test(d1.alt)&&d1.ov==='hidden',`кадр целиком: 3 кадра и 3 миниатюры; Enter на лупе — модальное окно, файл кадра, «${d1.cap}», фон не прокручивается`);
   log('F',/^Кадр 2 из 3 · Витрина с перчатками$/.test(d2.cap)&&d2.pressed==='false,true,false'&&d2.on===1&&!d3.open&&/"n":2/.test(d3.f)&&d3.on===1&&d3.ov==='',`кадр целиком: → в окне листает и просмотрщик («${d2.cap}», миниатюры ${d2.pressed}); Escape — окно закрыто, просмотрщик на 2-м кадре, фокус на его лупе; ошибок ${errs.length}`);
   // клик по тёмному полю закрывает; стрелки просмотрщика по-прежнему работают
   await page.click('#ag-cl03-06 .ag-gg__item.is-on .ag-gg__open');await page.waitForTimeout(200);await page.mouse.click(8,450);await page.waitForTimeout(150);
   const o2=await page.evaluate(()=>document.querySelector('#ag-cl03-06 dialog').open);
   await page.click('#ag-cl03-06 [data-ag-next]');await page.waitForTimeout(400);const on2=await page.evaluate(()=>[...document.querySelectorAll('#ag-cl03-06 .ag-gg__item')].findIndex(li=>li.classList.contains('is-on')));
   log('F',!o2&&on2===2,`кадр целиком: щелчок по тёмному полю закрыл; стрелка просмотрщика → кадр ${on2+1}`);
   await browser.close();}
  {const {browser,page}=await open({w:390,h:844,mobile:true,touch:true});await page.goto(AFTER);await settle(page);
   await page.evaluate(()=>document.getElementById('ag-cl03-06').scrollIntoView());await page.waitForTimeout(400);
   // свайп по кадру листает, окно не открывает
   const fr=await (await page.$('#ag-cl03-06 .ag-gg__item.is-on .ag-gg__frame')).boundingBox();const cdp=await page.context().newCDPSession(page);
   await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x:fr.x+fr.width*0.8,y:fr.y+fr.height/2}]});
   for(let i=1;i<=8;i++){await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:fr.x+fr.width*0.8-i*25,y:fr.y+fr.height/2}]});await page.waitForTimeout(16);}
   await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await page.waitForTimeout(400);
   const sw=await page.evaluate(()=>({open:document.querySelector('#ag-cl03-06 dialog').open,on:[...document.querySelectorAll('#ag-cl03-06 .ag-gg__item')].findIndex(li=>li.classList.contains('is-on'))}));
   const z=await (await page.$('#ag-cl03-06 .ag-gg__item.is-on .ag-gg__zoom')).boundingBox();await page.touchscreen.tap(z.x+z.width/2,z.y+z.height/2);await page.waitForTimeout(300);
   const r=await page.evaluate(()=>{const d=document.querySelector('#ag-cl03-06 dialog');const bs=[...d.querySelectorAll('button')].map(b=>b.getBoundingClientRect());return {open:d.open,btn:bs.every(b=>b.width>=44&&b.height>=44&&b.bottom<=innerHeight&&b.right<=innerWidth),cap:d.querySelector('[data-ag-ui-cap]').textContent};});
   await page.screenshot({path:'shots/dialog_390.png'});
   log('F',!sw.open&&sw.on===1&&r.open&&r.btn&&z.width>=44,`кадр целиком, телефон: свайп листает (кадр ${sw.on+1}) и окно не открывает; касание лупы (${Math.round(z.width)} px) — окно «${r.cap}», кнопки ≥ 44 px в экране`);await browser.close();}
  // ---- 04 F10 подложка
  const ind=(i)=>`(()=>{const l=document.querySelector('#ag-cl03-04 .ag-gd__tabs'),t=document.querySelectorAll('#ag-cl03-04 .ag-gd__tab')[${i}];const cs=getComputedStyle(l,'::before');const m=new DOMMatrix(cs.transform);return {x:m.m41,y:m.m42,w:parseFloat(cs.width),h:parseFloat(cs.height),z:cs.zIndex,tx:t.offsetLeft,ty:t.offsetTop,tw:t.offsetWidth,th:t.offsetHeight,bg:getComputedStyle(t).backgroundColor,sel:t.getAttribute('aria-selected')};})()`;
  const ok=(r)=>Math.abs(r.x-r.tx)<1&&Math.abs(r.y-r.ty)<1&&Math.abs(r.w-r.tw)<1&&Math.abs(r.h-r.th)<1;
  {const {browser,page}=await open({w:1440,h:900});await page.goto(AFTER);await settle(page);
   await page.evaluate(()=>document.getElementById('ag-cl03-04').scrollIntoView());await page.waitForTimeout(600);
   const r0=await page.evaluate(ind(0));
   log('F',ok(r0)&&r0.sel==='true'&&r0.bg==='rgba(0, 0, 0, 0)'&&r0.z==='1',`подложка, ПК: под «Боксом» (${Math.round(r0.x)},${Math.round(r0.y)} ${Math.round(r0.w)}×${Math.round(r0.h)} ↔ ${r0.tx},${r0.ty} ${r0.tw}×${r0.th}), над фоном вкладок (z ${r0.z}), своя заливка выбранной прозрачна`);
   await page.click('#ag-cl03-04 .ag-gd__tab >> nth=2');await page.waitForTimeout(120);const mid=await page.evaluate(ind(2));await page.waitForTimeout(420);const r2=await page.evaluate(ind(2));
   await (await page.$('#ag-cl03-04')).screenshot({path:'shots/tabs_1440.png'});
   log('F',ok(r2)&&Math.abs(mid.y-r2.ty)>2&&mid.y>r0.ty&&r2.sel==='true',`подложка, ПК: клик «ФитБокс» — едет по столбцу (на 120 мс y=${Math.round(mid.y)}, в конце ${Math.round(r2.y)} ↔ ${r2.ty})`);
   await page.focus('#ag-cl03-04 .ag-gd__tab >> nth=2');await page.keyboard.press('ArrowUp');await page.waitForTimeout(450);const r1=await page.evaluate(ind(1));
   log('F',ok(r1)&&r1.sel==='true',`подложка, ПК: стрелка ↑ — «Тайский бокс», подложка следом`);
   await page.setViewportSize({width:768,height:900});await page.waitForTimeout(400);const a=await page.evaluate(ind(1));
   await page.setViewportSize({width:767,height:900});await page.waitForTimeout(400);const b=await page.evaluate(ind(1));
   log('F',ok(a)&&ok(b),`подложка: 1440 → 768 (столбец) → 767 (ряд) — на месте (${Math.round(a.x)},${Math.round(a.y)} / ${Math.round(b.x)},${Math.round(b.y)})`);
   await browser.close();}
  for(const w of [320,390]){const {browser,page}=await open({w,h:844,mobile:true,touch:true});await page.goto(AFTER);await settle(page);
   await page.evaluate(()=>document.getElementById('ag-cl03-04').scrollIntoView());await page.waitForTimeout(500);
   const bx=await (await page.$$('#ag-cl03-04 .ag-gd__tab'))[2].boundingBox();await page.touchscreen.tap(bx.x+bx.width/2,bx.y+bx.height/2);await page.waitForTimeout(120);
   const mid=await page.evaluate(ind(2));await page.waitForTimeout(420);const r=await page.evaluate(ind(2));
   const ov=await page.evaluate(()=>[...document.querySelectorAll('#ag-cl03-04 .ag-gd__tname')].some(e=>e.scrollWidth>e.clientWidth+1));
   if(w===390) await (await page.$('#ag-cl03-04')).screenshot({path:'shots/tabs_390.png'});
   log('F',ok(r)&&Math.abs(mid.x-r.tx)>2&&!ov,`подложка, телефон ${w}px: касание «ФитБокс» — едет по ряду (на 120 мс x=${Math.round(mid.x)}, в конце ${Math.round(r.x)} ↔ ${r.tx}), подписи не обрезаны`);await browser.close();}
  // ---- 07 «Скопировать адрес»
  {const {browser,page,errs}=await open({w:1440,h:900});await page.context().grantPermissions(['clipboard-read','clipboard-write']);
   await page.goto(AFTER);await settle(page);await page.evaluate(()=>document.getElementById('ag-cl03-07').scrollIntoView());await page.waitForTimeout(400);
   const st=await page.evaluate(()=>({copy:!document.querySelector('#ag-cl03-07 [data-ag-ui-copy]').hidden,share:!document.querySelector('#ag-cl03-07 [data-ag-share]').hidden}));
   await page.click('#ag-cl03-07 [data-ag-ui-copy]');await page.waitForTimeout(300);
   const r=await page.evaluate(async()=>{let clip='';try{clip=await Promise.race([navigator.clipboard.readText(),new Promise(r=>setTimeout(()=>r('(нет доступа: тайм-аут)'),1500))]);}catch(e){clip='(нет доступа: '+e.name+')';}return {note:document.querySelector('#ag-cl03-07 [data-ag-ui-copied]').textContent,clip,live:document.querySelector('#ag-cl03-07 [data-ag-ui-copied]').getAttribute('aria-live')};});
   await page.waitForTimeout(3200);const gone=await page.$eval('#ag-cl03-07 [data-ag-ui-copied]',e=>e.textContent);
   log('F',st.copy&&!st.share&&r.note==='Адрес скопирован'&&r.clip==='Самара, улица Ново-Садовая, 106Б'&&gone===''&&errs.length===0,`копирование, ПК: кнопка видна, «Поделиться» скрыта; после клика «${r.note}» (aria-live=${r.live}), в буфере «${r.clip}», через 3 с подтверждение ушло`);
   await browser.close();}
  {const {browser,page}=await open({w:390,h:844,mobile:true,touch:true});await page.addInitScript(()=>{navigator.share=()=>Promise.resolve();});await page.goto(AFTER);await settle(page);
   await page.evaluate(()=>document.getElementById('ag-cl03-07').scrollIntoView());await page.waitForTimeout(300);
   const r=await page.evaluate(()=>{const c=document.querySelector('#ag-cl03-07 [data-ag-ui-copy]'),s=document.querySelector('#ag-cl03-07 [data-ag-share]');const a=c.getBoundingClientRect(),b=s.getBoundingClientRect();return {c:!c.hidden,s:!s.hidden,row:Math.abs(a.top-b.top)<2,h:Math.round(a.height)};});
   await (await page.$('#ag-cl03-07')).screenshot({path:'shots/after/ag-cl03-07_390_share.png'});
   log('F',r.c&&r.s&&r.row&&r.h>=44,`копирование, телефон с Web Share: «Поделиться» и «Скопировать» в один ряд (${r.row}), высота кнопки ${r.h}`);await browser.close();}
  // ---- 08 F22 + FAQPage
  {const {browser,page}=await open({w:1440,h:900});await page.goto(AFTER);await settle(page);
   await page.evaluate(()=>document.getElementById('ag-cl03-08').scrollIntoView());await page.waitForTimeout(400);
   const H=n=>page.evaluate(n=>Math.round(document.querySelector('#ag-cl03-08 .ag-fq__item:nth-of-type('+n+')').getBoundingClientRect().height),n);
   const h0=await H(2);await page.click('#ag-cl03-08 .ag-fq__item:nth-of-type(2) summary');await page.waitForTimeout(90);const hm=await H(2);await page.waitForTimeout(450);const h1=await H(2);
   const HA=()=>page.evaluate(()=>[...document.querySelectorAll('#ag-cl03-08 .ag-fq__item')].map(d=>Math.round(d.getBoundingClientRect().height)).join(','));
   await page.click('#ag-cl03-08 .ag-fq__all');await page.waitForTimeout(40);const b1=await HA();await page.waitForTimeout(500);const b2=await HA();
   const st=await page.evaluate(()=>({open:[...document.querySelectorAll('#ag-cl03-08 .ag-fq__item')].filter(d=>d.open).length,btn:document.querySelector('#ag-cl03-08 .ag-fq__all').textContent.trim(),bulk:document.getElementById('ag-cl03-08').classList.contains('is-bulk')}));
   log('F',h0<hm&&hm<h1&&b1===b2&&st.open===6&&!st.bulk,`FAQ: ответ раскрывается плавно (высота ${h0} → ${hm} на 90 мс → ${h1}), «Раскрыть все» — все ${st.open} сразу без перехода (${b1===b2}), кнопка «${st.btn}», is-bulk снят`);
   const head=JSON.parse(fs.readFileSync('out/HEAD_gym_v1.1.html','utf8').match(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/)[1]);
   const faq=head['@graph'].find(n=>n['@type']==='FAQPage').mainEntity;const wp=head['@graph'].find(n=>n['@type']==='WebPage');
   const qs=await page.evaluate(()=>[...document.querySelectorAll('#ag-cl03-08 .ag-fq__item')].map(d=>[d.querySelector('.ag-fq__qt').textContent.replace(/\s+/g,' ').trim(),d.querySelector('.ag-fq__a').textContent.replace(/\s+/g,' ').trim()]));
   const same=qs.length===faq.length&&qs.every(([q,a],i)=>faq[i].name===q&&faq[i].acceptedAnswer.text===a);
   const ans=qs.map(x=>x[1]).find(t=>/бесплатно/.test(t))||'';
   log('F',same&&/для взрослых — бесплатно/.test(ans)&&/Взрослым первое групповое бесплатно\.$/.test(wp.description),`FAQPage в HEAD v1.1 = блок 08 дословно (${qs.length} вопросов): ${same}; description WebPage — «…${wp.description.slice(-60)}»`);
   await browser.close();}
  // ---- магниты, F23, зерно
  {const {browser,page}=await open({w:1440,h:900});await page.goto(AFTER);await settle(page);
   const mag=await page.$$eval('[data-ag-magnetic]',x=>x.length);log('F',mag===0,`магнитных кнопок: ${mag}`);
   const res=[];
   for(const [sel,inn] of [['#ag-cl03-01 .ag-btn--primary','.ag-btn__in'],['#ag-cl03-03 .ag-btn--primary','.ag-btn__in'],['#ag-cl03-04 .ag-btn--primary','.ag-btn__in'],['#ag-cl03-05 .ag-gp__btn--ink','.ag-gp__in'],['#ag-cl03-07 .ag-btn--primary','.ag-btn__in'],['#ag-cl03-08 .ag-fq__all','.ag-fq__ain']]){
    const el=await page.$(sel);if(!el){res.push(sel+': нет');continue;}await el.scrollIntoViewIfNeeded();await page.waitForTimeout(250);const b0=await el.boundingBox();
    await page.evaluate(s=>document.querySelector(s).addEventListener('click',e=>e.preventDefault(),{once:true}),sel);
    await page.mouse.move(b0.x+b0.width/2,b0.y+b0.height/2);await page.mouse.down();await page.waitForTimeout(220);
    const t=await page.$eval(sel+' '+inn,e=>getComputedStyle(e).transform);const b1=await el.boundingBox();await page.mouse.up();await page.waitForTimeout(80);res.push([sel.split(' ')[0].slice(-2),/matrix\(0\.98/.test(t)&&Math.abs(b1.x-b0.x)<0.5]);}
   log('F',res.every(r=>Array.isArray(r)&&r[1]===true),`F23 нажатие (scale .98, кнопка на месте): ${res.map(r=>Array.isArray(r)?r.join(':'):r).join(' ')}`);
   const gr=await page.evaluate(()=>['#ag-cl03-02 .ag-gz','#ag-cl03-05 .ag-gp'].map(s=>/svg/.test(getComputedStyle(document.querySelector(s),'::before').backgroundImage)));
   log('F',gr.every(Boolean),`зерно бумаги на ПК: 02 ${gr[0]}, 05 ${gr[1]}`);await browser.close();}
  {const {browser,page}=await open({w:390,h:844,mobile:true,touch:true});await page.goto(AFTER);await settle(page);
   const gr=await page.evaluate(()=>['#ag-cl03-02 .ag-gz','#ag-cl03-05 .ag-gp'].map(s=>/svg/.test(getComputedStyle(document.querySelector(s),'::before').backgroundImage)));
   log('F',!gr[0]&&!gr[1],`телефон: зерна нет (02 ${gr[0]}, 05 ${gr[1]})`);await browser.close();}
  // forced-colors: подложки нет, мешок неподвижен
  {const {browser,page}=await open({w:1440,h:900});await page.emulateMedia({forcedColors:'active'});await page.goto(AFTER);await settle(page);
   const fc=await page.evaluate(()=>({b:getComputedStyle(document.querySelector('#ag-cl03-04 .ag-gd__tabs'),'::before').content,sel:getComputedStyle(document.querySelector('#ag-cl03-04 .ag-gd__tab[aria-selected="true"]')).backgroundColor,sw:getComputedStyle(document.querySelector('#ag-cl03-01 .ag-gh__swing')).transform}));
   const p=await bagPt(page,0.5,0.5);await page.mouse.move(p.x,p.y);await page.waitForTimeout(700);const sw2=await page.$eval('#ag-cl03-01 .ag-gh__swing',e=>getComputedStyle(e).transform);
   await page.evaluate(()=>document.getElementById('ag-cl03-04').scrollIntoView());await page.waitForTimeout(300);await page.screenshot({path:'shots/forced_04.png'});
   log('F',fc.b==='none'&&fc.sel!=='rgba(0, 0, 0, 0)'&&sw2==='none',`forced-colors: подложки нет (${fc.b}), выбранная вкладка своей заливкой (${fc.sel}), мешок и при наведении неподвижен (${sw2})`);await browser.close();}
 }
 if(G.includes('A')){const axeSrc=fs.readFileSync(require.resolve('axe-core/axe.min.js'),'utf8');
  for(const m of [{w:1440},{w:1024},{w:390,mobile:true},{w:390,mobile:true,reduce:true},{w:390,nojs:true}]){
   let o;if(m.nojs){fs.writeFileSync('after_nojs.html',fs.readFileSync('after.html','utf8').replace(/<script>[\s\S]*?<\/script>/g,'').replace(/<!--[\s\S]*?-->/g,'').replace(/<noscript>([\s\S]*?)<\/noscript>/g,'$1'));o=await open({w:390,h:900});await o.page.goto('file://'+path.resolve('after_nojs.html'));await o.page.waitForTimeout(800);}
   else {o=await open({...m,h:900});await o.page.goto(AFTER);await settle(o.page);}
   await o.page.addScriptTag({content:axeSrc});const res=await o.page.evaluate(async()=>(await axe.run(document.getElementById('allrecords'),{resultTypes:['violations']})).violations.map(v=>[v.id,v.impact,v.nodes.length,v.nodes[0].target.join(' ')]));
   const s=res.filter(v=>/serious|critical/.test(v[1]));log('A',res.length===0,`${m.w}${m.reduce?' reduce':''}${m.nojs?' без JS':''}: нарушений ${res.length} (serious/critical ${s.length}) ${res.map(v=>v.join(':')).join(' ; ').slice(0,300)}`);await o.browser.close();}
  {const o=await open({w:1440,h:900});await o.page.goto(AFTER);await settle(o.page);
   const p=await bagPt(o.page,0.1,0.8);await o.page.mouse.move(p.x,p.y);await o.page.mouse.down();await o.page.mouse.up();
   await o.page.click('#ag-cl03-08 .ag-fq__all');await o.page.click('#ag-cl03-07 [data-ag-ui-copy]').catch(()=>{});
   await o.page.click('#ag-cl03-04 .ag-gd__tab >> nth=1');
   await o.page.evaluate(()=>document.getElementById('ag-cl03-06').scrollIntoView());await o.page.waitForTimeout(300);
   await o.page.click('#ag-cl03-06 .ag-gg__item.is-on .ag-gg__open');await o.page.waitForTimeout(300);
   await o.page.addScriptTag({content:axeSrc});const res=await o.page.evaluate(async()=>(await axe.run(document,{resultTypes:['violations']})).violations.map(v=>[v.id,v.impact,v.nodes[0].target.join(' ')]));
   log('A',res.length===0,`1440, окно кадра открыто + мешок после удара + вкладка выбрана + FAQ раскрыт + адрес скопирован: нарушений ${res.length} ${res.map(v=>v.join(':')).join(' ; ').slice(0,300)}`);await o.browser.close();}}
 fs.writeFileSync('checks_g_'+G+'.json',JSON.stringify(out,null,1));
 for(const g of Object.keys(out)){console.log('## '+g);out[g].forEach(x=>console.log('  '+x));}
})();
