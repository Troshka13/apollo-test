# -*- coding: utf-8 -*-
"""/gym (CL03) · проход «дизайн, движение и фишка» (PROMPT_CL03_DESIGN_MOTION_v2, 30.09.2026).
src/CL03-0N_*.html (03 — v1.0.2, 04 — v1.0.1) → out/CL03-0N_v1.1.0.html. Каждая замена обязана найтись нужное число раз."""
import re, os, sys

sys.path.insert(0, '/home/claude/pr')
from build_prices_dm import rep, rx, focus3, wrap, press_css, touch, GRAIN  # noqa: E402

SRC, OUT = 'src', 'out'
os.makedirs(OUT, exist_ok=True)
DATE = '30.09.2026'
BASE = {3: 'v1.0.2', 4: 'v1.0.1'}

IMG = {
    '1_2-1': 'https://static.tildacdn.pub/tild3462-3532-4939-a633-656637613062/1_2-1-1024x683.jpg',
    '1_15': 'https://static.tildacdn.pub/tild3565-3365-4830-b436-633539316331/1_15-1024x683.jpg',
    '1_16': 'https://static.tildacdn.pub/tild3566-3235-4265-b039-643661326635/1_16-1024x683.jpg',
    '1_13': 'https://static.tildacdn.pub/tild6662-3230-4664-b338-613431613566/1_13-683x1024.jpg',
    '1_19': 'https://static.tildacdn.pub/tild6334-3933-4430-b632-623034346430/1_19-683x1024.jpg',
    '1_17': 'https://static.tildacdn.pub/tild6461-6466-4961-b139-633434633963/1_17-683x1024.jpg',
    '1_18': 'https://static.tildacdn.pub/tild6236-3432-4762-a232-306539303563/1_18-683x1024.jpg',
}


def load(n):
    return open('%s/CL03-0%d_%s.html' % (SRC, n, BASE.get(n, 'v1.0.0')), encoding='utf-8').read()


def save(n, t):
    p = '%s/CL03-0%d_v1.1.0.html' % (OUT, n)
    open(p, 'w', encoding='utf-8').write(t)
    print('CL03-0%d v1.1.0 %6d байт' % (n, len(t.encode('utf-8'))))


def bump(t, n, note):
    base = BASE.get(n, 'v1.0.0')
    t = rx(t, r'(APOLLO GYM · CL03-0\d[^\n]*?)· %s · \d\d\.09\.2026' % re.escape(base), r'\1· v1.1.0 · 30.09.2026')
    i = t.index('-->') + 3
    return t[:i] + '\n<!-- v1.1.0 (проход «дизайн, движение и фишка», PROMPT_CL03_DESIGN_MOTION_v2, %s):\n     %s -->' % (DATE, note) + t[i:]


def add_css(t, css):
    i = t.index('  </style>')
    return t[:i] + '\n  /* ===== v1.1.0 · дизайн, движение и фишка (30.09) ===== */\n' + css + t[i:]


def grain_css(root, sec, wrap_cls):
    return '''  /* F29 · зерно бумаги (статично, только ≥ 640 px; forced-colors и печать — без зерна) */
  @media (min-width:640px){
    %(r)s .%(s)s::before{content:"";position:absolute;inset:0;z-index:0;pointer-events:none;opacity:.12;background-image:%(g)s;background-size:180px 180px;}
    %(r)s .%(w)s{position:relative;z-index:1;}
  }
  @media (forced-colors:active){%(r)s .%(s)s::before{display:none;}}
  @media print{%(r)s .%(s)s::before{display:none;}}
''' % {'r': root, 's': sec, 'w': wrap_cls, 'g': GRAIN}


def before_engine(t, js):
    i = t.index('<!-- Движок движения')
    return t[:i] + js.lstrip('\n') + '\n  ' + t[i:]


def add_touch_at_end(t, marker):
    """touchstart для iOS (F23) в блоке без «страховки скана»: в конец своего скрипта."""
    return rep(t, marker, '    /* iOS включает :active только при слушателе касания (F23) */\n'
                          '    root.addEventListener("touchstart", function () {}, { passive: true });\n' + marker)


# ---------------------------------------------------------------- CL03-01
BAG_JS = r'''
  <script>
  /* v1.1.0 · «Тяжёлый мешок» (ведущая фишка страницы). По мешку можно ударить: щелчок мышью или касание —
     мешок уходит от удара маятником (тяжёлый: период 1,6 с, ζ ≈ 0,2, два видимых размаха ≈ 3 с), ремни и кольцо
     идут с ним, тень на «полу» — за низом мешка; в точке удара — короткая «вмятина». Сторона удара задаёт
     направление, удар ниже — сильнее, удары копятся до потолка (ПК 3°, 600–959 px 2,5°, телефон 2°).
     Наведение мышью — один лёгкий толчок (≤ 0,6°, не чаще раза в 2 с). До первого действия читателя узлы
     не трогаем (первый экран и LCP как в v1.0.0); rAF только пока мешок качается; вне экрана и в скрытой
     вкладке — стоп и покой. Касание — удар, только если жест не стал прокруткой (без pointercancel, сдвиг
     ≤ 10 px, ≤ 350 мс); слушатели пассивные, touch-action не трогаем. reduce и forced-colors — фишки нет
     (на лету — покой и CSS v1.0.0). Параллакс кадра — у img, качание — у .ag-gh__swing: разные узлы. */
  (function () {
    "use strict";
    var W = window, D = document;
    var root = D.currentScript && D.currentScript.closest(".ag-scope");
    if (!root || root.hasAttribute("data-ag-ui-bag-on")) return;
    root.setAttribute("data-ag-ui-bag-on", "");
    var bag = root.querySelector(".ag-gh__bag");
    var swing = root.querySelector(".ag-gh__swing");
    var frame = root.querySelector(".ag-gh__frame");
    var floor = root.querySelector(".ag-gh__floor");
    if (!bag || !swing || !frame || !W.matchMedia || !W.requestAnimationFrame || !("IntersectionObserver" in W)) return;
    var mqR = W.matchMedia("(prefers-reduced-motion: reduce)");
    var mqF = W.matchMedia("(forced-colors: active)");
    var fine = W.matchMedia("(hover: hover) and (pointer: fine)");
    var W0 = 2 * Math.PI / 1.6, ZETA = 0.2;
    var th = 0, om = 0, raf = 0, last = 0, seen = true, on = false, down = null, nudgeAt = -1e9, H = 0, dent = null;
    function off() { return mqR.matches || mqF.matches; }
    function maxDeg() { var w = W.innerWidth || D.documentElement.clientWidth; return w >= 960 ? 3 : (w >= 600 ? 2.5 : 2); }
    function hang() { return parseFloat(W.getComputedStyle(root).getPropertyValue("--hang")) || 0; }
    function draw() {
      swing.style.transform = "rotate(" + th.toFixed(3) + "deg)";
      if (floor && H) {
        var k = Math.min(1, Math.abs(th) / maxDeg());
        floor.style.transform = "translateX(" + (-H * Math.sin(th * Math.PI / 180)).toFixed(1) + "px) scaleX(" + (1 - 0.06 * k).toFixed(3) + ")";
        floor.style.opacity = (1 - 0.2 * k).toFixed(3);
      }
    }
    function rest() {
      if (raf) W.cancelAnimationFrame(raf);
      raf = 0; th = 0; om = 0;
      swing.style.transform = "";
      if (floor) { floor.style.transform = ""; floor.style.opacity = ""; }
    }
    function swingFrame(now) {
      raf = 0;
      var dt = Math.min((now - last) / 1000, 1 / 30);
      last = now;
      var n = Math.max(1, Math.ceil(dt * 120)), h = dt / n;
      for (var i = 0; i < n; i++) { om += (-W0 * W0 * th - 2 * ZETA * W0 * om) * h; th += om * h; }
      var m = maxDeg();
      if (th > m) { th = m; if (om > 0) om = 0; } else if (th < -m) { th = -m; if (om < 0) om = 0; }
      if (Math.abs(th) < 0.05 && Math.abs(om) < 0.3) { rest(); return; }
      draw();
      if (seen && !D.hidden) raf = W.requestAnimationFrame(swingFrame); else rest();
    }
    function kick(v) {
      if (!seen || D.hidden) return;
      var cap = maxDeg() * W0 * 1.25;
      om = Math.max(-cap, Math.min(cap, om + v));
      H = Math.max(0, bag.clientHeight - 10);
      if (!raf) { last = W.performance.now(); raf = W.requestAnimationFrame(swingFrame); }
    }
    /* Точка на мешке: обратный поворот от оси (кольцо). getBoundingClientRect у повёрнутого узла — габарит, не точка */
    function local(e) {
      var r = bag.getBoundingClientRect();
      var px = r.left + r.width / 2, py = r.top + 10;
      var a = -th * Math.PI / 180, dx = e.clientX - px, dy = e.clientY - py;
      var ux = px + dx * Math.cos(a) - dy * Math.sin(a), uy = py + dx * Math.sin(a) + dy * Math.cos(a);
      return { x: ux - (r.left + frame.offsetLeft), y: uy - (r.top + hang() + frame.offsetTop), w: frame.offsetWidth, h: frame.offsetHeight };
    }
    function side(p) { var s = (p.x - p.w / 2) / (p.w / 2); return Math.abs(s) < 0.35 ? (s < 0 ? -0.35 : 0.35) : Math.max(-1, Math.min(1, s)); }
    function showDent(x, y) {
      if (!dent) {
        dent = D.createElement("span");
        dent.className = "ag-gh__dent";
        dent.setAttribute("aria-hidden", "true");
        var seam = frame.querySelector(".ag-gh__seam");
        frame.insertBefore(dent, seam || null);
      }
      dent.style.left = x.toFixed(1) + "px";
      dent.style.top = y.toFixed(1) + "px";
      if (dent.animate) {
        try { dent.animate([{ transform: "scale(.6)", opacity: 0.9 }, { transform: "scale(1.4)", opacity: 0 }], { duration: 260, easing: "cubic-bezier(.2,.7,.2,1)" }); } catch (err) {}
      }
    }
    function hit(e, power) {
      var p = local(e);
      if (p.x < 0 || p.y < 0 || p.x > p.w || p.y > p.h) return;
      var low = 0.6 + 0.8 * (p.y / p.h);
      kick(side(p) * low * maxDeg() * 0.7 * W0 * power);
      showDent(p.x, p.y);
    }
    function onEnter(e) {
      if (e.pointerType !== "mouse" || !fine.matches) return;
      var now = W.performance.now();
      if (now - nudgeAt < 2000) return;
      nudgeAt = now;
      var p = local(e);
      kick((p.x < p.w / 2 ? -1 : 1) * 0.6 * W0);
    }
    function onDown(e) {
      if (e.pointerType === "mouse") { if (e.button === 0) hit(e, 1); return; }
      down = { id: e.pointerId, x: e.clientX, y: e.clientY, t: W.performance.now(), ok: true };
    }
    function onUp(e) {
      if (!down || down.id !== e.pointerId) return;
      var moved = Math.abs(e.clientX - down.x) + Math.abs(e.clientY - down.y);
      if (down.ok && moved <= 10 && W.performance.now() - down.t <= 350) hit(e, 1);
      down = null;
    }
    function onCancel() { if (down) down.ok = false; down = null; }
    function enable() {
      if (on || off()) return;
      on = true;
      root.setAttribute("data-ag-ui-bag", "");
      bag.addEventListener("pointerenter", onEnter, { passive: true });
      bag.addEventListener("pointerdown", onDown, { passive: true });
      bag.addEventListener("pointerup", onUp, { passive: true });
      bag.addEventListener("pointercancel", onCancel, { passive: true });
    }
    function disable() {
      if (!on) return;
      on = false;
      bag.removeEventListener("pointerenter", onEnter);
      bag.removeEventListener("pointerdown", onDown);
      bag.removeEventListener("pointerup", onUp);
      bag.removeEventListener("pointercancel", onCancel);
      rest();
      root.removeAttribute("data-ag-ui-bag");
    }
    new IntersectionObserver(function (es) {
      seen = es[es.length - 1].isIntersecting;
      if (!seen) rest();
    }).observe(bag);
    D.addEventListener("visibilitychange", function () { if (D.hidden) rest(); });
    function onPref() { if (off()) disable(); else enable(); }
    [mqR, mqF].forEach(function (q) { if (q.addEventListener) q.addEventListener("change", onPref); else if (q.addListener) q.addListener(onPref); });
    enable();
  })();
  </script>
'''


def c01():
    t = load(1); R = '#ag-cl03-01'
    t = bump(t, 1, 'Кадр первого экрана — 1_2-1 (общий вид зала: роспись на стене, пол с логотипом; сверено глазами 30.09).\n'
                   '     Прежний 1_18 — душевая, со страницы снят. Ведущая фишка «Тяжёлый мешок»: по мешку можно ударить —\n'
                   '     маятник с затуханием, «вмятина» в точке удара, тень за низом мешка; наведение — лёгкий толчок\n'
                   '     (ограничения — в комментарии скрипта). Подвес на ≤ 959 px — отрезок 18 px над кольцом.\n'
                   '     Факт № 11: «0 ₽ — первое групповое занятие для взрослых». Магнит снят, F23, фокус 3 px.')
    t = rep(t, '«Первое групповое занятие — бесплатно». Две ячейки',
            '«Первое групповое занятие для взрослых — бесплатно» (v1.1.0). Две ячейки')
    t = rep(t, '<img class="ag-gh__img" src="%s" width="683" height="1024"' % IMG['1_18'],
            '<img class="ag-gh__img" src="%s" width="1024" height="683"' % IMG['1_2-1'])
    t = rep(t, '<b>0&nbsp;₽</b><span>первое групповое занятие</span>', '<b>0&nbsp;₽</b><span>первое групповое занятие для&nbsp;взрослых</span>')
    t = rep(t, ' data-ag-magnetic="0.18"', '')
    t = wrap(t, 'a', 'ag-btn ag-btn--primary', 'ag-btn__in')
    t = wrap(t, 'a', 'ag-btn ag-btn--ghost', 'ag-btn__in')
    t = focus3(t, R)
    css = press_css(R, [('ag-btn', 'ag-btn__in')])
    css += '''  /* Кадр 1_2-1 (горизонтальный): в рамке 4:5 — роспись с боксёром и пол с логотипом */
  #ag-cl03-01 .ag-gh__img{object-position:10% 50%;}
  @media (max-width:959px){#ag-cl03-01 .ag-gh__img{object-position:40% 55%;}}
  /* «Тяжёлый мешок»: при работающей фишке мешок качает скрипт — CSS-переход и поворот по наведению сняты */
  #ag-cl03-01[data-ag-ui-bag] .ag-gh__swing{transition:none;}
  #ag-cl03-01[data-ag-ui-bag] .ag-gh__bag:hover .ag-gh__swing{transform:none;}
  #ag-cl03-01[data-ag-ui-bag] .ag-gh__frame{cursor:pointer;}
  #ag-cl03-01 .ag-gh__dent{position:absolute;left:50%;top:50%;width:150px;height:150px;margin:-75px 0 0 -75px;border-radius:50%;pointer-events:none;opacity:0;
    background:radial-gradient(closest-side,rgba(9,9,10,.34) 0,rgba(9,9,10,.18) 38%,rgba(255,226,140,.34) 56%,rgba(255,226,140,0) 72%);}
  /* Подвес на ≤ 959 px: без него кольцо висит в воздухе */
  @media (max-width:959px){
    #ag-cl03-01 .ag-gh__line{display:block;height:calc(var(--hang) + 8px);}
  }
  @media (forced-colors:active){
    #ag-cl03-01 .ag-gh__swing{transform:none !important;}
    #ag-cl03-01 .ag-gh__dent{display:none;}
  }
  @media print{
    #ag-cl03-01 .ag-gh__swing{transform:none !important;}
    #ag-cl03-01 .ag-gh__dent{display:none;}
  }
'''
    t = add_css(t, css)
    t = touch(t)
    t = before_engine(t, BAG_JS)
    save(1, t)


# ---------------------------------------------------------------- CL03-02
def c02():
    t = load(2); R = '#ag-cl03-02'
    t = bump(t, 2, 'Кадр — 1_15 «Зона с покрытием» (сверено глазами 30.09): прежний 1_17 с подписью «Работа в парах» — раздевалка,\n'
                   '     людей на нём нет; снят со страницы. Кадрирование — на покрытие и тренажёры. F29 зерно бумаги (≥ 640 px),\n'
                   '     фокус 3 px. Текст — как есть (фраза «Ринга в этом зале нет» — вопрос владельцу, см. отчёт).')
    t = rep(t, '<img class="ag-gz__img" src="%s" width="683" height="1024" alt="Работа в парах в зале Apollo Gym на Ново-Садовой, 106Б"' % IMG['1_17'],
            '<img class="ag-gz__img" src="%s" width="1024" height="683" alt="Зона с покрытием, мячами и тренажёрами"' % IMG['1_15'])
    t = rep(t, '<span class="ag-gz__dot" aria-hidden="true"></span>Работа в парах</figcaption>',
            '<span class="ag-gz__dot" aria-hidden="true"></span>Зона с покрытием</figcaption>')
    t = focus3(t, R)
    css = '''  /* Кадр 1_15 (горизонтальный): покрытие, гребной тренажёр, мячи */
  #ag-cl03-02 .ag-gz__img{object-position:35% 50%;}
'''
    css += grain_css(R, 'ag-gz', 'ag-gz__wrap')
    t = add_css(t, css)
    save(2, t)


# ---------------------------------------------------------------- CL03-03
def c03():
    t = load(3); R = '#ag-cl03-03'
    t = bump(t, 3, 'От v1.0.2 (на тесте — v1.0.1 с именами в комментарии: заменить). Состав и текст — как есть.\n'
                   '     F23 — нажатие кнопок, фокус 3 px.')
    t = wrap(t, 'a', 'ag-btn ag-btn--primary ag-gt__primary', 'ag-btn__in')
    t = wrap(t, 'a', 'ag-btn ag-btn--ghost', 'ag-btn__in')
    t = focus3(t, R)
    t = add_css(t, press_css(R, [('ag-btn', 'ag-btn__in')]))
    t = touch(t)
    save(3, t)


# ---------------------------------------------------------------- CL03-04
IND_JS = '''    /* v1.1.0 · F10: жёлтая подложка выбранного направления переезжает (::before у tablist, над фоном вкладок,
       под подписями). ПК — по столбцу, телефон — по ряду; первая установка и смена раскладки — без перехода. */
    var ind = { on: false, x: null, y: null, cur: 0 };
    function placeInd(i, jump) {
      var t = tabs[i];
      ind.cur = i;
      if (!t || !t.offsetWidth) return;
      var x = t.offsetLeft, y = t.offsetTop;
      var wrapJump = ind.x !== null && Math.abs(ind.x - x) > 2 && Math.abs(ind.y - y) > 2;
      if (!ind.on || jump || wrapJump) list.classList.add("is-jump");
      list.style.setProperty("--ix", x + "px");
      list.style.setProperty("--iy", y + "px");
      list.style.setProperty("--iw", t.offsetWidth + "px");
      list.style.setProperty("--ih", t.offsetHeight + "px");
      if (!ind.on) { list.classList.add("is-ind"); ind.on = true; }
      else if (wrapJump && !jump && !reduce && list.animate) {
        try { list.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 180, easing: "ease-out", pseudoElement: "::before" }); } catch (e) {}
      }
      ind.x = x; ind.y = y;
      if (list.classList.contains("is-jump")) W.requestAnimationFrame(function () { W.requestAnimationFrame(function () { list.classList.remove("is-jump"); }); });
    }
'''


def c04():
    t = load(4); R = '#ag-cl03-04'
    t = bump(t, 4, 'От v1.0.1 (на тесте — v1.0.0 с именами в комментарии: заменить). F10: жёлтая подложка выбранного\n'
                   '     направления переезжает — на ПК по столбцу, на телефоне по ряду (340 мс); подложка над фоном\n'
                   '     вкладок и под подписями, текст выбранной темнеет с задержкой 140 мс; появление столбца вкладок —\n'
                   '     rise вместо stagger. F23, фокус 3 px.')
    t = rep(t, 'data-ag-anim="stagger" data-ag-children=".ag-gd__tab" data-ag-stagger="70" data-ag-distance="14">',
            'data-ag-anim="rise" data-ag-distance="14">')
    t = wrap(t, 'a', 'ag-btn ag-btn--primary', 'ag-btn__in')
    t = wrap(t, 'a', 'ag-btn ag-btn--ghost ag-gd__call', 'ag-btn__in')
    t = focus3(t, R)
    t = rep(t, '    function select(i, focus, byReader) {\n', IND_JS + '    function select(i, focus, byReader) {\n')
    t = rep(t, '      if (byReader) chosen = true;\n', '      placeInd(i, !byReader);\n      if (byReader) chosen = true;\n')
    t = rep(t, '    select(0, false, false);\n  })();',
            '    select(0, false, false);\n'
            '    if ("ResizeObserver" in W) new W.ResizeObserver(function () { placeInd(ind.cur, true); }).observe(list);\n'
            '    if (D.fonts && D.fonts.ready) D.fonts.ready.then(function () { placeInd(ind.cur, true); });\n  })();')
    css = press_css(R, [('ag-btn', 'ag-btn__in')])
    css += '''  /* F10 · подложка выбранного направления */
  #ag-cl03-04 .ag-gd__tabs{position:relative;isolation:isolate;}
  @media not (forced-colors:active){
    #ag-cl03-04 .ag-gd__tabs.is-ind::before{
      content:"";position:absolute;z-index:1;left:0;top:0;width:var(--iw,0px);height:var(--ih,0px);border-radius:var(--r);background:var(--accent);pointer-events:none;
      transform:translate(var(--ix,0px),var(--iy,0px));
      transition:transform .34s cubic-bezier(.22,.61,.36,1),width .34s cubic-bezier(.22,.61,.36,1),height .34s cubic-bezier(.22,.61,.36,1);
    }
    #ag-cl03-04 .ag-gd__tabs.is-jump::before{transition:none;}
    #ag-cl03-04 .ag-gd__tabs.is-ind .ag-gd__tname,
    #ag-cl03-04 .ag-gd__tabs.is-ind .ag-gd__tsub{position:relative;z-index:2;}
    #ag-cl03-04 .ag-gd__tabs.is-ind .ag-gd__tab[aria-selected="true"]{background:transparent;border-color:transparent;}
    #ag-cl03-04 .ag-gd__tabs.is-ind .ag-gd__tab[aria-selected="true"] .ag-gd__tname,
    #ag-cl03-04 .ag-gd__tabs.is-ind .ag-gd__tab[aria-selected="true"] .ag-gd__tsub{transition:color .2s ease .14s;}
    @media (max-width:767.98px){#ag-cl03-04 .ag-gd__tabs.is-ind::before{border-radius:12px;}}
    @media (prefers-reduced-motion:reduce){
      #ag-cl03-04 .ag-gd__tabs.is-ind::before,
      #ag-cl03-04 .ag-gd__tabs.is-ind .ag-gd__tab[aria-selected="true"] .ag-gd__tname,
      #ag-cl03-04 .ag-gd__tabs.is-ind .ag-gd__tab[aria-selected="true"] .ag-gd__tsub{transition:none;}
    }
  }
  @media print{#ag-cl03-04 .ag-gd__tabs::before{display:none;}}
'''
    t = add_css(t, css)
    t = touch(t)
    save(4, t)


# ---------------------------------------------------------------- CL03-05
def c05():
    t = load(5); R = '#ag-cl03-05'
    t = bump(t, 5, 'Факт № 11: «Первое групповое занятие для взрослых — бесплатно.» Таблица и тариф — как есть.\n'
                   '     F29 зерно бумаги (≥ 640 px). F23 — нажатие кнопок, фокус 3 px. Телефон: условия плотнее.')
    t = rep(t, '<b>Первое групповое занятие — бесплатно.</b>', '<b>Первое групповое занятие для взрослых — бесплатно.</b>')
    t = wrap(t, 'a', 'ag-gp__btn ag-gp__btn--ink', 'ag-gp__in')
    t = wrap(t, 'a', 'ag-gp__btn ag-gp__btn--line', 'ag-gp__in')
    t = focus3(t, R)
    css = press_css(R, [('ag-gp__btn', 'ag-gp__in')])
    css += grain_css(R, 'ag-gp', 'ag-gp__wrap')
    css += '''  @media (max-width:599.98px){
    /* «для взрослых» переносит строку — лист плотнее, телефон не длиннее v1.0.0 */
    #ag-cl03-05 .ag-gp__card{gap:14px;}
    #ag-cl03-05 .ag-gp__terms li{line-height:1.35;}
    #ag-cl03-05 .ag-gp__btn{min-height:48px;}
  }
'''
    t = add_css(t, css)
    t = touch(t)
    save(5, t)


# ---------------------------------------------------------------- CL03-06
FRAMES = [
    # (ключ, ширина, высота, подпись (HTML), alt)
    ('1_16', 1024, 683, 'Роспись на&nbsp;стене зала', 'Стойка администратора и роспись на стене зала Apollo Gym'),
    ('1_13', 683, 1024, 'Витрина с&nbsp;перчатками', 'Витрина с боксёрскими перчатками'),
    ('1_19', 683, 1024, 'Раздевалка', 'Раздевалка: шкафчики, скамья и зеркало'),
]

DLG6_JS = r'''
    /* v1.1.0 · F07 «кадр целиком»: ссылка поверх большого кадра ведёт на файл (без JS — так и остаётся);
       с JS кадр открывается во весь экран в <dialog> — то же состояние, что у просмотрщика: стрелки окна
       листают просмотрщик, после закрытия он стоит на том же кадре, фокус — на ссылку «открыть». */
    var dlg = root.querySelector("dialog");
    var opens = Array.prototype.slice.call(root.querySelectorAll("[data-ag-ui-open]"));
    if (dlg && typeof dlg.showModal === "function" && opens.length === items.length) {
      var dImg = dlg.querySelector("[data-ag-ui-img]"), dCap = dlg.querySelector("[data-ag-ui-cap]");
      var html = D.documentElement, keep = "";
      dlgFill = function (i) {
        if (!dlg.open) return;
        dImg.setAttribute("src", opens[i].getAttribute("href"));
        dImg.setAttribute("alt", opens[i].getAttribute("data-ag-ui-alt") || "");
        var txt = "Кадр " + (i + 1) + " из " + items.length + " · " + caps[i];
        if (dCap.firstChild) dCap.firstChild.nodeValue = txt; else dCap.appendChild(D.createTextNode(txt));
        if (!reduce && dImg.animate) { try { dImg.animate([{ opacity: 0.001 }, { opacity: 1 }], { duration: 200, easing: "ease-out" }); } catch (e) {} }
      };
      opens.forEach(function (a, i) {
        a.addEventListener("click", function (e) {
          if (e.metaKey || e.ctrlKey || e.shiftKey || e.button > 0) return;
          e.preventDefault();
          keep = html.style.overflow; html.style.overflow = "hidden";
          dlg.showModal();
          dlgFill(cur);
        });
      });
      dlg.querySelector("[data-ag-ui-prev]").addEventListener("click", function () { show(cur - 1, true); });
      dlg.querySelector("[data-ag-ui-next]").addEventListener("click", function () { show(cur + 1, true); });
      dlg.querySelector("[data-ag-ui-close]").addEventListener("click", function () { dlg.close(); });
      var dbox = dlg.querySelector(".ag-gg__dbox");
      dlg.addEventListener("click", function (e) { if (e.target === dlg || e.target === dbox) dlg.close(); });
      dlg.addEventListener("keydown", function (e) {
        if (e.key === "ArrowRight") { e.preventDefault(); show(cur + 1, true); }
        else if (e.key === "ArrowLeft") { e.preventDefault(); show(cur - 1, true); }
      });
      dlg.addEventListener("close", function () {
        html.style.overflow = keep;
        try { opens[cur].focus({ preventScroll: true }); } catch (e) { opens[cur].focus(); }
      });
    }
'''


def c06():
    t = load(6); R = '#ag-cl03-06'
    t = bump(t, 6, 'Кадры сверены глазами 30.09 (вопрос 10.4): людей на кадрах нет, подписи владельца не совпадали с кадрами.\n'
                   '     На 1_11, 1_10 (и 1_5) — ринг, а текст страницы говорит «ринга в этом зале нет»: до ответа владельца\n'
                   '     эти кадры не ставим. 1_2-1 ушёл в первый экран, 1_15 — в CL03-02. Остались три кадра, подписи — что\n'
                   '     видно: 1_16 «Роспись на стене зала» (в v1.0.0 не брали из-за подписи владельца\n'
                   '     о размере группы — подпись теперь по кадру), 1_13 «Витрина с перчатками», 1_19 «Раздевалка».\n'
                   '     F07 «кадр целиком»: лупа поверх кадра — ссылка на файл, с JS — <dialog> (общее состояние с\n'
                   '     просмотрщиком). Миниатюры — в ряд. Фокус 3 px.')
    # список кадров — заново, по шаблону первого пункта
    i = t.index('<ul class="ag-gg__list"')
    a = t.index('>', i) + 1
    b = t.index('        </ul>', a)
    lis = []
    for k, (key, w, h, cap, alt) in enumerate(FRAMES):
        src = IMG[key]
        cap_txt = re.sub(r'&nbsp;', ' ', cap)
        lis.append(
            '\n          <li class="ag-gg__item%s">\n'
            '            <figure class="ag-gg__fig">\n'
            '              <span class="ag-gg__frame"><img class="ag-gg__bg" src="%s" alt="" loading="lazy" decoding="async" aria-hidden="true">'
            '<img class="ag-gg__img" src="%s" width="%d" height="%d" alt="%s" loading="lazy" decoding="async">'
            '<a class="ag-gg__open" href="%s" data-ag-ui-open data-ag-ui-alt="%s" data-ag-track="gallery_open" data-ag-params=\'{"from":"CL03-06","n":%d}\'>'
            '<span class="ag-vh">Открыть кадр %d из %d целиком: %s</span>'
            '<svg class="ag-gg__zoom" width="20" height="20" viewBox="0 0 20 20" aria-hidden="true" focusable="false">'
            '<path d="M8.5 3.5a5 5 0 1 0 0 10 5 5 0 0 0 0-10ZM12.2 12.2 16.5 16.5M8.5 6.5v4M6.5 8.5h4" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg></a></span>\n'
            '              <figcaption class="ag-gg__cap"><span>%s</span></figcaption>\n'
            '            </figure>\n'
            '          </li>' % (' is-on' if k == 0 else '', src, src, w, h, alt, src, alt, k + 1, k + 1, len(FRAMES), cap_txt, cap))
    t = t[:a] + ''.join(lis) + '\n' + t[b:]
    # миниатюры
    i = t.index('data-ag-thumbs hidden')
    a = t.index('>', i) + 1
    b = t.index('        </div>', a)
    th = []
    for k, (key, w, h, cap, alt) in enumerate(FRAMES):
        th.append('\n          <button class="ag-gg__thumb" type="button" aria-pressed="%s" aria-label="Показать кадр: %s"><img src="%s" alt="" loading="lazy" decoding="async"></button>'
                  % ('true' if k == 0 else 'false', re.sub(r'&nbsp;', ' ', cap), IMG[key]))
    t = t[:a] + ''.join(th) + '\n' + t[b:]
    t = rep(t, '<p class="ag-gg__now" data-ag-now hidden aria-hidden="true"><span>Зал на <span class="ag-nw">Ново-Садовой,</span>&nbsp;106Б</span></p>',
            '<p class="ag-gg__now" data-ag-now hidden aria-hidden="true"><span>%s</span></p>' % FRAMES[0][3])
    # окно «кадр целиком»
    dialog = ('<dialog class="ag-gg__dlg" aria-labelledby="ag-cl03-06-dlg-t">'
              '<div class="ag-gg__dbox">'
              '<p class="ag-gg__dt" id="ag-cl03-06-dlg-t" data-ag-ui-cap aria-live="polite">Кадр 1 из %d</p>'
              '<img class="ag-gg__dimg" data-ag-ui-img src="%s" alt="" width="1024" height="683" loading="lazy" decoding="async">'
              '<div class="ag-gg__dnav">'
              '<button class="ag-gg__dbtn" type="button" data-ag-ui-prev><svg width="20" height="20" aria-hidden="true" focusable="false"><use href="#ag-cl03-06-i-l"/></svg><span class="ag-vh">Предыдущий кадр</span></button>'
              '<button class="ag-gg__dbtn" type="button" data-ag-ui-next><svg width="20" height="20" aria-hidden="true" focusable="false"><use href="#ag-cl03-06-i-r"/></svg><span class="ag-vh">Следующий кадр</span></button>'
              '</div>'
              '<button class="ag-gg__dx" type="button" data-ag-ui-close><svg width="20" height="20" viewBox="0 0 20 20" aria-hidden="true" focusable="false"><path d="M5 5l10 10M15 5 5 15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg><span class="ag-vh">Закрыть</span></button>'
              '</div></dialog>\n  ') % (len(FRAMES), IMG[FRAMES[0][0]])
    t = rep(t, '  </section>\n', '  ' + dialog + '</section>\n')
    # скрипт просмотрщика: общее состояние с окном
    t = rep(t, '    var cur = 0;\n', '    var cur = 0;\n    var dlgFill = null;\n')
    t = rep(t, '      setNow(i);\n', '      setNow(i);\n      if (dlgFill) dlgFill(i);\n')
    t = rep(t, '    setNow(0);\n  })();', DLG6_JS + '    setNow(0);\n  })();')
    t = rep(t, 'Позиция «кадр N из 6» — только для чтения с экрана. */', 'Позиция «кадр N из 3» — только для чтения с экрана. */')
    t = rep(t, '/* Без JS: сетка из шести кадров с подписями */', '/* Без JS: сетка из трёх кадров с подписями */')
    t = focus3(t, R)
    css = '''  /* F07 · ссылка «открыть кадр целиком»: вся рамка, значок лупы в верхнем углу (стрелки — внизу справа) */
  #ag-cl03-06 .ag-gg__open{position:absolute;inset:0;z-index:2;display:block;}
  #ag-cl03-06 .ag-gg__zoom{position:absolute;right:14px;top:14px;width:44px;height:44px;padding:11px;border-radius:50%;
    background:rgba(9,9,10,.62);box-shadow:inset 0 0 0 1px rgba(255,255,255,.24);color:var(--text);
    -webkit-backdrop-filter:blur(6px);backdrop-filter:blur(6px);transition:background-color .2s ease,color .2s ease;}
  #ag-cl03-06 .ag-gg__arrows{z-index:3;}
  #ag-cl03-06.ag-scope .ag-gg__open:focus-visible{outline:3px solid var(--accent);outline-offset:-4px;}
  @media (hover:hover){#ag-cl03-06 .ag-gg__open:hover .ag-gg__zoom{background:var(--accent);color:var(--accent-ink);}}
  #ag-cl03-06 .ag-gg__dlg{width:100vw;height:100vh;max-width:none;max-height:none;margin:0;padding:0;border:0;background:rgba(6,6,7,.96);color:var(--text);overscroll-behavior:contain;}
  #ag-cl03-06 .ag-gg__dlg::backdrop{background:rgba(6,6,7,.94);}
  #ag-cl03-06 .ag-gg__dbox{position:relative;display:grid;grid-template-rows:auto minmax(0,1fr) auto;gap:14px;width:100%;height:100%;padding:18px clamp(16px,4vw,48px) 22px;}
  #ag-cl03-06 .ag-gg__dt{margin:0;padding-right:56px;font-family:var(--f-display);font-size:15px;font-weight:600;letter-spacing:.08em;text-transform:uppercase;color:var(--text);min-height:44px;display:flex;align-items:center;}
  #ag-cl03-06 .ag-gg__dimg{display:block;width:auto;height:auto;max-width:100%;max-height:calc(100dvh - 150px);margin:auto;object-fit:contain;}
  #ag-cl03-06 .ag-gg__dnav{display:flex;justify-content:center;gap:14px;}
  #ag-cl03-06 .ag-gg__dbtn,#ag-cl03-06 .ag-gg__dx{display:inline-flex;align-items:center;justify-content:center;width:48px;height:48px;padding:0;border-radius:50%;
    box-shadow:inset 0 0 0 1px rgba(255,255,255,.28);background:rgba(20,20,22,.9);color:var(--text);cursor:pointer;}
  #ag-cl03-06 .ag-gg__dx{position:absolute;top:16px;right:clamp(16px,4vw,48px);}
  #ag-cl03-06.ag-scope .ag-gg__dlg button:focus-visible{outline:3px solid var(--accent);outline-offset:3px;}
  @media (hover:hover){#ag-cl03-06 .ag-gg__dbtn:hover,#ag-cl03-06 .ag-gg__dx:hover{color:var(--accent);box-shadow:inset 0 0 0 1px var(--accent);}}
  /* Три кадра: миниатюры в один ряд; на телефоне — 2:1 (высота как у шести квадратов) */
  @media (max-width:959.98px){
    #ag-cl03-06 .ag-gg__thumbs{grid-template-columns:repeat(3,minmax(0,1fr));}
    #ag-cl03-06 .ag-gg__thumb{aspect-ratio:2/1;}
  }
  @media (max-width:599.98px){
    #ag-cl03-06 .ag-gg__zoom{right:10px;top:10px;}
  }
  @media (forced-colors:active){#ag-cl03-06 .ag-gg__zoom,#ag-cl03-06 .ag-gg__dbtn,#ag-cl03-06 .ag-gg__dx{border:1px solid CanvasText;}}
  @media print{#ag-cl03-06 .ag-gg__zoom{display:none;}}
'''
    t = add_css(t, css)
    t = touch(t)
    save(6, t)


# ---------------------------------------------------------------- CL03-07
def share_new():
    src = open('/home/claude/mm/build_cl02_dm.py', encoding='utf-8').read()
    s = re.search(r"SHARE_NEW = '''(.*?)'''", src, re.S).group(1)
    s = s.replace('\\\\s', '\\s')
    for o, n in [('.ag-mr__street', '.ag-gr__street'), ('"Самара, улица Чкалова, 72"', '"Самара, улица Ново-Садовая, 106Б"'),
                 ('title: "Apollo MMA Gym", text: "Apollo MMA Gym, "', 'title: "Apollo Gym", text: "Apollo Gym, "')]:
        assert s.count(o) == 1, o
        s = s.replace(o, n)
    return s


def c07():
    t = load(7); R = '#ag-cl03-07'
    t = bump(t, 7, '«Скопировать адрес» (ПК и телефон, где есть буфер обмена) с подтверждением «Адрес скопирован» в aria-live;\n'
                   '     «Поделиться адресом» — только на сенсорном экране (на телефоне обе кнопки в один ряд). Карта — как была.\n'
                   '     F23 — нажатие кнопок, фокус 3 px.')
    t = rx(t, r'(<button class="ag-btn ag-btn--quiet" type="button" data-ag-share hidden>)(.*?)(</button>)',
           lambda m: m.group(1) + '<span class="ag-btn__in">' + m.group(2) + '</span>' + m.group(3))
    copybtn = ('<button class="ag-btn ag-btn--quiet" type="button" data-ag-ui-copy hidden><span class="ag-btn__in">'
               '<svg class="ag-btn__i" width="16" height="16" viewBox="0 0 16 16" aria-hidden="true" focusable="false">'
               '<rect x="5.5" y="5.5" width="8" height="8.5" rx="1.6" fill="none" stroke="currentColor" stroke-width="1.6"/>'
               '<path d="M10.5 3.5V3a1.5 1.5 0 0 0-1.5-1.5H4A1.5 1.5 0 0 0 2.5 3v6A1.5 1.5 0 0 0 4 10.5h.5" fill="none" stroke="currentColor" stroke-width="1.6"/></svg>'
               'Скопировать адрес</span></button> <span class="ag-gr__copied" data-ag-ui-copied aria-live="polite"></span>')
    t = rx(t, r'(<button class="ag-btn ag-btn--quiet" type="button" data-ag-share hidden>.*?</button>)', lambda m: m.group(1) + '\n          ' + copybtn)
    t = wrap(t, 'a', 'ag-btn ag-btn--primary', 'ag-btn__in')
    t = wrap(t, 'a', 'ag-btn ag-btn--ghost', 'ag-btn__in')
    t = wrap(t, 'a', 'ag-btn ag-btn--ghost ag-gr__call', 'ag-btn__in')
    t = focus3(t, R)
    old = '    var btn = root.querySelector("[data-ag-share]");\n'
    i = t.index(old)
    j = t.index('  })();\n', i) + len('  })();\n')
    t = t[:i] + share_new() + t[j:]
    css = press_css(R, [('ag-btn', 'ag-btn__in')])
    css += '''  #ag-cl03-07 .ag-gr__copied{flex-basis:100%;font-size:14px;font-weight:600;color:var(--kick);}
  #ag-cl03-07 .ag-gr__copied:empty{display:none;}
  @media (max-width:767.98px){
    /* «Скопировать» и «Поделиться» — в один ряд */
    #ag-cl03-07 .ag-btn--quiet{flex:1 1 40%;}
  }
'''
    t = add_css(t, css)
    save(7, t)


# ---------------------------------------------------------------- CL03-08
def c08():
    t = load(8); R = '#ag-cl03-08'
    t = bump(t, 8, 'Факт № 11 в ответе «Сколько стоит заниматься?»: «Первое групповое занятие для взрослых — бесплатно.»\n'
                   '     (FAQPage в HEAD — тем же текстом, генератор). F22: ответ раскрывается плавно (::details-content +\n'
                   '     interpolate-size, прогрессивно); «Раскрыть все» — без перехода; refresh и по toggle, и по окончании\n'
                   '     перехода высоты. F23 — нажатие «Раскрыть все», фокус 3 px.')
    t = rep(t, 'Первое групповое занятие — бесплатно.</p>', 'Первое групповое занятие для взрослых — бесплатно.</p>')
    t = wrap(t, 'button', 'ag-fq__all', 'ag-fq__ain')
    t = focus3(t, R)
    css = press_css(R, [('ag-fq__all', 'ag-fq__ain')])
    css += '''  /* F22 · плавное раскрытие ответа (Chromium 131+); иначе — мгновенно, как было */
  @supports (interpolate-size:allow-keywords) and selector(::details-content){
    #ag-cl03-08 .ag-fq__list{interpolate-size:allow-keywords;}
    #ag-cl03-08 .ag-fq__item::details-content{
      height:0;overflow:clip;
      transition:height .32s cubic-bezier(.22,.61,.36,1),content-visibility .32s allow-discrete;
    }
    #ag-cl03-08 .ag-fq__item[open]::details-content{height:auto;}
    #ag-cl03-08.is-bulk .ag-fq__item::details-content{transition:none;}
    @media (prefers-reduced-motion:reduce){
      #ag-cl03-08 .ag-fq__item::details-content{transition:none;}
    }
  }
'''
    t = add_css(t, css)
    t = rx(t, r'(      busy = true;\n)(.*?)(      busy = false;\n)',
           lambda m: m.group(1) + '      root.classList.add("is-bulk");\n' + m.group(2) + m.group(3)
           + '      W.requestAnimationFrame(function () { W.requestAnimationFrame(function () { root.classList.remove("is-bulk"); }); });\n')
    t = rep(t, '      d.addEventListener("toggle", function () { if (!busy) { sync(); refresh(); } });\n    });\n',
            '      d.addEventListener("toggle", function () { if (!busy) { sync(); refresh(); } });\n    });\n'
            '    /* v1.1.0: высота ответа меняется переходом — пересчитать позиции анимаций ниже по окончании */\n'
            '    root.addEventListener("transitionend", function (e) {\n'
            '      if (e.propertyName === "height" && e.pseudoElement === "::details-content") refresh();\n'
            '    });\n')
    t = touch(t)
    save(8, t)


# ---------------------------------------------------------------- CL03-09
def c09():
    t = load(9)
    t = bump(t, 9, 'Фокус 3 px. Остальное — как есть.')
    t = rep(t, '#ag-cl03-09.ag-scope a:focus-visible{outline:2px solid', '#ag-cl03-09.ag-scope a:focus-visible{outline:3px solid')
    save(9, t)


if __name__ == '__main__':
    for f in (c01, c02, c03, c04, c05, c06, c07, c08, c09):
        f()
