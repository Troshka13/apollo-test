# -*- coding: utf-8 -*-
"""/muay-thai-samara (DIR02) · проход «дизайн, движение и фишка» (PROMPT_DIR02_DESIGN_MOTION_v2, 01.10.2026).
src/DIR02-0N_*.html (05, 07 — v1.0.1) → out/DIR02-0N_v1.1.0.html. Каждая замена обязана найтись нужное число раз."""
import re, os, sys

sys.path.insert(0, '/home/claude/pr')
from build_prices_dm import rep, rx, focus3, wrap, press_css, touch, GRAIN  # noqa: E402

SRC, OUT = 'src', 'out'
os.makedirs(OUT, exist_ok=True)
DATE = '01.10.2026'
BASE = {5: 'v1.0.1', 7: 'v1.0.1'}
NUMS = [1, 2, 3, 4, 5, 6, 7, 9]

IMG = {
    '1_10': 'https://static.tildacdn.pub/tild3363-3434-4565-b334-663933366339/1_10-1024x683.jpg',
    'Zal_5': 'https://static.tildacdn.pub/tild6431-3366-4135-a466-383164353738/Zal_5-1024x683.jpg',
    'Zal_2': 'https://static.tildacdn.pub/tild3664-6661-4632-b134-326433383464/Zal_2-1024x683.jpg',
    'Zal_4': 'https://static.tildacdn.pub/tild3166-6164-4830-b734-616332326261/Zal_4-1024x683.jpg',
    'img_5431': 'https://static.tildacdn.pub/tild6435-3261-4039-b537-656637633435/img_5431-scaled.jpeg',
    'img_5464': 'https://static.tildacdn.pub/tild3334-6462-4835-b461-663439656337/img_5464-scaled.jpeg',
}


def load(n):
    return open('%s/DIR02-0%d_%s.html' % (SRC, n, BASE.get(n, 'v1.0.0')), encoding='utf-8').read()


def save(n, t):
    p = '%s/DIR02-0%d_v1.1.0.html' % (OUT, n)
    open(p, 'w', encoding='utf-8').write(t)
    print('DIR02-0%d v1.1.0 %6d байт' % (n, len(t.encode('utf-8'))))


def bump(t, n, note):
    base = BASE.get(n, 'v1.0.0')
    t = rx(t, r'(APOLLO GYM · DIR02-0\d[^\n]*?)· %s · \d\d\.09\.2026' % re.escape(base), r'\1· v1.1.0 · 01.10.2026')
    i = t.index('-->') + 3
    return t[:i] + '\n<!-- v1.1.0 (проход «дизайн, движение и фишка», PROMPT_DIR02_DESIGN_MOTION_v2, %s):\n     %s -->' % (DATE, note) + t[i:]


def add_css(t, css):
    i = t.index('  </style>')
    return t[:i] + '\n  /* ===== v1.1.0 · дизайн, движение и фишка (01.10) ===== */\n' + css + t[i:]


def grain_css(root, sec, wrap_cls):
    return '''  /* F29 · зерно бумаги (статично, только ≥ 640 px; forced-colors и печать — без зерна) */
  @media (min-width:640px){
    %(r)s .%(s)s::before{content:"";position:absolute;inset:0;z-index:0;pointer-events:none;opacity:.12;background-image:%(g)s;background-size:180px 180px;}
    %(r)s .%(w)s{position:relative;z-index:1;}
  }
  @media (forced-colors:active){%(r)s .%(s)s::before{display:none;}}
  @media print{%(r)s .%(s)s::before{display:none;}}
''' % {'r': root, 's': sec, 'w': wrap_cls, 'g': GRAIN}


# ---------------------------------------------------------------- DIR02-01
def c01():
    t = load(1); R = '#ag-dir02-01'
    t = bump(t, 1, 'Кадр — Zal_5 (мешки вдоль стены, Галактионовская, 81; сверен глазами, совпадает со слотом DIR02-01-hall и с\n'
                   '     текстом CL01/DIR02-04). Прежний 1_10 — стойка администратора с рингом на заднем плане (ринг на Ново-Садовой —\n'
                   '     открытый вопрос владельцу, см. /gym), со страницы снят. Факт № 11: «0 ₽ — первое групповое занятие для\n'
                   '     взрослых». Магнит снят, F23, фокус 3 px.')
    t = rep(t, '<img class="ag-mh__img" src="%s" width="1024" height="683" alt="Зал Apollo на Ново-Садовой, 106Б"' % IMG['1_10'],
            '<img class="ag-mh__img" src="%s" width="1024" height="683" alt="Мешки вдоль стены в зале Apollo Boxing Gym на Галактионовской, 81"' % IMG['Zal_5'])
    t = rep(t, '<figcaption class="ag-mh__label"><span class="ag-mh__dot" aria-hidden="true"></span><span class="ag-nw">Ново-Садовая,&nbsp;106Б</span></figcaption>',
            '<figcaption class="ag-mh__label"><span class="ag-mh__dot" aria-hidden="true"></span><span class="ag-nw">Галактионовская,&nbsp;81</span></figcaption>')
    t = rep(t, '<b>0&nbsp;₽</b><span class="ag-mh__cap"><span>первое групповое занятие</span></span>',
            '<b>0&nbsp;₽</b><span class="ag-mh__cap"><span>первое групповое занятие для&nbsp;взрослых</span></span>')
    t = rep(t, ' data-ag-magnetic="0.18"', '')
    t = wrap(t, 'a', 'ag-btn ag-btn--primary', 'ag-btn__in')
    t = focus3(t, R)
    t = add_css(t, press_css(R, [('ag-btn', 'ag-btn__in')]))
    t = touch(t)
    save(1, t)


# ---------------------------------------------------------------- DIR02-02
FIG_OLD_RE = r'<svg class="ag-wp__fig" viewBox="0 0 240 360" width="240" height="360" aria-hidden="true" focusable="false">.*?</svg>'
J = 'ag-wp__j ag-wp__j--'
FIG_NEW = '''<svg class="ag-wp__fig" viewBox="0 0 240 360" width="240" height="360" aria-hidden="true" focusable="false">
              <line class="ag-wp__ground" x1="54" y1="341" x2="186" y2="341"/>
              <g class="ag-wp__body">
                <circle cx="120" cy="42" r="20"/>
                <path class="ag-wp__torso" d="M92 80Q120 73 148 80L138 166H102Z"/>
                <path class="ag-wp__seg ag-wp__seg--elbows" d="M144 88 171 138"/>
                <path class="ag-wp__seg ag-wp__seg--fists" d="M171 138 160 72"/>
                <path class="ag-wp__seg ag-wp__seg--knees" d="M130 168 156 244"/>
                <path class="ag-wp__seg ag-wp__seg--shins" d="M156 244 159 312 172 327"/>
                <g class="%(j)ship"><path class="ag-wp__seg ag-wp__seg--knees" d="M110 168 84 244"/><g class="%(j)sknee"><path class="ag-wp__seg ag-wp__seg--shins" d="M84 244 86 318 70 324"/></g></g>
                <g class="%(j)ssh"><path class="ag-wp__seg ag-wp__seg--elbows" d="M96 88 69 138"/><g class="%(j)sel"><path class="ag-wp__seg ag-wp__seg--fists" d="M69 138 80 72"/></g></g>
              </g>
              <path class="ag-wp__shorts" d="M99 158H141L151 204H126L120 190L114 204H89Z"/>
              <path class="ag-wp__belt" d="M100 162H140"/>
              <circle class="ag-wp__pt ag-wp__pt--fists" cx="158" cy="54" r="16"/>
              <circle class="ag-wp__pt ag-wp__pt--elbows" cx="171" cy="138" r="10"/>
              <circle class="ag-wp__pt ag-wp__pt--knees" cx="156" cy="244" r="10"/>
              <circle class="ag-wp__pt ag-wp__pt--shins" cx="158" cy="283" r="10"/>
              <g class="%(j)ship"><circle class="ag-wp__pt ag-wp__pt--knees" cx="84" cy="244" r="10"/><g class="%(j)sknee"><circle class="ag-wp__pt ag-wp__pt--shins" cx="85" cy="288" r="10"/></g></g>
              <g class="%(j)ssh"><circle class="ag-wp__pt ag-wp__pt--elbows" cx="69" cy="138" r="10"/><g class="%(j)sel"><g class="%(j)sglove"><circle class="ag-wp__pt ag-wp__pt--fists" cx="82" cy="54" r="16"/></g></g></g>
              <g class="ag-wp__zones" data-ag-ui-zones hidden>
                <rect data-ag-ui-zone="fists" x="20" y="0" width="200" height="98"/>
                <rect data-ag-ui-zone="elbows" x="20" y="98" width="200" height="98"/>
                <rect data-ag-ui-zone="knees" x="20" y="196" width="200" height="74"/>
                <rect data-ag-ui-zone="shins" x="20" y="270" width="200" height="80"/>
              </g>
            </svg>''' % {'j': J}

# Позы: углы в градусах (плюс — по часовой), сторона бойца слева на экране; подобраны по снимкам стенда
POSES = {
    'fists':  {'sh': 15, 'el': 18},
    'elbows': {'sh': 62, 'el': 10},
    'knees':  {'hip': 85, 'knee': -120},
    'shins':  {'hip': 36, 'knee': -30},
}
PIV = {'sh': (96, 88), 'el': (69, 138), 'hip': (110, 168), 'knee': (84, 244)}

LEG_JS = r'''    /* v1.1.0 · «Боец показывает удар»: выбор пары ставит позу (атрибут корня data-ag-pose — только выбор, не наведение);
       касание фигуры по высоте — то же, что кнопка легенды (полосы-цели; схема aria-hidden, доступный путь — легенда).
       F10: жёлтая подложка нажатой кнопки едет по столбцу легенды (::before, над фоном кнопок, под подписью). */
    var leg = { on: false, cur: -1 };
    function placeLeg(jump) {
      var i = -1;
      keys.forEach(function (b, k) { if (b.getAttribute("aria-pressed") === "true") i = k; });
      var b = keys[i];
      if (!b || !b.offsetWidth) return;
      if (!leg.on || jump) legend.classList.add("is-jump");
      legend.style.setProperty("--iy", b.offsetTop + "px");
      legend.style.setProperty("--ix", b.offsetLeft + "px");
      legend.style.setProperty("--iw", b.offsetWidth + "px");
      legend.style.setProperty("--ih", b.offsetHeight + "px");
      if (!leg.on) { legend.classList.add("is-ind"); leg.on = true; }
      leg.cur = i;
      if (legend.classList.contains("is-jump")) W.requestAnimationFrame(function () { W.requestAnimationFrame(function () { legend.classList.remove("is-jump"); }); });
    }
'''


def c02():
    t = load(2); R = '#ag-dir02-02'
    t = bump(t, 2, 'Ведущая фишка «Боец показывает удар»: выбор пары ставит позу пиктограммы — «Руки»: прямой на зрителя (перчатка к осевой, крупнее);\n'
                   '     «Локти»: локоть в сторону на уровне плеча; «Колени»: колено вверх; «Ноги»: голень по дуге не выше корпуса.\n'
                   '     Двигается сторона бойца слева на экране (легенда справа). Механика: data-ag-pose (только выбор, не наведение),\n'
                   '     вложенные группы по суставам (сегменты и точки — в двух слоях, порядок отрисовки как в v1.0.0), CSS-переход\n'
                   '     300 мс; reduce — поза сразу; печать — стойка. Касание фигуры по высоте выбирает пару (полосы-цели, схема\n'
                   '     aria-hidden). F10: жёлтая подложка легенды едет к нажатой кнопке. F29 зерно бумаги (≥ 640 px), фокус 3 px.')
    t = rx(t, FIG_OLD_RE, lambda m: FIG_NEW)
    # поза — только по выбору
    t = rep(t, '      live.firstChild.nodeValue = hl ? hl.textContent : " ";\n      paint();\n',
            '      live.firstChild.nodeValue = hl ? hl.textContent : " ";\n      root.setAttribute("data-ag-pose", k);\n      paint();\n      placeLeg(false);\n')
    t = rep(t, '    function choose(k) {\n', LEG_JS + '    function choose(k) {\n')
    t = rep(t, '    root.setAttribute("data-ag-js", "");\n    legend.hidden = false;\n    choose("all");\n  })();',
            '    root.setAttribute("data-ag-js", "");\n    legend.hidden = false;\n    choose("all");\n'
            '    if ("ResizeObserver" in W) new W.ResizeObserver(function () { placeLeg(true); }).observe(legend);\n'
            '    if (D.fonts && D.fonts.ready) D.fonts.ready.then(function () { placeLeg(true); });\n'
            '    /* касание фигуры: полоса по высоте = кнопка легенды той же пары */\n'
            '    var zones = root.querySelector("[data-ag-ui-zones]");\n'
            '    if (zones) {\n'
            '      zones.removeAttribute("hidden");\n'
            '      zones.addEventListener("click", function (e) {\n'
            '        var z = e.target && e.target.getAttribute && e.target.getAttribute("data-ag-ui-zone");\n'
            '        var b = z && root.querySelector(\'.ag-wp__key[data-ag-key="\' + z + \'"]\');\n'
            '        if (b) b.click();\n'
            '      });\n'
            '    }\n  })();')
    t = focus3(t, R)
    pose_css = []
    for pose, angs in POSES.items():
        for j, a in angs.items():
            ox, oy = PIV[j]
            pose_css.append('  #ag-dir02-02[data-ag-pose="%s"] .ag-wp__j--%s{transform:translate(%dpx,%dpx) rotate(%ddeg) translate(%dpx,%dpx);}'
                            % (pose, j, ox, oy, a, -ox, -oy))
    css = '''  /* «Боец показывает удар»: суставы — вложенные группы, поворот вокруг сустава (координаты viewBox 240×360) */
  #ag-dir02-02 .ag-wp__j{transform-origin:0 0;transition:transform .3s cubic-bezier(.22,.61,.36,1);}
%s
  /* «Руки»: прямой на зрителя — перчатка у осевой на уровне подбородка и крупнее */
  #ag-dir02-02[data-ag-pose="fists"] .ag-wp__j--glove{transform:translate(82px,54px) scale(1.15) translate(-82px,-54px);}
  #ag-dir02-02 .ag-wp__zones{fill:transparent;cursor:pointer;}
  #ag-dir02-02 .ag-wp__zones[hidden]{display:none;}
  @media print{#ag-dir02-02 .ag-wp__j{transform:none !important;transition:none !important;}}
  /* F10 · подложка нажатой кнопки легенды: над фоном кнопок, под подписью */
  #ag-dir02-02 .ag-wp__legend{position:relative;isolation:isolate;}
  @media not (forced-colors:active){
    #ag-dir02-02 .ag-wp__legend.is-ind::before{
      content:"";position:absolute;z-index:1;left:0;top:0;width:var(--iw,0px);height:var(--ih,0px);border-radius:14px;background:var(--accent);pointer-events:none;
      transform:translate(var(--ix,0px),var(--iy,0px));transition:transform .3s cubic-bezier(.22,.61,.36,1),height .3s cubic-bezier(.22,.61,.36,1);
    }
    #ag-dir02-02 .ag-wp__legend.is-jump::before{transition:none;}
    #ag-dir02-02 .ag-wp__legend.is-ind .ag-wp__key>span{position:relative;z-index:2;}
    #ag-dir02-02 .ag-wp__legend.is-ind .ag-wp__key[aria-pressed="true"]{background:transparent;border-color:transparent;transition:background-color .25s ease,border-color .25s ease,color .2s ease .14s;}
    @media (max-width:599px){#ag-dir02-02 .ag-wp__legend.is-ind::before{border-radius:12px;}}
  }
  @media print{#ag-dir02-02 .ag-wp__legend::before{display:none;}}
''' % '\n'.join(pose_css)
    css += grain_css(R, 'ag-wp', 'ag-wp__wrap')
    t = add_css(t, css)
    save(2, t)


# ---------------------------------------------------------------- DIR02-03
def c03():
    t = load(3); R = '#ag-dir02-03'
    t = bump(t, 3, 'Фокус 3 px (если есть ссылки). Остальное — как есть.')
    if re.search(r'%s\.ag-scope :is\([^)]*\):focus-visible\{outline:2px' % re.escape(R), t):
        t = focus3(t, R)
    save(3, t)


# ---------------------------------------------------------------- DIR02-04
IND_JS = r'''    /* v1.1.0 · F10: жёлтая подложка выбранного зала переезжает (::before у tablist, над фоном вкладок, под подписями).
       Смена ряда (телефон, перенос 2+1 — стандарт 51) — перенос с проявлением; первая установка — без перехода. */
    var ind = { on: false, cur: 0, row: null };
    function placeInd(i, jump) {
      var t = tabs[i];
      ind.cur = i;
      if (!t || !t.offsetWidth) return;
      var row = t.offsetTop, wrapRow = ind.row !== null && Math.abs(row - ind.row) > t.offsetHeight / 2;
      if (!ind.on || jump || wrapRow) list.classList.add("is-jump");
      list.style.setProperty("--ix", t.offsetLeft + "px");
      list.style.setProperty("--iy", row + "px");
      list.style.setProperty("--iw", t.offsetWidth + "px");
      list.style.setProperty("--ih", t.offsetHeight + "px");
      if (!ind.on) { list.classList.add("is-ind"); ind.on = true; }
      else if (wrapRow && !jump && !reduce && list.animate) {
        try { list.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 180, easing: "ease-out", pseudoElement: "::before" }); } catch (e) {}
      }
      ind.row = row;
      if (list.classList.contains("is-jump")) W.requestAnimationFrame(function () { W.requestAnimationFrame(function () { list.classList.remove("is-jump"); }); });
    }
'''


def c04():
    t = load(4); R = '#ag-dir02-04'
    t = bump(t, 4, 'Кадры сверены глазами 01.10 и поставлены по тексту панели: «Галактионовская» — Zal_4 (ринг; прежний Zal_2 —\n'
                   '     силовой угол), «Чкалова» — img_5464 (клетка; прежний img_5431 — мяч, скамья, покрышка), «Ново-Садовая» — 1_16\n'
                   '     (стойка администратора и роспись). Alt — по кадру. F10: жёлтая подложка зала переезжает; на телефоне\n'
                   '     перенос ряда — с проявлением. F23 у кнопок, фокус 3 px.')
    t = rep(t, 'src="%s" width="1024" height="683" alt="Зал Apollo на Галактионовской, 81"' % IMG['Zal_2'],
            'src="%s" width="1024" height="683" alt="Ринг в зале Apollo Boxing Gym на Галактионовской, 81"' % IMG['Zal_4'])
    t = rep(t, 'src="%s" width="1024" height="683" alt="Зал Apollo на Чкалова, 72"' % IMG['img_5431'],
            'src="%s" width="1024" height="683" alt="Клетка для ММА в зале Apollo MMA Gym на Чкалова, 72"' % IMG['img_5464'])
    t = rep(t, 'alt="Зал Apollo на Ново-Садовой, 106Б"', 'alt="Стойка администратора и роспись на стене зала Apollo Gym"')
    t = wrap(t, 'a', 'ag-btn ag-btn--primary', 'ag-btn__in', 3)
    t = focus3(t, R)
    t = rep(t, '    function select(i, focus) {\n', IND_JS + '    function select(i, focus) {\n')
    t = rep(t, '      if (focus) tabs[i].focus();\n', '      placeInd(i, false);\n      if (focus) tabs[i].focus();\n')
    t = rep(t, '    select(current(), false);\n  })();',
            '    select(current(), false);\n'
            '    if ("ResizeObserver" in W) new W.ResizeObserver(function () { placeInd(ind.cur, true); }).observe(list);\n'
            '    if (D.fonts && D.fonts.ready) D.fonts.ready.then(function () { placeInd(ind.cur, true); });\n  })();')
    css = press_css(R, [('ag-btn', 'ag-btn__in')])
    css += '''  /* F10 · подложка выбранного зала */
  #ag-dir02-04 .ag-mz__tabs{position:relative;isolation:isolate;}
  @media not (forced-colors:active){
    #ag-dir02-04 .ag-mz__tabs.is-ind::before{
      content:"";position:absolute;z-index:1;left:0;top:0;width:var(--iw,0px);height:var(--ih,0px);border-radius:var(--r-pill);background:var(--accent);pointer-events:none;
      transform:translate(var(--ix,0px),var(--iy,0px));
      transition:transform .32s cubic-bezier(.22,.61,.36,1),width .32s cubic-bezier(.22,.61,.36,1),height .32s cubic-bezier(.22,.61,.36,1);
    }
    #ag-dir02-04 .ag-mz__tabs.is-jump::before{transition:none;}
    #ag-dir02-04 .ag-mz__tabs.is-ind .ag-mz__tab>*{position:relative;z-index:2;}
    #ag-dir02-04 .ag-mz__tabs.is-ind .ag-mz__tab[aria-selected="true"]{background:transparent;border-color:transparent;transition:background-color .2s ease,border-color .2s ease,color .2s ease .12s;}
  }
  @media print{#ag-dir02-04 .ag-mz__tabs::before{display:none;}}
'''
    t = add_css(t, css)
    t = touch(t)
    save(4, t)


# ---------------------------------------------------------------- DIR02-05
def c05():
    t = load(5); R = '#ag-dir02-05'
    t = bump(t, 5, 'От v1.0.1 (на тесте — v1.0.0 с именами в комментарии: заменить). Состав и текст — как есть.\n'
                   '     F23 — нажатие кнопки, фокус 3 px.')
    t = wrap(t, 'a', 'ag-btn ag-btn--ghost', 'ag-btn__in')
    t = focus3(t, R)
    t = add_css(t, press_css(R, [('ag-btn', 'ag-btn__in')]))
    t = touch(t)
    save(5, t)


# ---------------------------------------------------------------- DIR02-06
def c06():
    t = load(6); R = '#ag-dir02-06'
    t = bump(t, 6, 'Факт № 11: «Первое групповое занятие для взрослых — бесплатно.» Цены — как есть. F29 зерно бумаги (≥ 640 px),\n'
                   '     F23, фокус 3 px. Телефон: полоса условий плотнее.')
    t = rep(t, 'тёмная полоса: «0 ₽ — первое групповое занятие» и два условия DIR02.md.',
            'тёмная полоса: «0 ₽ — первое групповое занятие для взрослых» (v1.1.0) и два условия DIR02.md.')
    t = rep(t, '<span>Первое групповое занятие — бесплатно.</span>', '<span>Первое групповое занятие для взрослых — бесплатно.</span>')
    t = wrap(t, 'a', 'ag-btn ag-btn--dark', 'ag-btn__in')
    t = focus3(t, R)
    css = press_css(R, [('ag-btn', 'ag-btn__in')])
    css += grain_css(R, 'ag-mp', 'ag-mp__wrap')
    t = add_css(t, css)
    t = touch(t)
    save(6, t)


# ---------------------------------------------------------------- DIR02-07
def c07():
    t = load(7); R = '#ag-dir02-07'
    t = bump(t, 7, 'F22: ответ раскрывается плавно (::details-content + interpolate-size, прогрессивно); «Раскрыть все» — без\n'
                   '     перехода; refresh и по toggle, и по окончании перехода высоты. F23 — «Раскрыть все» и кнопка, фокус 3 px.')
    t = wrap(t, 'button', 'ag-mq__all', 'ag-mq__ain')
    t = wrap(t, 'a', 'ag-btn ag-btn--primary', 'ag-btn__in')
    t = focus3(t, R)
    css = press_css(R, [('ag-mq__all', 'ag-mq__ain'), ('ag-btn', 'ag-btn__in')])
    css += '''  /* F22 · плавное раскрытие ответа (Chromium 131+); иначе — мгновенно, как было */
  @supports (interpolate-size:allow-keywords) and selector(::details-content){
    #ag-dir02-07 .ag-mq__list{interpolate-size:allow-keywords;}
    #ag-dir02-07 .ag-mq__item::details-content{
      height:0;overflow:clip;
      transition:height .32s cubic-bezier(.22,.61,.36,1),content-visibility .32s allow-discrete;
    }
    #ag-dir02-07 .ag-mq__item[open]::details-content{height:auto;}
    #ag-dir02-07.is-bulk .ag-mq__item::details-content{transition:none;}
    @media (prefers-reduced-motion:reduce){
      #ag-dir02-07 .ag-mq__item::details-content{transition:none;}
    }
  }
'''
    t = add_css(t, css)
    t = rx(t, r'(      busy = true;\n)(.*?)(      busy = false;\n)',
           lambda m: m.group(1) + '      root.classList.add("is-bulk");\n' + m.group(2) + m.group(3)
           + '      W.requestAnimationFrame(function () { W.requestAnimationFrame(function () { root.classList.remove("is-bulk"); }); });\n')
    t = rep(t, '      d.addEventListener("toggle", function () { if (!busy) { sync(); refresh(); } });\n    });\n',
            '      d.addEventListener("toggle", function () { if (!busy) { sync(); refresh(); } });\n    });\n'
            '    /* v1.1.0: высота ответа меняется переходом — пересчитать позиции анимаций ниже по окончании */\n'
            '    root.addEventListener("transitionend", function (e) {\n'
            '      if (e.propertyName === "height" && e.pseudoElement === "::details-content") refresh();\n'
            '    });\n')
    t = touch(t)
    save(7, t)


# ---------------------------------------------------------------- DIR02-09
def c09():
    t = load(9); R = '#ag-dir02-09'
    t = bump(t, 9, 'Магнит снят, F23 — нажатие кнопок, фокус 3 px. Напоминание: записи rec3979542201, rec3980647801,\n'
                   '     rec3980806401 (старые THAI-09/10/11) на тесте ещё стоят — удалить по поручению владельца.')
    t = rep(t, ' data-ag-magnetic="0.2"', '')
    t = wrap(t, 'a', 'ag-btn ag-btn--primary', 'ag-btn__in')
    t = wrap(t, 'a', 'ag-btn ag-btn--ghost', 'ag-btn__in')
    t = focus3(t, R)
    t = add_css(t, press_css(R, [('ag-btn', 'ag-btn__in')]))
    t = touch(t)
    save(9, t)


if __name__ == '__main__':
    for f in (c01, c02, c03, c04, c05, c06, c07, c09):
        f()
