// /muay-thai-samara (DIR02) · проверки прохода «дизайн, движение и фишка» (PROMPT_DIR02_DESIGN_MOTION_v2)
const {open,settle}=require('./lib');const fs=require('fs'),path=require('path');
const AFTER='file://'+path.resolve('after.html'), BEFORE='file://'+path.resolve('before.html');
const out={};const log=(g,ok,msg)=>{const s=(ok?"pass ":"FAIL ")+msg;(out[g]=out[g]||[]).push(s);console.log(g+" "+s);};
const G=process.env.G||'LTCMFA';
async function txt(url){const {browser,page}=await open({reduce:true});await page.goto(url);await page.waitForTimeout(2600);
  const r=await page.evaluate(()=>{const o={};document.querySelectorAll('.ag-scope').forEach(r=>{const c=r.cloneNode(true);c.querySelectorAll('style,script,.ag-vh').forEach(x=>x.remove());o[r.id]=c.textContent.replace(/\s+/g,' ').trim();});return o;});await browser.close();return r;}
async function links(url){const {browser,page}=await open({reduce:true});await page.goto(url);await page.waitForTimeout(400);
  const r=await page.evaluate(()=>[...document.querySelectorAll('.ag-scope a[href]')].map(a=>a.closest('.ag-scope').id+' '+a.getAttribute('href')));await browser.close();return r;}
const P=`(()=>{const r=document.getElementById('ag-dir02-02');const tr=s=>getComputedStyle(r.querySelector(s)).transform;const ang=s=>{const t=tr(s);if(t==='none')return 0;const m=new DOMMatrix(t);return Math.round(Math.atan2(m.b,m.a)*180/Math.PI);};
  return {show:r.getAttribute('data-ag-show'),pose:r.getAttribute('data-ag-pose'),pressed:[...r.querySelectorAll('.ag-wp__key')].findIndex(b=>b.getAttribute('aria-pressed')==='true'),sh:ang('.ag-wp__j--sh'),el:ang('.ag-wp__j--el'),hip:ang('.ag-wp__j--hip'),knee:ang('.ag-wp__j--knee'),live:r.querySelector('.ag-wp__live').textContent.trim().slice(0,30)};})()`;
const LEG=`(()=>{const l=document.querySelector('#ag-dir02-02 .ag-wp__legend');const b=[...l.querySelectorAll('.ag-wp__key')].find(x=>x.getAttribute('aria-pressed')==='true');const cs=getComputedStyle(l,'::before');const m=new DOMMatrix(cs.transform);return {y:m.m42,ty:b.offsetTop,h:parseFloat(cs.height),th:b.offsetHeight,w:parseFloat(cs.width),tw:b.offsetWidth,bg:getComputedStyle(b).backgroundColor,c:cs.content};})()`;
const IND=(i)=>`(()=>{const l=document.querySelector('#ag-dir02-04 .ag-mz__tabs'),t=document.querySelectorAll('#ag-dir02-04 .ag-mz__tab')[${i}];const cs=getComputedStyle(l,'::before');const m=new DOMMatrix(cs.transform);return {x:m.m41,y:m.m42,w:parseFloat(cs.width),h:parseFloat(cs.height),tx:t.offsetLeft,ty:t.offsetTop,tw:t.offsetWidth,th:t.offsetHeight,bg:getComputedStyle(t).backgroundColor,c:cs.content};})()`;
const ok=(r)=>Math.abs(r.x-r.tx)<1&&Math.abs(r.y-r.ty)<1&&Math.abs(r.w-r.tw)<1&&Math.abs(r.h-r.th)<1;
async function toFig(page){await page.evaluate(()=>{const s=document.querySelector('#ag-dir02-02 .ag-wp__plate').getBoundingClientRect();scrollTo(0,scrollY+s.top-80);});await page.waitForTimeout(400);}
async function zone(page,z){return page.evaluate(z=>{const r=document.querySelector(`#ag-dir02-02 [data-ag-ui-zone="${z}"]`).getBoundingClientRect();return {x:r.left+r.width/2,y:r.top+r.height/2,h:r.height};},z);}
(async()=>{
 if(G.includes('L')) for(const reduce of [false,true]) for(const fontsOff of [false,true]) for(const w of [320,360,390,768,1024,1440,1920]){
   const {browser,page}=await open({w,h:w<700?800:900,reduce,mobile:w<700,touch:w<700});
   if(fontsOff) await page.route('**/fonts.googleapis.com/**',r=>r.abort());
   await page.goto(AFTER);await settle(page);
   const r=await page.evaluate(()=>({ov:document.documentElement.scrollWidth>document.documentElement.clientWidth,h:document.body.scrollHeight}));
   log('L',!r.ov,`${w}px reduce=${reduce} fontsOff=${fontsOff} overflowX=${r.ov} h=${r.h}`);await browser.close();
 }
 if(G.includes('T')){const tb=await txt(BEFORE),ta=await txt(AFTER);
  const EXC={'ag-dir02-01':[['первое групповое занятие для взрослых','первое групповое занятие'],['Галактионовская, 81 ','Ново-Садовая, 106Б ']],
   'ag-dir02-06':[['Первое групповое занятие для взрослых — бесплатно.','Первое групповое занятие — бесплатно.']]};
  for(const id of Object.keys(tb)){let a=ta[id];(EXC[id]||[]).forEach(([n,o])=>{a=a.split(n).join(o);});a=a.replace(/\s+/g,' ').trim();let i=0;while(i<tb[id].length&&tb[id][i]===a[i])i++;
   log('T',a===tb[id],id+(a===tb[id]?' текст совпадает'+(EXC[id]?' (кроме правок: '+EXC[id].map(x=>'«'+x[0].trim()+'»').join(', ')+')':''):' РАЗНИЦА '+JSON.stringify(tb[id].slice(i-40,i+40))+' → '+JSON.stringify(a.slice(i-40,i+40))));}
  const html=fs.readFileSync('after.html','utf8').replace(/<!--[\s\S]*?-->/g,'').replace(/\/\*[\s\S]*?\*\//g,'');const used=['Zal_5-1024','Zal_4-1024','img_5464','1_16-1024'].every(k=>html.includes(k))&&!['1_10-1024','Zal_2-1024','img_5431'].some(k=>html.includes(k));
  log('T',used,`кадры: Zal_5 (01), Zal_4 / img_5464 / 1_16 (04) на месте; 1_10, Zal_2, img_5431 сняты: ${used}`);}
 if(G.includes('C')){const lb=await links(BEFORE),la=await links(AFTER);const add=la.filter(x=>!lb.includes(x)),rem=lb.filter(x=>!la.includes(x));
  log('C',rem.length===0&&add.length===0,`ссылки +${add.length} −${rem.length}`);}
 if(G.includes('M')){
  for(const mode of [{name:'js off',js:false},{name:'reduce',reduce:true},{name:'cdn fail',cdn:'fail'},{name:'cdn hang',cdn:'hang'}]){
   const {browser,page}=await open({w:390,h:800,mobile:true,...mode});await page.goto(AFTER,{waitUntil:'domcontentloaded'});await page.waitForTimeout(2700);
   if(mode.js!==false) for(let y=0;y<9000;y+=600){await page.evaluate(y=>scrollTo(0,y),y);await page.waitForTimeout(40);}
   const r=await page.evaluate(()=>{const bad=[];document.querySelectorAll('.ag-scope :is(p,h1,h2,h3,a,li,dt,dd,summary,td,th,figcaption)').forEach(el=>{if(el.closest('[aria-hidden="true"],[hidden],dialog'))return;let n=el,op=1;while(n&&n.nodeType===1){op*=parseFloat(getComputedStyle(n).opacity);n=n.parentElement;}if(getComputedStyle(el).display==='none')return;if(op<0.99&&el.textContent.trim())bad.push(el.textContent.trim().slice(0,30));});
     const z=document.querySelector('#ag-dir02-02 .ag-wp__zones');return {bad,m:document.documentElement.getAttribute('data-ag-motion'),zones:getComputedStyle(z).display,pose:getComputedStyle(document.querySelector('#ag-dir02-02 .ag-wp__j--hip')).transform};});
   log('M',r.bad.length===0&&r.pose==='none'&&(mode.js===false?r.zones==='none':true),`${mode.name}: motion=${r.m} скрытых текстов ${r.bad.length} ${r.bad.slice(0,3).join('|')}; боец в стойке; полосы-цели ${r.zones}`);await browser.close();}
  const {browser,page}=await open({w:1440});await page.goto(AFTER);await settle(page);
  const r=await page.evaluate(()=>{const o={};document.querySelectorAll('.ag-scope').forEach(root=>{const all=root.querySelectorAll('[data-ag-anim]');o[root.id]=[all.length,[...all].filter(e=>!e.hasAttribute('data-ag-done')).length];});return o;});
  for(const [id,[n,left]] of Object.entries(r)) log('M',left===0,`motion on: ${id} анимаций ${n}, не отсканировано ${left}`);await browser.close();}

 if(G.includes('F')){
  // ---- 02 «Боец показывает удар»
  {const {browser,page,errs}=await open({w:1440,h:900});await page.goto(AFTER);await settle(page);await toFig(page);
   const s0=await page.evaluate(P);
   const want={fists:{sh:15,el:18,hip:0,knee:0},elbows:{sh:62,el:10,hip:0,knee:0},knees:{sh:0,el:0,hip:85,knee:-120},shins:{sh:0,el:0,hip:36,knee:-30}};
   const res=[];let mid=null;
   for(const k of ['fists','elbows','knees','shins']){await page.click(`#ag-dir02-02 .ag-wp__key[data-ag-key="${k}"]`);if(k==='knees'){await page.waitForTimeout(120);mid=await page.evaluate(P);}await page.waitForTimeout(450);const s=await page.evaluate(P);const w=want[k];
    res.push([k,s.pose===k&&s.show===k&&s.sh===w.sh&&s.el===w.el&&s.hip===w.hip&&s.knee===w.knee&&s.live.length>3,`${s.sh}/${s.el}/${s.hip}/${s.knee}`]);}
   log('F',s0.pose==='all'&&s0.sh===0&&s0.hip===0&&res.every(r=>r[1]),`боец, ПК: стойка в покое; позы — ${res.map(r=>r[0]+' '+r[2]+(r[1]?'':' ✗')).join('; ')} (плечо/локоть/бедро/колено, °), подсветка и фраза для чтения с экрана — по паре`);
   log('F',mid&&mid.hip>0&&mid.hip<85,`боец: поза приходит переходом (на 120 мс бедро ${mid&&mid.hip}° из 85°)`);
   await page.click('#ag-dir02-02 .ag-wp__key[data-ag-key="shins"]');await page.waitForTimeout(450);const back=await page.evaluate(P);
   // наведение на другую кнопку — подсветка меняется, поза и подложка — нет
   await page.click('#ag-dir02-02 .ag-wp__key[data-ag-key="fists"]');await page.waitForTimeout(450);const l0=await page.evaluate(LEG);
   await page.hover('#ag-dir02-02 .ag-wp__key[data-ag-key="knees"]');await page.waitForTimeout(450);const hv=await page.evaluate(P);const l1=await page.evaluate(LEG);
   log('F',back.pose==='all'&&back.hip===0&&hv.show==='knees'&&hv.pose==='fists'&&hv.sh===15&&Math.abs(l1.y-l0.y)<1,`боец: повторное нажатие пары — снова стойка; наведение на «Колени» — подсветка колен, поза «Руки» и подложка на месте`);
   await page.mouse.move(5,5);await page.waitForTimeout(300);
   // касание фигуры: полосы-цели
   await page.click('#ag-dir02-02 .ag-wp__key[data-ag-key="all"]');await page.waitForTimeout(400);
   let z=await zone(page,'knees');await page.mouse.click(z.x,z.y);await page.waitForTimeout(450);const zk=await page.evaluate(P);
   await page.mouse.click(z.x,z.y);await page.waitForTimeout(450);const zk2=await page.evaluate(P);
   z=await zone(page,'fists');await page.mouse.click(z.x,z.y);await page.waitForTimeout(450);const zf=await page.evaluate(P);
   log('F',zk.pose==='knees'&&zk.pressed===3&&zk2.pose==='all'&&zf.pose==='fists'&&errs.length===0,`боец: щелчок по фигуре на уровне колен — «Колени» (кнопка нажата), повторный — «Все восемь»; на уровне перчаток — «Руки»; ошибок ${errs.length} ${errs[0]||''}`);
   // подложка легенды
   const a=await page.evaluate(LEG);await page.click('#ag-dir02-02 .ag-wp__key[data-ag-key="elbows"]');await page.waitForTimeout(120);const m=await page.evaluate(LEG);await page.waitForTimeout(400);const b=await page.evaluate(LEG);
   log('F',Math.abs(a.y-a.ty)<1&&Math.abs(b.y-b.ty)<1&&m.y>a.ty+2&&m.y<b.ty-2&&b.bg==='rgba(0, 0, 0, 0)'&&Math.abs(b.w-b.tw)<1,`подложка легенды: под нажатой кнопкой, едет по столбцу (на 120 мс y=${Math.round(m.y)} между ${a.ty} и ${b.ty}), у кнопки фон снят`);
   await (await page.$('#ag-dir02-02 .ag-wp__plate')).screenshot({path:'shots/fighter_1440.png'});
   await browser.close();}
  // телефон: позы в плашке, полосы ≥ 36 px, касание, прокрутка со схемы
  for(const w of [320,390]){const {browser,page,errs}=await open({w,h:844,mobile:true,touch:true});await page.goto(AFTER);await settle(page);await toFig(page);
   const bands=await page.evaluate(()=>[...document.querySelectorAll('#ag-dir02-02 [data-ag-ui-zone]')].map(r=>Math.round(r.getBoundingClientRect().height)));
   let inside=true;const rows=[];
   for(const k of ['fists','elbows','knees','shins']){await page.click(`#ag-dir02-02 .ag-wp__key[data-ag-key="${k}"]`);await page.waitForTimeout(450);
    const r=await page.evaluate(()=>{const p=document.querySelector('#ag-dir02-02 .ag-wp__plate').getBoundingClientRect();const lg=document.querySelector('#ag-dir02-02 .ag-wp__legend').getBoundingClientRect();let x0=1e9,x1=-1e9;document.querySelectorAll('#ag-dir02-02 .ag-wp__fig .ag-wp__body > *, #ag-dir02-02 .ag-wp__fig .ag-wp__pt').forEach(e=>{const b=e.getBoundingClientRect();if(!b.width)return;x0=Math.min(x0,b.left);x1=Math.max(x1,b.right);});return {l:Math.round(x0-p.left),r:Math.round(lg.left-x1)};});
    rows.push(k+' '+r.l+'/'+r.r);if(r.l<6||r.r<0)inside=false;}
   await page.click('#ag-dir02-02 .ag-wp__key[data-ag-key="all"]');await page.waitForTimeout(400);
   const z=await zone(page,'shins');await page.touchscreen.tap(z.x,z.y);await page.waitForTimeout(450);const t1=await page.evaluate(P);
   const cdp=await page.context().newCDPSession(page);const z2=await zone(page,'elbows');const y0=await page.evaluate(()=>scrollY);
   await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x:z2.x,y:z2.y}]});for(let i=1;i<=12;i++){await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:z2.x,y:z2.y-i*25}]});await page.waitForTimeout(16);}
   await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await page.waitForTimeout(600);const y1=await page.evaluate(()=>scrollY);const t2=await page.evaluate(P);
   if(w===390) {await toFig(page);await (await page.$('#ag-dir02-02 .ag-wp__plate')).screenshot({path:'shots/fighter_390.png'});}
   log('F',inside&&Math.min(...bands)>=36&&t1.pose==='shins'&&y1-y0>100&&t2.pose==='shins'&&errs.length===0,`боец, телефон ${w}px: позы в плашке и не задевают легенду (запас слева/до легенды, px: ${rows.join('; ')}); полосы-цели ${bands.join('/')} px; касание голени — «Ноги»; свайп от схемы — прокрутка ${y0}→${y1}, поза та же`);await browser.close();}
  // reduce: поза сразу; reduce на лету; forced; печать
  {const {browser,page}=await open({w:1440,h:900,reduce:true});await page.goto(AFTER);await settle(page);await toFig(page);
   await page.click('#ag-dir02-02 .ag-wp__key[data-ag-key="knees"]');await page.waitForTimeout(40);const s=await page.evaluate(P);
   log('F',s.pose==='knees'&&s.hip===85&&s.knee===-120,`боец, reduce: поза встаёт сразу (через 40 мс бедро ${s.hip}°)`);await browser.close();}
  {const {browser,page}=await open({w:1440,h:900});await page.goto(AFTER);await settle(page);await toFig(page);await page.emulateMedia({reducedMotion:'reduce'});
   await page.click('#ag-dir02-02 .ag-wp__key[data-ag-key="shins"]');await page.waitForTimeout(40);const s=await page.evaluate(P);
   await page.emulateMedia({reducedMotion:'no-preference',media:'print'});await page.waitForTimeout(500);const pr=await page.evaluate(()=>getComputedStyle(document.querySelector('#ag-dir02-02 .ag-wp__j--hip')).transform);
   log('F',s.hip===36&&pr==='none',`боец: reduce на лету — поза сразу (${s.hip}°); печать — стойка (${pr})`);await browser.close();}
  {const {browser,page}=await open({w:1440,h:900});await page.emulateMedia({forcedColors:'active'});await page.goto(AFTER);await settle(page);await toFig(page);
   await page.click('#ag-dir02-02 .ag-wp__key[data-ag-key="elbows"]');await page.waitForTimeout(450);const s=await page.evaluate(P);const l=await page.evaluate(LEG);
   const t4=await page.evaluate(()=>getComputedStyle(document.querySelector('#ag-dir02-04 .ag-mz__tabs'),'::before').content);
   await (await page.$('#ag-dir02-02 .ag-wp__plate')).screenshot({path:'shots/forced_02.png'});
   log('F',s.pose==='elbows'&&s.sh===62&&l.c==='none'&&t4==='none',`forced-colors: поза работает, подложек нет (легенда ${l.c}, вкладки ${t4})`);await browser.close();}
  // ---- 04 подложка вкладок
  {const {browser,page}=await open({w:1440,h:900});await page.goto(AFTER);await settle(page);
   await page.evaluate(()=>document.getElementById('ag-dir02-04').scrollIntoView());await page.waitForTimeout(500);
   const r0=await page.evaluate(IND(0));await page.click('#ag-dir02-04 .ag-mz__tab >> nth=2');await page.waitForTimeout(110);const m=await page.evaluate(IND(2));await page.waitForTimeout(420);const r2=await page.evaluate(IND(2));
   log('F',ok(r0)&&r0.bg==='rgba(0, 0, 0, 0)'&&ok(r2)&&m.x>r0.tx+2&&m.x<r2.tx-2,`подложка залов, ПК: под «Галактионовской», едет к «Ново-Садовой» (на 110 мс x=${Math.round(m.x)}, в конце ${Math.round(r2.x)} ↔ ${r2.tx})`);
   for(const w of [960,768,767]){await page.setViewportSize({width:w,height:900});await page.waitForTimeout(400);}
   const r3=await page.evaluate(IND(2));log('F',ok(r3),`подложка залов: 1440 → 960 → 768 → 767 — на месте (${Math.round(r3.x)},${Math.round(r3.y)})`);await browser.close();}
  for(const w of [320,360,390,480]){const {browser,page}=await open({w,h:844,mobile:true,touch:true});await page.goto(AFTER);await settle(page);
   await page.evaluate(()=>document.getElementById('ag-dir02-04').scrollIntoView());await page.waitForTimeout(400);
   const rows=await page.$$eval('#ag-dir02-04 .ag-mz__tab',x=>x.map(t=>t.offsetTop));const tb=await (await page.$$('#ag-dir02-04 .ag-mz__tab'))[2].boundingBox();
   await page.touchscreen.tap(tb.x+tb.width/2,tb.y+tb.height/2);await page.waitForTimeout(40);
   const an=await page.evaluate(()=>document.querySelector('#ag-dir02-04 .ag-mz__tabs').getAnimations({subtree:true}).filter(a=>a.effect&&a.effect.pseudoElement==='::before').length);
   await page.waitForTimeout(450);const r=await page.evaluate(IND(2));const wrapRow=rows[2]!==rows[0];
   log('F',ok(r)&&(!wrapRow||an===1),`подложка залов, телефон ${w}px: рядов ${[...new Set(rows)].length}; «Ново-Садовая» — ${wrapRow?'перенос с проявлением ('+an+')':'едет по ряду'}, на месте`);await browser.close();}
  // ---- 07 F22 + FAQPage = блок 07 (HEAD без изменений)
  {const {browser,page}=await open({w:1440,h:900});await page.goto(AFTER);await settle(page);
   await page.evaluate(()=>document.getElementById('ag-dir02-07').scrollIntoView());await page.waitForTimeout(400);
   const H=n=>page.evaluate(n=>Math.round(document.querySelector('#ag-dir02-07 .ag-mq__item:nth-of-type('+n+')').getBoundingClientRect().height),n);
   const h0=await H(2);await page.click('#ag-dir02-07 .ag-mq__item:nth-of-type(2) summary');await page.waitForTimeout(90);const hm=await H(2);await page.waitForTimeout(450);const h1=await H(2);
   const HA=()=>page.evaluate(()=>[...document.querySelectorAll('#ag-dir02-07 .ag-mq__item')].map(d=>Math.round(d.getBoundingClientRect().height)).join(','));
   await page.click('#ag-dir02-07 .ag-mq__all');await page.waitForTimeout(40);const b1=await HA();await page.waitForTimeout(500);const b2=await HA();
   const st=await page.evaluate(()=>({open:[...document.querySelectorAll('#ag-dir02-07 .ag-mq__item')].filter(d=>d.open).length,n:document.querySelectorAll('#ag-dir02-07 .ag-mq__item').length,bulk:document.getElementById('ag-dir02-07').classList.contains('is-bulk')}));
   log('F',h0<hm&&hm<h1&&b1===b2&&st.open===st.n&&!st.bulk,`FAQ: ответ раскрывается плавно (${h0} → ${hm} на 90 мс → ${h1}), «Раскрыть все» — все ${st.open} сразу без перехода, is-bulk снят`);
   const head=JSON.parse(fs.readFileSync('/home/claude/work/head_test/HEAD_muay-thai-samara.html','utf8').match(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/)[1]);
   const faq=head['@graph'].find(n=>n['@type']==='FAQPage').mainEntity;
   const QA=()=>page.evaluate(()=>[...document.querySelectorAll('#ag-dir02-07 .ag-mq__item')].map(d=>[d.querySelector('.ag-mq__qt').textContent.replace(/\s+/g,' ').trim(),d.querySelector('.ag-mq__a').textContent.replace(/\s+/g,' ').trim()]));
   const qs=await QA();await page.goto(BEFORE);await settle(page);const qb=await QA();
   const strip=t=>t.replace(/<[^>]+>/g,'').replace(/\s+/g,' ').trim();
   const dif=q=>q.map(([n,a],i)=>faq[i]&&(faq[i].name!==n||strip(faq[i].acceptedAnswer.text)!==a)?i:null).filter(x=>x!==null);
   const da=dif(qs),db=dif(qb);const sameBlock=JSON.stringify(qs)===JSON.stringify(qb);
   log('F',sameBlock&&qs.length===faq.length&&JSON.stringify(da)===JSON.stringify(db),`FAQPage в HEAD (без изменений): вопросы и ответы блока 07 v1.1.0 = v1.0.0 (${qs.length}); расхождения HEAD с блоком те же, что у v1.0.0: [${da.join(',')}] (известные: ответ 5 — в блоке подпись кнопки «Спросить расписание»)`);
   log('F',true,'FAQPage: расхождения v1.0.0 — '+da.map(i=>i+': HEAD «'+strip(faq[i].acceptedAnswer.text).slice(-60)+'» / блок «'+qs[i][1].slice(-60)+'»').join(' || '));await browser.close();}
  // ---- магниты, F23, зерно
  {const {browser,page}=await open({w:1440,h:900});await page.goto(AFTER);await settle(page);
   const mag=await page.$$eval('[data-ag-magnetic]',x=>x.length);log('F',mag===0,`магнитных кнопок: ${mag}`);
   const res=[];
   for(const [sel,inn] of [['#ag-dir02-01 .ag-btn--primary','.ag-btn__in'],['#ag-dir02-04 .ag-btn--primary','.ag-btn__in'],['#ag-dir02-05 .ag-btn--ghost','.ag-btn__in'],['#ag-dir02-06 .ag-btn--dark','.ag-btn__in'],['#ag-dir02-07 .ag-mq__all','.ag-mq__ain'],['#ag-dir02-09 .ag-btn--primary','.ag-btn__in']]){
    const el=await page.$(sel);if(!el){res.push(sel+': нет');continue;}await el.scrollIntoViewIfNeeded();await page.waitForTimeout(250);const b0=await el.boundingBox();
    await page.evaluate(s=>document.querySelector(s).addEventListener('click',e=>e.preventDefault(),{once:true}),sel);
    await page.mouse.move(b0.x+b0.width/2,b0.y+b0.height/2);await page.mouse.down();await page.waitForTimeout(220);
    const t=await page.$eval(sel+' '+inn,e=>getComputedStyle(e).transform);const b1=await el.boundingBox();await page.mouse.up();await page.waitForTimeout(80);
    res.push([sel.split(' ')[0].slice(-2),/matrix\(0\.98/.test(t)&&Math.abs(b1.x-b0.x)<0.5]);}
   log('F',res.every(r=>Array.isArray(r)&&r[1]===true),`F23 нажатие: ${res.map(r=>Array.isArray(r)?r.join(':'):r).join(' ')}`);
   const gr=await page.evaluate(()=>['#ag-dir02-02 .ag-wp','#ag-dir02-06 .ag-mp'].map(s=>/svg/.test(getComputedStyle(document.querySelector(s),'::before').backgroundImage)));
   log('F',gr.every(Boolean),`зерно бумаги на ПК: 02 ${gr[0]}, 06 ${gr[1]}`);await browser.close();}
  {const {browser,page}=await open({w:390,h:844,mobile:true,touch:true});await page.goto(AFTER);await settle(page);
   const gr=await page.evaluate(()=>['#ag-dir02-02 .ag-wp','#ag-dir02-06 .ag-mp'].map(s=>/svg/.test(getComputedStyle(document.querySelector(s),'::before').backgroundImage)));
   log('F',!gr[0]&&!gr[1],`телефон: зерна нет (02 ${gr[0]}, 06 ${gr[1]})`);await browser.close();}
 }
 if(G.includes('A')){const axeSrc=fs.readFileSync(require.resolve('axe-core/axe.min.js'),'utf8');
  for(const m of [{w:1440},{w:1024},{w:390,mobile:true},{w:390,mobile:true,reduce:true},{w:390,nojs:true}]){
   let o;if(m.nojs){fs.writeFileSync('after_nojs.html',fs.readFileSync('after.html','utf8').replace(/<script>[\s\S]*?<\/script>/g,'').replace(/<!--[\s\S]*?-->/g,'').replace(/<noscript>([\s\S]*?)<\/noscript>/g,'$1'));o=await open({w:390,h:900});await o.page.goto('file://'+path.resolve('after_nojs.html'));await o.page.waitForTimeout(800);}
   else {o=await open({...m,h:900});await o.page.goto(AFTER);await settle(o.page);}
   await o.page.addScriptTag({content:axeSrc});const res=await o.page.evaluate(async()=>(await axe.run(document.getElementById('allrecords'),{resultTypes:['violations']})).violations.map(v=>[v.id,v.impact,v.nodes.length,v.nodes[0].target.join(' ')]));
   const s=res.filter(v=>/serious|critical/.test(v[1]));log('A',res.length===0,`${m.w}${m.reduce?' reduce':''}${m.nojs?' без JS':''}: нарушений ${res.length} (serious/critical ${s.length}) ${res.map(v=>v.join(':')).join(' ; ').slice(0,300)}`);await o.browser.close();}
  {const o=await open({w:1440,h:900});await o.page.goto(AFTER);await settle(o.page);await toFig(o.page);
   await o.page.click('#ag-dir02-02 .ag-wp__key[data-ag-key="knees"]');await o.page.click('#ag-dir02-04 .ag-mz__tab >> nth=1');await o.page.click('#ag-dir02-07 .ag-mq__all');await o.page.waitForTimeout(500);
   await o.page.addScriptTag({content:axeSrc});const res=await o.page.evaluate(async()=>(await axe.run(document.getElementById('allrecords'),{resultTypes:['violations']})).violations.map(v=>[v.id,v.impact,v.nodes[0].target.join(' ')]));
   log('A',res.length===0,`1440, поза «Колени» + зал «Чкалова» + FAQ раскрыт: нарушений ${res.length} ${res.map(v=>v.join(':')).join(' ; ').slice(0,300)}`);await o.browser.close();}}
 fs.writeFileSync('checks_t_'+G+'.json',JSON.stringify(out,null,1));
 for(const g of Object.keys(out)){console.log('## '+g);out[g].forEach(x=>console.log('  '+x));}
})();
