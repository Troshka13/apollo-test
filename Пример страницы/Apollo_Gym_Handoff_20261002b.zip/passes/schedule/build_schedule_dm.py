# -*- coding: utf-8 -*-
"""/schedule (SCHEDULE) · проход «дизайн, движение и фишка» (PROMPT_SCHEDULE_DESIGN_MOTION_v2, 30.09.2026).
src/SCHEDULE-0N_v1.0.0.html → out/SCHEDULE-0N_v1.1.0.html. Каждая замена обязана найтись нужное число раз."""
import re, os, sys

sys.path.insert(0, '/home/claude/pr')
from build_prices_dm import rep, rx, focus3, wrap, press_css, add_css, touch, GRAIN  # noqa: E402

SRC, OUT = 'src', 'out'
os.makedirs(OUT, exist_ok=True)
DATE = '30.09.2026'


def load(n):
    return open('%s/SCHEDULE-0%d_v1.0.0.html' % (SRC, n), encoding='utf-8').read()


def save(n, t):
    p = '%s/SCHEDULE-0%d_v1.1.0.html' % (OUT, n)
    open(p, 'w', encoding='utf-8').write(t)
    print('SCHEDULE-0%d v1.1.0 %6d байт' % (n, len(t.encode('utf-8'))))


def bump(t, note):
    t = rx(t, r'(APOLLO GYM · SCHEDULE-0\d[^\n]*?)· v1\.0\.0 · 24\.09\.2026', r'\1· v1.1.0 · 30.09.2026')
    i = t.index('-->') + 3
    return t[:i] + '\n<!-- v1.1.0 (проход «дизайн, движение и фишка», PROMPT_SCHEDULE_DESIGN_MOTION_v2, %s):\n     %s -->' % (DATE, note) + t[i:]


def grain_css(root, sec, wrap_cls):
    return '''  /* F29 · зерно бумаги (статично, только ≥ 640 px; forced-colors и печать — без зерна) */
  @media (min-width:640px){
    %(r)s .%(s)s::before{content:"";position:absolute;inset:0;z-index:0;pointer-events:none;opacity:.12;background-image:%(g)s;background-size:180px 180px;}
    %(r)s .%(w)s{position:relative;z-index:1;}
  }
  @media (forced-colors:active){%(r)s .%(s)s::before{display:none;}}
  @media print{%(r)s .%(s)s::before{display:none;}}
''' % {'r': root, 's': sec, 'w': wrap_cls, 'g': GRAIN}


# ---------------------------------------------------------------- SCHEDULE-01
def s01():
    t = load(1); R = '#ag-schedule-01'
    t = bump(t, 'Факт № 11: «0 ₽ — первое групповое занятие для взрослых» (для детей не подтверждено; как на всех\n'
                '     страницах после 30.09). Магнит с кнопки снят (F23: CTA не убегает от курсора), нажатие F23,\n'
                '     фокус 3 px. «В зале включают свет» — как есть. Телефон: строки планки плотнее (высота блока прежняя).')
    t = rep(t, '<li><b>0&nbsp;₽</b><span>первое групповое занятие</span></li>',
            '<li><b>0&nbsp;₽</b><span>первое групповое занятие для&nbsp;взрослых</span></li>')
    t = rep(t, ' data-ag-magnetic="0.18"', '')
    t = wrap(t, 'a', 'ag-btn ag-btn--primary', 'ag-btn__in')
    t = focus3(t, R)
    css = press_css(R, [('ag-btn', 'ag-btn__in')])
    css += '''  /* телефон: «для взрослых» добавило строку в планке — строки плотнее, высота блока прежняя */
  @media (max-width:599px){
    #ag-schedule-01 .ag-sh__facts>li{padding-top:5px;padding-bottom:5px;}
    #ag-schedule-01 .ag-sh__facts li>span{line-height:1.35;}
  }
'''
    t = add_css(t, css)
    t = touch(t)
    save(1, t)


# ---------------------------------------------------------------- SCHEDULE-02
IND_JS = '''    /* v1.1.0 · F10: жёлтая кромка выбранной закладки — одна на ряд (::before у tablist на CSS-переменных),
       переезжает к новой закладке; между рядами (сетка 2×2 на телефоне — отступление по Р2) — перенос
       с проявлением. Первая установка — без перехода. Ширина — ширина закладки минус отступы --kin. */
    var ind = { on: false, row: null, cur: 0 };
    function placeInd(i, jump) {
      var t = tabs[i];
      ind.cur = i;
      if (!t || !t.offsetWidth) return;
      var kin = parseFloat(W.getComputedStyle(list).getPropertyValue("--kin")) || 18;
      var row = t.offsetTop, change = ind.row !== null && Math.abs(ind.row - row) > 2;
      if (!ind.on || jump || change) list.classList.add("is-jump");
      list.style.setProperty("--ix", (t.offsetLeft + kin) + "px");
      list.style.setProperty("--iy", row + "px");
      list.style.setProperty("--iw", Math.max(0, t.offsetWidth - 2 * kin) + "px");
      if (!ind.on) { list.classList.add("is-ind"); ind.on = true; }
      else if (change && list.animate && !reduceNow()) {
        try { list.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 180, easing: "ease-out", pseudoElement: "::before" }); } catch (e) {}
      }
      ind.row = row; ind.cur = i;
      if (list.classList.contains("is-jump")) W.requestAnimationFrame(function () { W.requestAnimationFrame(function () { list.classList.remove("is-jump"); }); });
    }
    function reduceNow() { return !!(W.matchMedia && W.matchMedia("(prefers-reduced-motion: reduce)").matches); }
'''

FLASH_OLD = '''    function flash(el) {
      if (!el || reduce) return;
      el.classList.add("is-new");
      W.setTimeout(function () { el.classList.remove("is-new"); }, 700);
    }
'''
FLASH_NEW = '''    /* v1.1.0 · «Билет-табло»: новое значение в билете перелистывается, как на табло (rotateX, 260 мс);
       текст уже поставлен через nodeValue — клонов и мутаций childList нет. Новая смена отменяет прежнюю;
       строка, только что показанная из hidden, не перелистывается; reduce — при каждом запуске. */
    function flash(el, delay) {
      if (!el || reduceNow()) return;
      el.classList.add("is-new");
      W.setTimeout(function () { el.classList.remove("is-new"); }, 700);
      if (!el.animate || el.__agFresh) return;
      if (el.__agFlip) { try { el.__agFlip.cancel(); } catch (e) {} }
      el.__agFlip = el.animate([{ transform: "rotateX(-90deg)", opacity: 0.2 }, { transform: "rotateX(0deg)", opacity: 1 }],
        { duration: 260, delay: delay || 0, easing: "cubic-bezier(.22,.61,.36,1)", fill: "backwards" });
    }
'''


def s02():
    t = load(2); R = '#ag-schedule-02'
    t = bump(t, 'F10 (ведущий приём страницы): жёлтая кромка выбранной закладки одна на ряд и переезжает к новой\n'
                '     закладке; на телефоне (сетка 2×2, стандарт 51 — отступление от «не переносятся» по Р2) между рядами —\n'
                '     перенос с проявлением. Появление ряда закладок — rise вместо stagger (кромка не висит без закладок).\n'
                '     «Билет-табло»: новое значение в билете перелистывается (WAAPI rotateX), reduce — без перелистывания.\n'
                '     F29 зерно бумаги (≥ 640 px). Факт № 11: корешок — «Первое групповое для взрослых». Магнит снят,\n'
                '     нажатие F23, фокус 3 px.')
    t = rep(t, '(REQUEST-02), с корешком «Первое групповое занятие — 0 ₽». Кнопка',
            '(REQUEST-02), с корешком «Первое групповое для взрослых — 0 ₽» (v1.1.0). Кнопка')
    t = rep(t, 'hidden data-ag-anim="stagger" data-ag-children=".ag-sf__tab" data-ag-stagger="60" data-ag-distance="12">',
            'hidden data-ag-anim="rise" data-ag-distance="12">')
    t = rep(t, '<p class="ag-sf__stub"><span>Первое групповое занятие</span><b>0&nbsp;₽</b></p>',
            '<p class="ag-sf__stub"><span>Первое групповое для взрослых</span><b>0&nbsp;₽</b></p>')
    t = rep(t, ' data-ag-go data-ag-magnetic="0.14"', ' data-ag-go')
    t = wrap(t, 'a', 'ag-sf__go', 'ag-sf__gin')
    t = wrap(t, 'a', 'ag-sf__call', 'ag-sf__cin')
    t = focus3(t, R)
    # JS: кромка
    t = rep(t, '    function openTab(club, focus, animate) {\n', IND_JS + '    function openTab(club, focus, animate) {\n')
    t = rep(t, '      if (focus) tabs[i].focus({ preventScroll: true });\n      if (animate && was !== club',
            '      placeInd(i, !animate);\n      if (focus) tabs[i].focus({ preventScroll: true });\n      if (animate && was !== club')
    # JS: табло
    t = rep(t, FLASH_OLD, FLASH_NEW)
    t = rep(t, '''      if (state.days.length) {
        setText(tDays, state.days.map(function (d) { return DAY_SHORT[d]; }).join(", "));
        tDaysRow.hidden = false;
      } else {''', '''      if (state.days.length) {
        setText(tDays, state.days.map(function (d) { return DAY_SHORT[d]; }).join(", "));
        tDays.__agFresh = tDaysRow.hidden;
        tDaysRow.hidden = false;
      } else {''')
    t = rep(t, '      if (changed === "days") flash(tDays);\n', '      if (changed === "days") flash(tDays);\n      tDays.__agFresh = false;\n')
    t = rep(t, '        if (clubChanged) flash(tDir);\n', '        if (clubChanged) flash(tDir, 60);\n')
    # замер кромки: ресайз и шрифты
    t = rep(t, '    /* ---------- подгонка улиц в закладках',
            '    if ("ResizeObserver" in W) new W.ResizeObserver(function () { placeInd(ind.cur, true); }).observe(list);\n'
            '    if (D.fonts && D.fonts.ready) D.fonts.ready.then(function () { placeInd(ind.cur, true); });\n\n'
            '    /* ---------- подгонка улиц в закладках')
    css = press_css(R, [('ag-sf__go', 'ag-sf__gin'), ('ag-sf__call', 'ag-sf__cin')])
    css += '''  /* F10 · кромка выбранной закладки: одна на ряд, над закладками */
  #ag-schedule-02 .ag-sf__tabs{position:relative;--kin:18px;}
  @media (max-width:767.98px){#ag-schedule-02 .ag-sf__tabs{--kin:12px;}}
  @media not (forced-colors:active){
    #ag-schedule-02 .ag-sf__tabs.is-ind::before{
      content:"";position:absolute;z-index:2;left:0;top:0;width:var(--iw,0px);height:4px;border-radius:0 0 4px 4px;background:var(--accent);pointer-events:none;
      transform:translate(var(--ix,0px),var(--iy,0px));
      transition:transform .34s cubic-bezier(.22,.61,.36,1),width .34s cubic-bezier(.22,.61,.36,1);
    }
    #ag-schedule-02 .ag-sf__tabs.is-jump::before{transition:none;}
    #ag-schedule-02 .ag-sf__tabs.is-ind .ag-sf__tab[aria-selected="true"]::after{background:transparent;}
  }
  /* «Билет-табло»: строки перелистываются от верхней кромки */
  #ag-schedule-02 .ag-sf__tk-rows{perspective:600px;}
  #ag-schedule-02 .ag-sf__tk-rows dd{transform-origin:50% 0;backface-visibility:hidden;}
'''
    css += grain_css(R, 'ag-sf', 'ag-sf__wrap')
    t = add_css(t, css)
    t = touch(t)
    save(2, t)


# ---------------------------------------------------------------- SCHEDULE-03
def s03():
    t = load(3); R = '#ag-schedule-03'
    t = bump(t, 'Адреса, маршруты, карта и подсветка зала — как есть. F23 — нажатие кнопок маршрута (×8), фокус 3 px.')
    t = wrap(t, 'a', 'ag-sa__btn', 'ag-sa__in', 4)
    t = wrap(t, 'a', 'ag-sa__ghost', 'ag-sa__gin', 4)
    t = focus3(t, R)
    t = add_css(t, press_css(R, [('ag-sa__btn', 'ag-sa__in'), ('ag-sa__ghost', 'ag-sa__gin')]))
    t = touch(t)
    save(3, t)


# ---------------------------------------------------------------- SCHEDULE-04
LAMP_JS = '''    /* v1.1.0 · «Лампа отвечает вечерам»: чем больше вечеров в адресе страницы (?days=, его пишет SCHEDULE-02),
       тем теплее и шире лампа над заголовком. Уровень — по адресу (без SCHEDULE-02 работает так же);
       меняется, когда блок на экране (IntersectionObserver), переходом 0,6 с. */
    var lampLv = 0, lampSeen = false;
    function lamp(n) {
      lampLv = Math.max(0, Math.min(7, n)) / 7;
      if (lampSeen) root.style.setProperty("--lv", lampLv.toFixed(3));
    }
    if ("IntersectionObserver" in W) {
      new IntersectionObserver(function (es) {
        lampSeen = es[es.length - 1].isIntersecting;
        if (lampSeen) root.style.setProperty("--lv", lampLv.toFixed(3));
      }).observe(root);
    } else { lampSeen = true; }
'''


def s04():
    t = load(4); R = '#ag-schedule-04'
    t = bump(t, '«Лампа отвечает вечерам»: чем больше вечеров отмечено (?days= в адресе, его пишет SCHEDULE-02), тем\n'
                '     теплее и шире лампа (свойство scale и тёплый слой ::after, потолок 0,12 — надзаголовок над лампой ≥ 4,5:1;\n'
                '     переход, когда блок на экране). Зерна бумаги здесь нет: над лампой оно роняет контраст надзаголовка.\n'
                '     Факт № 11 в лиде: «Первое групповое занятие для взрослых бесплатное.»\n'
                '     Магнит снят, нажатие F23, фокус 3 px. Контурное «ВЕЧЕР» — как было.')
    t = rep(t, 'Администратор подберёт группу, назовёт день и время, а на первое занятие поставит бесплатно.</p>',
            'Администратор подберёт группу и назовёт день и время. Первое групповое занятие для взрослых бесплатное.</p>')
    t = rep(t, ' data-ag-go data-ag-magnetic data-ag-track', ' data-ag-go data-ag-track')
    t = wrap(t, 'a', 'ag-sc__btn', 'ag-sc__in')
    t = wrap(t, 'a', 'ag-sc__tel', 'ag-sc__tin')
    t = focus3(t, R)
    t = rep(t, '    var DAYS = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"];\n    function build() {\n',
            '    var DAYS = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"];\n' + LAMP_JS + '    function build() {\n')
    t = rep(t, '        if (days.length) q.push("days=" + days.join(","));\n',
            '        if (days.length) q.push("days=" + days.join(","));\n        lamp(days.length);\n')
    css = press_css(R, [('ag-sc__btn', 'ag-sc__in'), ('ag-sc__tel', 'ag-sc__tin')])
    css += '''  /* «Лампа отвечает вечерам»: шире и теплее с числом вечеров (--lv 0…1 ставит скрипт) */
  #ag-schedule-04 .ag-sc__lamp{scale:calc(1 + .1 * var(--lv,0));transition:scale .6s cubic-bezier(.22,.61,.36,1);}
  #ag-schedule-04 .ag-sc__lamp::after{
    content:"";position:absolute;inset:6% 14%;border-radius:50%;pointer-events:none;
    background:radial-gradient(closest-side,rgba(255,150,40,.12),rgba(255,150,40,.05) 50%,rgba(255,150,40,0) 75%);
    opacity:var(--lv,0);transition:opacity .6s ease;
  }
'''
    t = add_css(t, css)
    t = touch(t)
    save(4, t)


if __name__ == '__main__':
    for f in (s01, s02, s03, s04):
        f()
