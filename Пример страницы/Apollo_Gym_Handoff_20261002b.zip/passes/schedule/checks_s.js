// /schedule (SCHEDULE) · проверки прохода «дизайн, движение и фишка» (PROMPT_SCHEDULE_DESIGN_MOTION_v2)
const {open,settle}=require('./lib');const fs=require('fs'),path=require('path');
const AFTER='file://'+path.resolve('after.html'), BEFORE='file://'+path.resolve('before.html');
const out={};const log=(g,ok,msg)=>{(out[g]=out[g]||[]).push((ok?'pass ':'FAIL ')+msg);};
const G=process.env.G||'LTCMFA';
async function txt(url){const {browser,page}=await open({reduce:true});await page.goto(url);await page.waitForTimeout(2600);
  const r=await page.evaluate(()=>{const o={};document.querySelectorAll('.ag-scope').forEach(r=>{const c=r.cloneNode(true);c.querySelectorAll('style,script,.ag-vh').forEach(x=>x.remove());o[r.id]=c.textContent.replace(/\s+/g,' ').trim();});return o;});await browser.close();return r;}
async function links(url){const {browser,page}=await open({reduce:true});await page.goto(url);await page.waitForTimeout(400);
  const r=await page.evaluate(()=>[...document.querySelectorAll('.ag-scope a[href]')].map(a=>a.closest('.ag-scope').id+' '+a.getAttribute('href')));await browser.close();return r;}
// в середине экрана (полоса IntersectionObserver — 45 % сверху и снизу)
async function _toStep(page,i){await page.evaluate(i=>{const s=document.querySelectorAll('#ag-dir01-02 .ag-tl__step')[i];const r=s.getBoundingClientRect();scrollTo(0,scrollY+r.top+Math.min(r.height,60)/2-innerHeight/2);},i);}
const RAF=`window.__rafF=0;const __r=window.requestAnimationFrame.bind(window);window.requestAnimationFrame=function(f){if(f&&f.name==='frame')window.__rafF++;return __r(f);};`;
const running=`document.getAnimations().filter(a=>a.playState==='running'&&!(a instanceof CSSTransition))`;
(async()=>{
 if(G.includes('L')) for(const reduce of [false,true]) for(const fontsOff of [false,true]) for(const w of [320,360,390,768,1024,1440,1920]){
   const {browser,page}=await open({w,h:w<700?800:900,reduce,mobile:w<700,touch:w<700});
   if(fontsOff) await page.route('**/fonts.googleapis.com/**',r=>r.abort());
   await page.goto(AFTER);await settle(page);
   const r=await page.evaluate(()=>({ov:document.documentElement.scrollWidth>document.documentElement.clientWidth,h:document.body.scrollHeight}));
   log('L',!r.ov,`${w}px reduce=${reduce} fontsOff=${fontsOff} overflowX=${r.ov} h=${r.h}`);await browser.close();
 }
 if(G.includes('T')){const tb=await txt(BEFORE),ta=await txt(AFTER);
  const EXC={'ag-schedule-01':[['первое групповое занятие для взрослых','первое групповое занятие']],'ag-schedule-02':[['Первое групповое для взрослых','Первое групповое занятие']],'ag-schedule-04':[['Администратор подберёт группу и назовёт день и время. Первое групповое занятие для взрослых бесплатное.','Администратор подберёт группу, назовёт день и время, а на первое занятие поставит бесплатно.']]};
  for(const id of Object.keys(tb)){let a=ta[id];(EXC[id]||[]).forEach(([n,o])=>{a=a.split(n).join(o);});let i=0;while(i<tb[id].length&&tb[id][i]===a[i])i++;
   log('T',a===tb[id],id+(a===tb[id]?' текст совпадает':' РАЗНИЦА '+JSON.stringify(tb[id].slice(i-30,i+40))+' → '+JSON.stringify(a.slice(i-30,i+40))));}}
 if(G.includes('C')){const lb=await links(BEFORE),la=await links(AFTER);const add=la.filter(x=>!lb.includes(x)),rem=lb.filter(x=>!la.includes(x));
  log('C',rem.length===0&&add.length===0,`ссылки +${add.length} −${rem.length}`);}
 if(G.includes('M')){
  for(const mode of [{name:'js off',js:false},{name:'reduce',reduce:true},{name:'cdn fail',cdn:'fail'},{name:'cdn hang',cdn:'hang'}]){
   const {browser,page}=await open({w:390,h:800,mobile:true,...mode});await page.goto(AFTER,{waitUntil:'domcontentloaded'});await page.waitForTimeout(2700);
   if(mode.js!==false) for(let y=0;y<9000;y+=600){await page.evaluate(y=>scrollTo(0,y),y);await page.waitForTimeout(40);}
   const r=await page.evaluate(()=>{const bad=[];document.querySelectorAll('.ag-scope :is(p,h1,h2,h3,a,li,dt,dd,summary,td,th)').forEach(el=>{if(el.closest('[aria-hidden="true"],[hidden]'))return;let n=el,op=1;while(n&&n.nodeType===1){op*=parseFloat(getComputedStyle(n).opacity);n=n.parentElement;}if(getComputedStyle(el).display==='none')return;if(op<0.99&&el.textContent.trim())bad.push(el.textContent.trim().slice(0,30));});
     return {bad,m:document.documentElement.getAttribute('data-ag-motion'),routes:0};});
   log('M',r.bad.length===0,`${mode.name}: motion=${r.m} скрытых текстов ${r.bad.length} ${r.bad.slice(0,3).join('|')}`);await browser.close();}
  const {browser,page}=await open({w:1440});await page.goto(AFTER);await settle(page);
  const r=await page.evaluate(()=>{const o={};document.querySelectorAll('.ag-scope').forEach(root=>{const all=root.querySelectorAll('[data-ag-anim]');o[root.id]=[all.length,[...all].filter(e=>!e.hasAttribute('data-ag-done')).length];});return o;});
  for(const [id,[n,left]] of Object.entries(r)) log('M',left===0,`motion on: ${id} анимаций ${n}, не отсканировано ${left}`);await browser.close();}


 if(G.includes('F')){
  const ind=(i)=>`(()=>{const l=document.querySelector('#ag-schedule-02 .ag-sf__tabs'),t=document.querySelectorAll('#ag-schedule-02 .ag-sf__tab')[${i}];const cs=getComputedStyle(l,'::before');const m=new DOMMatrix(cs.transform);const kin=parseFloat(getComputedStyle(l).getPropertyValue('--kin'));return {x:m.m41,y:m.m42,w:parseFloat(cs.width),tx:t.offsetLeft+kin,ty:t.offsetTop,tw:t.offsetWidth-2*kin,after:getComputedStyle(t,'::after').backgroundColor,sel:t.getAttribute('aria-selected')};})()`;
  const ok=(r)=>Math.abs(r.x-r.tx)<1&&Math.abs(r.y-r.ty)<1&&Math.abs(r.w-r.tw)<1;
  const flips=`[...document.querySelectorAll('#ag-schedule-02 [data-ag-t]')].map(d=>d.getAttribute('data-ag-t')+':'+d.getAnimations().filter(a=>!(a instanceof CSSTransition)).length).join(' ')`;
  {const {browser,page}=await open({w:1440,h:900});await page.goto(AFTER);await settle(page);
   await page.evaluate(()=>document.getElementById('ag-schedule-02').scrollIntoView());await page.waitForTimeout(600);
   const r0=await page.evaluate(ind(0));log('F',ok(r0)&&r0.sel==='true'&&r0.after==='rgba(0, 0, 0, 0)',`ПК: кромка над выбранной закладкой (${Math.round(r0.x)},${Math.round(r0.y)} ${Math.round(r0.w)} px ↔ ${Math.round(r0.tx)},${r0.ty} ${Math.round(r0.tw)} px), своя кромка закладки скрыта`);
   await page.click('#ag-schedule-02-t-gym');await page.waitForTimeout(110);const mid=await page.evaluate(ind(2));await page.waitForTimeout(400);const r2=await page.evaluate(ind(2));
   log('F',ok(r2)&&mid.x<r2.tx-2,`ПК: клик «Ново-Садовая» — кромка переезжает (на 110 мс x=${Math.round(mid.x)}, в конце ${Math.round(r2.x)} ↔ ${Math.round(r2.tx)})`);
   await page.focus('#ag-schedule-02-t-gym');await page.keyboard.press('ArrowRight');await page.waitForTimeout(450);const r3=await page.evaluate(ind(3));
   log('F',ok(r3)&&r3.sel==='true',`ПК: стрелка → «Молодогвардейская», кромка следом`);
   // билет-табло
   await page.goto(AFTER);await page.waitForTimeout(1500);await page.evaluate(()=>document.getElementById('ag-schedule-02').scrollIntoView());await page.waitForTimeout(600);
   await page.click('#ag-hall-boxing .ag-sf__chip[data-dir="boxing-samara"]');await page.waitForTimeout(30);
   const f1=await page.evaluate(flips);
   await page.waitForTimeout(500);
   const day=async d=>{await page.click(`#ag-schedule-02 .ag-sf__day[data-day="${d}"]`);await page.waitForTimeout(30);return page.evaluate(flips);};
   const f2=await day('mon');await page.waitForTimeout(400);const f3=await day('wed');
   log('F',/club:1/.test(f1)&&/direction:1/.test(f1)&&/days:0/.test(f2)&&/days:1/.test(f3),`билет-табло: чип — перелистнулись «зал» и «направление» (${f1}); первый вечер — строка появилась без перелистывания (${f2}); второй — перелистнулась (${f3})`);
   for(const d of ['tue','thu','fri','sat','sun','tue','mon','wed','thu']){await page.click(`#ag-schedule-02 .ag-sf__day[data-day="${d}"]`);await page.waitForTimeout(25);}
   await page.waitForTimeout(1000);
   const st=await page.evaluate(()=>({t:document.querySelector('#ag-schedule-02 [data-ag-t="days"]').textContent,u:location.search,n:document.getAnimations().filter(a=>!(a instanceof CSSTransition)&&a.playState==='running').length}));
   log('F',st.t==='Пт, Сб, Вс'&&/days=fri,sat,sun/.test(st.u)&&st.n===0,`10 быстрых нажатий: в билете «${st.t}», адрес ${st.u}, анимаций через 1 с: ${st.n}`);
   // лампа
   for(const d of ['mon','tue','wed','thu']){await page.click(`#ag-schedule-02 .ag-sf__day[data-day="${d}"]`);await page.waitForTimeout(25);}
   const lv0=await page.evaluate(()=>getComputedStyle(document.getElementById('ag-schedule-04')).getPropertyValue('--lv'));
   await page.evaluate(()=>document.getElementById('ag-schedule-04').scrollIntoView());await page.waitForTimeout(900);
   const L=await page.evaluate(()=>{const r=document.getElementById('ag-schedule-04'),l=r.querySelector('.ag-sc__lamp');return {lv:getComputedStyle(r).getPropertyValue('--lv').trim(),scale:getComputedStyle(l).scale,op:getComputedStyle(l,'::after').opacity,href:r.querySelector('.ag-sc__btn').getAttribute('href')};});
   log('F',L.lv==='1.000'&&/1\.1/.test(L.scale)&&+L.op>0.99,`лампа: 7 вечеров — --lv ${L.lv} (пока блок вне экрана: «${lv0.trim()}»), scale ${L.scale}, тёплый слой ${L.op}; ссылка ${L.href}`);
   // магнит и F23
   const mag=await page.$$eval('[data-ag-magnetic]',x=>x.length);log('F',mag===0,`магнитных кнопок: ${mag}`);
   const btn=await page.$('#ag-schedule-04 .ag-sc__btn');const b0=await btn.boundingBox();
   await page.mouse.move(b0.x+b0.width/2,b0.y+b0.height/2);await page.mouse.move(b0.x+b0.width/2+30,b0.y+b0.height/2+10,{steps:5});await page.waitForTimeout(250);const b1=await btn.boundingBox();
   await page.evaluate(()=>document.querySelector('#ag-schedule-04 .ag-sc__btn').addEventListener('click',e=>e.preventDefault(),{once:true}));
   await page.mouse.down();await page.waitForTimeout(220);const tr=await page.$eval('#ag-schedule-04 .ag-sc__in',e=>getComputedStyle(e).transform);await page.mouse.up();
   log('F',Math.abs(b1.x-b0.x)<0.5&&/matrix\(0\.98/.test(tr),`F23: кнопка на месте (Δ ${(b1.x-b0.x).toFixed(1)}), при нажатии ${tr}`);
   const gr=await page.evaluate(()=>['#ag-schedule-02 .ag-sf'].map(s=>/svg/.test(getComputedStyle(document.querySelector(s),'::before').backgroundImage)));
   log('F',gr.every(Boolean),`зерно бумаги на ПК: 02 ${gr[0]} (04 — без зерна: лампа)`);
   await browser.close();}
  // загрузка с выбором в адресе и с #ag-hall-…
  for(const q of ['?club=gym&direction=fitbox&days=tue,thu','#ag-hall-nofitness']){
   const {browser,page}=await open({w:1440,h:900});await page.goto(AFTER+q);await page.waitForTimeout(1500);
   const i=q.includes('gym')?2:3;const r=await page.evaluate(ind(i));
   await page.evaluate(()=>document.getElementById('ag-schedule-04').scrollIntoView());await page.waitForTimeout(900);
   const lv=await page.evaluate(()=>getComputedStyle(document.getElementById('ag-schedule-04')).getPropertyValue('--lv').trim());
   const want=q.includes('days')?'0.286':'0.000';
   log('F',ok(r)&&r.sel==='true'&&lv===want,`загрузка ${q}: кромка над своей закладкой, лампа по адресу --lv ${lv}`);await browser.close();}
  // телефон: 2×2 и перенос между рядами; зерна нет
  {const {browser,page}=await open({w:390,h:800,mobile:true,touch:true});await page.goto(AFTER);await settle(page);
   await page.evaluate(()=>document.getElementById('ag-schedule-02').scrollIntoView());await page.waitForTimeout(500);
   await page.click('#ag-schedule-02-t-gym');await page.waitForTimeout(40);
   const m=await page.evaluate(()=>{const l=document.querySelector('#ag-schedule-02 .ag-sf__tabs');return l.getAnimations({subtree:true}).length;});
   await page.waitForTimeout(400);const r=await page.evaluate(ind(2));
   const gr=await page.evaluate(()=>getComputedStyle(document.querySelector('#ag-schedule-02 .ag-sf'),'::before').backgroundImage);
   log('F',ok(r)&&r.ty>10&&!/svg/.test(gr),`телефон: кромка во втором ряду (${Math.round(r.x)},${Math.round(r.y)} ↔ ${Math.round(r.tx)},${r.ty}), перенос с проявлением (${m}), зерна нет`);
   await browser.close();}
  // reduce и reduce на лету; forced-colors
  {const {browser,page}=await open({w:1440,h:900,reduce:true});await page.goto(AFTER);await settle(page);
   await page.evaluate(()=>document.getElementById('ag-schedule-02').scrollIntoView());await page.waitForTimeout(300);
   await page.click('#ag-hall-boxing .ag-sf__chip[data-dir="boxing-samara"]');await page.waitForTimeout(30);const f=await page.evaluate(flips);
   log('F',!/:1/.test(f),`reduce: билет без перелистывания (${f})`);await browser.close();}
  {const {browser,page}=await open({w:1440,h:900});await page.goto(AFTER);await settle(page);
   await page.evaluate(()=>document.getElementById('ag-schedule-02').scrollIntoView());await page.waitForTimeout(300);await page.emulateMedia({reducedMotion:'reduce'});
   await page.click('#ag-hall-boxing .ag-sf__chip[data-dir="boxing-samara"]');await page.waitForTimeout(30);const f=await page.evaluate(flips);
   log('F',!/:1/.test(f),`reduce на лету: без перелистывания (${f})`);await browser.close();}
  {const {browser,page}=await open({w:1440,h:900});await page.emulateMedia({forcedColors:'active'});await page.goto(AFTER);await settle(page);
   await page.evaluate(()=>document.getElementById('ag-schedule-02').scrollIntoView());await page.waitForTimeout(300);
   const fc=await page.evaluate(()=>{const l=document.querySelector('#ag-schedule-02 .ag-sf__tabs');const t=document.querySelector('#ag-schedule-02 .ag-sf__tab[aria-selected="true"]');return {b:getComputedStyle(l,'::before').content,a:getComputedStyle(t,'::after').backgroundColor};});
   await page.screenshot({path:'shots/forced_02.png',clip:await (await page.$('#ag-schedule-02')).boundingBox().then(b=>({x:0,y:b.y,width:1440,height:Math.min(b.height,900)}))});
   log('F',fc.b==='none'&&fc.a!=='rgba(0, 0, 0, 0)',`forced-colors: общей кромки нет (${fc.b}), своя кромка закладки видна (${fc.a})`);await browser.close();}
 }
 if(G.includes('A')){const axeSrc=fs.readFileSync(require.resolve('axe-core/axe.min.js'),'utf8');
  for(const m of [{w:1440},{w:1024},{w:390,mobile:true},{w:390,mobile:true,reduce:true},{w:390,nojs:true}]){
   let o;if(m.nojs){fs.writeFileSync('after_nojs.html',fs.readFileSync('after.html','utf8').replace(/<script>[\s\S]*?<\/script>/g,'').replace(/<!--[\s\S]*?-->/g,'').replace(/<noscript>([\s\S]*?)<\/noscript>/g,'$1'));o=await open({w:390,h:900});await o.page.goto('file://'+path.resolve('after_nojs.html'));await o.page.waitForTimeout(800);}
   else {o=await open({...m,h:900});await o.page.goto(AFTER);await settle(o.page);}
   await o.page.addScriptTag({content:axeSrc});const res=await o.page.evaluate(async()=>(await axe.run(document.getElementById('allrecords'),{resultTypes:['violations']})).violations.map(v=>[v.id,v.impact,v.nodes.length,v.nodes[0].target.join(' ')]));
   const s=res.filter(v=>/serious|critical/.test(v[1]));log('A',s.length===0,`${m.w}${m.reduce?' reduce':''}${m.nojs?' без JS':''}: нарушений ${res.length} (serious/critical ${s.length}) ${res.map(v=>v.join(':')).join(' ; ').slice(0,300)}`);await o.browser.close();}
  {const o=await open({w:1440,h:900});await o.page.goto(AFTER);await settle(o.page);await o.page.evaluate(()=>{document.querySelectorAll('#ag-schedule-02 .ag-sf__day').forEach(d=>d.click());});await o.page.waitForTimeout(500);
   await o.page.addScriptTag({content:axeSrc});const res=await o.page.evaluate(async()=>(await axe.run(document.getElementById('allrecords'),{resultTypes:['violations']})).violations.map(v=>[v.id,v.impact]));
   log('A',res.length===0,`1440, отмечены все вечера: нарушений ${res.length} ${res.join(' ; ')}`);await o.browser.close();}}
 fs.writeFileSync('checks_s_'+G+'.json',JSON.stringify(out,null,1));
 for(const g of Object.keys(out)){console.log('## '+g);out[g].forEach(x=>console.log('  '+x));}
})();
