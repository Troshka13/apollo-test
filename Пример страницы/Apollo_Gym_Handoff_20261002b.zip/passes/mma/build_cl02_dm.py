# -*- coding: utf-8 -*-
"""/mma (CL02) · проход «дизайн, движение и фишка» (PROMPT_CL02_DESIGN_MOTION_v2, 30.09.2026).
src/CL02-0N_v1.0.0.html (05 — v1.0.1) → out/CL02-0N_v1.1.0.html. Каждая замена обязана найтись нужное число раз."""
import re, os, sys

sys.path.insert(0, '/home/claude/pr')
from build_prices_dm import rep, rx, focus3, wrap, press_css, add_css, touch, GRAIN  # noqa: E402

SRC, OUT = 'src', 'out'
os.makedirs(OUT, exist_ok=True)
DATE = '30.09.2026'
BASE = {5: 'v1.0.1'}


def load(n):
    return open('%s/CL02-0%d_%s.html' % (SRC, n, BASE.get(n, 'v1.0.0')), encoding='utf-8').read()


def save(n, t):
    p = '%s/CL02-0%d_v1.1.0.html' % (OUT, n)
    open(p, 'w', encoding='utf-8').write(t)
    print('CL02-0%d v1.1.0 %6d байт' % (n, len(t.encode('utf-8'))))


def bump(t, n, note):
    base = BASE.get(n, 'v1.0.0')
    t = rx(t, r'(APOLLO GYM · CL02-0\d[^\n]*?)· %s · \d\d\.09\.2026' % re.escape(base), r'\1· v1.1.0 · 30.09.2026')
    i = t.index('-->') + 3
    return t[:i] + '\n<!-- v1.1.0 (проход «дизайн, движение и фишка», PROMPT_CL02_DESIGN_MOTION_v2, %s):\n     %s -->' % (DATE, note) + t[i:]


def grain_css(root, sec, wrap_cls):
    return '''  /* F29 · зерно бумаги (статично, только ≥ 640 px; forced-colors и печать — без зерна) */
  @media (min-width:640px){
    %(r)s .%(s)s::before{content:"";position:absolute;inset:0;z-index:0;pointer-events:none;opacity:.12;background-image:%(g)s;background-size:180px 180px;}
    %(r)s .%(w)s{position:relative;z-index:1;}
  }
  @media (forced-colors:active){%(r)s .%(s)s::before{display:none;}}
  @media print{%(r)s .%(s)s::before{display:none;}}
''' % {'r': root, 's': sec, 'w': wrap_cls, 'g': GRAIN}


def before_engine(t, js):
    i = t.index('<!-- Движок движения')
    return t[:i] + js.lstrip('\n') + '\n  ' + t[i:]


IMG = {
    '5410': 'https://static.tildacdn.pub/tild6432-3439-4361-b633-313734343633/img_5410-scaled.jpeg',
    '5464': 'https://static.tildacdn.pub/tild3334-6462-4835-b461-663439656337/img_5464-scaled.jpeg',
}

# ---------------------------------------------------------------- CL02-01
MESH_JS = r'''
  <script>
  /* v1.1.0 · «Живая сетка клетки» (ведущая фишка страницы, F30). Рабица в углу ленты отзывается на удар:
     нажатие мышью или касание — по сетке расходится круговая волна, проволока коротко дребезжит, вокруг
     удара сетка на миг ярче; под курсором сетка слегка «дышит». Canvas создаётся при первом наведении
     или касании ленты (кадр первого экрана и LCP не трогаем), живёт внутри .ag-mh__meshi — параллакс
     движка и маска наследуются; первый кадр canvas повторяет SVG (ромб 36, xMaxYMin slice), только потом
     SVG прячется. Модель — затухающие волны от ударов (без поля узлов), шаг ≤ 2 кадров; rAF только пока
     волны живы; вне экрана и в скрытой вкладке — стоп и сброс. Слушатели пассивные, touch-action не
     трогаем: свайп и щипок работают; удар касанием — только если жест не стал прокруткой (без
     pointercancel, сдвиг ≤ 10 px). reduce и forced-colors — фишки нет (на лету — возврат SVG). */
  (function () {
    "use strict";
    var W = window, D = document;
    var root = D.currentScript && D.currentScript.closest(".ag-scope");
    if (!root || root.hasAttribute("data-ag-ui-mesh-on")) return;
    root.setAttribute("data-ag-ui-mesh-on", "");
    var band = root.querySelector(".ag-mh__band");
    var host = root.querySelector(".ag-mh__meshi");
    var svg = host && host.querySelector("svg");
    if (!band || !host || !svg || !W.matchMedia || !W.requestAnimationFrame || !("IntersectionObserver" in W)) return;
    var mqR = W.matchMedia("(prefers-reduced-motion: reduce)");
    var mqF = W.matchMedia("(forced-colors: active)");
    var fine = W.matchMedia("(hover: hover) and (pointer: fine)");
    var cv = null, ctx = null, w = 0, h = 0, dpr = 1, sc = 1, ox = 0;
    var nodes = [], segs = [], hits = [], raf = 0, last = 0, seen = true, on = false;
    var hover = null, hoverAt = 0, down = null;
    var LIFE = 1100;
    function off() { return mqR.matches || mqF.matches; }
    function geom() {
      if (!cv) return;
      var r = host.getBoundingClientRect();
      w = Math.max(1, r.width); h = Math.max(1, r.height);
      dpr = Math.min(2, W.devicePixelRatio || 1);
      cv.width = Math.round(w * dpr); cv.height = Math.round(h * dpr);
      sc = Math.max(w / 480, h / 480); ox = w - 480 * sc;
      var s = 18 * sc, i0 = Math.floor(-ox / s) - 1, i1 = Math.ceil((w - ox) / s) + 1, j1 = Math.ceil(h / s) + 1, idx = {};
      nodes = []; segs = [];
      for (var i = i0; i <= i1; i++) for (var j = -1; j <= j1; j++) {
        if (((i + j) % 2 + 2) % 2 !== 1) continue;
        idx[i + "," + j] = nodes.length;
        nodes.push({ x: ox + i * s, y: j * s, px: 0, py: 0 });
      }
      for (var k in idx) {
        var p = k.split(","), a = +p[0], b = +p[1];
        var n1 = idx[(a + 1) + "," + (b + 1)], n2 = idx[(a + 1) + "," + (b - 1)];
        if (n1 !== undefined) segs.push([idx[k], n1]);
        if (n2 !== undefined) segs.push([idx[k], n2]);
      }
    }
    function field(now) {
      var hv = hover && now - hoverAt < 450 ? 1 - (now - hoverAt) / 450 : 0;
      for (var n = 0; n < nodes.length; n++) {
        var q = nodes[n], dx = 0, dy = 0;
        for (var m = 0; m < hits.length; m++) {
          var ht = hits[m], age = (now - ht.t) / 1000;
          var ex = q.x - ht.x, ey = q.y - ht.y, d = Math.sqrt(ex * ex + ey * ey) || 1;
          var front = 520 * sc * age, lam = 34 * sc, g = d - front;
          if (g < lam * 2.5) {
            var amp = ht.a * Math.exp(-age * 3.2) * Math.exp(-(g * g) / (2 * lam * lam)) * Math.max(0, 1 - d / (420 * sc));
            dx += ex / d * amp; dy += ey / d * amp;
          }
          if (d < 120 * sc) {
            var rat = ht.a * 0.35 * Math.exp(-age * 7) * Math.sin(age * 55) * (1 - d / (120 * sc));
            dx += -ey / d * rat; dy += ex / d * rat;
          }
        }
        if (hv && hover) {
          var hx = q.x - hover.x, hy = q.y - hover.y, hd = Math.sqrt(hx * hx + hy * hy) || 1, R = 110 * sc;
          if (hd < R) { var f = 5 * sc * hv * Math.pow(1 - hd / R, 2); dx += hx / hd * f; dy += hy / hd * f; }
        }
        q.px = q.x + dx; q.py = q.y + dy;
      }
    }
    function draw(now) {
      if (!ctx) return;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, w, h);
      ctx.lineWidth = 2.2 * sc; ctx.lineJoin = "round"; ctx.lineCap = "round";
      ctx.strokeStyle = "#E9E9EC";
      ctx.beginPath();
      for (var s = 0; s < segs.length; s++) { var a = nodes[segs[s][0]], b = nodes[segs[s][1]]; ctx.moveTo(a.px, a.py); ctx.lineTo(b.px, b.py); }
      ctx.stroke();
      /* вокруг удара проволока на миг ярче */
      for (var m = 0; m < hits.length; m++) {
        var ht = hits[m], age = (now - ht.t) / 1000, al = Math.max(0, 1 - age / (LIFE / 1000)) * 0.9, R = (140 + 360 * age) * sc;
        if (al <= 0.01) continue;
        ctx.strokeStyle = "rgba(255,226,140," + al.toFixed(3) + ")";
        ctx.beginPath();
        for (var t = 0; t < segs.length; t++) {
          var p = nodes[segs[t][0]], q = nodes[segs[t][1]], mx = (p.x + q.x) / 2 - ht.x, my = (p.y + q.y) / 2 - ht.y;
          if (mx * mx + my * my < R * R) { ctx.moveTo(p.px, p.py); ctx.lineTo(q.px, q.py); }
        }
        ctx.stroke();
      }
    }
    function still() { for (var n = 0; n < nodes.length; n++) { nodes[n].px = nodes[n].x; nodes[n].py = nodes[n].y; } draw(0); }
    function frame(now) {
      raf = 0;
      last = now;
      hits = hits.filter(function (ht) { return now - ht.t < LIFE; });
      var alive = hits.length || (hover && now - hoverAt < 450);
      field(now); draw(now);
      if (alive && seen && !D.hidden) raf = W.requestAnimationFrame(frame);
      else { hits = []; still(); }
    }
    function kick() { if (!raf && cv && seen && !D.hidden) raf = W.requestAnimationFrame(frame); }
    function make() {
      if (cv || off()) return !!cv;
      cv = D.createElement("canvas");
      cv.className = "ag-mh__meshc";
      cv.setAttribute("aria-hidden", "true");
      ctx = cv.getContext && cv.getContext("2d");
      if (!ctx) { cv = null; return false; }
      host.appendChild(cv);
      geom(); still();
      svg.style.visibility = "hidden";
      if ("ResizeObserver" in W) new W.ResizeObserver(function () { if (cv) { geom(); still(); } }).observe(host);
      return true;
    }
    function destroy() {
      if (raf) W.cancelAnimationFrame(raf);
      raf = 0; hits = []; hover = null;
      if (cv && cv.parentNode) cv.parentNode.removeChild(cv);
      cv = null; ctx = null;
      svg.style.visibility = "";
    }
    function at(e) { var r = cv.getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; }
    function hit(e, a) {
      if (!make()) return;
      var p = at(e);
      hits.push({ x: p.x, y: p.y, t: W.performance.now(), a: a * sc });
      if (hits.length > 4) hits.shift();
      kick();
    }
    function onEnter() { if (fine.matches && !off()) make(); }
    function onMove(e) {
      if (!cv || e.pointerType !== "mouse" || !fine.matches) return;
      hover = at(e); hoverAt = W.performance.now(); kick();
    }
    function onDown(e) {
      if (off()) return;
      if (e.pointerType === "mouse") { if (e.button === 0) hit(e, 14); return; }
      down = { id: e.pointerId, x: e.clientX, y: e.clientY, ok: true };
    }
    function onUp(e) {
      if (!down || down.id !== e.pointerId) return;
      var moved = Math.abs(e.clientX - down.x) + Math.abs(e.clientY - down.y);
      if (down.ok && moved <= 10) hit(e, 16);
      down = null;
    }
    function onCancel() { if (down) down.ok = false; down = null; }
    function enable() {
      if (on || off()) return;
      on = true;
      band.addEventListener("pointerenter", onEnter, { passive: true });
      band.addEventListener("pointermove", onMove, { passive: true });
      band.addEventListener("pointerdown", onDown, { passive: true });
      band.addEventListener("pointerup", onUp, { passive: true });
      band.addEventListener("pointercancel", onCancel, { passive: true });
    }
    function disable() {
      if (!on) return;
      on = false;
      band.removeEventListener("pointerenter", onEnter);
      band.removeEventListener("pointermove", onMove);
      band.removeEventListener("pointerdown", onDown);
      band.removeEventListener("pointerup", onUp);
      band.removeEventListener("pointercancel", onCancel);
      destroy();
    }
    new IntersectionObserver(function (es) {
      seen = es[es.length - 1].isIntersecting;
      if (!seen && cv) { if (raf) W.cancelAnimationFrame(raf); raf = 0; hits = []; hover = null; still(); }
    }).observe(band);
    D.addEventListener("visibilitychange", function () { if (D.hidden && cv) { if (raf) W.cancelAnimationFrame(raf); raf = 0; hits = []; still(); } });
    W.addEventListener("resize", function () { if (cv) { geom(); still(); } });
    function onPref() { if (off()) disable(); else enable(); }
    [mqR, mqF].forEach(function (q) { if (q.addEventListener) q.addEventListener("change", onPref); else if (q.addListener) q.addListener(onPref); });
    enable();
  })();
  </script>
'''


def c01():
    t = load(1); R = '#ag-cl02-01'
    t = bump(t, 1, 'Кадр первого экрана — img_5464: на нём клетка (сверено глазами 30.09); прежний img_5410 — ринг, подпись\n'
                   '     «Клетка для ММА» ему не подходила, он ушёл в ленту CL02-02. Ведущая фишка страницы «Живая сетка клетки»:\n'
                   '     удар мышью или касание — по рабице волна и дребезг, вокруг удара сетка ярче; наведение — слабое\n'
                   '     «дыхание» (canvas при первом взаимодействии, ограничения — в комментарии скрипта). Сетка — из нашей\n'
                   '     сборки v1.0.0. Факт № 11: «0 ₽ — первое групповое занятие для взрослых». Магнит снят, F23, фокус 3 px.\n'
                   '     Телефон: строки планки плотнее.')
    t = rep(t, 'Плашка\n     «Первое групповое занятие — бесплатно» — это ячейка «0 ₽» планки.',
            'Плашка\n     «Первое групповое занятие для взрослых — бесплатно» — это ячейка «0 ₽» планки (v1.1.0).')
    t = rep(t, '<img class="ag-mh__img" src="%s"' % IMG['5410'], '<img class="ag-mh__img" src="%s"' % IMG['5464'])
    t = rep(t, '<b>0&nbsp;₽</b><span>первое групповое занятие</span>', '<b>0&nbsp;₽</b><span>первое групповое занятие для&nbsp;взрослых</span>')
    t = rep(t, ' data-ag-magnetic="0.18"', '')
    t = wrap(t, 'a', 'ag-btn ag-btn--primary', 'ag-btn__in')
    t = wrap(t, 'a', 'ag-btn ag-btn--ghost', 'ag-btn__in')
    t = focus3(t, R)
    css = press_css(R, [('ag-btn', 'ag-btn__in')])
    css += '''  /* «Живая сетка клетки»: canvas поверх той же сетки (SVG прячется после первого кадра canvas) */
  #ag-cl02-01 .ag-mh__meshc{position:absolute;inset:0;display:block;width:100%;height:100%;opacity:.5;pointer-events:none;}
  @media (forced-colors:active){#ag-cl02-01 .ag-mh__meshc{display:none;}}
  @media (max-width:767.98px){
    #ag-cl02-01 .ag-mh__fact{padding-top:7px;padding-bottom:6px;}
    #ag-cl02-01 .ag-mh__fact>span{line-height:1.35;}
  }
'''
    t = add_css(t, css)
    t = touch(t)
    t = before_engine(t, MESH_JS)
    save(1, t)


# ---------------------------------------------------------------- CL02-02
CAPS = [
    # (img id, старая подпись, новая подпись, alt)
    ('img_5464-scaled.jpeg', 'Зал на Чкалова,&nbsp;72', 'Зал на Чкалова,&nbsp;72', None),
    ('img_5470-scaled.jpeg', 'Тренировка в клетке', 'Ударная зона у клетки', 'Боксёрские мешки у клетки'),
    ('img_5433-scaled.jpeg', 'Тренировка на мягком покрытии', 'Ударная зона у стены с граффити', 'Боксёрский мешок у стены с граффити'),
    ('img_5413-scaled-e174.jpeg', 'Грэпплинг: борьба без ударов', 'Тренажёры: гребной и велосипед', 'Гребной тренажёр и велотренажёр в зале Apollo MMA Gym на Чкалова, 72'),
    ('img_5431-scaled.jpeg', 'Групповая тренировка', 'Мяч, скамья, покрышка и канат', 'Мяч, скамья, покрышка и канат в зале Apollo MMA Gym на Чкалова, 72'),
]

DLG_JS = r'''
  <script>
  /* v1.1.0 · F07 «кадр целиком»: ссылка на файл поверх кадра работает и без JS; с JS кадр открывается
     в <dialog> (showModal: фон недоступен, Escape или клик по тёмному полю закрывает), ← → листают, фокус
     возвращается на ссылку.
     Название окна — «Кадр N из 5 · подпись кадра» (подписи — что видно в кадре, сверено 30.09). */
  (function () {
    "use strict";
    var W = window, D = document;
    var root = D.currentScript && D.currentScript.closest(".ag-scope");
    if (!root || root.hasAttribute("data-ag-ui-dlg")) return;
    root.setAttribute("data-ag-ui-dlg", "");
    var dlg = root.querySelector("dialog");
    if (!dlg || typeof dlg.showModal !== "function") return;
    var links = Array.prototype.slice.call(root.querySelectorAll("[data-ag-ui-open]"));
    var img = dlg.querySelector("[data-ag-ui-img]");
    var cap = dlg.querySelector("[data-ag-ui-cap]");
    var html = D.documentElement, back = null, cur = 0, keep = "";
    function show(i) {
      cur = (i + links.length) % links.length;
      var a = links[cur];
      img.setAttribute("src", a.getAttribute("href"));
      img.setAttribute("alt", a.getAttribute("data-ag-ui-alt") || "");
      var txt = "Кадр " + (cur + 1) + " из " + links.length + " · " + (a.getAttribute("data-ag-ui-place") || "");
      if (cap.firstChild) cap.firstChild.nodeValue = txt; else cap.appendChild(D.createTextNode(txt));
    }
    links.forEach(function (a, i) {
      a.addEventListener("click", function (e) {
        if (e.metaKey || e.ctrlKey || e.shiftKey || e.button > 0) return;
        e.preventDefault();
        back = a; show(i);
        keep = html.style.overflow; html.style.overflow = "hidden";
        dlg.showModal();
      });
    });
    dlg.querySelector("[data-ag-ui-prev]").addEventListener("click", function () { show(cur - 1); });
    dlg.querySelector("[data-ag-ui-next]").addEventListener("click", function () { show(cur + 1); });
    dlg.querySelector("[data-ag-ui-close]").addEventListener("click", function () { dlg.close(); });
    var box = dlg.querySelector(".ag-mg__dbox");
    dlg.addEventListener("click", function (e) { if (e.target === dlg || e.target === box) dlg.close(); });
    dlg.addEventListener("keydown", function (e) {
      if (e.key === "ArrowRight") { e.preventDefault(); show(cur + 1); }
      else if (e.key === "ArrowLeft") { e.preventDefault(); show(cur - 1); }
    });
    dlg.addEventListener("close", function () {
      html.style.overflow = keep;
      if (back) { try { back.focus({ preventScroll: true }); } catch (e) { back.focus(); } }
    });
  })();
  </script>
'''


def c02():
    t = load(2); R = '#ag-cl02-02'
    t = bump(t, 2, 'Кадры сверены глазами 30.09: людей на них нет, подписи владельца не совпадали с кадрами. Первый кадр —\n'
                   '     img_5410 (ринг; ушёл из первого экрана, на Чкалова ринг в фактах не значится) — подпись «Зал на Чкалова, 72»,\n'
                   '     alt пустой (закон 10). Дальше — только то, что видно: «Ударная зона у клетки», «Ударная зона у стены\n'
                   '     с граффити» (слово «мешки» в подписи — после ответа 3.4; alt описывает кадр),\n'
                   '     «Тренажёры: гребной и велосипед», «Мяч, скамья, покрышка и канат». Клетка (img_5464) — в первом экране.\n'
                   '     F07 «кадр целиком»: ссылка на файл поверх кадра, с JS — <dialog> (стрелки, Escape, возврат фокуса).')
    first = True
    for i, (img, old, new, alt) in enumerate(CAPS):
        if first:
            t = rep(t, 'src="%s" width="1024" height="683" alt="Зал Apollo MMA Gym на Чкалова, 72"' % IMG['5464'],
                    'src="%s" width="1024" height="683" alt=""' % IMG['5410'])
            src = IMG['5410']; place = 'Зал на Чкалова, 72'; alt_v = ''
            first = False
        else:
            m = re.search(r'src="([^"]*%s)" width="1024" height="683" alt="([^"]*)"' % re.escape(img), t)
            assert m, img
            src = m.group(1)
            t = rep(t, 'src="%s" width="1024" height="683" alt="%s"' % (src, m.group(2)),
                    'src="%s" width="1024" height="683" alt="%s"' % (src, alt))
            t = rep(t, '<span class="ag-mg__dot" aria-hidden="true"></span>%s<span class="ag-vh">' % old,
                    '<span class="ag-mg__dot" aria-hidden="true"></span>%s<span class="ag-vh">' % new)
            place = new.replace('&nbsp;', ' '); alt_v = alt
        link = ('<a class="ag-mg__open" href="%s" data-ag-ui-open data-ag-ui-place="%s" data-ag-ui-alt="%s" data-ag-track="gallery_open" '
                'data-ag-params=\'{"from":"CL02-02","n":%d}\'><span class="ag-vh">Открыть кадр %d из 5</span>'
                '<svg class="ag-mg__zoom" width="20" height="20" viewBox="0 0 20 20" aria-hidden="true" focusable="false">'
                '<path d="M8.5 3.5a5 5 0 1 0 0 10 5 5 0 0 0 0-10ZM12.2 12.2 16.5 16.5M8.5 6.5v4M6.5 8.5h4" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg></a>'
                ) % (src, place, alt_v, i + 1, i + 1)
        pat = r'(<span class="ag-mg__frame"><span class="ag-mg__imgbox"><img class="ag-mg__img" src="%s"[^>]*></span>)(</span>)' % re.escape(src)
        t = rx(t, pat, lambda m: m.group(1) + link + m.group(2))
    dialog = ('<dialog class="ag-mg__dlg" aria-labelledby="ag-cl02-02-dlg-t">'
              '<div class="ag-mg__dbox">'
              '<p class="ag-mg__dt" id="ag-cl02-02-dlg-t" data-ag-ui-cap aria-live="polite">Кадр 1 из 5 · Зал на Чкалова, 72</p>'
              '<img class="ag-mg__dimg" data-ag-ui-img src="%s" alt="" width="1024" height="683" loading="lazy" decoding="async">'
              '<div class="ag-mg__dnav">'
              '<button class="ag-mg__dbtn" type="button" data-ag-ui-prev><svg width="20" height="20" aria-hidden="true" focusable="false"><use href="#ag-cl02-02-i-l"/></svg><span class="ag-vh">Предыдущий кадр</span></button>'
              '<button class="ag-mg__dbtn" type="button" data-ag-ui-next><svg width="20" height="20" aria-hidden="true" focusable="false"><use href="#ag-cl02-02-i-r"/></svg><span class="ag-vh">Следующий кадр</span></button>'
              '</div>'
              '<button class="ag-mg__dx" type="button" data-ag-ui-close><svg width="20" height="20" viewBox="0 0 20 20" aria-hidden="true" focusable="false"><path d="M5 5l10 10M15 5 5 15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg><span class="ag-vh">Закрыть</span></button>'
              '</div></dialog>\n  ') % IMG['5410']
    t = rep(t, '  </section>\n', '  ' + dialog + '</section>\n')
    t = focus3(t, R)
    css = '''  /* F07 · ссылка «открыть кадр»: весь кадр, значок лупы в углу */
  #ag-cl02-02 .ag-mg__open{position:absolute;inset:0;z-index:3;display:block;}
  #ag-cl02-02 .ag-mg__zoom{position:absolute;right:12px;top:12px;width:40px;height:40px;padding:10px;border-radius:50%;
    background:rgba(9,9,10,.62);border:1px solid rgba(255,255,255,.22);color:var(--text);
    -webkit-backdrop-filter:blur(6px);backdrop-filter:blur(6px);transition:background-color 200ms ease,color 200ms ease;}
  #ag-cl02-02.ag-scope .ag-mg__open:focus-visible{outline:3px solid var(--accent);outline-offset:-4px;}
  @media (hover:hover){#ag-cl02-02 .ag-mg__open:hover .ag-mg__zoom{background:var(--accent);color:#09090A;}}
  #ag-cl02-02 .ag-mg__dlg{width:100vw;height:100vh;max-width:none;max-height:none;margin:0;padding:0;border:0;background:transparent;color:var(--text);overscroll-behavior:contain;}
  #ag-cl02-02 .ag-mg__dlg::backdrop{background:rgba(6,6,7,.92);}
  #ag-cl02-02 .ag-mg__dbox{position:relative;display:grid;grid-template-rows:auto minmax(0,1fr) auto;gap:14px;width:100%;height:100%;padding:18px clamp(16px,4vw,48px) 22px;}
  #ag-cl02-02 .ag-mg__dt{margin:0;padding-right:56px;font-family:var(--f-display,"Oswald",sans-serif);font-size:15px;font-weight:600;letter-spacing:.08em;text-transform:uppercase;color:var(--text);min-height:44px;display:flex;align-items:center;}
  #ag-cl02-02 .ag-mg__dimg{display:block;width:100%;height:100%;max-height:calc(100dvh - 150px);object-fit:contain;}
  #ag-cl02-02 .ag-mg__dnav{display:flex;justify-content:center;gap:14px;}
  #ag-cl02-02 .ag-mg__dbtn,#ag-cl02-02 .ag-mg__dx{display:inline-flex;align-items:center;justify-content:center;width:48px;height:48px;padding:0;border-radius:50%;
    border:1px solid rgba(255,255,255,.28);background:rgba(20,20,22,.9);color:var(--text);cursor:pointer;font:inherit;}
  #ag-cl02-02 .ag-mg__dx{position:absolute;top:16px;right:clamp(16px,4vw,48px);}
  #ag-cl02-02.ag-scope .ag-mg__dlg :is(button):focus-visible{outline:3px solid var(--accent);outline-offset:3px;}
  @media (hover:hover){#ag-cl02-02 .ag-mg__dbtn:hover,#ag-cl02-02 .ag-mg__dx:hover{border-color:var(--accent);color:var(--accent);}}
  @media (forced-colors:active){#ag-cl02-02 .ag-mg__zoom,#ag-cl02-02 .ag-mg__dbtn,#ag-cl02-02 .ag-mg__dx{border:1px solid CanvasText;}}
  @media print{#ag-cl02-02 .ag-mg__zoom{display:none;}}
'''
    t = add_css(t, css)
    t = touch(t)
    t = before_engine(t, DLG_JS)
    save(2, t)


# ---------------------------------------------------------------- CL02-03
def c03():
    t = load(3); R = '#ag-cl02-03'
    t = bump(t, 3, 'Кадр, текст и ссылка — как есть. F29 зерно бумаги (≥ 640 px), фокус 3 px.')
    t = focus3(t, R)
    t = add_css(t, grain_css(R, 'ag-mz', 'ag-mz__wrap'))
    t = touch(t)
    save(3, t)


# ---------------------------------------------------------------- CL02-04
IND_JS = '''    /* v1.1.0 · F10: жёлтая подложка выбранного направления переезжает (::before у tablist, CSS-переменные).
       Между рядами (телефон, вкладки переносятся — отступление по Р2) — перенос с проявлением.
       Первая установка — без перехода. */
    var ind = { on: false, row: null, cur: 1 };
    function placeInd(i, jump) {
      var t = tabs[i];
      ind.cur = i;
      if (!t || !t.offsetWidth) return;
      var row = t.offsetTop, change = ind.row !== null && Math.abs(ind.row - row) > 2;
      if (!ind.on || jump || change) list.classList.add("is-jump");
      list.style.setProperty("--ix", t.offsetLeft + "px");
      list.style.setProperty("--iy", row + "px");
      list.style.setProperty("--iw", t.offsetWidth + "px");
      list.style.setProperty("--ih", t.offsetHeight + "px");
      if (!ind.on) { list.classList.add("is-ind"); ind.on = true; }
      else if (change && list.animate && !(W.matchMedia && W.matchMedia("(prefers-reduced-motion: reduce)").matches)) {
        try { list.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 180, easing: "ease-out", pseudoElement: "::before" }); } catch (e) {}
      }
      ind.row = row;
      if (list.classList.contains("is-jump")) W.requestAnimationFrame(function () { W.requestAnimationFrame(function () { list.classList.remove("is-jump"); }); });
    }
'''


def c04():
    t = load(4); R = '#ag-cl02-04'
    t = bump(t, 4, 'F10: жёлтая подложка выбранного направления переезжает (320 мс), текст выбранной — с задержкой 120 мс\n'
                   '     (не тёмный на тёмном); появление ряда вкладок — rise вместо stagger; на телефоне между рядами —\n'
                   '     перенос с проявлением (отступление по Р2). Шкала «удары — борьба» — как есть. F23, фокус 3 px.')
    t = rep(t, 'data-ag-anim="stagger" data-ag-children=".ag-md__tab" data-ag-stagger="60" data-ag-distance="12">',
            'data-ag-anim="rise" data-ag-distance="12">')
    t = wrap(t, 'a', 'ag-btn ag-btn--primary', 'ag-btn__in')
    t = wrap(t, 'a', 'ag-btn ag-btn--ghost ag-md__call', 'ag-btn__in')
    t = focus3(t, R)
    t = rep(t, '    function select(i, focus, byReader) {\n', IND_JS + '    function select(i, focus, byReader) {\n')
    t = rep(t, '      var zone = tabs[i].getAttribute("data-zone");\n', '      placeInd(i, !byReader);\n      var zone = tabs[i].getAttribute("data-zone");\n')
    t = rep(t, '    select(1, false, false);\n  })();',
            '    select(1, false, false);\n'
            '    if ("ResizeObserver" in W) new W.ResizeObserver(function () { placeInd(ind.cur, true); }).observe(list);\n'
            '    if (D.fonts && D.fonts.ready) D.fonts.ready.then(function () { placeInd(ind.cur, true); });\n  })();')
    css = press_css(R, [('ag-btn', 'ag-btn__in')])
    css += '''  /* F10 · подложка выбранного направления */
  #ag-cl02-04 .ag-md__tabs{position:relative;isolation:isolate;}
  @media not (forced-colors:active){
    #ag-cl02-04 .ag-md__tabs.is-ind::before{
      content:"";position:absolute;z-index:-1;left:0;top:0;width:var(--iw,0px);height:var(--ih,0px);border-radius:12px;background:var(--accent);pointer-events:none;
      transform:translate(var(--ix,0px),var(--iy,0px));
      transition:transform .32s cubic-bezier(.22,.61,.36,1),width .32s cubic-bezier(.22,.61,.36,1),height .32s cubic-bezier(.22,.61,.36,1);
    }
    #ag-cl02-04 .ag-md__tabs.is-jump::before{transition:none;}
    #ag-cl02-04 .ag-md__tabs.is-ind .ag-md__tab[aria-selected="true"]{background:transparent;transition:border-color .2s ease,color .2s ease .12s;}
  }
'''
    t = add_css(t, css)
    t = touch(t)
    save(4, t)


# ---------------------------------------------------------------- CL02-05
def c05():
    t = load(5); R = '#ag-cl02-05'
    t = bump(t, 5, 'От v1.0.1 (патч комментария 28.09 — на тесте стоит v1.0.0 с именем из списка «не публикуются»: заменить).\n'
                   '     Состав и тексты — как есть (I041, I053 ждут владельца). F23 — нажатие кнопок, фокус 3 px.')
    t = wrap(t, 'a', 'ag-btn ag-btn--primary', 'ag-btn__in')
    t = wrap(t, 'a', 'ag-btn ag-btn--ghost', 'ag-btn__in')
    t = focus3(t, R)
    t = add_css(t, press_css(R, [('ag-btn', 'ag-btn__in')]))
    t = touch(t)
    save(5, t)


# ---------------------------------------------------------------- CL02-06
def c06():
    t = load(6); R = '#ag-cl02-06'
    t = bump(t, 6, 'Факт № 11: «Первое групповое занятие для взрослых — бесплатно.» Жетоны и тариф — как есть.\n'
                   '     F29 зерно бумаги (≥ 640 px). F23 — нажатие кнопок, фокус 3 px.')
    t = rep(t, '<b>Первое групповое занятие — бесплатно.</b>', '<b>Первое групповое занятие для взрослых — бесплатно.</b>')
    t = wrap(t, 'a', 'ag-mp__btn ag-mp__btn--ink', 'ag-mp__in')
    t = wrap(t, 'a', 'ag-mp__btn ag-mp__btn--line', 'ag-mp__in')
    t = focus3(t, R)
    css = press_css(R, [('ag-mp__btn', 'ag-mp__in')])
    css += grain_css(R, 'ag-mp', 'ag-mp__wrap')
    css += '''  @media (max-width:599.98px){
    /* «для взрослых» переносит строку — карточку условий делаем плотнее, телефон не длиннее v1.0.0 */
    #ag-cl02-06 .ag-mp__terms li{line-height:1.35;}
    #ag-cl02-06 .ag-mp__side{gap:8px;padding:12px 14px;}
    #ag-cl02-06 .ag-mp__acts{gap:6px;}
    #ag-cl02-06 .ag-mp__btn{min-height:48px;}
  }
'''
    t = add_css(t, css)
    t = touch(t)
    save(6, t)


# ---------------------------------------------------------------- CL02-07
SHARE_OLD_START = '    var btn = root.querySelector("[data-ag-share]");\n'
SHARE_NEW = '''    /* v1.1.0: «Скопировать адрес» — везде, где браузер даёт буфер обмена; «Поделиться адресом» — только на
       сенсорном экране с Web Share. Подтверждение копирования — в aria-live. Уходит видимая строка адреса. */
    var share = root.querySelector("[data-ag-share]");
    var copy = root.querySelector("[data-ag-ui-copy]");
    var note = root.querySelector("[data-ag-ui-copied]");
    var street = root.querySelector(".ag-mr__street");
    var text = street ? street.textContent.replace(/\\s+/g, " ").trim() : "Самара, улица Чкалова, 72";
    var coarse = W.matchMedia && W.matchMedia("(pointer: coarse)").matches;
    if (share && navigator.share && coarse) {
      share.hidden = false;
      share.addEventListener("click", function () {
        try {
          var p = navigator.share({ title: "Apollo MMA Gym", text: "Apollo MMA Gym, " + text + ", +7 917 107-51-79" });
          if (p && p.catch) p.catch(function () { /* отмена или запрет — ничего не делаем */ });
        } catch (e) { /* браузер отказал — адрес виден на странице */ }
      });
    }
    function said(msg) {
      if (!note) return;
      if (note.firstChild) note.firstChild.nodeValue = msg; else note.appendChild(D.createTextNode(msg));
      W.clearTimeout(said.t);
      said.t = W.setTimeout(function () { if (note.firstChild) note.firstChild.nodeValue = ""; }, 3000);
    }
    function fallback() {
      var ta = D.createElement("textarea");
      ta.value = text; ta.setAttribute("readonly", ""); ta.style.position = "fixed"; ta.style.opacity = "0";
      D.body.appendChild(ta); ta.select();
      var ok = false;
      try { ok = D.execCommand("copy"); } catch (e) {}
      D.body.removeChild(ta);
      return ok;
    }
    var canCopy = !!(navigator.clipboard && navigator.clipboard.writeText) || (D.queryCommandSupported && D.queryCommandSupported("copy"));
    if (copy && canCopy) {
      copy.hidden = false;
      copy.addEventListener("click", function () {
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(text).then(function () { said("Адрес скопирован"); }, function () {
            if (fallback()) said("Адрес скопирован"); else copy.hidden = true;
          });
        } else if (fallback()) said("Адрес скопирован"); else copy.hidden = true;
      });
    }
    /* iOS включает :active только при слушателе касания (F23) */
    root.addEventListener("touchstart", function () {}, { passive: true });
  })();
'''


def c07():
    t = load(7); R = '#ag-cl02-07'
    t = bump(t, 7, '«Скопировать адрес» (ПК и телефон, где есть буфер обмена) с подтверждением «Адрес скопирован» в aria-live;\n'
                   '     «Поделиться адресом» — только на сенсорном экране (на телефоне обе кнопки в один ряд). Карта — как была.\n'
                   '     F23 — нажатие кнопок, фокус 3 px.')
    t = rx(t, r'(<button class="ag-btn ag-btn--quiet" type="button" data-ag-share hidden>)(.*?)(</button>)',
           lambda m: m.group(1) + '<span class="ag-btn__in">' + m.group(2) + '</span>' + m.group(3))
    copybtn = ('<button class="ag-btn ag-btn--quiet" type="button" data-ag-ui-copy hidden><span class="ag-btn__in">'
               '<svg class="ag-btn__i" width="16" height="16" viewBox="0 0 16 16" aria-hidden="true" focusable="false">'
               '<rect x="5.5" y="5.5" width="8" height="8.5" rx="1.6" fill="none" stroke="currentColor" stroke-width="1.6"/>'
               '<path d="M10.5 3.5V3a1.5 1.5 0 0 0-1.5-1.5H4A1.5 1.5 0 0 0 2.5 3v6A1.5 1.5 0 0 0 4 10.5h.5" fill="none" stroke="currentColor" stroke-width="1.6"/></svg>'
               'Скопировать адрес</span></button> <span class="ag-mr__copied" data-ag-ui-copied aria-live="polite"></span>')
    t = rx(t, r'(<button class="ag-btn ag-btn--quiet" type="button" data-ag-share hidden>.*?</button>)', lambda m: m.group(1) + '\n          ' + copybtn)
    t = wrap(t, 'a', 'ag-btn ag-btn--primary', 'ag-btn__in')
    t = wrap(t, 'a', 'ag-btn ag-btn--ghost', 'ag-btn__in')
    t = wrap(t, 'a', 'ag-btn ag-btn--ghost ag-mr__call', 'ag-btn__in')
    t = focus3(t, R)
    i = t.index(SHARE_OLD_START)
    j = t.index('  })();\n', i) + len('  })();\n')
    t = t[:i] + SHARE_NEW + t[j:]
    css = press_css(R, [('ag-btn', 'ag-btn__in')])
    css += '''  #ag-cl02-07 .ag-mr__copied{flex-basis:100%;font-size:14px;font-weight:600;color:var(--accent);}
  #ag-cl02-07 .ag-mr__copied:empty{display:none;}
  @media (max-width:767.98px){
    /* «Скопировать» и «Поделиться» — в один ряд */
    #ag-cl02-07 .ag-btn--quiet{flex:1 1 40%;}
  }
'''
    t = add_css(t, css)
    save(7, t)


# ---------------------------------------------------------------- CL02-08
def c08():
    t = load(8); R = '#ag-cl02-08'
    t = bump(t, 8, 'Факт № 11 в ответе «Сколько стоит заниматься?»: «Первое групповое для взрослых — бесплатно.» (FAQPage в HEAD —\n'
                   '     тем же текстом, генератор). F22: ответ раскрывается плавно (::details-content + interpolate-size,\n'
                   '     прогрессивно); «Раскрыть все» — без перехода; refresh и по toggle, и по окончании перехода высоты.\n'
                   '     F23 — нажатие «Раскрыть все», фокус 3 px.')
    t = rep(t, 'это 500&nbsp;₽ за занятие. Первое групповое — бесплатно.', 'это 500&nbsp;₽ за занятие. Первое групповое для взрослых — бесплатно.')
    t = wrap(t, 'button', 'ag-fq__all', 'ag-fq__ain')
    t = focus3(t, R)
    css = press_css(R, [('ag-fq__all', 'ag-fq__ain')])
    css += '''  /* F22 · плавное раскрытие ответа (Chromium 131+); иначе — мгновенно, как было */
  @supports (interpolate-size:allow-keywords) and selector(::details-content){
    #ag-cl02-08 .ag-fq__list{interpolate-size:allow-keywords;}
    #ag-cl02-08 .ag-fq__item::details-content{
      height:0;overflow:clip;
      transition:height .32s cubic-bezier(.22,.61,.36,1),content-visibility .32s allow-discrete;
    }
    #ag-cl02-08 .ag-fq__item[open]::details-content{height:auto;}
    #ag-cl02-08.is-bulk .ag-fq__item::details-content{transition:none;}
    @media (prefers-reduced-motion:reduce){
      #ag-cl02-08 .ag-fq__item::details-content{transition:none;}
    }
  }
'''
    t = add_css(t, css)
    t = rx(t, r'(      busy = true;\n)(.*?)(      busy = false;\n)',
           lambda m: m.group(1) + '      root.classList.add("is-bulk");\n' + m.group(2) + m.group(3)
           + '      W.requestAnimationFrame(function () { W.requestAnimationFrame(function () { root.classList.remove("is-bulk"); }); });\n')
    t = rep(t, '      d.addEventListener("toggle", function () { if (!busy) { sync(); refresh(); } });\n    });\n',
            '      d.addEventListener("toggle", function () { if (!busy) { sync(); refresh(); } });\n    });\n'
            '    /* v1.1.0: высота ответа меняется переходом — пересчитать позиции анимаций ниже по окончании */\n'
            '    root.addEventListener("transitionend", function (e) {\n'
            '      if (e.propertyName === "height" && e.pseudoElement === "::details-content") refresh();\n'
            '    });\n')
    t = touch(t)
    save(8, t)


# ---------------------------------------------------------------- CL02-09
def c09():
    t = load(9); R = '#ag-cl02-09'
    t = bump(t, 9, 'Ссылки и тексты — как есть. Фокус 3 px.')
    t = focus3(t, R)
    save(9, t)


if __name__ == '__main__':
    for f in (c01, c02, c03, c04, c05, c06, c07, c08, c09):
        f()
