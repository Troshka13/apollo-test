// /mma (CL02) · проверки прохода «дизайн, движение и фишка» (PROMPT_CL02_DESIGN_MOTION_v2)
const {open,settle}=require('./lib');const fs=require('fs'),path=require('path');
const AFTER='file://'+path.resolve('after.html'), BEFORE='file://'+path.resolve('before.html');
const out={};const log=(g,ok,msg)=>{const s=(ok?"pass ":"FAIL ")+msg;(out[g]=out[g]||[]).push(s);console.log(g+" "+s);};
const G=process.env.G||'LTCMFA';
async function txt(url){const {browser,page}=await open({reduce:true});await page.goto(url);await page.waitForTimeout(2600);
  const r=await page.evaluate(()=>{const o={};document.querySelectorAll('.ag-scope').forEach(r=>{const c=r.cloneNode(true);c.querySelectorAll('style,script,.ag-vh').forEach(x=>x.remove());o[r.id]=c.textContent.replace(/\s+/g,' ').trim();});return o;});await browser.close();return r;}
async function links(url){const {browser,page}=await open({reduce:true});await page.goto(url);await page.waitForTimeout(400);
  const r=await page.evaluate(()=>[...document.querySelectorAll('.ag-scope a[href]')].map(a=>a.closest('.ag-scope').id+' '+a.getAttribute('href')));await browser.close();return r;}
// счётчик кадров сетки (функция frame в скрипте «Живая сетка клетки» — единственная с таким именем на странице)
const RAF=`window.__rafF=0;const __r=window.requestAnimationFrame.bind(window);window.requestAnimationFrame=function(f){if(f&&f.name==='frame')window.__rafF++;return __r(f);};`;
const MESH=`(()=>{const r=document.getElementById('ag-cl02-01');const c=r.querySelector('.ag-mh__meshc'),s=r.querySelector('.ag-mh__meshi svg');
  let lit=0;if(c){const x=c.getContext('2d').getImageData(0,0,c.width,c.height).data;for(let i=3;i<x.length;i+=16)if(x[i]>0)lit++;}
  return {cv:!!c,vis:getComputedStyle(s).visibility,lit,raf:window.__rafF||0,w:c?c.width:0};})()`;
async function bandPoint(page){return page.evaluate(()=>{const b=document.querySelector('#ag-cl02-01 .ag-mh__band').getBoundingClientRect(),m=document.querySelector('#ag-cl02-01 .ag-mh__meshi').getBoundingClientRect();
  // точка внутри сетки и ленты, не на ссылке
  const x=Math.min(b.right,m.right)-Math.min(60,m.width/3),y=Math.max(b.top,m.top)+Math.min(60,m.height/3);const el=document.elementFromPoint(x,y);return {x,y,link:!!(el&&el.closest('a,button'))};});}
(async()=>{
 if(G.includes('L')) for(const reduce of [false,true]) for(const fontsOff of [false,true]) for(const w of [320,360,390,768,1024,1440,1920]){
   const {browser,page}=await open({w,h:w<700?800:900,reduce,mobile:w<700,touch:w<700});
   if(fontsOff) await page.route('**/fonts.googleapis.com/**',r=>r.abort());
   await page.goto(AFTER);await settle(page);
   const r=await page.evaluate(()=>({ov:document.documentElement.scrollWidth>document.documentElement.clientWidth,h:document.body.scrollHeight}));
   log('L',!r.ov,`${w}px reduce=${reduce} fontsOff=${fontsOff} overflowX=${r.ov} h=${r.h}`);await browser.close();
 }
 if(G.includes('T')){const tb=await txt(BEFORE),ta=await txt(AFTER);
  const EXC={'ag-cl02-01':[['первое групповое занятие для взрослых','первое групповое занятие']],
   'ag-cl02-02':[['Ударная зона у клетки','Тренировка в клетке'],['Ударная зона у стены с граффити','Тренировка на мягком покрытии'],['Тренажёры: гребной и велосипед','Грэпплинг: борьба без ударов'],['Мяч, скамья, покрышка и канат','Групповая тренировка'],['Кадр 1 из 5 · Зал на Чкалова, 72','']],
   'ag-cl02-06':[['Первое групповое занятие для взрослых — бесплатно.','Первое групповое занятие — бесплатно.']],
   'ag-cl02-07':[[' Скопировать адрес','']],
   'ag-cl02-08':[['Первое групповое для взрослых — бесплатно.','Первое групповое — бесплатно.']]};
  for(const id of Object.keys(tb)){let a=ta[id];(EXC[id]||[]).forEach(([n,o])=>{a=a.split(n).join(o);});a=a.replace(/\s+/g,' ').trim();let i=0;while(i<tb[id].length&&tb[id][i]===a[i])i++;
   log('T',a===tb[id],id+(a===tb[id]?' текст совпадает'+(EXC[id]?' (кроме правок: '+EXC[id].map(x=>'«'+x[0]+'»').join(', ')+')':''):' РАЗНИЦА '+JSON.stringify(tb[id].slice(i-30,i+40))+' → '+JSON.stringify(a.slice(i-30,i+40))));}}
 if(G.includes('C')){const lb=await links(BEFORE),la=await links(AFTER);const add=la.filter(x=>!lb.includes(x)),rem=lb.filter(x=>!la.includes(x));
  const okAdd=add.every(x=>/^ag-cl02-02 https:\/\/static\.tildacdn\.pub\/.*\.jpe?g$/.test(x));
  log('C',rem.length===0&&add.length===5&&okAdd,`ссылки +${add.length} −${rem.length} (добавлены — файлы 5 кадров ленты: ${okAdd})`);}
 if(G.includes('M')){
  for(const mode of [{name:'js off',js:false},{name:'reduce',reduce:true},{name:'cdn fail',cdn:'fail'},{name:'cdn hang',cdn:'hang'}]){
   const {browser,page}=await open({w:390,h:800,mobile:true,...mode});await page.goto(AFTER,{waitUntil:'domcontentloaded'});await page.waitForTimeout(2700);
   if(mode.js!==false) for(let y=0;y<9000;y+=600){await page.evaluate(y=>scrollTo(0,y),y);await page.waitForTimeout(40);}
   const r=await page.evaluate(()=>{const bad=[];document.querySelectorAll('.ag-scope :is(p,h1,h2,h3,a,li,dt,dd,summary,td,th,figcaption)').forEach(el=>{if(el.closest('[aria-hidden="true"],[hidden],dialog'))return;let n=el,op=1;while(n&&n.nodeType===1){op*=parseFloat(getComputedStyle(n).opacity);n=n.parentElement;}if(getComputedStyle(el).display==='none')return;if(op<0.99&&el.textContent.trim())bad.push(el.textContent.trim().slice(0,30));});
     const s=document.querySelector('#ag-cl02-01 .ag-mh__meshi svg');return {bad,m:document.documentElement.getAttribute('data-ag-motion'),svg:getComputedStyle(s).visibility};});
   log('M',r.bad.length===0&&r.svg==='visible',`${mode.name}: motion=${r.m} скрытых текстов ${r.bad.length} ${r.bad.slice(0,3).join('|')}; сетка SVG ${r.svg}`);await browser.close();}
  const {browser,page}=await open({w:1440});await page.goto(AFTER);await settle(page);
  const r=await page.evaluate(()=>{const o={};document.querySelectorAll('.ag-scope').forEach(root=>{const all=root.querySelectorAll('[data-ag-anim]');o[root.id]=[all.length,[...all].filter(e=>!e.hasAttribute('data-ag-done')).length];});return o;});
  for(const [id,[n,left]] of Object.entries(r)) log('M',left===0,`motion on: ${id} анимаций ${n}, не отсканировано ${left}`);await browser.close();}

 if(G.includes('F')){
  // ---- 01 «Живая сетка клетки»: мышь
  {const {browser,page,errs}=await open({w:1440,h:900});await page.addInitScript(RAF);await page.goto(AFTER);await settle(page);
   const m0=await page.evaluate(MESH);
   const p=await bandPoint(page);
   await page.mouse.move(p.x-200,p.y+300);await page.mouse.move(p.x,p.y,{steps:6});await page.waitForTimeout(120);
   const m1=await page.evaluate(MESH);
   log('F',!m0.cv&&m0.vis==='visible'&&m1.cv&&m1.vis==='hidden'&&m1.lit>50,`сетка, ПК: до наведения canvas нет, SVG виден; после наведения canvas есть (${m1.w} px, закрашено ${m1.lit}), SVG спрятан; точка не на ссылке: ${!p.link}`);
   await page.mouse.move(p.x+30,p.y+20,{steps:4});await page.waitForTimeout(80);
   const hv=await page.evaluate(MESH);
   await page.waitForTimeout(700);const f0=(await page.evaluate(MESH)).raf;
   await page.mouse.down();await page.mouse.up();await page.waitForTimeout(250);const f1=(await page.evaluate(MESH)).raf;
   await page.waitForTimeout(1300);const f2=(await page.evaluate(MESH)).raf;await page.waitForTimeout(800);const f3=(await page.evaluate(MESH)).raf;
   log('F',hv.raf>0&&f1-f0>5&&f3===f2,`сетка, ПК: наведение — «дыхание» (${hv.raf} кадров), удар мышью — волна (${f1-f0} кадров за 250 мс), в покое через 1,5 с — 0 кадров (${f3-f2})`);
   // ссылки и кнопки первого экрана кликаются как раньше
   const cta=await page.evaluate(()=>{const a=document.querySelector('#ag-cl02-01 .ag-btn--primary');const r=a.getBoundingClientRect();const el=document.elementFromPoint(r.left+r.width/2,r.top+r.height/2);return !!(el&&el.closest('.ag-btn--primary'));});
   // вне экрана — стоп
   await page.mouse.down();await page.mouse.up();await page.evaluate(()=>scrollTo(0,3000));await page.waitForTimeout(300);const g0=(await page.evaluate(MESH)).raf;await page.waitForTimeout(500);const g1=(await page.evaluate(MESH)).raf;
   log('F',cta&&g1===g0,`сетка: canvas не перекрывает кнопку первого экрана (${cta}); удар и сразу прокрутка вниз — кадров вне экрана ${g1-g0}`);
   // reduce на лету: canvas уходит, SVG возвращается
   await page.evaluate(()=>scrollTo(0,0));await page.waitForTimeout(200);await page.emulateMedia({reducedMotion:'reduce'});await page.waitForTimeout(150);
   const rr=await page.evaluate(MESH);
   log('F',!rr.cv&&rr.vis==='visible'&&errs.length===0,`сетка: reduce на лету — canvas снят, SVG виден (${rr.vis}); ошибок ${errs.length} ${errs[0]||''}`);
   await page.screenshot({path:'shots/mesh_hit_1440.png',clip:{x:0,y:0,width:1440,height:900}});
   await browser.close();}
  // кадр сетки сразу после удара — для глаза
  {const {browser,page}=await open({w:1440,h:900});await page.goto(AFTER);await settle(page);const p=await bandPoint(page);
   await page.mouse.move(p.x,p.y,{steps:4});await page.mouse.down();await page.mouse.up();await page.waitForTimeout(140);
   const b=await (await page.$('#ag-cl02-01 .ag-mh__band')).boundingBox();await page.screenshot({path:'shots/mesh_wave_1440.png',clip:{x:b.x,y:b.y,width:b.width,height:Math.min(b.height,700)}});await browser.close();}
  // ---- 01: телефон — касание = волна; свайп по ленте — прокрутка, удара нет
  {const {browser,page,errs}=await open({w:390,h:844,mobile:true,touch:true});await page.addInitScript(RAF);await page.goto(AFTER);await settle(page);
   const b=await page.evaluate(()=>{const r=document.querySelector('#ag-cl02-01 .ag-mh__band').getBoundingClientRect(),m=document.querySelector('#ag-cl02-01 .ag-mh__meshi').getBoundingClientRect();return {x:Math.min(r.right,m.right)-40,y:Math.max(r.top,m.top)+40,top:r.top,bottom:r.bottom};});
   await page.evaluate(y=>scrollTo(0,Math.max(0,y-200)),b.top);await page.waitForTimeout(300);
   const pt=await page.evaluate(()=>{const r=document.querySelector('#ag-cl02-01 .ag-mh__band').getBoundingClientRect(),m=document.querySelector('#ag-cl02-01 .ag-mh__meshi').getBoundingClientRect();return {x:Math.min(r.right,m.right)-40,y:Math.max(r.top,m.top)+40};});
   // свайп: CDP-жест прокрутки начинается в сетке
   const cdp=await page.context().newCDPSession(page);const y0=await page.evaluate(()=>scrollY);
   await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x:pt.x,y:pt.y}]});for(let i=1;i<=12;i++){await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:pt.x,y:pt.y-i*25}]});await page.waitForTimeout(16);}await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await page.waitForTimeout(600);
   const y1=await page.evaluate(()=>scrollY);const s1=await page.evaluate(MESH);
   log('F',y1-y0>100&&s1.raf===0,`сетка, телефон: свайп по сетке прокручивает страницу (${y0}→${y1}), удара нет (кадров ${s1.raf}, canvas ${s1.cv})`);
   await page.evaluate(y=>scrollTo(0,y),y0);await page.waitForTimeout(300);
   const pt2=await page.evaluate(()=>{const r=document.querySelector('#ag-cl02-01 .ag-mh__band').getBoundingClientRect(),m=document.querySelector('#ag-cl02-01 .ag-mh__meshi').getBoundingClientRect();return {x:Math.min(r.right,m.right)-40,y:Math.max(r.top,m.top)+40};});
   await page.touchscreen.tap(pt2.x,pt2.y);await page.waitForTimeout(200);const t1=await page.evaluate(MESH);
   await page.waitForTimeout(1500);const t2=await page.evaluate(MESH);await page.waitForTimeout(600);const t3=await page.evaluate(MESH);
   log('F',t1.cv&&t1.raf>5&&t3.raf===t2.raf&&t1.vis==='hidden'&&errs.length===0,`сетка, телефон: касание — canvas и волна (${t1.raf} кадров за 200 мс), потом 0 кадров (${t3.raf-t2.raf}); ошибок ${errs.length}`);
   await browser.close();}
  // ---- 01: reduce и forced-colors — касание/удар ничего не создаёт, SVG на месте
  for(const md of [{reduce:true,n:'reduce'},{forced:true,n:'forced-colors'}]){
   const {browser,page}=await open({w:1440,h:900,reduce:!!md.reduce});if(md.forced)await page.emulateMedia({forcedColors:'active'});await page.addInitScript(RAF);await page.goto(AFTER);await settle(page);
   const p=await bandPoint(page);await page.mouse.move(p.x,p.y,{steps:4});await page.mouse.down();await page.mouse.up();await page.waitForTimeout(300);const r=await page.evaluate(MESH);
   log('F',!r.cv&&r.raf===0,`сетка, ${md.n}: наведение и удар — canvas нет, кадров ${r.raf}, SVG ${r.vis}`);await browser.close();}
  // ---- 02 F07 «кадр целиком»
  {const {browser,page,errs}=await open({w:1440,h:900});await page.goto(AFTER);await settle(page);
   await page.evaluate(()=>document.getElementById('ag-cl02-02').scrollIntoView());await page.waitForTimeout(500);
   const links=await page.$$('#ag-cl02-02 .ag-mg__open');
   await links[1].focus();await page.keyboard.press('Enter');await page.waitForTimeout(200);
   const d1=await page.evaluate(()=>{const d=document.querySelector('#ag-cl02-02 dialog');return {open:d.open,modal:d.matches(':modal'),src:d.querySelector('img').getAttribute('src'),alt:d.querySelector('img').alt,cap:d.querySelector('[data-ag-ui-cap]').textContent,ov:document.documentElement.style.overflow};});
   const h1=await links[1].getAttribute('href');
   await page.keyboard.press('ArrowRight');await page.waitForTimeout(80);const c2=await page.evaluate(()=>document.querySelector('#ag-cl02-02 [data-ag-ui-cap]').textContent);
   await page.keyboard.press('ArrowLeft');await page.keyboard.press('ArrowLeft');await page.keyboard.press('ArrowLeft');await page.waitForTimeout(80);const c5=await page.evaluate(()=>document.querySelector('#ag-cl02-02 [data-ag-ui-cap]').textContent);
   await page.screenshot({path:'shots/dialog_1440.png'});
   await page.keyboard.press('Escape');await page.waitForTimeout(150);
   const d2=await page.evaluate(()=>({open:document.querySelector('#ag-cl02-02 dialog').open,f:document.activeElement.getAttribute('data-ag-params'),ov:document.documentElement.style.overflow}));
   log('F',d1.open&&d1.modal&&d1.src===h1&&/^Кадр 2 из 5 · Ударная зона у клетки$/.test(d1.cap)&&/мешки у клетки/i.test(d1.alt)&&d1.ov==='hidden',`кадр целиком: Enter на 2-м кадре — модальное окно, файл кадра, «${d1.cap}», фон не прокручивается`);
   log('F',/^Кадр 3 из 5/.test(c2)&&/^Кадр 5 из 5/.test(c5)&&!d2.open&&/"n":2/.test(d2.f||'')&&d2.ov==='',`кадр целиком: → «${c2}», ← ← ← по кругу «${c5}», Escape закрыл, фокус на ссылке 2-го кадра, прокрутка вернулась; ошибок ${errs.length}`);
   // мышь: клик и закрытие по фону
   await links[0].click();await page.waitForTimeout(150);const a0=await page.evaluate(()=>document.querySelector('#ag-cl02-02 [data-ag-ui-cap]').textContent);
   await page.mouse.click(5,450);await page.waitForTimeout(150);const o2=await page.evaluate(()=>document.querySelector('#ag-cl02-02 dialog').open);
   log('F',/^Кадр 1 из 5 · Зал на Чкалова, 72$/.test(a0)&&!o2,`кадр целиком: клик по 1-му кадру — «${a0}», клик по фону закрыл`);
   await browser.close();}
  {const {browser,page}=await open({w:390,h:844,mobile:true,touch:true});await page.goto(AFTER);await settle(page);
   await page.evaluate(()=>document.getElementById('ag-cl02-02').scrollIntoView());await page.waitForTimeout(400);
   const l=await page.$$('#ag-cl02-02 .ag-mg__open');const bx=await l[0].boundingBox();await page.touchscreen.tap(bx.x+bx.width/2,bx.y+bx.height/2);await page.waitForTimeout(250);
   const r=await page.evaluate(()=>{const d=document.querySelector('#ag-cl02-02 dialog'),i=d.querySelector('img').getBoundingClientRect();const bs=[...d.querySelectorAll('button')].map(b=>b.getBoundingClientRect());return {open:d.open,iw:Math.round(i.width),ih:Math.round(i.height),btn:bs.every(b=>b.width>=44&&b.height>=44&&b.bottom<=innerHeight&&b.right<=innerWidth)};});
   await page.screenshot({path:'shots/dialog_390.png'});
   log('F',r.open&&r.iw>=350&&r.btn,`кадр целиком, телефон: касание открыло, кадр ${r.iw}×${r.ih}, кнопки ≥ 44 px и в экране: ${r.btn}`);await browser.close();}
  // ---- 04 F10 подложка
  const ind=(i)=>`(()=>{const l=document.querySelector('#ag-cl02-04 .ag-md__tabs'),t=document.querySelectorAll('#ag-cl02-04 .ag-md__tab')[${i}];const cs=getComputedStyle(l,'::before');const m=new DOMMatrix(cs.transform);return {x:m.m41,y:m.m42,w:parseFloat(cs.width),h:parseFloat(cs.height),tx:t.offsetLeft,ty:t.offsetTop,tw:t.offsetWidth,th:t.offsetHeight,bg:getComputedStyle(t).backgroundColor,sel:t.getAttribute('aria-selected'),col:getComputedStyle(t).color};})()`;
  const ok=(r)=>Math.abs(r.x-r.tx)<1&&Math.abs(r.y-r.ty)<1&&Math.abs(r.w-r.tw)<1&&Math.abs(r.h-r.th)<1;
  const ntabs=async page=>page.$$eval('#ag-cl02-04 .ag-md__tab',x=>x.length);
  {const {browser,page}=await open({w:1440,h:900});await page.goto(AFTER);await settle(page);
   await page.evaluate(()=>document.getElementById('ag-cl02-04').scrollIntoView());await page.waitForTimeout(600);
   const n=await ntabs(page);const r0=await page.evaluate(ind(1));
   log('F',ok(r0)&&r0.sel==='true'&&r0.bg==='rgba(0, 0, 0, 0)',`подложка, ПК (${n} вкладок): стоит под «ММА» (${Math.round(r0.x)},${Math.round(r0.y)} ${Math.round(r0.w)}×${Math.round(r0.h)} ↔ ${r0.tx},${r0.ty} ${r0.tw}×${r0.th}), своя заливка вкладки прозрачна`);
   await page.click('#ag-cl02-04-t3');await page.waitForTimeout(110);const mid=await page.evaluate(ind(2));await page.waitForTimeout(420);const r2=await page.evaluate(ind(2));
   log('F',ok(r2)&&Math.abs(mid.x-r2.tx)>2&&r2.sel==='true',`подложка, ПК: клик «Тайский бокс» — переезд (на 110 мс x=${Math.round(mid.x)}, в конце ${Math.round(r2.x)} ↔ ${r2.tx}); текст выбранной ${r2.col}`);
   await page.focus('#ag-cl02-04-t3');await page.keyboard.press('ArrowLeft');await page.waitForTimeout(450);const r1=await page.evaluate(ind(1));
   log('F',ok(r1)&&r1.sel==='true',`подложка, ПК: стрелка ← — снова «ММА», подложка следом`);
   await page.setViewportSize({width:768,height:900});await page.waitForTimeout(400);const a=await page.evaluate(ind(1));
   await page.setViewportSize({width:767,height:900});await page.waitForTimeout(400);const b=await page.evaluate(ind(1));
   log('F',ok(a)&&ok(b),`подложка: смена ширины 1440 → 768 → 767 — на месте (${Math.round(a.x)}/${a.tx}, ${Math.round(b.x)}/${b.tx})`);
   await browser.close();}
  {const {browser,page}=await open({w:390,h:844,mobile:true,touch:true});await page.goto(AFTER);await settle(page);
   await page.evaluate(()=>document.getElementById('ag-cl02-04').scrollIntoView());await page.waitForTimeout(500);
   const n=await ntabs(page);const rows=await page.$$eval('#ag-cl02-04 .ag-md__tab',x=>[...new Set(x.map(t=>t.offsetTop))].length);
   const r1=await page.evaluate(ind(1));
   // вкладка в другом ряду (если есть)
   const other=await page.$$eval('#ag-cl02-04 .ag-md__tab',x=>{const y=x[1].offsetTop;const i=x.findIndex(t=>Math.abs(t.offsetTop-y)>2);return i;});
   let msg='один ряд';let pass=ok(r1);
   if(other>=0){const bx=await (await page.$$('#ag-cl02-04 .ag-md__tab'))[other].boundingBox();await page.touchscreen.tap(bx.x+bx.width/2,bx.y+bx.height/2);await page.waitForTimeout(40);
    const an=await page.evaluate(()=>document.querySelector('#ag-cl02-04 .ag-md__tabs').getAnimations({subtree:true}).filter(a=>a.effect&&a.effect.pseudoElement==='::before').length);
    await page.waitForTimeout(400);const r=await page.evaluate(ind(other));pass=pass&&ok(r)&&an===1;msg=`касание вкладки в другом ряду — перенос с проявлением (${an}), подложка на месте (${Math.round(r.x)},${Math.round(r.y)} ↔ ${r.tx},${r.ty})`;}
   await (await page.$('#ag-cl02-04')).screenshot({path:'shots/tabs_390.png'});
   log('F',pass,`подложка, телефон: ${n} вкладок в ${rows} ряд(а); ${msg}`);await browser.close();}
  // ---- 07 «Скопировать адрес»
  {const {browser,page,errs}=await open({w:1440,h:900});await page.context().grantPermissions(['clipboard-read','clipboard-write']).catch(()=>{});
   await page.goto(AFTER);await settle(page);await page.evaluate(()=>document.getElementById('ag-cl02-07').scrollIntoView());await page.waitForTimeout(400);
   const st=await page.evaluate(()=>({copy:!document.querySelector('[data-ag-ui-copy]').hidden,share:!document.querySelector('[data-ag-share]').hidden}));
   await page.click('#ag-cl02-07 [data-ag-ui-copy]');await page.waitForTimeout(300);
   const r=await page.evaluate(async()=>{let clip='';try{clip=await Promise.race([navigator.clipboard.readText(),new Promise(r=>setTimeout(()=>r('(нет доступа: тайм-аут)'),1500))]);}catch(e){clip='(нет доступа: '+e.name+')';}return {note:document.querySelector('[data-ag-ui-copied]').textContent,clip,live:document.querySelector('[data-ag-ui-copied]').getAttribute('aria-live')};});
   await page.waitForTimeout(3200);const gone=await page.evaluate(()=>document.querySelector('[data-ag-ui-copied]').textContent);
   log('F',st.copy&&!st.share&&r.note==='Адрес скопирован'&&(r.clip==='Самара, улица Чкалова, 72'||/нет доступа/.test(r.clip))&&gone===''&&errs.length===0,`копирование, ПК: кнопка видна, «Поделиться» скрыта; после клика «${r.note}» (aria-live=${r.live}), в буфере «${r.clip}», через 3 с подтверждение ушло`);
   await browser.close();}
  {const {browser,page}=await open({w:390,h:844,mobile:true,touch:true});await page.addInitScript(()=>{navigator.share=()=>Promise.resolve();});await page.goto(AFTER);await settle(page);
   await page.evaluate(()=>document.getElementById('ag-cl02-07').scrollIntoView());await page.waitForTimeout(300);
   const r=await page.evaluate(()=>{const c=document.querySelector('[data-ag-ui-copy]'),s=document.querySelector('[data-ag-share]');const a=c.getBoundingClientRect(),b=s.getBoundingClientRect();return {c:!c.hidden,s:!s.hidden,row:Math.abs(a.top-b.top)<2,h:Math.round(a.height)};});
   await (await page.$('#ag-cl02-07')).screenshot({path:'shots/after/ag-cl02-07_390_share.png'});
   log('F',r.c&&r.s&&r.row&&r.h>=44,`копирование, телефон с Web Share: «Поделиться» и «Скопировать» в один ряд (${r.row}), высота кнопки ${r.h}`);await browser.close();}
  // ---- 08 F22
  {const {browser,page}=await open({w:1440,h:900});await page.goto(AFTER);await settle(page);
   await page.evaluate(()=>document.getElementById('ag-cl02-08').scrollIntoView());await page.waitForTimeout(400);
   const H=n=>page.evaluate(n=>Math.round(document.querySelector('#ag-cl02-08 .ag-fq__item:nth-of-type('+n+')').getBoundingClientRect().height),n);
   const h0=await H(2);await page.click('#ag-cl02-08 .ag-fq__item:nth-of-type(2) summary');await page.waitForTimeout(90);const hm=await H(2);await page.waitForTimeout(450);const h1=await H(2);
   const HA=()=>page.evaluate(()=>[...document.querySelectorAll('#ag-cl02-08 .ag-fq__item')].map(d=>Math.round(d.getBoundingClientRect().height)).join(','));
   await page.click('#ag-cl02-08 .ag-fq__all');await page.waitForTimeout(40);const b1=await HA();await page.waitForTimeout(500);const b2=await HA();
   const st=await page.evaluate(()=>({open:[...document.querySelectorAll('#ag-cl02-08 .ag-fq__item')].filter(d=>d.open).length,btn:document.querySelector('#ag-cl02-08 .ag-fq__all').textContent.trim(),bulk:document.getElementById('ag-cl02-08').classList.contains('is-bulk')}));
   log('F',h0<hm&&hm<h1&&b1===b2&&st.open===6&&!st.bulk,`FAQ: ответ раскрывается плавно (высота ${h0} → ${hm} на 90 мс → ${h1}), «Раскрыть все» — все ${st.open} сразу без перехода (высоты через 40 мс = итоговым: ${b1===b2}), кнопка «${st.btn}», is-bulk снят`);
   await page.click('#ag-cl02-08 .ag-fq__all');await page.waitForTimeout(400);
   const ans=await page.evaluate(()=>[...document.querySelectorAll('#ag-cl02-08 .ag-fq__a')].map(a=>a.textContent.replace(/\s+/g,' ').trim()).find(t=>/бесплатно/.test(t)));
   const head=JSON.parse(fs.readFileSync('out/HEAD_mma_v1.1.html','utf8').match(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/)[1]);
   const faq=head['@graph'].find(n=>n['@type']==='FAQPage').mainEntity;
   const qs=await page.evaluate(()=>[...document.querySelectorAll('#ag-cl02-08 .ag-fq__item')].map(d=>[d.querySelector('.ag-fq__qt').textContent.replace(/\s+/g,' ').trim(),d.querySelector('.ag-fq__a').textContent.replace(/\s+/g,' ').trim()]));
   const same=qs.length===faq.length&&qs.every(([q,a],i)=>faq[i].name===q&&faq[i].acceptedAnswer.text===a);
   log('F',same&&/для взрослых — бесплатно/.test(ans),`FAQPage в HEAD v1.1 = блок 08 дословно (${qs.length} вопросов): ${same}; ответ о цене: «…${ans.slice(ans.indexOf('Первое'),ans.indexOf('Первое')+45)}…»`);
   await browser.close();}
  // ---- магниты, F23, зерно
  {const {browser,page}=await open({w:1440,h:900});await page.goto(AFTER);await settle(page);
   const mag=await page.$$eval('[data-ag-magnetic]',x=>x.length);log('F',mag===0,`магнитных кнопок: ${mag}`);
   const res=[];
   for(const [sel,inn] of [['#ag-cl02-01 .ag-btn--primary','.ag-btn__in'],['#ag-cl02-04 .ag-btn--primary','.ag-btn__in'],['#ag-cl02-05 .ag-btn--primary','.ag-btn__in'],['#ag-cl02-06 .ag-mp__btn--ink','.ag-mp__in'],['#ag-cl02-07 .ag-btn--primary','.ag-btn__in'],['#ag-cl02-08 .ag-fq__all','.ag-fq__ain']]){
    const el=await page.$(sel);if(!el){res.push(sel+': нет');continue;}await el.scrollIntoViewIfNeeded();await page.waitForTimeout(250);const b0=await el.boundingBox();
    await page.evaluate(s=>document.querySelector(s).addEventListener('click',e=>e.preventDefault(),{once:true}),sel);
    await page.mouse.move(b0.x+b0.width/2,b0.y+b0.height/2);await page.mouse.down();await page.waitForTimeout(220);
    const t=await page.$eval(sel+' '+inn,e=>getComputedStyle(e).transform);await page.mouse.up();await page.waitForTimeout(80);
    const b1=await el.boundingBox();res.push([sel.split(' ')[0].slice(-2),/matrix\(0\.98/.test(t)&&Math.abs(b1.x-b0.x)<0.5]);}
   log('F',res.every(r=>r[1]===true),`F23 нажатие (scale .98, кнопка на месте): ${res.map(r=>Array.isArray(r)?r.join(':'):r).join(' ')}`);
   const gr=await page.evaluate(()=>['#ag-cl02-03 .ag-mz','#ag-cl02-06 .ag-mp'].map(s=>/svg/.test(getComputedStyle(document.querySelector(s),'::before').backgroundImage)));
   log('F',gr.every(Boolean),`зерно бумаги на ПК: 03 ${gr[0]}, 06 ${gr[1]}`);await browser.close();}
  {const {browser,page}=await open({w:390,h:844,mobile:true,touch:true});await page.goto(AFTER);await settle(page);
   const gr=await page.evaluate(()=>['#ag-cl02-03 .ag-mz','#ag-cl02-06 .ag-mp'].map(s=>/svg/.test(getComputedStyle(document.querySelector(s),'::before').backgroundImage)));
   log('F',!gr[0]&&!gr[1],`телефон: зерна нет (03 ${gr[0]}, 06 ${gr[1]})`);await browser.close();}
  // forced-colors: подложки нет, выбранная вкладка своей рамкой; кадр окна с рамками
  {const {browser,page}=await open({w:1440,h:900});await page.emulateMedia({forcedColors:'active'});await page.goto(AFTER);await settle(page);
   const fc=await page.evaluate(()=>{const l=document.querySelector('#ag-cl02-04 .ag-md__tabs');return {b:getComputedStyle(l,'::before').content,c:!!document.querySelector('#ag-cl02-01 .ag-mh__meshc')};});
   const r4=await (await page.$('#ag-cl02-04')).boundingBox();await page.evaluate(()=>document.getElementById('ag-cl02-04').scrollIntoView());await page.waitForTimeout(300);
   await page.screenshot({path:'shots/forced_04.png'});
   log('F',fc.b==='none'&&!fc.c,`forced-colors: подложки нет (${fc.b}), canvas сетки нет`);await browser.close();}
 }
 if(G.includes('A')){const axeSrc=fs.readFileSync(require.resolve('axe-core/axe.min.js'),'utf8');
  for(const m of [{w:1440},{w:1024},{w:390,mobile:true},{w:390,mobile:true,reduce:true},{w:390,nojs:true}]){
   let o;if(m.nojs){fs.writeFileSync('after_nojs.html',fs.readFileSync('after.html','utf8').replace(/<script>[\s\S]*?<\/script>/g,'').replace(/<!--[\s\S]*?-->/g,'').replace(/<noscript>([\s\S]*?)<\/noscript>/g,'$1'));o=await open({w:390,h:900});await o.page.goto('file://'+path.resolve('after_nojs.html'));await o.page.waitForTimeout(800);}
   else {o=await open({...m,h:900});await o.page.goto(AFTER);await settle(o.page);}
   await o.page.addScriptTag({content:axeSrc});const res=await o.page.evaluate(async()=>(await axe.run(document.getElementById('allrecords'),{resultTypes:['violations']})).violations.map(v=>[v.id,v.impact,v.nodes.length,v.nodes[0].target.join(' ')]));
   const s=res.filter(v=>/serious|critical/.test(v[1]));log('A',res.length===0,`${m.w}${m.reduce?' reduce':''}${m.nojs?' без JS':''}: нарушений ${res.length} (serious/critical ${s.length}) ${res.map(v=>v.join(':')).join(' ; ').slice(0,300)}`);await o.browser.close();}
  // открытое окно кадра; сетка после удара; FAQ раскрыт; адрес скопирован
  {const o=await open({w:1440,h:900});await o.page.goto(AFTER);await settle(o.page);
   const p=await bandPoint(o.page);await o.page.mouse.move(p.x,p.y,{steps:3});await o.page.mouse.down();await o.page.mouse.up();
   await o.page.click('#ag-cl02-08 .ag-fq__all');await o.page.click('#ag-cl02-07 [data-ag-ui-copy]').catch(()=>{});
   await o.page.evaluate(()=>document.getElementById('ag-cl02-02').scrollIntoView());await o.page.waitForTimeout(300);
   await o.page.click('#ag-cl02-02 .ag-mg__open >> nth=1');await o.page.waitForTimeout(300);
   await o.page.addScriptTag({content:axeSrc});const res=await o.page.evaluate(async()=>(await axe.run(document,{resultTypes:['violations']})).violations.map(v=>[v.id,v.impact,v.nodes[0].target.join(' ')]));
   log('A',res.length===0,`1440, окно кадра открыто + сетка после удара + FAQ раскрыт + адрес скопирован: нарушений ${res.length} ${res.map(v=>v.join(':')).join(' ; ').slice(0,300)}`);await o.browser.close();}}
 fs.writeFileSync('checks_m_'+G+'.json',JSON.stringify(out,null,1));
 for(const g of Object.keys(out)){console.log('## '+g);out[g].forEach(x=>console.log('  '+x));}
})();
