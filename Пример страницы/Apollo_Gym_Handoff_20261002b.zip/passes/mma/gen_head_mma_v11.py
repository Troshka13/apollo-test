# HEAD /mma v1.1: FAQPage из CL02-08 v1.1.0 + Description «для взрослых» (факт № 11)
import re, json, html
W='/home/claude/work/'
old=open(W+'head_test/HEAD_mma.html',encoding='utf-8').read()
g=json.loads(re.search(r'<script type="application/ld\+json">(.*?)</script>',old,re.S).group(1))
DESC_OLD="Зал на Чкалова, 72 в Самаре: клетка для ММА и зона с мягким покрытием для борьбы. ММА, грэпплинг, бокс, тайский бокс. Первое групповое занятие бесплатно."
DESC="Зал на Чкалова, 72 в Самаре: клетка для ММА и зона с мягким покрытием для борьбы. ММА, грэпплинг, бокс, тайский бокс. Первое групповое для взрослых бесплатно."
b8=open('out/CL02-08_v1.1.0.html',encoding='utf-8').read()
items=re.findall(r'<span class="ag-fq__qt">(.*?)</span>.*?<div class="ag-fq__a">(.*?)</div>',b8,re.S)
assert len(items)==6, len(items)
def clean(s):
    s=re.sub(r'<[^>]+>',' ',s); s=html.unescape(s).replace(' ',' ')
    return re.sub(r'\s+',' ',s).strip()
faq=[{"@type":"Question","name":clean(q),"acceptedAnswer":{"@type":"Answer","text":clean(a)}} for q,a in items]
n=0
for node in g['@graph']:
    if node.get('@type')=='WebPage':
        assert node['description']==DESC_OLD; node['description']=DESC; n+=1
    if node.get('@type')=='FAQPage':
        oldq=[q['name'] for q in node['mainEntity']]
        assert oldq==[f['name'] for f in faq]; node['mainEntity']=faq; n+=1
assert n==2
diffs=[i for i,(a,b) in enumerate(zip(json.loads(re.search(r'<script type="application/ld\+json">(.*?)</script>',old,re.S).group(1))['@graph'][-1]['mainEntity'],faq)) if a!=b]
com=('<!-- Apollo Gym · /mma · HEAD v1.1 · 30.09.2026 · Tilda → Настройки страницы → Дополнительно → «HTML-код для вставки внутрь HEAD». '
     'Тестовая копия с адресами apolloboxing.tilda.ws. Заменяет HEAD от 24.09 целиком; старый JSON-LD удалить. '
     'v1.1: FAQPage = CL02-08 v1.1.0 дословно (факт № 11 «для взрослых»); description WebPage = новый meta Description. -->\n')
out=com+'<script type="application/ld+json">\n'+json.dumps(g,ensure_ascii=False,indent=1)+'\n</script>\n'
open('out/HEAD_mma_v1.1.html','w',encoding='utf-8').write(out)
print('FAQ changed idx',diffs,'desc len',len(DESC))
