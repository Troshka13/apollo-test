// /boxing-samara (DIR01) · проверки прохода «дизайн, движение и фишка» (PROMPT_DIR01_DESIGN_MOTION_v2)
const {open,settle}=require('./lib');const fs=require('fs'),path=require('path');
const AFTER='file://'+path.resolve('after.html'), BEFORE='file://'+path.resolve('before.html');
const out={};const log=(g,ok,msg)=>{(out[g]=out[g]||[]).push((ok?'pass ':'FAIL ')+msg);};
const G=process.env.G||'LTCMFA';
async function txt(url){const {browser,page}=await open({reduce:true});await page.goto(url);await page.waitForTimeout(2600);
  const r=await page.evaluate(()=>{const o={};document.querySelectorAll('.ag-scope').forEach(r=>{const c=r.cloneNode(true);c.querySelectorAll('style,script,.ag-vh').forEach(x=>x.remove());o[r.id]=c.textContent.replace(/\s+/g,' ').trim();});return o;});await browser.close();return r;}
async function links(url){const {browser,page}=await open({reduce:true});await page.goto(url);await page.waitForTimeout(400);
  const r=await page.evaluate(()=>[...document.querySelectorAll('.ag-scope a[href]')].map(a=>a.closest('.ag-scope').id+' '+a.getAttribute('href')));await browser.close();return r;}
// центр шага в середине экрана (полоса IntersectionObserver — 45 % сверху и снизу)
async function toStep(page,i){await page.evaluate(i=>{const s=document.querySelectorAll('#ag-dir01-02 .ag-tl__step')[i];const r=s.getBoundingClientRect();scrollTo(0,scrollY+r.top+Math.min(r.height,60)/2-innerHeight/2);},i);}
const running=`document.getAnimations().filter(a=>a.playState==='running'&&!(a instanceof CSSTransition))`;
(async()=>{
 if(G.includes('L')) for(const reduce of [false,true]) for(const fontsOff of [false,true]) for(const w of [320,360,390,768,1024,1440,1920]){
   const {browser,page}=await open({w,h:w<700?800:900,reduce,mobile:w<700,touch:w<700});
   if(fontsOff) await page.route('**/fonts.googleapis.com/**',r=>r.abort());
   await page.goto(AFTER);await settle(page);
   const r=await page.evaluate(()=>({ov:document.documentElement.scrollWidth>document.documentElement.clientWidth,h:document.body.scrollHeight}));
   log('L',!r.ov,`${w}px reduce=${reduce} fontsOff=${fontsOff} overflowX=${r.ov} h=${r.h}`);await browser.close();
 }
 if(G.includes('T')){const tb=await txt(BEFORE),ta=await txt(AFTER);
  for(const id of Object.keys(tb)){const a=ta[id];let i=0;while(i<tb[id].length&&tb[id][i]===a[i])i++;
   log('T',a===tb[id],id+(a===tb[id]?' текст совпадает':' РАЗНИЦА '+JSON.stringify(tb[id].slice(i-30,i+40))+' → '+JSON.stringify(a.slice(i-30,i+40))));}}
 if(G.includes('C')){const lb=await links(BEFORE),la=await links(AFTER);const add=la.filter(x=>!lb.includes(x)),rem=lb.filter(x=>!la.includes(x));
  log('C',rem.length===0&&add.length===3&&add.every(x=>/^ag-dir01-03 https:\/\/yandex\.ru\/maps\/\?text=/.test(x)),`ссылки +${add.length} −${rem.length}: ${add.map(x=>decodeURIComponent(x.split('text=')[1]||x)).join(' | ')}`);}
 if(G.includes('M')){
  for(const mode of [{name:'js off',js:false},{name:'reduce',reduce:true},{name:'cdn fail',cdn:'fail'},{name:'cdn hang',cdn:'hang'}]){
   const {browser,page}=await open({w:390,h:800,mobile:true,...mode});await page.goto(AFTER,{waitUntil:'domcontentloaded'});await page.waitForTimeout(2700);
   if(mode.js!==false) for(let y=0;y<9000;y+=600){await page.evaluate(y=>scrollTo(0,y),y);await page.waitForTimeout(40);}
   const r=await page.evaluate(()=>{const bad=[];document.querySelectorAll('.ag-scope :is(p,h1,h2,h3,a,li,dt,dd,summary,td,th)').forEach(el=>{if(el.closest('[aria-hidden="true"],[hidden]'))return;let n=el,op=1;while(n&&n.nodeType===1){op*=parseFloat(getComputedStyle(n).opacity);n=n.parentElement;}if(getComputedStyle(el).display==='none')return;if(op<0.99&&el.textContent.trim())bad.push(el.textContent.trim().slice(0,30));});
     return {bad,m:document.documentElement.getAttribute('data-ag-motion'),routes:document.querySelectorAll('#ag-dir01-03 a.ag-hs__route').length};});
   log('M',r.bad.length===0&&r.routes===3,`${mode.name}: motion=${r.m} скрытых текстов ${r.bad.length} ${r.bad.slice(0,3).join('|')} ссылок маршрута ${r.routes}`);await browser.close();}
  const {browser,page}=await open({w:1440});await page.goto(AFTER);await settle(page);
  const r=await page.evaluate(()=>{const o={};document.querySelectorAll('.ag-scope').forEach(root=>{const all=root.querySelectorAll('[data-ag-anim]');o[root.id]=[all.length,[...all].filter(e=>!e.hasAttribute('data-ag-done')).length];});return o;});
  for(const [id,[n,left]] of Object.entries(r)) log('M',left===0,`motion on: ${id} анимаций ${n}, не отсканировано ${left}`);await browser.close();}
 if(G.includes('F')){
  // ПК: пиктограммы сцены
  {const {browser,page}=await open({w:1440,h:900});await page.goto(AFTER);await settle(page);
   const res=[];
   for(const [i,p] of [[0,'rope'],[1,'l'],[2,'glove'],[3,'pad'],[4,'c']]){
     await toStep(page,i);await page.waitForTimeout(320);
     const r=await page.evaluate(([i,p])=>{const art=document.querySelector('#ag-dir01-02 [data-ag-art]');const pic=art.querySelectorAll('.ag-tl__pic')[i];
       const an=document.getAnimations().filter(a=>!(a instanceof CSSTransition)&&a.effect&&a.effect.target&&a.effect.target.closest&&a.effect.target.closest('.ag-tl__pic')===pic);
       const g=document.querySelector('#ag-dir01-02 .ag-tl__glow');const n=document.querySelectorAll('#ag-dir01-02 .ag-tl__node')[i].getBoundingClientRect();const gb=g.getBoundingClientRect();
       return {cur:art.getAttribute('data-cur'),n:an.length,part:an.some(a=>a.effect.target.getAttribute('data-p')===p),on:g.classList.contains('is-on'),dy:Math.round(gb.top+gb.height/2-(n.top+n.height/2))};},[i,p]);
     await page.waitForTimeout(650);const dy2=await page.evaluate(i=>{const g=document.querySelector('#ag-dir01-02 .ag-tl__glow').getBoundingClientRect();const n=document.querySelectorAll('#ag-dir01-02 .ag-tl__node')[i].getBoundingClientRect();return Math.round(g.top+g.height/2-(n.top+n.height/2));},i);r.dy=dy2;res.push(r);
     log('F',r.cur===String(i)&&r.n>0&&r.part,`ПК шаг ${i}: сцена data-cur=${r.cur}, анимаций пиктограммы ${r.n} (часть «${p}» ${r.part})`);
     log('F',r.on&&Math.abs(r.dy)<=2,`ПК шаг ${i}: свечение у узла (смещение ${r.dy} px после перехода)`);
     await page.waitForTimeout(100);}
   await page.waitForTimeout(2000);
   const idle=await page.evaluate(`${running}.length`);log('F',idle===0,`ПК: через 2 с после последнего шага анимаций в работе ${idle}`);
   // наведение на сцену — повтор (через 1,6 с)
   const ab=await page.$('#ag-dir01-02 .ag-tl__art');const bb=await ab.boundingBox();
   await page.mouse.move(bb.x+bb.width/2,bb.y+bb.height/2);await page.waitForTimeout(120);
   const hv=await page.evaluate(`${running}.length`);log('F',hv>0,`ПК: наведение мыши на сцену повторяет действие (анимаций ${hv})`);
   await page.mouse.move(5,5);await page.waitForTimeout(100);await page.mouse.move(bb.x+bb.width/2,bb.y+bb.height/2);await page.waitForTimeout(120);
   // быстрая прокрутка туда-обратно
   for(let k=0;k<6;k++){await toStep(page,k%5);await page.waitForTimeout(60);}
   await page.evaluate(()=>scrollTo(0,0));await page.waitForTimeout(2200);
   const idle2=await page.evaluate(`${running}.length`);log('F',idle2===0,`ПК: быстрая прокрутка по шагам, через 2 с анимаций ${idle2}`);
   // маршрут
   const rt=await page.evaluate(()=>[...document.querySelectorAll('#ag-dir01-03 a.ag-hs__route')].map(a=>({href:decodeURIComponent(a.href.split('text=')[1]),t:a.target,rel:a.rel,name:a.textContent.replace(/\s+/g,' ').trim(),track:a.dataset.agTrack,p:a.dataset.agParams})));
   const want=['Самара, ул. Галактионовская, 81','Самара, ул. Чкалова, 72','Самара, ул. Ново-Садовая, 106Б'];
   log('F',rt.length===3&&rt.every((r,k)=>r.href===want[k]&&r.t==='_blank'&&/noopener/.test(r.rel)&&/^Построить маршрут: .+\(откроется в новой вкладке\)$/.test(r.name)&&r.track==='route_click'),`маршрут: ${rt.map(r=>r.href+' · «'+r.name+'»').join(' | ')}`);
   const lab=await page.$('#ag-dir01-03 a.ag-hs__route');await lab.scrollIntoViewIfNeeded();await page.waitForTimeout(200);const lb=await lab.boundingBox();
   const hit=await page.evaluate(([x,y])=>{const e=document.elementFromPoint(x,y);return !!(e&&e.closest('a.ag-hs__route'));},[lb.x+lb.width/2,lb.y+lb.height/2+lb.height/2+8]);
   log('F',hit&&lb.height+24>=44,`маршрут: цель касания ${Math.round(lb.width)}×${Math.round(lb.height+24)} (видимая ${Math.round(lb.height)} + 12/12), точка под подписью попадает в ссылку: ${hit}`);
   // FAQ
   const q=await page.$('#ag-dir01-08 .ag-fq__item:nth-child(2) summary');await q.scrollIntoViewIfNeeded();await q.focus();await page.keyboard.press('Enter');await page.waitForTimeout(60);
   const mid=await page.evaluate(()=>{const d=document.querySelector('#ag-dir01-08 .ag-fq__item:nth-child(2)');return {open:d.open,h:d.querySelector('.ag-fq__a').getBoundingClientRect().height,dc:CSS.supports('selector(::details-content)')};});
   await page.waitForTimeout(500);
   const end=await page.evaluate(()=>{const d=document.querySelector('#ag-dir01-08 .ag-fq__item:nth-child(2)');const a=d.querySelector('.ag-fq__a');return {vis:a.checkVisibility(),h:d.getBoundingClientRect().height};});
   log('F',mid.open&&end.vis,`FAQ: Enter открыл ответ, ::details-content ${mid.dc}, ответ виден по окончании, высота вопроса ${Math.round(end.h)}`);
   const all=await page.$('#ag-dir01-08 [data-ag-all]');await all.click();await page.waitForTimeout(500);
   const alls=await page.evaluate(()=>({n:[...document.querySelectorAll('#ag-dir01-08 .ag-fq__item')].filter(d=>d.open).length,l:document.querySelector('#ag-dir01-08 [data-ag-all-label]').textContent}));
   log('F',alls.n===12&&alls.l==='Свернуть ответы',`FAQ: «Раскрыть все» открыл ${alls.n} из 12, подпись «${alls.l}»`);
   // магнит и F23
   const mag=await page.$$eval('[data-ag-magnetic]',x=>x.length);log('F',mag===0,`магнитных кнопок: ${mag}`);
   const btn=await page.$('#ag-dir01-09 .ag-dc__btn');await btn.scrollIntoViewIfNeeded();await page.waitForTimeout(300);const b0=await btn.boundingBox();
   await page.mouse.move(b0.x+b0.width/2,b0.y+b0.height/2);await page.mouse.move(b0.x+b0.width/2+30,b0.y+b0.height/2+10,{steps:5});await page.waitForTimeout(250);const b1=await btn.boundingBox();
   await page.evaluate(()=>document.querySelector('#ag-dir01-09 .ag-dc__btn').addEventListener('click',e=>e.preventDefault(),{once:true}));
   await page.mouse.down();await page.waitForTimeout(220);const tr=await page.$eval('#ag-dir01-09 .ag-dc__in',e=>getComputedStyle(e).transform);await page.mouse.up();
   log('F',Math.abs(b1.x-b0.x)<0.5&&Math.abs(b1.y-b0.y)<0.5&&/matrix\(0\.98/.test(tr),`F23: кнопка записи на месте при движении мыши (Δ ${(b1.x-b0.x).toFixed(1)}, ${(b1.y-b0.y).toFixed(1)}), при нажатии подпись ${tr}`);
   await browser.close();}
  // телефон: пиктограмма в узле
  {const {browser,page}=await open({w:390,h:800,mobile:true,touch:true});await page.goto(AFTER);await settle(page);
   for(const [i,p] of [[2,'glove'],[3,'pad']]){await toStep(page,i);await page.waitForTimeout(320);
    const r=await page.evaluate(([i,p])=>{const n=document.querySelectorAll('#ag-dir01-02 .ag-tl__node svg')[i];const an=document.getAnimations().filter(a=>!(a instanceof CSSTransition)&&a.effect&&a.effect.target&&n.contains(a.effect.target));return {n:an.length,part:an.some(a=>a.effect.target.getAttribute('data-p')===p),stage:getComputedStyle(document.querySelector('#ag-dir01-02 .ag-tl__stage')).display};},[i,p]);
    log('F',r.n>0&&r.part&&r.stage==='none',`телефон шаг ${i}: пиктограмма в узле играет (${r.n}, часть «${p}» ${r.part}), сцена скрыта`);await page.waitForTimeout(700);}
   const lab=await page.$('#ag-dir01-03 .ag-hs__card a.ag-hs__route');const lb=await lab.boundingBox();
   log('F',lb&&lb.width>40,`телефон: ссылка маршрута на рамке ${lb?Math.round(lb.width)+'×'+Math.round(lb.height):'нет'}`);
   await browser.close();}
  // reduce и forced-colors: статично
  for(const env of [{name:'reduce',o:{reduce:true}},{name:'forced-colors',fc:true}]){
   const {browser,page}=await open({w:1440,h:900,...(env.o||{})});if(env.fc) await page.emulateMedia({forcedColors:'active'});await page.goto(AFTER);await settle(page);
   let mx=0;for(const i of [0,2,3]){await toStep(page,i);await page.waitForTimeout(320);mx=Math.max(mx,await page.evaluate(`document.getAnimations().filter(a=>!(a instanceof CSSTransition)&&a.effect&&a.effect.target&&a.effect.target.closest&&a.effect.target.closest('#ag-dir01-02 .ag-tl__pic,#ag-dir01-02 .ag-tl__node')).length`));}
   const g=await page.$eval('#ag-dir01-02 .ag-tl__glow',e=>getComputedStyle(e).display);
   if(env.fc){await page.screenshot({path:'shots/forced_02.png',clip:await (await page.$('#ag-dir01-02')).boundingBox().then(b=>({x:0,y:b.y,width:1440,height:Math.min(b.height,1200)}))});}
   log('F',mx===0&&g==='none',`${env.name}: анимаций пиктограмм ${mx}, свечение display=${g}`);await browser.close();}
  // смена reduce на лету
  {const {browser,page}=await open({w:1440,h:900});await page.goto(AFTER);await settle(page);
   await toStep(page,1);await page.waitForTimeout(250);await page.emulateMedia({reducedMotion:'reduce'});await page.waitForTimeout(80);
   const n=await page.evaluate(`document.getAnimations().filter(a=>!(a instanceof CSSTransition)&&a.playState==='running'&&a.effect&&a.effect.target&&a.effect.target.closest&&a.effect.target.closest('#ag-dir01-02 .ag-tl__pic')).length`);
   await toStep(page,3);await page.waitForTimeout(320);
   const n2=await page.evaluate(`document.getAnimations().filter(a=>!(a instanceof CSSTransition)&&a.playState==='running'&&a.effect&&a.effect.target&&a.effect.target.closest&&a.effect.target.closest('#ag-dir01-02 .ag-tl__pic')).length`);
   log('F',n===0&&n2===0,`reduce на лету: текущая анимация отменена (${n}), следующий шаг не играет (${n2})`);await browser.close();}
 }
 if(G.includes('A')){const axeSrc=fs.readFileSync(require.resolve('axe-core/axe.min.js'),'utf8');
  for(const m of [{w:1440},{w:1024},{w:390,mobile:true},{w:390,mobile:true,reduce:true},{w:390,nojs:true}]){
   let o;if(m.nojs){fs.writeFileSync('after_nojs.html',fs.readFileSync('after.html','utf8').replace(/<script>[\s\S]*?<\/script>/g,'').replace(/<!--[\s\S]*?-->/g,'').replace(/<noscript>([\s\S]*?)<\/noscript>/g,'$1'));o=await open({w:390,h:900});await o.page.goto('file://'+path.resolve('after_nojs.html'));await o.page.waitForTimeout(800);}
   else {o=await open({...m,h:900});await o.page.goto(AFTER);await settle(o.page);}
   await o.page.addScriptTag({content:axeSrc});const res=await o.page.evaluate(async()=>(await axe.run(document.getElementById('allrecords'),{resultTypes:['violations']})).violations.map(v=>[v.id,v.impact,v.nodes.length,v.nodes[0].target.join(' ')]));
   const s=res.filter(v=>/serious|critical/.test(v[1]));log('A',s.length===0,`${m.w}${m.reduce?' reduce':''}${m.nojs?' без JS':''}: нарушений ${res.length} (serious/critical ${s.length}) ${res.map(v=>v.join(':')).join(' ; ').slice(0,300)}`);await o.browser.close();}
  {const o=await open({w:1440,h:900});await o.page.goto(AFTER);await settle(o.page);await o.page.evaluate(()=>{document.querySelectorAll('#ag-dir01-08 details').forEach(d=>d.open=true);});await o.page.waitForTimeout(500);
   await o.page.addScriptTag({content:axeSrc});const res=await o.page.evaluate(async()=>(await axe.run(document.getElementById('allrecords'),{resultTypes:['violations']})).violations.map(v=>[v.id,v.impact]));
   log('A',res.length===0,`1440, все ответы открыты: нарушений ${res.length} ${res.join(' ; ')}`);await o.browser.close();}}
 fs.writeFileSync('checks_d_'+G+'.json',JSON.stringify(out,null,1));
 for(const g of Object.keys(out)){console.log('## '+g);out[g].forEach(x=>console.log('  '+x));}
})();
