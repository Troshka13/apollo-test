# -*- coding: utf-8 -*-
"""/boxing-samara (DIR01) · проход «дизайн, движение и фишка» (PROMPT_DIR01_DESIGN_MOTION_v2, 30.09.2026).
src/DIR01-0N_v1.1.0.html → out/DIR01-0N_v1.2.0.html. Каждая замена обязана найтись нужное число раз."""
import re, os

SRC, OUT = 'src', 'out'
os.makedirs(OUT, exist_ok=True)
DATE = '30.09.2026'
EASE_OUT = 'cubic-bezier(.34,1.56,.64,1)'


def rep(t, old, new, n=1):
    c = t.count(old)
    if c != n:
        raise SystemExit('replace %d != %d: %r' % (c, n, old[:140]))
    return t.replace(old, new)


def rx(t, pat, new, n=1):
    t2, c = re.subn(pat, new, t, flags=re.S)
    if c != n:
        raise SystemExit('regex %d != %d: %r' % (c, n, pat[:140]))
    return t2


def load(n):
    return open('%s/DIR01-0%d_v1.1.0.html' % (SRC, n), encoding='utf-8').read()


def save(n, t):
    p = '%s/DIR01-0%d_v1.2.0.html' % (OUT, n)
    open(p, 'w', encoding='utf-8').write(t)
    print('DIR01-0%d v1.2.0 %6d байт' % (n, len(t.encode('utf-8'))))


def bump(t, note):
    t = rx(t, r'(APOLLO GYM · DIR01-0\d[^\n]*?)· v1\.1\.0 · 30\.09\.2026', r'\1· v1.2.0 · 30.09.2026')
    i = t.index('-->') + 3
    return t[:i] + '\n<!-- v1.2.0 (проход «дизайн, движение и фишка», PROMPT_DIR01_DESIGN_MOTION_v2, %s):\n     %s -->' % (DATE, note) + t[i:]


def focus3(t, root):
    return rx(t, r'(%s\.ag-scope :is\([^)]*\):focus-visible\{outline:)2px' % re.escape(root), r'\g<1>3px')


def wrap(t, tag, cls, inner, n=1):
    """подпись и значок кнопки — во внутренний span (F23: область неподвижна, сжимается содержимое)"""
    pat = r'(<%s class="%s"[^>]*>)(.*?)(</%s>)' % (tag, re.escape(cls), tag)
    return rx(t, pat, lambda m: m.group(1) + '<span class="%s">' % inner + m.group(2) + '</span>' + m.group(3), n)


def press_css(root, pairs):
    sel_in = ',\n  '.join('%s .%s' % (root, i) for b, i in pairs)
    sel_act = ',\n  '.join('%s .%s:active .%s' % (root, b, i) for b, i in pairs)
    red_in = ', '.join('%s .%s' % (root, i) for b, i in pairs)
    red_act = ', '.join('%s .%s:active .%s' % (root, b, i) for b, i in pairs)
    return ('''  /* F23 · нажатие: область кнопки неподвижна, сжимается подпись со значком */
  %s{display:inline-flex;align-items:center;justify-content:inherit;gap:inherit;flex:1 1 auto;min-width:0;
    transition:transform 260ms %s;}
  %s{transform:scale(.98);transition-duration:140ms;transition-timing-function:cubic-bezier(.22,.61,.36,1);}
  @media (prefers-reduced-motion:reduce){
    %s{transition:none;}
    %s{transform:none;}
  }
''' % (sel_in, EASE_OUT, sel_act, red_in, red_act))


def add_css(t, css):
    i = t.index('  </style>')
    return t[:i] + '\n  /* ===== v1.2.0 · дизайн, движение и фишка (30.09) ===== */\n' + css + t[i:]


TOUCH = '    /* iOS включает :active только при слушателе касания (F23) */\n    root.addEventListener("touchstart", function () {}, { passive: true });\n'


def touch(t):
    return rep(t, '    var tries = 0;\n', TOUCH + '    var tries = 0;\n')


# ---------------------------------------------------------------- DIR01-01
def d01():
    t = load(1); R = '#ag-dir01-01'
    t = bump(t, 'H1 на тесте — «Бокс в Самаре», «Секция бокса в Самаре» — первыми словами лида (правка в Tilda,\n'
                '     принята как есть; запись v1.1.0 ниже — о прежнем варианте). Магнит с кнопки снят (F23: CTA не убегает\n'
                '     от курсора), нажатие F23, фокус 3 px. «Мешок качается» — как есть. Телефон: планка фактов плотнее.')
    t = rep(t, ' data-ag-magnetic="0.18"', '')
    t = wrap(t, 'a', 'ag-btn ag-btn--primary', 'ag-btn__in')
    t = focus3(t, R)
    css = press_css(R, [('ag-btn', 'ag-btn__in')])
    css += '''  @media (max-width:639px){
    #ag-dir01-01 .ag-dh__facts>li{padding:7px 14px;}
    #ag-dir01-01 .ag-dh__facts b{font-size:24px;}
  }
'''
    t = add_css(t, css)
    t = touch(t)
    save(1, t)


# ---------------------------------------------------------------- DIR01-02
SW = 'fill="none" stroke="currentColor" stroke-width="2.4"'
PICS = [
    # 0 · скакалка: ручки неподвижны, дуга прокручивается (отражение от линии ручек)
    '<path d="M12 8v10M36 8v10" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"/>'
    '<g class="ag-pz" data-p="rope"><path d="M12 18c0 14 5 22 12 22s12-8 12-22" %s stroke-linecap="round"/></g>'
    '<rect x="9" y="4" width="6" height="10" rx="2.4" fill="currentColor"/><rect x="33" y="4" width="6" height="10" rx="2.4" fill="currentColor"/>' % SW,
    # 1 · следы: левая и правая стопа шагают по очереди
    '<g class="ag-pz" data-p="l"><path d="M15 9c3.3 0 5 3.4 5 8.4 0 5.4-1.6 9.6-4.6 9.6S11 22.9 11 17.4C11 12.4 12 9 15 9Z" %s/>'
    '<path d="M12.6 31.2h6.2l-.6 5.2c-.3 2.2-4.8 2.2-5 0Z" %s stroke-linejoin="round"/></g>'
    '<g class="ag-pz" data-p="r"><path d="M33 15c3.3 0 5 3.4 5 8.4 0 5.4-1.6 9.6-4.6 9.6S29 28.9 29 23.4C29 18.4 30 15 33 15Z" %s/>'
    '<path d="M30.6 37.2h6.2l-.6 5.2c-.3 2.2-4.8 2.2-5 0Z" %s stroke-linejoin="round"/></g>' % (SW, SW, SW, SW),
    # 2 · перчатка: прямой удар — выпад и возврат, штрихи удара
    '<g class="ag-pz" data-p="glove"><path d="M14 30V17a9 9 0 0 1 9-9h5a9 9 0 0 1 9 9v7a8 8 0 0 1-8 8h-2" %s stroke-linejoin="round"/>'
    '<path d="M14 22h-1a4 4 0 0 0-4 4v1a5 5 0 0 0 5 5" %s stroke-linecap="round"/>'
    '<path d="M14 32h15v8H14Z" %s stroke-linejoin="round"/><path d="M22 18h8" %s stroke-linecap="round"/></g>'
    '<g class="ag-pz ag-pz--hit" data-p="hit"><path d="M44 12l3-2.5M44.5 20H48M44 28l3 2.5" %s stroke-linecap="round"/></g>' % (SW, SW, SW, SW, SW),
    # 3 · лапа: принимает удар — сжатие и отскок, штрихи удара
    '<g class="ag-pz" data-p="pad"><ellipse cx="24" cy="21" rx="13" ry="15" %s/><ellipse cx="24" cy="21" rx="5.5" ry="6.5" %s/></g>'
    '<path d="M18 35.5V42h12v-6.5" %s stroke-linejoin="round"/>'
    '<g class="ag-pz ag-pz--hit" data-p="hit"><path d="M4.5 8l4 3M2.5 16.5H7.5M10.5 2.5l2 4" %s stroke-linecap="round"/></g>' % (SW, SW, SW, SW),
    # 4 · пара: двое сходятся и расходятся, касание перчаток
    '<g class="ag-pz" data-p="l"><circle cx="14" cy="12" r="4.5" %s/><path d="M8 42V28a6 6 0 0 1 12 0v14M20 26h3.5" %s stroke-linecap="round"/></g>'
    '<g class="ag-pz" data-p="r"><circle cx="34" cy="12" r="4.5" %s/><path d="M28 42V28a6 6 0 0 1 12 0v14M24.5 26H28" %s stroke-linecap="round"/></g>'
    '<g class="ag-pz" data-p="c"><ellipse cx="24" cy="26" rx="1.8" ry="3.4" fill="currentColor"/></g>' % (SW, SW, SW, SW),
]

STEPS_FX_JS = r'''
    /* v1.2.0 · «Живые пиктограммы» (ведущая фишка страницы, F14): пиктограмма текущего шага
       показывает действие — скакалка прокручивается, стопы шагают, перчатка бьёт прямой, лапа
       принимает удар, пара сходится. ПК — крупная пиктограмма сцены, до 1024 px — пиктограмма
       в узле шага. Играет, когда шаг продержался текущим 180 мс, и при наведении мыши на сцену;
       один и тот же шаг — не чаще раза в 1,6 с, прежняя анимация отменяется. Только transform
       и opacity групп внутри svg (element.animate), без циклов. reduce и forced-colors —
       проверка при каждом запуске, при смене настройки — отмена. Свечение за линией шагов
       переезжает к текущему шагу (transition, без rAF). */
    var wide = W.matchMedia("(min-width: 1024px)");
    var mqR = W.matchMedia("(prefers-reduced-motion: reduce)");
    var mqF = W.matchMedia("(forced-colors: active)");
    var fine = W.matchMedia("(hover: hover) and (pointer: fine)");
    var stagePics = art ? Array.prototype.slice.call(art.querySelectorAll(".ag-tl__pic")) : [];
    var nodePics = steps.map(function (s) { return s.querySelector(".ag-tl__node svg"); });
    var glow = root.querySelector(".ag-tl__glow");
    var body = root.querySelector(".ag-tl__body");
    var running = [], last = [0, 0, 0, 0, 0], timer = 0;
    var canAnim = typeof D.documentElement.animate === "function";
    var IN = "cubic-bezier(.22,.61,.36,1)", SWG = "cubic-bezier(.45,0,.55,1)";
    function stop() { running.forEach(function (a) { try { a.cancel(); } catch (e) {} }); running = []; }
    function go(el, frames, opts) { if (el) running.push(el.animate(frames, opts)); }
    function part(svg, p) { return svg.querySelector('[data-p="' + p + '"]'); }
    var FX = [
      function (s) { go(part(s, "rope"), [{ transform: "scaleY(1)" }, { transform: "scaleY(-.55)", offset: .5 }, { transform: "scaleY(1)" }], { duration: 420, iterations: 2, easing: SWG }); },
      function (s) {
        var k = [{ transform: "translateY(0)" }, { transform: "translateY(-6px)", offset: .45 }, { transform: "translateY(0)" }];
        go(part(s, "l"), k, { duration: 420, easing: IN });
        go(part(s, "r"), k, { duration: 420, delay: 300, easing: IN });
      },
      function (s) {
        go(part(s, "glove"), [{ transform: "translateX(0)" }, { transform: "translateX(5px)", offset: .3 }, { transform: "translateX(0)" }], { duration: 560, easing: IN });
        go(part(s, "hit"), [{ opacity: 0, transform: "translateX(-3px)" }, { opacity: 1, transform: "translateX(0)", offset: .35 }, { opacity: 0, transform: "translateX(2px)" }], { duration: 560, easing: "ease-out" });
      },
      function (s) {
        go(part(s, "pad"), [{ transform: "scale(1)" }, { transform: "scale(.86)", offset: .25 }, { transform: "scale(1.05)", offset: .55 }, { transform: "scale(1)" }], { duration: 620, easing: IN });
        go(part(s, "hit"), [{ opacity: 0 }, { opacity: 1, offset: .25 }, { opacity: 0 }], { duration: 620, easing: "ease-out" });
      },
      function (s) {
        go(part(s, "l"), [{ transform: "translateX(0)" }, { transform: "translateX(2.5px)", offset: .5 }, { transform: "translateX(0)" }], { duration: 380, iterations: 2, easing: SWG });
        go(part(s, "r"), [{ transform: "translateX(0)" }, { transform: "translateX(-2.5px)", offset: .5 }, { transform: "translateX(0)" }], { duration: 380, iterations: 2, easing: SWG });
        go(part(s, "c"), [{ transform: "scale(1)" }, { transform: "scale(1.5)", offset: .5 }, { transform: "scale(1)" }], { duration: 380, iterations: 2, easing: SWG });
      }
    ];
    function play(i, force) {
      if (!canAnim || i < 0 || mqR.matches || mqF.matches) return;
      var now = Date.now();
      if (!force && now - last[i] < 1600) return;
      last[i] = now;
      stop();
      var svg = wide.matches ? stagePics[i] : nodePics[i];
      if (svg) FX[i](svg);
    }
    function schedule(i) {
      W.clearTimeout(timer);
      timer = W.setTimeout(function () { if (i === cur) play(i); }, 180);
    }
    function place(i) {
      if (!glow || !body || i < 0) return;
      /* координаты по раскладке (offset*), не по экрану: шаги могут ещё въезжать анимацией движка */
      var n = steps[i].querySelector(".ag-tl__node"), x = n.offsetWidth / 2, y = n.offsetHeight / 2, el = n;
      while (el && el !== body) { x += el.offsetLeft; y += el.offsetTop; el = el.offsetParent; }
      if (el !== body) return;
      glow.style.setProperty("--gx", Math.round(x) + "px");
      glow.style.setProperty("--gy", Math.round(y) + "px");
      glow.classList.add("is-on");
    }
    function onPref() { if (mqR.matches || mqF.matches) stop(); }
    [mqR, mqF].forEach(function (q) { if (q.addEventListener) q.addEventListener("change", onPref); else if (q.addListener) q.addListener(onPref); });
    if (art) art.addEventListener("pointerenter", function () { if (fine.matches && cur >= 0) play(cur); });
    if (glow && "ResizeObserver" in W) new W.ResizeObserver(function () { place(cur); }).observe(body);
'''


def d02():
    t = load(2); R = '#ag-dir01-02'
    t = bump(t, 'Ведущая фишка страницы «Живые пиктограммы» (F14): пиктограмма текущего шага показывает действие —\n'
                '     скакалка прокручивается, стопы шагают, перчатка бьёт прямой, лапа принимает удар, пара сходится.\n'
                '     ПК — крупная пиктограмма прилипающей сцены (сцена — раскладка v1.0.0 по Р2; F14 «без pin» —\n'
                '     отступление, новой прилипалки нет), до 1024 px — пиктограмма в узле шага. Пиктограммы встроены\n'
                '     (без <use>, без id), части — группы <g>; element.animate, только transform/opacity, без циклов;\n'
                '     reduce и forced-colors — статично. Свечение за линией шагов переезжает к текущему шагу. Без JS —\n'
                '     как было: линия залита, пиктограммы статичны.')
    # спрайт больше не нужен: пиктограммы встроены
    t = rx(t, r'\n  <svg class="ag-tl__sprite"[^>]*>\n(?:    <symbol[^\n]*\n){5}  </svg>\n', '\n')
    for i in range(5):
        t = rep(t, '<svg class="ag-tl__pic" data-i="%d" focusable="false"><use href="#ag-dir01-02-i%d"/></svg>' % (i, i),
                '<svg class="ag-tl__pic" data-i="%d" viewBox="0 0 48 48" focusable="false">%s</svg>' % (i, PICS[i]))
        t = rep(t, '<span class="ag-tl__node" aria-hidden="true"><svg width="26" height="26" focusable="false"><use href="#ag-dir01-02-i%d"/></svg></span>' % i,
                '<span class="ag-tl__node" aria-hidden="true"><svg width="26" height="26" viewBox="0 0 48 48" focusable="false">%s</svg></span>' % PICS[i])
    t = rep(t, '      <div class="ag-tl__body">\n', '      <div class="ag-tl__body">\n        <span class="ag-tl__glow" aria-hidden="true"></span>\n')
    css = '''  /* «Живые пиктограммы»: части пиктограмм — группы; ось каждой — по своей рамке */
  #ag-dir01-02 .ag-pz{transform-box:fill-box;transform-origin:50% 50%;}
  #ag-dir01-02 .ag-pz[data-p="rope"]{transform-origin:50% 0;}
  #ag-dir01-02 .ag-pz--hit{opacity:0;}
  /* свечение за линией шагов: едет к узлу текущего шага (координаты ставит скрипт) */
  #ag-dir01-02 .ag-tl__body{position:relative;isolation:isolate;}
  #ag-dir01-02 .ag-tl__glow{
    position:absolute;z-index:-1;left:0;top:0;width:360px;height:360px;margin:-180px 0 0 -180px;border-radius:50%;pointer-events:none;
    background:radial-gradient(closest-side,rgba(255,196,0,.13),rgba(255,196,0,.05) 55%,rgba(255,196,0,0));
    opacity:0;transform:translate(var(--gx,0px),var(--gy,0px));
    transition:transform .6s cubic-bezier(.22,.61,.36,1),opacity .5s ease;
  }
  #ag-dir01-02 .ag-tl.is-live .ag-tl__glow.is-on{opacity:1;}
  @media (max-width:599px){
    #ag-dir01-02 .ag-tl__glow{width:260px;height:260px;margin:-130px 0 0 -130px;}
  }
  @media (prefers-reduced-motion:reduce){
    #ag-dir01-02 .ag-tl__glow{display:none;}
  }
  @media (forced-colors:active){
    #ag-dir01-02 .ag-tl__glow{display:none;}
  }
'''
    t = add_css(t, css)
    # фишка — в скрипт шагов: объявления после data-cur, вызовы из set()
    t = rep(t, '      if (art) art.setAttribute("data-cur", String(Math.max(0, i)));\n    }\n',
            '      if (art) art.setAttribute("data-cur", String(Math.max(0, i)));\n      place(i);\n      schedule(i);\n    }\n' + STEPS_FX_JS)
    t = touch(t)
    save(2, t)


# ---------------------------------------------------------------- DIR01-03
MAPS = {
    'Галактионовская, 81': ('boxing', 'https://yandex.ru/maps/?text=%D0%A1%D0%B0%D0%BC%D0%B0%D1%80%D0%B0%2C%20%D1%83%D0%BB.%20%D0%93%D0%B0%D0%BB%D0%B0%D0%BA%D1%82%D0%B8%D0%BE%D0%BD%D0%BE%D0%B2%D1%81%D0%BA%D0%B0%D1%8F%2C%2081'),
    'Чкалова, 72': ('mma', 'https://yandex.ru/maps/?text=%D0%A1%D0%B0%D0%BC%D0%B0%D1%80%D0%B0%2C%20%D1%83%D0%BB.%20%D0%A7%D0%BA%D0%B0%D0%BB%D0%BE%D0%B2%D0%B0%2C%2072'),
    '<span class="ag-nw">Ново-Садовая,</span> 106Б': ('gym', 'https://yandex.ru/maps/?text=%D0%A1%D0%B0%D0%BC%D0%B0%D1%80%D0%B0%2C%20%D1%83%D0%BB.%20%D0%9D%D0%BE%D0%B2%D0%BE-%D0%A1%D0%B0%D0%B4%D0%BE%D0%B2%D0%B0%D1%8F%2C%20106%D0%91'),
}
PIN = ('<svg class="ag-hs__pin" width="14" height="14" viewBox="0 0 24 24" aria-hidden="true" focusable="false">'
       '<path d="M12 21.5s7-5.8 7-11.2A7 7 0 0 0 5 10.3c0 5.4 7 11.2 7 11.2Z" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linejoin="round"/>'
       '<circle cx="12" cy="10.2" r="2.4" fill="currentColor"/></svg>')


def d03():
    t = load(3); R = '#ag-dir01-03'
    t = bump(t, 'F20 «Построить маршрут»: адрес на рамке карточки — ссылка на Яндекс Карты (поиск по адресу, как HOME-03;\n'
                '     карточки организаций не сверены), новая вкладка, значок булавки; видимый текст прежний, имя ссылки —\n'
                '     «Построить маршрут: {адрес} (откроется в новой вкладке)»; цель касания ≥ 44 px, высота блока та же.\n'
                '     Фокус 3 px.')
    for addr, (club, href) in MAPS.items():
        t = rep(t, '<span class="ag-hs__label">%s</span>' % addr,
                ('<a class="ag-hs__label ag-hs__route" href="%s" target="_blank" rel="noopener" data-ag-track="route_click" '
                 'data-ag-params=\'{"club":"%s","map":"yandex","from":"DIR01"}\'><span class="ag-vh">Построить маршрут: </span>%s%s'
                 '<span class="ag-vh"> (откроется в новой вкладке)</span></a>') % (href, club, PIN, addr))
    t = focus3(t, R)
    css = '''  /* F20 · адрес на рамке — ссылка маршрута; цель касания расширена псевдоэлементом */
  #ag-dir01-03 .ag-hs__route{display:inline-flex;align-items:center;gap:6px;transition:background-color .2s ease,color .2s ease,border-color .2s ease;}
  #ag-dir01-03 .ag-hs__route::after{content:"";position:absolute;left:-6px;right:-6px;top:-12px;bottom:-12px;}
  #ag-dir01-03 .ag-hs__pin{flex:none;}
  #ag-dir01-03.ag-scope .ag-hs__route:focus-visible{outline-offset:4px;}
  @media (hover:hover){
    #ag-dir01-03 .ag-hs__route:hover{background:var(--accent);border-color:var(--accent);color:var(--accent-ink,#09090A);}
  }
  @media (forced-colors:active){
    #ag-dir01-03 .ag-hs__route{border:1px solid LinkText;color:LinkText;}
  }  @media (max-width:599px){
    #ag-dir01-03 .ag-hs__allp{margin-top:10px;}
  }
'''
    t = add_css(t, css)
    t = touch(t)
    save(3, t)


# ---------------------------------------------------------------- DIR01-04
def d04():
    t = load(4); R = '#ag-dir01-04'
    t = bump(t, 'Вкладки и «табло» — как есть. Фокус 3 px.')
    t = focus3(t, R)
    t = touch(t)
    save(4, t)


# ---------------------------------------------------------------- DIR01-05
def d05():
    t = load(5); R = '#ag-dir01-05'
    t = bump(t, 'Состав и тексты — как есть (I041, I053 ждут владельца). F23 — нажатие кнопки, фокус 3 px.')
    t = wrap(t, 'a', 'ag-tc__all', 'ag-tc__in')
    t = focus3(t, R)
    t = add_css(t, press_css(R, [('ag-tc__all', 'ag-tc__in')]))
    t = touch(t)
    save(5, t)


# ---------------------------------------------------------------- DIR01-06
def d06():
    t = load(6); R = '#ag-dir01-06'
    t = bump(t, 'Таблица, полосы и жёлтая карточка — как есть. F23 — нажатие тёмной кнопки, фокус чернилами 3 px.')
    t = wrap(t, 'a', 'ag-dp__btn', 'ag-dp__in')
    t = focus3(t, R)
    t = add_css(t, press_css(R, [('ag-dp__btn', 'ag-dp__in')]))
    t = touch(t)
    save(6, t)


# ---------------------------------------------------------------- DIR01-07
def d07():
    t = load(7); R = '#ag-dir01-07'
    t = bump(t, 'Сравнение, вкладки телефона и #fitbox — как есть. F23 — нажатие кнопки, фокус 3 px.')
    t = wrap(t, 'a', 'ag-fm__btn', 'ag-fm__in')
    t = focus3(t, R)
    t = add_css(t, press_css(R, [('ag-fm__btn', 'ag-fm__in')]))
    t = touch(t)
    save(7, t)


# ---------------------------------------------------------------- DIR01-08
def d08():
    t = load(8); R = '#ag-dir01-08'
    t = bump(t, 'Вопросы и ответы не менялись (FAQPage в HEAD — те же тексты). F22: ответ раскрывается плавно —\n'
                '     ::details-content + interpolate-size (прогрессивно, где свойства нет — как было); ScrollTrigger.refresh()\n'
                '     и по toggle, и по окончании перехода высоты. F23 — нажатие кнопок, фокус 3 px. Телефон: строка вопроса 54 → 48 px.')
    t = wrap(t, 'a', 'ag-fq__btn', 'ag-fq__bin')
    t = wrap(t, 'button', 'ag-fq__all', 'ag-fq__ain')
    t = focus3(t, R)
    css = press_css(R, [('ag-fq__btn', 'ag-fq__bin'), ('ag-fq__all', 'ag-fq__ain')])
    css += '''  /* F22 · плавное раскрытие ответа (Chromium 131+); иначе — мгновенно, как было */
  @supports (interpolate-size:allow-keywords) and selector(::details-content){
    #ag-dir01-08 .ag-fq__list{interpolate-size:allow-keywords;}
    #ag-dir01-08 .ag-fq__item::details-content{
      height:0;overflow:clip;
      transition:height .32s cubic-bezier(.22,.61,.36,1),content-visibility .32s allow-discrete;
    }
    #ag-dir01-08 .ag-fq__item[open]::details-content{height:auto;}
    @media (prefers-reduced-motion:reduce){
      #ag-dir01-08 .ag-fq__item::details-content{transition:none;}
    }
  }
  /* телефон: строка вопроса ниже (цель касания остаётся ≥ 44 px) */
  @media (max-width:599px){
    #ag-dir01-08 .ag-fq__q{min-height:48px;padding-top:10px;padding-bottom:10px;}
  }
'''
    t = add_css(t, css)
    t = rep(t, '''    items.forEach(function (d) {
      d.addEventListener("toggle", function () { if (!busy) { sync(); refresh(); } });
    });
''', '''    items.forEach(function (d) {
      d.addEventListener("toggle", function () { if (!busy) { sync(); refresh(); } });
    });
    /* v1.2.0: высота ответа меняется переходом — пересчитать позиции анимаций ниже по окончании */
    root.addEventListener("transitionend", function (e) {
      if (e.propertyName === "height" && e.pseudoElement === "::details-content") refresh();
    });
''')
    t = touch(t)
    save(8, t)


# ---------------------------------------------------------------- DIR01-09
def d09():
    t = load(9); R = '#ag-dir01-09'
    t = bump(t, 'Магнит с кнопки записи снят (F23: CTA не убегает от курсора), нажатие F23, фокус 3 px.\n'
                '     Контурное «БОКС» — как было: только parallax, без заливки.')
    t = rep(t, ' data-ag-magnetic data-ag-track="request_start"', ' data-ag-track="request_start"')
    t = wrap(t, 'a', 'ag-dc__btn', 'ag-dc__in')
    t = focus3(t, R)
    css = press_css(R, [('ag-dc__btn', 'ag-dc__in')])
    t = add_css(t, css)
    t = touch(t)
    save(9, t)


if __name__ == '__main__':
    for f in (d01, d02, d03, d04, d05, d06, d07, d08, d09):
        f()
