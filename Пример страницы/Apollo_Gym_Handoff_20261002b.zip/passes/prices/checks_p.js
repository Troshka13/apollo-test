// /prices (PRICES) · проверки прохода «дизайн, движение и фишка» (PROMPT_PRICES_DESIGN_MOTION_v2)
const {open,settle}=require('./lib');const fs=require('fs'),path=require('path');
const AFTER='file://'+path.resolve('after.html'), BEFORE='file://'+path.resolve('before.html');
const out={};const log=(g,ok,msg)=>{(out[g]=out[g]||[]).push((ok?'pass ':'FAIL ')+msg);};
const G=process.env.G||'LTCMFA';
async function txt(url){const {browser,page}=await open({reduce:true});await page.goto(url);await page.waitForTimeout(2600);
  const r=await page.evaluate(()=>{const o={};document.querySelectorAll('.ag-scope').forEach(r=>{const c=r.cloneNode(true);c.querySelectorAll('style,script,.ag-vh').forEach(x=>x.remove());o[r.id]=c.textContent.replace(/\s+/g,' ').trim();});return o;});await browser.close();return r;}
async function links(url){const {browser,page}=await open({reduce:true});await page.goto(url);await page.waitForTimeout(400);
  const r=await page.evaluate(()=>[...document.querySelectorAll('.ag-scope a[href]')].map(a=>a.closest('.ag-scope').id+' '+a.getAttribute('href')));await browser.close();return r;}
// в середине экрана (полоса IntersectionObserver — 45 % сверху и снизу)
async function _toStep(page,i){await page.evaluate(i=>{const s=document.querySelectorAll('#ag-dir01-02 .ag-tl__step')[i];const r=s.getBoundingClientRect();scrollTo(0,scrollY+r.top+Math.min(r.height,60)/2-innerHeight/2);},i);}
const RAF=`window.__rafF=0;const __r=window.requestAnimationFrame.bind(window);window.requestAnimationFrame=function(f){if(f&&f.name==='frame')window.__rafF++;return __r(f);};`;
const running=`document.getAnimations().filter(a=>a.playState==='running'&&!(a instanceof CSSTransition))`;
(async()=>{
 if(G.includes('L')) for(const reduce of [false,true]) for(const fontsOff of [false,true]) for(const w of [320,360,390,768,1024,1440,1920]){
   const {browser,page}=await open({w,h:w<700?800:900,reduce,mobile:w<700,touch:w<700});
   if(fontsOff) await page.route('**/fonts.googleapis.com/**',r=>r.abort());
   await page.goto(AFTER);await settle(page);
   const r=await page.evaluate(()=>({ov:document.documentElement.scrollWidth>document.documentElement.clientWidth,h:document.body.scrollHeight}));
   log('L',!r.ov,`${w}px reduce=${reduce} fontsOff=${fontsOff} overflowX=${r.ov} h=${r.h}`);await browser.close();
 }
 if(G.includes('T')){const tb=await txt(BEFORE),ta=await txt(AFTER);
  for(const id of Object.keys(tb)){const a=ta[id];let i=0;while(i<tb[id].length&&tb[id][i]===a[i])i++;
   log('T',a===tb[id],id+(a===tb[id]?' текст совпадает':' РАЗНИЦА '+JSON.stringify(tb[id].slice(i-30,i+40))+' → '+JSON.stringify(a.slice(i-30,i+40))));}}
 if(G.includes('C')){const lb=await links(BEFORE),la=await links(AFTER);const add=la.filter(x=>!lb.includes(x)),rem=lb.filter(x=>!la.includes(x));
  log('C',rem.length===0&&add.length===0,`ссылки +${add.length} −${rem.length}`);}
 if(G.includes('M')){
  for(const mode of [{name:'js off',js:false},{name:'reduce',reduce:true},{name:'cdn fail',cdn:'fail'},{name:'cdn hang',cdn:'hang'}]){
   const {browser,page}=await open({w:390,h:800,mobile:true,...mode});await page.goto(AFTER,{waitUntil:'domcontentloaded'});await page.waitForTimeout(2700);
   if(mode.js!==false) for(let y=0;y<9000;y+=600){await page.evaluate(y=>scrollTo(0,y),y);await page.waitForTimeout(40);}
   const r=await page.evaluate(()=>{const bad=[];document.querySelectorAll('.ag-scope :is(p,h1,h2,h3,a,li,dt,dd,summary,td,th)').forEach(el=>{if(el.closest('[aria-hidden="true"],[hidden]'))return;let n=el,op=1;while(n&&n.nodeType===1){op*=parseFloat(getComputedStyle(n).opacity);n=n.parentElement;}if(getComputedStyle(el).display==='none')return;if(op<0.99&&el.textContent.trim())bad.push(el.textContent.trim().slice(0,30));});
     return {bad,m:document.documentElement.getAttribute('data-ag-motion'),routes:0};});
   log('M',r.bad.length===0,`${mode.name}: motion=${r.m} скрытых текстов ${r.bad.length} ${r.bad.slice(0,3).join('|')}`);await browser.close();}
  const {browser,page}=await open({w:1440});await page.goto(AFTER);await settle(page);
  const r=await page.evaluate(()=>{const o={};document.querySelectorAll('.ag-scope').forEach(root=>{const all=root.querySelectorAll('[data-ag-anim]');o[root.id]=[all.length,[...all].filter(e=>!e.hasAttribute('data-ag-done')).length];});return o;});
  for(const [id,[n,left]] of Object.entries(r)) log('M',left===0,`motion on: ${id} анимаций ${n}, не отсканировано ${left}`);await browser.close();}

 if(G.includes('F')){
  const sway=`[...document.querySelectorAll('#ag-prices-01 .ag-ph__sway')].map(e=>{const m=(e.style.transform||'').match(/rotate\\(([-\\d.]+)deg\\)/);return m?+m[1]:0;})`;
  // ПК: прокрутка колесом — ценники качаются и затихают, кадров в покое нет
  {const {browser,page}=await open({w:1440,h:900});await page.addInitScript(RAF);await page.goto(AFTER);await settle(page);await page.waitForTimeout(1200);
   const on=await page.evaluate(()=>document.getElementById('ag-prices-01').hasAttribute('data-ag-ui-swing'));
   await page.mouse.move(300,400);
   for(let k=0;k<4;k++){await page.mouse.wheel(0,90);await page.waitForTimeout(30);} 
   let mx=0;for(let k=0;k<14;k++){await page.waitForTimeout(40);const a=await page.evaluate(sway);mx=Math.max(mx,...a.map(Math.abs));}
   log('F',on&&mx>0.3,`ПК: фишка включена (${on}), колесо качнуло ценники, наибольший угол ${mx.toFixed(2)}°`);
   await page.waitForTimeout(4500);const a2=await page.evaluate(sway);const r1=await page.evaluate(()=>window.__rafF);await page.waitForTimeout(2000);const r2=await page.evaluate(()=>window.__rafF);
   log('F',a2.every(x=>x===0)&&r2===r1,`ПК: ценники успокоились (${a2.join(', ')}), кадров цикла в покое за 2 с: ${r2-r1}`);
   // мышь по ценнику
   const tag=await page.$('#ag-prices-01 .ag-ph__it--2 .ag-ph__card');const tb=await tag.boundingBox();
   await page.mouse.move(tb.x+10,tb.y+tb.height/2);await page.mouse.move(tb.x+tb.width-10,tb.y+tb.height/2,{steps:5});await page.waitForTimeout(120);
   const a3=await page.evaluate(sway);log('F',Math.abs(a3[1])>0.2,`ПК: мышь качнула средний ценник (${a3.map(x=>x.toFixed(2)).join(', ')})`);
   await page.mouse.move(5,5);await page.waitForTimeout(4500);
   // наведение не поворачивает ссылку CSS-ом при работающей фишке
   await page.mouse.move(tb.x+tb.width/2,tb.y+tb.height/2);await page.waitForTimeout(1000);
   const lt=await page.$eval('#ag-prices-01 .ag-ph__it--2 .ag-ph__swing',e=>getComputedStyle(e).transform);
   log('F',/matrix\(0\.999/.test(lt),`ПК: при наведении ссылка в покое (поворот ${lt.slice(0,40)}; покой 2°)`);
   await page.mouse.move(5,5);await page.waitForTimeout(3000);
   // фокус: ценник не качается
   await page.focus('#ag-prices-01 .ag-ph__it--1 .ag-ph__swing');await page.mouse.move(300,400);
   for(let k=0;k<4;k++){await page.mouse.wheel(0,90);await page.waitForTimeout(30);}
   let f1=0;for(let k=0;k<10;k++){await page.waitForTimeout(40);const a=await page.evaluate(sway);f1=Math.max(f1,Math.abs(a[0]));}
   log('F',f1<0.3,`ПК: ценник в фокусе не качается (угол ≤ ${f1.toFixed(2)}°)`);
   // скачок по якорю — без толчка
   await page.evaluate(()=>document.activeElement.blur());await page.waitForTimeout(4000);
   await page.evaluate(()=>scrollTo(0,0));await page.waitForTimeout(3000);
   await page.evaluate(()=>{const t=document.getElementById('ag-price-12');scrollTo(0,t.getBoundingClientRect().top+scrollY-100);});await page.waitForTimeout(30);await page.evaluate(()=>scrollTo(0,0));
   let jmx=0;for(let k=0;k<10;k++){await page.waitForTimeout(40);const a=await page.evaluate(sway);jmx=Math.max(jmx,...a.map(Math.abs));}
   log('F',jmx<0.3,`ПК: скачок по якорю туда-обратно — без толчка (угол ≤ ${jmx.toFixed(2)}°)`);
   // клик по ценнику ведёт к колонке
   await page.evaluate(()=>scrollTo(0,0));await page.waitForTimeout(300);await page.click('#ag-prices-01 .ag-ph__it--1 .ag-ph__card');await page.waitForTimeout(900);
   const hash=await page.evaluate(()=>{const c=document.getElementById('ag-price-1').getBoundingClientRect();return location.hash+' top='+Math.round(c.top);});
   log('F',/#ag-price-1 /.test(hash+' '),`ценник ведёт к колонке: ${hash}`);
   const nm=await page.evaluate(()=>[...document.querySelectorAll('#ag-prices-01 .ag-ph__swing')].map(a=>a.textContent.replace(/\s+/g,' ').trim()));
   log('F',nm.length===3&&nm.every(x=>/— к (таблице цен|условиям)$/.test(x)),`имена ценников: ${nm.join(' | ')}`);
   // 02 подбор
   await page.evaluate(()=>document.getElementById('ag-prices-02').scrollIntoView());await page.waitForTimeout(600);
   const inc=await page.$('#ag-prices-02 [data-ag-inc]');await inc.focus();for(let k=0;k<4;k++){await page.keyboard.press('Enter');await page.waitForTimeout(60);}
   await page.waitForTimeout(400);
   const pk=await page.evaluate(()=>{const inc=document.querySelector('#ag-prices-02 [data-ag-inc]');return {n:document.querySelector('#ag-prices-02 [data-ag-n]').textContent,ad:inc.getAttribute('aria-disabled'),dis:inc.disabled,focus:document.activeElement===inc,
     floor:[...document.querySelectorAll('#ag-prices-02 .ag-pl__col')].map(c=>c.id.replace('ag-price-','')+':'+(c.classList.contains('is-pick')?1:0)+':'+getComputedStyle(c,'::after').transform),res:document.querySelector('#ag-prices-02 [data-ag-res]').textContent};});
   log('F',pk.n==='12'&&pk.ad==='true'&&!pk.dis&&pk.focus&&/12:1:matrix\(1, 0, 0, 1/.test(pk.floor.join(' '))&&/1:0:matrix\(0, /.test(pk.floor.join(' ')),`подбор: N=${pk.n}, «+» aria-disabled=${pk.ad}, фокус на месте ${pk.focus}; пол: ${pk.floor.map(x=>x.split(':').slice(0,2).join(':')+(x.includes('matrix(1,')?'↑':'·')).join(' ')}; «${pk.res}»`);
   await page.keyboard.press('Enter');await page.waitForTimeout(100);const n2=await page.$eval('#ag-prices-02 [data-ag-n]',e=>e.textContent);log('F',n2==='12',`подбор: «+» на 12 не меняет число (${n2})`);
   await page.focus('#ag-prices-02 [data-ag-dec]');await page.keyboard.press('Enter');await page.waitForTimeout(40);
   const an=await page.evaluate(()=>document.querySelector('#ag-prices-02 [data-ag-res]').getAnimations().length);log('F',an>0,`подбор: итог проявляется (анимаций ${an})`);
   // 03 подложка вкладок
   await page.evaluate(()=>document.getElementById('ag-prices-03').scrollIntoView());await page.waitForTimeout(500);
   await page.click('#ag-prices-03-t3');await page.waitForTimeout(450);
   const ind=await page.evaluate(()=>{const l=document.querySelector('#ag-prices-03 .ag-pc__tabs'),t=document.getElementById('ag-prices-03-t3');const cs=getComputedStyle(l,'::before');const m=new DOMMatrix(cs.transform);return {w:parseFloat(cs.width),tw:t.offsetWidth,x:m.m41,tx:t.offsetLeft,y:m.m42,ty:t.offsetTop,bg:getComputedStyle(t).backgroundColor};});
   log('F',Math.abs(ind.w-ind.tw)<1&&Math.abs(ind.x-ind.tx)<1&&Math.abs(ind.y-ind.ty)<1,`вкладки ПК: подложка под «Персональные и сплит» (${Math.round(ind.x)},${Math.round(ind.y)} ${Math.round(ind.w)} px ↔ ${ind.tx},${ind.ty} ${ind.tw} px), фон вкладки ${ind.bg}`);
   await page.focus('#ag-prices-03-t3');await page.keyboard.press('ArrowRight');await page.waitForTimeout(450);
   const ind2=await page.evaluate(()=>{const l=document.querySelector('#ag-prices-03 .ag-pc__tabs'),t=document.getElementById('ag-prices-03-t4');const m=new DOMMatrix(getComputedStyle(l,'::before').transform);return {x:m.m41,tx:t.offsetLeft,sel:t.getAttribute('aria-selected')};});
   log('F',ind2.sel==='true'&&Math.abs(ind2.x-ind2.tx)<1,`вкладки: стрелка → «Сайкл и растяжка», подложка следом (${Math.round(ind2.x)} ↔ ${ind2.tx})`);
   const gr=await page.evaluate(()=>['#ag-prices-03 .ag-pc','#ag-prices-05 .ag-pq'].map(s=>/svg/.test(getComputedStyle(document.querySelector(s),'::before').backgroundImage)));
   log('F',gr.every(Boolean),`зерно бумаги на ПК: 03 ${gr[0]}, 05 ${gr[1]}`);
   // 05 FAQ
   const q=await page.$('#ag-prices-05 .ag-pq__item:nth-child(3) summary');await q.scrollIntoViewIfNeeded();await q.focus();await page.keyboard.press('Enter');await page.waitForTimeout(500);
   const fo=await page.evaluate(()=>{const d=document.querySelector('#ag-prices-05 .ag-pq__item:nth-child(3)');return {open:d.open,vis:d.querySelector('.ag-pq__a').checkVisibility(),dc:CSS.supports('selector(::details-content)')};});
   log('F',fo.open&&fo.vis,`FAQ: Enter открыл ответ (::details-content ${fo.dc}), ответ виден`);
   const all=await page.$('#ag-prices-05 [data-ag-all]');await all.click();await page.waitForTimeout(60);
   const bulk=await page.evaluate(()=>{const it=[...document.querySelectorAll('#ag-prices-05 .ag-pq__item')];return {n:it.filter(d=>d.open).length,t:it.length,h:it.map(d=>d.getBoundingClientRect().height)};});
   await page.waitForTimeout(400);const lab=await page.$eval('#ag-prices-05 [data-ag-all-label]',e=>e.textContent);
   log('F',bulk.n===bulk.t&&lab==='Свернуть ответы',`FAQ: «Раскрыть все» открыл ${bulk.n} из ${bulk.t} сразу, подпись «${lab}»`);
   // магнит, F23
   const mag=await page.$$eval('[data-ag-magnetic]',x=>x.length);log('F',mag===0,`магнитных кнопок: ${mag}`);
   const btn=await page.$('#ag-prices-06 .ag-dc__btn');await btn.scrollIntoViewIfNeeded();await page.waitForTimeout(300);const b0=await btn.boundingBox();
   await page.mouse.move(b0.x+b0.width/2,b0.y+b0.height/2);await page.mouse.move(b0.x+b0.width/2+30,b0.y+b0.height/2+10,{steps:5});await page.waitForTimeout(250);const b1=await btn.boundingBox();
   await page.evaluate(()=>document.querySelector('#ag-prices-06 .ag-dc__btn').addEventListener('click',e=>e.preventDefault(),{once:true}));
   await page.mouse.down();await page.waitForTimeout(220);const tr=await page.$eval('#ag-prices-06 .ag-dc__in',e=>getComputedStyle(e).transform);await page.mouse.up();
   log('F',Math.abs(b1.x-b0.x)<0.5&&Math.abs(b1.y-b0.y)<0.5&&/matrix\(0\.98/.test(tr),`F23: кнопка записи на месте (Δ ${(b1.x-b0.x).toFixed(1)}, ${(b1.y-b0.y).toFixed(1)}), при нажатии ${tr}`);
   await browser.close();}
  // телефон: прокрутка качает, наклон с покоем ≤ 4,5°; подложка между рядами; край якорей; без зерна
  {const {browser,page}=await open({w:390,h:800,mobile:true,touch:true});await page.goto(AFTER);await settle(page);await page.waitForTimeout(1200);
   const rec=await page.evaluate(async()=>{const els=[...document.querySelectorAll('#ag-prices-01 .ag-ph__sway')];const rest=[...document.querySelectorAll('#ag-prices-01 .ag-ph__it')].map(li=>parseFloat(getComputedStyle(li).getPropertyValue('--rest')));let mx=[0,0,0],tot=0;
     const fr=()=>new Promise(r=>requestAnimationFrame(r));
     for(let k=0;k<12;k++){scrollBy(0,k<6?k*6:(12-k)*6);await fr();els.forEach((e,i)=>{const m=(e.style.transform||'').match(/rotate\(([-\d.]+)deg\)/);const a=m?+m[1]:0;mx[i]=Math.max(mx[i],Math.abs(a));tot=Math.max(tot,Math.abs(a+rest[i]));});}
     for(let k=0;k<40;k++){await fr();els.forEach((e,i)=>{const m=(e.style.transform||'').match(/rotate\(([-\d.]+)deg\)/);const a=m?+m[1]:0;mx[i]=Math.max(mx[i],Math.abs(a));const cur=Math.abs(a+rest[i]);tot=Math.max(tot,cur);});}
     return {mx,tot};});
   log('F',Math.max(...rec.mx)>0.2&&rec.tot<=4.51,`телефон: прокрутка качнула ценники (${rec.mx.map(x=>x.toFixed(2)).join(', ')}°), наклон с покоем ≤ ${rec.tot.toFixed(2)}°`);
   const jm=await page.evaluate(()=>{const j=document.querySelector('#ag-prices-01 .ag-ph__jump');const a=j.classList.contains('is-more');j.scrollLeft=j.scrollWidth;return new Promise(r=>setTimeout(()=>r([a,j.classList.contains('is-more')]),200));});
   log('F',jm[0]&&!jm[1],`телефон: край якорей затухает (${jm[0]}), в конце ряда — нет (${jm[1]})`);
   await page.evaluate(()=>document.getElementById('ag-prices-03').scrollIntoView());await page.waitForTimeout(500);
   await page.click('#ag-prices-03-t3');await page.waitForTimeout(60);
   const mid=await page.evaluate(()=>{const l=document.querySelector('#ag-prices-03 .ag-pc__tabs');return {jump:l.classList.contains('is-jump'),an:l.getAnimations({subtree:true}).length};});
   await page.waitForTimeout(400);
   const ph=await page.evaluate(()=>{const l=document.querySelector('#ag-prices-03 .ag-pc__tabs'),t=document.getElementById('ag-prices-03-t3');const m=new DOMMatrix(getComputedStyle(l,'::before').transform);return {x:m.m41,tx:t.offsetLeft,y:m.m42,ty:t.offsetTop,ov:document.documentElement.scrollWidth>document.documentElement.clientWidth};});
   log('F',Math.abs(ph.y-ph.ty)<1&&Math.abs(ph.x-ph.tx)<1,`телефон: подложка перешла во второй ряд переносом (is-jump ${mid.jump}, проявление ${mid.an}), (${Math.round(ph.x)},${Math.round(ph.y)}) ↔ (${ph.tx},${ph.ty})`);
   const gr=await page.evaluate(()=>getComputedStyle(document.querySelector('#ag-prices-03 .ag-pc'),'::before').backgroundImage);
   log('F',!/svg/.test(gr),`телефон: зерна нет (${gr.slice(0,20)})`);
   await browser.close();}
  // reduce, forced-colors: фишка выключена; смена reduce на лету
  for(const env of [{name:'reduce',o:{reduce:true}},{name:'forced-colors',fc:true}]){
   const {browser,page}=await open({w:1440,h:900,...(env.o||{})});if(env.fc) await page.emulateMedia({forcedColors:'active'});await page.goto(AFTER);await settle(page);await page.waitForTimeout(1200);
   await page.mouse.move(300,400);for(let k=0;k<4;k++){await page.mouse.wheel(0,90);await page.waitForTimeout(30);}
   let mx=0;for(let k=0;k<10;k++){await page.waitForTimeout(40);const a=await page.evaluate(sway);mx=Math.max(mx,...a.map(Math.abs));}
   const at=await page.evaluate(()=>document.getElementById('ag-prices-01').hasAttribute('data-ag-ui-swing'));
   if(env.fc){await page.evaluate(()=>document.getElementById('ag-prices-03').scrollIntoView());await page.waitForTimeout(300);await page.screenshot({path:'shots/forced_03.png',clip:await (await page.$('#ag-prices-03')).boundingBox().then(b=>({x:0,y:b.y,width:1440,height:Math.min(b.height,900)}))});}
   log('F',mx===0&&!at,`${env.name}: ценники неподвижны (угол ${mx}), фишка ${at?'включена':'выключена'}`);await browser.close();}
  {const {browser,page}=await open({w:1440,h:900});await page.goto(AFTER);await settle(page);await page.waitForTimeout(1200);
   await page.mouse.move(300,400);for(let k=0;k<4;k++){await page.mouse.wheel(0,90);await page.waitForTimeout(30);}
   await page.waitForTimeout(60);await page.emulateMedia({reducedMotion:'reduce'});await page.waitForTimeout(80);
   const a=await page.evaluate(sway);const at=await page.evaluate(()=>document.getElementById('ag-prices-01').hasAttribute('data-ag-ui-swing'));
   log('F',a.every(x=>x===0)&&!at,`reduce на лету: ценники сброшены (${a.join(', ')}), фишка выключена`);await browser.close();}
 }
 if(G.includes('A')){const axeSrc=fs.readFileSync(require.resolve('axe-core/axe.min.js'),'utf8');
  for(const m of [{w:1440},{w:1024},{w:390,mobile:true},{w:390,mobile:true,reduce:true},{w:390,nojs:true}]){
   let o;if(m.nojs){fs.writeFileSync('after_nojs.html',fs.readFileSync('after.html','utf8').replace(/<script>[\s\S]*?<\/script>/g,'').replace(/<!--[\s\S]*?-->/g,'').replace(/<noscript>([\s\S]*?)<\/noscript>/g,'$1'));o=await open({w:390,h:900});await o.page.goto('file://'+path.resolve('after_nojs.html'));await o.page.waitForTimeout(800);}
   else {o=await open({...m,h:900});await o.page.goto(AFTER);await settle(o.page);}
   await o.page.addScriptTag({content:axeSrc});const res=await o.page.evaluate(async()=>(await axe.run(document.getElementById('allrecords'),{resultTypes:['violations']})).violations.map(v=>[v.id,v.impact,v.nodes.length,v.nodes[0].target.join(' ')]));
   const s=res.filter(v=>/serious|critical/.test(v[1]));log('A',s.length===0,`${m.w}${m.reduce?' reduce':''}${m.nojs?' без JS':''}: нарушений ${res.length} (serious/critical ${s.length}) ${res.map(v=>v.join(':')).join(' ; ').slice(0,300)}`);await o.browser.close();}
  {const o=await open({w:1440,h:900});await o.page.goto(AFTER);await settle(o.page);await o.page.evaluate(()=>{document.querySelectorAll('#ag-prices-05 details').forEach(d=>d.open=true);});await o.page.waitForTimeout(500);
   await o.page.addScriptTag({content:axeSrc});const res=await o.page.evaluate(async()=>(await axe.run(document.getElementById('allrecords'),{resultTypes:['violations']})).violations.map(v=>[v.id,v.impact]));
   log('A',res.length===0,`1440, все ответы открыты: нарушений ${res.length} ${res.join(' ; ')}`);await o.browser.close();}}
 fs.writeFileSync('checks_p_'+G+'.json',JSON.stringify(out,null,1));
 for(const g of Object.keys(out)){console.log('## '+g);out[g].forEach(x=>console.log('  '+x));}
})();
