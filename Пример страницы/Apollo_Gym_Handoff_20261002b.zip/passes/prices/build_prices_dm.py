# -*- coding: utf-8 -*-
"""/prices (PRICES) · проход «дизайн, движение и фишка» (PROMPT_PRICES_DESIGN_MOTION_v2, 30.09.2026).
src/PRICES-0N_v1.1.0.html → out/PRICES-0N_v1.2.0.html. Каждая замена обязана найтись нужное число раз."""
import re, os

SRC, OUT = 'src', 'out'
os.makedirs(OUT, exist_ok=True)
DATE = '30.09.2026'
EASE_OUT = 'cubic-bezier(.34,1.56,.64,1)'


def rep(t, old, new, n=1):
    c = t.count(old)
    if c != n:
        raise SystemExit('replace %d != %d: %r' % (c, n, old[:140]))
    return t.replace(old, new)


def rx(t, pat, new, n=1):
    t2, c = re.subn(pat, new, t, flags=re.S)
    if c != n:
        raise SystemExit('regex %d != %d: %r' % (c, n, pat[:140]))
    return t2


def load(n):
    return open('%s/PRICES-0%d_v1.1.0.html' % (SRC, n), encoding='utf-8').read()


def save(n, t):
    p = '%s/PRICES-0%d_v1.2.0.html' % (OUT, n)
    open(p, 'w', encoding='utf-8').write(t)
    print('PRICES-0%d v1.2.0 %6d байт' % (n, len(t.encode('utf-8'))))


def bump(t, note):
    t = rx(t, r'(APOLLO GYM · PRICES-0\d[^\n]*?)· v1\.1\.0 · 30\.09\.2026', r'\1· v1.2.0 · 30.09.2026')
    i = t.index('-->') + 3
    return t[:i] + '\n<!-- v1.2.0 (проход «дизайн, движение и фишка», PROMPT_PRICES_DESIGN_MOTION_v2, %s):\n     %s -->' % (DATE, note) + t[i:]


def focus3(t, root):
    return rx(t, r'(%s\.ag-scope :is\([^)]*\):focus-visible\{outline:)2px' % re.escape(root), r'\g<1>3px')


def wrap(t, tag, cls, inner, n=1):
    pat = r'(<%s class="%s"[^>]*>)(.*?)(</%s>)' % (tag, re.escape(cls), tag)
    return rx(t, pat, lambda m: m.group(1) + '<span class="%s">' % inner + m.group(2) + '</span>' + m.group(3), n)


def press_css(root, pairs):
    sel_in = ',\n  '.join('%s .%s' % (root, i) for b, i in pairs)
    sel_act = ',\n  '.join('%s .%s:active .%s' % (root, b, i) for b, i in pairs)
    red_in = ', '.join('%s .%s' % (root, i) for b, i in pairs)
    red_act = ', '.join('%s .%s:active .%s' % (root, b, i) for b, i in pairs)
    return ('''  /* F23 · нажатие: область кнопки неподвижна, сжимается подпись со значком */
  %s{display:inline-flex;align-items:center;justify-content:inherit;gap:inherit;flex:1 1 auto;min-width:0;
    transition:transform 260ms %s;}
  %s{transform:scale(.98);transition-duration:140ms;transition-timing-function:cubic-bezier(.22,.61,.36,1);}
  @media (prefers-reduced-motion:reduce){
    %s{transition:none;}
    %s{transform:none;}
  }
''' % (sel_in, EASE_OUT, sel_act, red_in, red_act))


def add_css(t, css):
    i = t.index('  </style>')
    return t[:i] + '\n  /* ===== v1.2.0 · дизайн, движение и фишка (30.09) ===== */\n' + css + t[i:]


TOUCH = '    /* iOS включает :active только при слушателе касания (F23) */\n    root.addEventListener("touchstart", function () {}, { passive: true });\n'


def touch(t):
    return rep(t, '    var tries = 0;\n', TOUCH + '    var tries = 0;\n')


def before_engine(t, js):
    i = t.index('<!-- Движок движения')
    return t[:i] + js.lstrip('\n') + '\n  ' + t[i:]


# F29 · зерно бумаги: статичная SVG-плитка 180 px, затемнение ≤ 6 % (0,5 фильтра × 0,12 слоя)
GRAIN = ("url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='180' height='180'%3E"
         "%3Cfilter id='g'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='.85' numOctaves='2' stitchTiles='stitch'/%3E"
         "%3CfeColorMatrix values='0 0 0 0 .04 0 0 0 0 .035 0 0 0 0 .03 0 0 0 .5 0'/%3E%3C/filter%3E"
         "%3Crect width='100%25' height='100%25' filter='url(%23g)'/%3E%3C/svg%3E\")")


def grain_css(root, sec, wrap_cls):
    return '''  /* F29 · зерно бумаги (статично, только ≥ 640 px; forced-colors и печать — без зерна) */
  @media (min-width:640px){
    %(r)s .%(s)s::before{content:"";position:absolute;inset:0;z-index:0;pointer-events:none;opacity:.12;background-image:%(g)s;background-size:180px 180px;}
    %(r)s .%(w)s{position:relative;z-index:1;}
  }
  @media (forced-colors:active){%(r)s .%(s)s::before{display:none;}}
  @media print{%(r)s .%(s)s::before{display:none;}}
''' % {'r': root, 's': sec, 'w': wrap_cls, 'g': GRAIN}


# ---------------------------------------------------------------- PRICES-01
SWING_JS = r'''
  <script>
  /* v1.2.0 · «Ценники на канате» (ведущая фишка страницы, П12): ценники висят на нитках и покачиваются
     по инерции — от изменения скорости прокрутки (разгон и остановка) и от мыши, прошедшей по ценнику;
     у каждого своя длина нитки, качаются вразнобой и затухают. Качается обёртка .ag-ph__sway (нитка
     и карточка), у ссылки transform занят покоем и фокусом. Ограничения (ревью Б1): скачок больше
     0,8 экрана за кадр (якорь, восстановление позиции) — без толчка; первую секунду и пока движок не
     закончил появление ценников — без толчка; scroll пассивный и только пока сцена видна; rAF — только
     пока ценники качаются, шаг ≤ 2 кадров; скрытая вкладка — сброс; мышь — только точный указатель;
     ценник в фокусе или под нажатием не качается; телефон — наклон с покоем ≤ 4,5°. reduce и
     forced-colors — фишка выключена (и при смене настройки на лету). */
  (function () {
    "use strict";
    var W = window, D = document;
    var root = D.currentScript && D.currentScript.closest(".ag-scope");
    if (!root || root.hasAttribute("data-ag-ui-swing-on")) return;
    root.setAttribute("data-ag-ui-swing-on", "");
    var stage = root.querySelector(".ag-ph__stage");
    var list = root.querySelector(".ag-ph__tags");
    if (!stage || !list || !W.matchMedia || !W.requestAnimationFrame || !("IntersectionObserver" in W)) return;
    var mqR = W.matchMedia("(prefers-reduced-motion: reduce)");
    var mqF = W.matchMedia("(forced-colors: active)");
    var fine = W.matchMedia("(hover: hover) and (pointer: fine)");
    var small = W.matchMedia("(max-width: 599px)");
    var K = [0.05, 0.034, 0.042], SIGN = [1, -1, 1];
    var tags = Array.prototype.slice.call(root.querySelectorAll(".ag-ph__swing")).map(function (a, i) {
      var rest = parseFloat(W.getComputedStyle(a.parentNode).getPropertyValue("--rest")) || 0;
      return { a: a, el: a.querySelector(".ag-ph__sway"), x: 0, v: 0, k: K[i % 3], s: SIGN[i % 3], rest: rest, hold: false };
    }).filter(function (t) { return t.el; });
    if (!tags.length) return;
    var on = false, seen = false, raf = 0, last = 0, t0 = Date.now();
    var lastY = W.pageYOffset, lastS = 0, lastScroll = 0;
    function ready() {
      if (Date.now() - t0 < 1000) return false;
      return list.hasAttribute("data-ag-done") || D.documentElement.getAttribute("data-ag-motion") !== "on";
    }
    function lim(t) { return small.matches ? Math.max(0.5, 4.5 - Math.abs(t.rest)) : 5; }
    function paint(t) {
      if (Math.abs(t.x) < 0.02 && Math.abs(t.v) < 0.005) { t.x = 0; t.v = 0; t.el.style.transform = ""; t.el.style.willChange = ""; return false; }
      t.el.style.willChange = "transform";
      t.el.style.transform = "rotate(" + t.x.toFixed(2) + "deg)";
      return true;
    }
    function frame(now) {
      raf = 0;
      var dt = last ? Math.min(2, (now - last) / 16.67) : 1;
      last = now;
      var y = W.pageYOffset, dy = y - lastY;
      lastY = y;
      if (Math.abs(dy) > W.innerHeight * 0.8) { lastS = 0; dy = 0; }
      var s = dy / dt, acc = s - lastS;
      lastS = s;
      var push = ready() ? Math.max(-0.8, Math.min(0.8, acc * 0.02)) : 0;
      var busy = false;
      tags.forEach(function (t) {
        if (t.hold) { t.v *= 0.6; t.x *= 0.75; }
        else {
          t.v += push * t.s;
          t.v += (-t.k * t.x - 0.07 * t.v) * dt;
          t.x += t.v * dt;
          var m = lim(t);
          if (t.x > m) { t.x = m; t.v = 0; } else if (t.x < -m) { t.x = -m; t.v = 0; }
        }
        if (paint(t)) busy = true;
      });
      if (busy || Date.now() - lastScroll < 140) raf = W.requestAnimationFrame(frame);
      else { last = 0; lastS = 0; }
    }
    function kick() { if (!raf && on) { lastY = W.pageYOffset; raf = W.requestAnimationFrame(frame); } }
    function onScroll() { lastScroll = Date.now(); kick(); }
    function onMove(e) {
      if (!fine.matches || !ready()) return;
      var a = e.target.closest && e.target.closest(".ag-ph__swing");
      if (!a) return;
      tags.forEach(function (t) {
        if (t.a === a && !t.hold) t.v += Math.max(-0.7, Math.min(0.7, (e.movementX || 0) * 0.02));
      });
      kick();
    }
    function reset() {
      if (raf) W.cancelAnimationFrame(raf);
      raf = 0; last = 0; lastS = 0;
      tags.forEach(function (t) { t.x = 0; t.v = 0; t.el.style.transform = ""; t.el.style.willChange = ""; });
    }
    function listen(v) {
      if (v) W.addEventListener("scroll", onScroll, { passive: true });
      else W.removeEventListener("scroll", onScroll);
    }
    function enable() {
      if (on || mqR.matches || mqF.matches) return;
      on = true;
      root.setAttribute("data-ag-ui-swing", "");
      stage.addEventListener("pointermove", onMove);
      if (seen) listen(true);
    }
    function disable() {
      if (!on) return;
      on = false;
      root.removeAttribute("data-ag-ui-swing");
      stage.removeEventListener("pointermove", onMove);
      listen(false);
      reset();
    }
    tags.forEach(function (t) {
      t.a.addEventListener("focus", function () { t.hold = true; kick(); });
      t.a.addEventListener("blur", function () { t.hold = false; });
      t.a.addEventListener("pointerdown", function () { t.hold = true; kick(); });
      ["pointerup", "pointercancel", "pointerleave"].forEach(function (ev) {
        t.a.addEventListener(ev, function () { if (D.activeElement !== t.a) t.hold = false; });
      });
    });
    new IntersectionObserver(function (es) {
      seen = es[es.length - 1].isIntersecting;
      if (on) listen(seen);
      if (!seen) reset();
    }).observe(stage);
    D.addEventListener("visibilitychange", function () { if (D.hidden) reset(); });
    function onPref() { if (mqR.matches || mqF.matches) disable(); else enable(); }
    [mqR, mqF].forEach(function (q) { if (q.addEventListener) q.addEventListener("change", onPref); else if (q.addListener) q.addListener(onPref); });
    enable();
  })();

  /* v1.2.0 · телефон: ряд якорей «На странице» уходит за край — край затухает, пока ряд не прокручен до конца */
  (function () {
    "use strict";
    var W = window, D = document;
    var root = D.currentScript && D.currentScript.closest(".ag-scope");
    var jump = root && root.querySelector(".ag-ph__jump");
    if (!jump || jump.hasAttribute("data-ag-ui-more")) return;
    jump.setAttribute("data-ag-ui-more", "");
    function more() { jump.classList.toggle("is-more", jump.scrollWidth - jump.clientWidth - jump.scrollLeft > 2); }
    jump.addEventListener("scroll", more, { passive: true });
    if ("ResizeObserver" in W) new W.ResizeObserver(more).observe(jump);
    W.addEventListener("load", more);
    more();
  })();
  </script>
'''


def p01():
    t = load(1); R = '#ag-prices-01'
    t = bump(t, 'Ведущая фишка страницы «Ценники на канате»: ценники покачиваются по инерции от прокрутки (разгон и\n'
                '     остановка) и от мыши, затухают; качается обёртка .ag-ph__sway (нитка + карточка, ось на канате),\n'
                '     CSS-поворот по наведению при работающей фишке снят, поворот по фокусу — как был. Ограничения —\n'
                '     в комментарии скрипта (ревью Б1). reduce, forced-colors, без JS — как в v1.1.0.\n'
                '     Телефон: край ряда якорей затухает, пока ряд не прокручен до конца. Магнит с кнопки снят,\n'
                '     нажатие F23. Текст не менялся.')
    t = rep(t, ' data-ag-magnetic="0.18"', '')
    t = wrap(t, 'a', 'ag-ph__btn', 'ag-ph__in')
    t = rx(t, r'(<a class="ag-ph__swing"[^>]*>\n)(.*?)(\n            </a>)',
           lambda m: m.group(1) + '              <span class="ag-ph__sway">\n' + m.group(2) + '\n              </span>' + m.group(3), 3)
    css = press_css(R, [('ag-ph__btn', 'ag-ph__in')])
    css += '''  /* «Ценники на канате»: качается обёртка, ось — точка на канате; отступ нитки переехал на неё */
  #ag-prices-01 .ag-ph__swing{padding-top:0;}
  #ag-prices-01 .ag-ph__sway{position:relative;display:block;padding-top:var(--len);transform-origin:50% 0;}
  #ag-prices-01[data-ag-ui-swing] .ag-ph__swing:hover{transform:rotate(var(--rest));}
  @media (max-width:599px){
    #ag-prices-01 .ag-ph__jump.is-more{-webkit-mask-image:linear-gradient(90deg,#000 calc(100% - 44px),transparent);mask-image:linear-gradient(90deg,#000 calc(100% - 44px),transparent);}
  }
  @media print{
    #ag-prices-01 .ag-ph__sway{padding-top:0;transform:none !important;}
  }
'''
    t = add_css(t, css)
    t = touch(t)
    t = before_engine(t, SWING_JS)
    save(1, t)


# ---------------------------------------------------------------- PRICES-02
def p02():
    t = load(2); R = '#ag-prices-02'
    t = bump(t, '«Подбор пакета» (F16): у колонок, попавших в подбор, жёлтая планка-«пол» (переход 280 мс), итог подбора\n'
                '     проявляется 160 мс (opacity); «−» и «+» на 1 и 12 — aria-disabled вместо disabled (фокус с клавиатуры\n'
                '     не теряется). F23 — нажатие «−/+» и кнопки записи, фокус 3 px. Лесенка и текст — как есть.')
    t = wrap(t, 'a', 'ag-pl__btn', 'ag-pl__in')
    t = wrap(t, 'button', 'ag-pl__sb', 'ag-pl__sbin', 2)
    t = focus3(t, R)
    t = rep(t, '  #ag-prices-02 .ag-pl__sb:disabled{opacity:.35;cursor:default;}',
            '  #ag-prices-02 .ag-pl__sb[aria-disabled="true"]{opacity:.35;cursor:default;}')
    t = rep(t, '#ag-prices-02 .ag-pl__sb:not(:disabled):hover', '#ag-prices-02 .ag-pl__sb:not([aria-disabled="true"]):hover')
    t = rep(t, '      dec.disabled = n <= 1; inc.disabled = n >= 12;\n',
            '      dec.setAttribute("aria-disabled", n <= 1 ? "true" : "false"); inc.setAttribute("aria-disabled", n >= 12 ? "true" : "false");\n')
    t = rep(t, '      res.innerHTML = text(b);\n',
            '      res.innerHTML = text(b);\n'
            '      /* v1.2.0: итог проявляется (F16: смена через opacity, цифры не прокручиваются) */\n'
            '      if (shown && res.animate && !(W.matchMedia && W.matchMedia("(prefers-reduced-motion: reduce)").matches)) res.animate([{ opacity: 0.25 }, { opacity: 1 }], { duration: 160, easing: "ease-out" });\n'
            '      shown = true;\n')
    t = rep(t, '    var n = 8, sent = false;\n', '    var n = 8, sent = false, shown = false;\n')
    css = press_css(R, [('ag-pl__btn', 'ag-pl__in'), ('ag-pl__sb', 'ag-pl__sbin')])
    css += '''  #ag-prices-02 .ag-pl__sb[aria-disabled="true"]:active .ag-pl__sbin{transform:none;}
  /* «пол» под колонками подбора: планка по нижней кромке, растёт от центра */
  #ag-prices-02 .ag-pl__col::after{
    content:"";position:absolute;left:12%;right:12%;bottom:-7px;height:4px;border-radius:2px;background:var(--accent);
    transform:scaleX(0);transition:transform .28s cubic-bezier(.22,.61,.36,1);pointer-events:none;
  }
  #ag-prices-02 .ag-pl__col.is-pick::after{transform:scaleX(1);}
  @media (forced-colors:active){#ag-prices-02 .ag-pl__col::after{background:Highlight;}}
  @media print{#ag-prices-02 .ag-pl__col::after{display:none;}}
'''
    t = add_css(t, css)
    t = touch(t)
    save(2, t)


# ---------------------------------------------------------------- PRICES-03
IND_JS = '''    /* v1.2.0 · F10: подложка выбранной вкладки (::before у tablist, CSS-переменные). Внутри ряда — сдвиг,
       между рядами (сетка 2×2 на телефоне) — перенос без сдвига с проявлением. Первая установка — без перехода. */
    var ind = { on: false, row: null, cur: 0 };
    function place(i, jump) {
      var t = tabs[i];
      if (!t || !t.offsetWidth) return;
      var row = t.offsetTop, change = ind.row !== null && Math.abs(ind.row - row) > 2;
      if (!ind.on || jump || change) list.classList.add("is-jump");
      list.style.setProperty("--ix", t.offsetLeft + "px");
      list.style.setProperty("--iy", row + "px");
      list.style.setProperty("--iw", t.offsetWidth + "px");
      list.style.setProperty("--ih", t.offsetHeight + "px");
      if (!ind.on) { list.classList.add("is-ind"); ind.on = true; }
      else if (change && list.animate && !(W.matchMedia && W.matchMedia("(prefers-reduced-motion: reduce)").matches)) {
        try { list.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 180, easing: "ease-out", pseudoElement: "::before" }); } catch (e) {}
      }
      ind.row = row;
      if (list.classList.contains("is-jump")) W.requestAnimationFrame(function () { W.requestAnimationFrame(function () { list.classList.remove("is-jump"); }); });
    }
'''


def p03():
    t = load(3); R = '#ag-prices-03'
    t = bump(t, 'F10: подложка выбранной вкладки переезжает (320 мс); на телефоне (сетка 2×2) между рядами — перенос\n'
                '     с проявлением 180 мс (отступление по Р2). F29: зерно бумаги (≥ 640 px). F23 — нажатие «Позвонить»,\n'
                '     фокус 3 px. Текст и сводка — как есть.')
    t = wrap(t, 'a', 'ag-pc__call', 'ag-pc__cin')
    t = focus3(t, R)
    t = rep(t, '    function select(i, focus) {\n', IND_JS + '    function select(i, focus) {\n')
    t = rep(t, '      sec.setAttribute("data-tab", String(i + 1));\n      if (focus) tabs[i].focus();\n',
            '      sec.setAttribute("data-tab", String(i + 1));\n      ind.cur = i;\n      place(i, false);\n      if (focus) tabs[i].focus();\n')
    t = rep(t, '    select(0, false);\n',
            '    select(0, false);\n'
            '    if ("ResizeObserver" in W) new W.ResizeObserver(function () { place(ind.cur, true); }).observe(list);\n'
            '    if (D.fonts && D.fonts.ready) D.fonts.ready.then(function () { place(ind.cur, true); });\n')
    css = press_css(R, [('ag-pc__call', 'ag-pc__cin')])
    css += '''  /* F10 · подложка вкладок */
  #ag-prices-03 .ag-pc__tabs{position:relative;isolation:isolate;}
  @media not (forced-colors:active){
    #ag-prices-03 .ag-pc__tabs.is-ind::before{
      content:"";position:absolute;z-index:-1;left:0;top:0;width:var(--iw,0px);height:var(--ih,0px);border-radius:var(--r-pill);background:var(--ink);
      transform:translate(var(--ix,0px),var(--iy,0px));
      transition:transform .32s cubic-bezier(.22,.61,.36,1),width .32s cubic-bezier(.22,.61,.36,1),height .32s cubic-bezier(.22,.61,.36,1);
    }
    #ag-prices-03 .ag-pc__tabs.is-jump::before{transition:none;}
    #ag-prices-03 .ag-pc__tabs.is-ind .ag-pc__tab[aria-selected="true"]{background:transparent;}
  }
'''
    css += grain_css(R, 'ag-pc', 'ag-pc__wrap')
    t = add_css(t, css)
    t = touch(t)
    save(3, t)


# ---------------------------------------------------------------- PRICES-04
def p04():
    t = load(4); R = '#ag-prices-04'
    t = bump(t, 'Сравнение, вкладки телефона и #ag-personal — как есть. F23 — нажатие кнопки, фокус 3 px.')
    t = wrap(t, 'a', 'ag-fm__btn', 'ag-fm__in')
    t = focus3(t, R)
    t = add_css(t, press_css(R, [('ag-fm__btn', 'ag-fm__in')]))
    t = touch(t)
    save(4, t)


# ---------------------------------------------------------------- PRICES-05
def p05():
    t = load(5); R = '#ag-prices-05'
    t = bump(t, 'Вопросы и ответы не менялись (FAQPage — тот же текст). F22: ответ раскрывается плавно — ::details-content +\n'
                '     interpolate-size (прогрессивно); «Раскрыть все» — без перехода; ScrollTrigger.refresh() и по toggle, и по\n'
                '     окончании перехода высоты. F29: зерно бумаги (≥ 640 px). F23 — нажатие «Раскрыть все», фокус 3 px.')
    t = wrap(t, 'button', 'ag-pq__all', 'ag-pq__ain')
    t = focus3(t, R)
    css = press_css(R, [('ag-pq__all', 'ag-pq__ain')])
    css += '''  /* F22 · плавное раскрытие ответа (Chromium 131+); иначе — мгновенно, как было */
  @supports (interpolate-size:allow-keywords) and selector(::details-content){
    #ag-prices-05 .ag-pq__list{interpolate-size:allow-keywords;}
    #ag-prices-05 .ag-pq__item::details-content{
      height:0;overflow:clip;
      transition:height .32s cubic-bezier(.22,.61,.36,1),content-visibility .32s allow-discrete;
    }
    #ag-prices-05 .ag-pq__item[open]::details-content{height:auto;}
    #ag-prices-05.is-bulk .ag-pq__item::details-content{transition:none;}
    @media (prefers-reduced-motion:reduce){
      #ag-prices-05 .ag-pq__item::details-content{transition:none;}
    }
  }
'''
    css += grain_css(R, 'ag-pq', 'ag-pq__wrap')
    t = add_css(t, css)
    t = rep(t, '''      busy = true;
      items.forEach(function (d) { d.open = open; });
      busy = false;
''', '''      busy = true;
      root.classList.add("is-bulk");
      items.forEach(function (d) { d.open = open; });
      busy = false;
      W.requestAnimationFrame(function () { W.requestAnimationFrame(function () { root.classList.remove("is-bulk"); }); });
''')
    t = rep(t, '''    items.forEach(function (d) {
      d.addEventListener("toggle", function () { if (!busy) { sync(); refresh(); } });
    });
''', '''    items.forEach(function (d) {
      d.addEventListener("toggle", function () { if (!busy) { sync(); refresh(); } });
    });
    /* v1.2.0: высота ответа меняется переходом — пересчитать позиции анимаций ниже по окончании */
    root.addEventListener("transitionend", function (e) {
      if (e.propertyName === "height" && e.pseudoElement === "::details-content") refresh();
    });
''')
    t = touch(t)
    save(5, t)


# ---------------------------------------------------------------- PRICES-06
def p06():
    t = load(6); R = '#ag-prices-06'
    t = bump(t, 'Магнит с кнопки записи снят (F23: CTA не убегает от курсора), нажатие F23, фокус 3 px.\n'
                '     Контурное «ЦЕНЫ» — как было: только parallax.')
    t = rep(t, ' data-ag-magnetic data-ag-track="request_start"', ' data-ag-track="request_start"')
    t = wrap(t, 'a', 'ag-dc__btn', 'ag-dc__in')
    t = focus3(t, R)
    t = add_css(t, press_css(R, [('ag-dc__btn', 'ag-dc__in')]))
    t = touch(t)
    save(6, t)


if __name__ == '__main__':
    for f in (p01, p02, p03, p04, p05, p06):
        f()
