# -*- coding: utf-8 -*-
"""/boxing (CL01) · проход «дизайн, движение и фишка» (PROMPT_CL01_DESIGN_MOTION_v2, 30.09.2026).
src/CL01-0N_v1.1.0.html → out/CL01-0N_v1.2.0.html. Каждая замена обязана найтись нужное число раз."""
import re, os

SRC, OUT = 'src', 'out'
os.makedirs(OUT, exist_ok=True)
DATE = '30.09.2026'
EASE_OUT = 'cubic-bezier(.34,1.56,.64,1)'

def rep(t, old, new, n=1):
    c = t.count(old)
    if c != n:
        raise SystemExit('replace %d != %d: %r' % (c, n, old[:120]))
    return t.replace(old, new)

def rx(t, pat, new, n=1):
    t2, c = re.subn(pat, new, t, flags=re.S)
    if c != n:
        raise SystemExit('regex %d != %d: %r' % (c, n, pat[:120]))
    return t2

def load(n):
    return open('%s/CL01-0%d_v1.1.0.html' % (SRC, n), encoding='utf-8').read()

def save(n, t):
    p = '%s/CL01-0%d_v1.2.0.html' % (OUT, n)
    open(p, 'w', encoding='utf-8').write(t)
    print('CL01-0%d v1.2.0 %6d байт' % (n, len(t.encode('utf-8'))))

def bump(t, note):
    t = rep(t, '· v1.1.0 · ', '· v1.2.0 · ') if t.count('· v1.1.0 · ') == 1 else rx(t, r'(APOLLO GYM · CL01-0\d[^\n]*?)v1\.1\.0', r'\1v1.2.0')
    i = t.index('-->') + 3
    return t[:i] + '\n<!-- v1.2.0 (проход «дизайн, движение и фишка», PROMPT_CL01_DESIGN_MOTION_v2, %s):\n     %s -->' % (DATE, note) + t[i:]

def focus3(t, root):
    t2, c = re.subn(r'(%s\.ag-scope :is\([^)]*\):focus-visible \{ outline: )2px' % re.escape(root), r'\g<1>3px', t)
    if c != 1:
        raise SystemExit('focus rule not found ' + root)
    return t2

def wrap_btn(t, cls, inner, n):
    pat = r'(<a class="%s(?: [^"]*)?"[^>]*>)(.*?)(</a>)' % re.escape(cls)
    return rx(t, pat, lambda m: m.group(1) + '<span class="%s">' % inner + m.group(2) + '</span>' + m.group(3), n)

def press_css(root, pairs):
    sel_in = ',\n  '.join('%s .%s' % (root, i) for b, i in pairs)
    sel_act = ',\n  '.join('%s .%s:active .%s' % (root, b, i) for b, i in pairs)
    red_in = ', '.join('%s .%s' % (root, i) for b, i in pairs)
    red_act = ', '.join('%s .%s:active .%s' % (root, b, i) for b, i in pairs)
    return ('''  /* F23 · нажатие: область кнопки неподвижна, сжимается подпись с иконкой */
  %s{display:inline-flex;align-items:center;justify-content:inherit;gap:inherit;flex:1 1 auto;min-width:0;
    transition:transform 260ms %s;}
  %s{transform:scale(.98);transition-duration:140ms;transition-timing-function:cubic-bezier(.22,.61,.36,1);}
  @media (prefers-reduced-motion:reduce){
    %s{transition:none;}
    %s{transform:none;}
  }
''' % (sel_in, EASE_OUT, sel_act, red_in, red_act))

def add_css(t, css):
    i = t.index('  </style>')
    return t[:i] + '\n  /* ===== v1.2.0 · дизайн, движение и фишка (30.09) ===== */\n' + css + t[i:]

def fit_title(t, R, cls, small=True):
    """Длинное слово «Галактионовской» не выходит за экран: на узком телефоне кегль ниже,
    перенос по слогу не включается, слово переносится только если не влезает целиком."""
    css = '  /* заголовок на узком экране: длинное слово не выходит за край (320 px, запасные шрифты) */\n'
    css += '  %s .%s{overflow-wrap:break-word;}\n' % (R, cls)
    if small:
        css += '  @media (max-width:420px){%s .%s{font-size:clamp(1.5rem,7.6vw,2.4rem);}}\n' % (R, cls)
    return add_css(t, css)

TOUCH = '    /* iOS включает :active только при слушателе касания (F23) */\n    root.addEventListener("touchstart", function () {}, { passive: true });\n'

def touch(t):
    """вставить пустой слушатель касания в скрипт страховки скана (у всех блоков он есть, кроме 07 и 09)"""
    return rep(t, '    var tries = 0;\n', TOUCH + '    var tries = 0;\n')

# ---------------------------------------------------------------- CL01-01
ROPES_JS = r'''
  <script>
  /* «Канаты ринга» (фишка страницы, П12): три каната между первым экраном и планкой фактов.
     Мышь, проходя через канат, оттягивает его; канат отпружинивает с затуханием.
     На сенсорном экране — касание дёргает ближайший канат (сдвиг пальца > 10 px — это прокрутка, не касание).
     Цикл requestAnimationFrame идёт только пока канат колеблется; вне экрана и в скрытой вкладке — стоп.
     reduce — канаты неподвижны, слушателей нет. Без JS — три прямые линии. */
  (function () {
    "use strict";
    var W = window, D = document;
    var root = D.getElementById("ag-cl01-01");
    if (!root || root.hasAttribute("data-ag-ui-ropes")) return;
    root.setAttribute("data-ag-ui-ropes", "");
    var band = root.querySelector("[data-ag-ui-ropes-band]");
    if (!band) return;
    var svg = band.querySelector("svg");
    var paths = Array.prototype.slice.call(band.querySelectorAll("path"));
    var mqR = W.matchMedia ? W.matchMedia("(prefers-reduced-motion: reduce)") : null;
    var H = 48, w = 1, raf = 0, last = 0, visible = true, on = false;
    var ptr = { in: false, cx: 0, cy: 0 };
    var ropes = paths.map(function (p) { return { p: p, b: parseFloat(p.getAttribute("data-y")) || 24, y: 0, v: 0, x: 0.5 }; });

    function draw(r) {
      var cx = Math.max(0.06, Math.min(0.94, r.x)) * w;
      r.p.setAttribute("d", "M0 " + r.b + "Q" + cx.toFixed(1) + " " + (r.b + 2 * r.y).toFixed(2) + " " + w + " " + r.b);
    }
    function size() {
      w = Math.max(1, Math.round(band.clientWidth));
      H = Math.max(1, Math.round(band.clientHeight)) || 48;
      svg.setAttribute("viewBox", "0 0 " + w + " " + H);
      ropes.forEach(draw);
    }
    function step(ts) {
      raf = 0;
      var dt = last ? Math.min(2, (ts - last) / 16.67) : 1;
      last = ts;
      var busy = false, px = 0, py = 0;
      if (ptr.in) {
        var r0 = band.getBoundingClientRect();
        px = ptr.cx - r0.left; py = ptr.cy - r0.top;
      }
      ropes.forEach(function (r) {
        var target = 0;
        if (ptr.in) {
          var d = py - r.b;
          if (Math.abs(d) < 15) { target = Math.max(-13, Math.min(13, d)); r.x = px / w; }
        }
        var a = 0.16 * (target - r.y) - 0.13 * r.v;
        r.v += a * dt; r.y += r.v * dt;
        if (target !== 0 || Math.abs(r.y) > 0.12 || Math.abs(r.v) > 0.12) busy = true;
        else { r.y = 0; r.v = 0; }
        draw(r);
      });
      if (busy && visible && !D.hidden) raf = W.requestAnimationFrame(step);
      else last = 0;
    }
    function kick() { if (!raf && visible && !D.hidden) { last = 0; raf = W.requestAnimationFrame(step); } }
    function stop() { if (raf) { W.cancelAnimationFrame(raf); raf = 0; } last = 0; }
    function flat() { stop(); ropes.forEach(function (r) { r.y = 0; r.v = 0; draw(r); }); }

    var down = null;
    function onMove(e) {
      if (e.pointerType !== "mouse") return;
      ptr.in = true; ptr.cx = e.clientX; ptr.cy = e.clientY; kick();
    }
    function onLeave(e) { if (e.pointerType === "mouse") { ptr.in = false; kick(); } }
    function onDown(e) { if (e.pointerType !== "mouse") down = { x: e.clientX, y: e.clientY }; }
    function onUp(e) {
      if (e.pointerType === "mouse" || !down) return;
      var moved = Math.abs(e.clientX - down.x) + Math.abs(e.clientY - down.y);
      down = null;
      if (moved > 10) return;
      var r0 = band.getBoundingClientRect(), px = e.clientX - r0.left, py = e.clientY - r0.top;
      var best = ropes[0];
      ropes.forEach(function (r) { if (Math.abs(r.b - py) < Math.abs(best.b - py)) best = r; });
      best.x = px / w; best.v += (py <= best.b ? 1 : -1) * 6.5;
      kick();
    }
    function onCancel() { down = null; }

    function enable() {
      if (on) return; on = true;
      band.addEventListener("pointermove", onMove, { passive: true });
      band.addEventListener("pointerleave", onLeave, { passive: true });
      band.addEventListener("pointerdown", onDown, { passive: true });
      band.addEventListener("pointerup", onUp, { passive: true });
      band.addEventListener("pointercancel", onCancel, { passive: true });
    }
    function disable() {
      if (!on) return; on = false;
      band.removeEventListener("pointermove", onMove);
      band.removeEventListener("pointerleave", onLeave);
      band.removeEventListener("pointerdown", onDown);
      band.removeEventListener("pointerup", onUp);
      band.removeEventListener("pointercancel", onCancel);
      ptr.in = false; flat();
    }
    function apply() { if (mqR && mqR.matches) disable(); else enable(); }

    size();
    if (W.ResizeObserver) new ResizeObserver(function () { size(); }).observe(band);
    else W.addEventListener("resize", size);
    if ("IntersectionObserver" in W) {
      new IntersectionObserver(function (en) {
        visible = en.some(function (x) { return x.isIntersecting; });
        if (!visible) flat();
      }).observe(band);
    }
    D.addEventListener("visibilitychange", function () { if (D.hidden) flat(); });
    apply();
    if (mqR) { if (mqR.addEventListener) mqR.addEventListener("change", apply); else if (mqR.addListener) mqR.addListener(apply); }
  })();
  </script>
'''

def cl01():
    t = load(1); R = '#ag-cl01-01'
    t = bump(t, 'Фишка страницы «Канаты ринга»: три каната поперёк страницы между первым экраном и планкой\n'
                '     фактов (граница ринга перед зрителем). Мышь оттягивает канат, он отпружинивает с затуханием;\n'
                '     на телефоне канат дёргается касанием. Движение только от действия читателя, rAF только пока\n'
                '     канат колеблется; reduce и без JS — неподвижные линии (aria-hidden). Магнитная реакция главной\n'
                '     кнопки снята (F23: область нажатия неподвижна), нажатие сжимает подпись. Фокус 3 px.\n'
                '     «81 загорается» и тексты — без изменений.')
    t = rep(t, ' data-ag-magnetic="0.18"', '')
    t = wrap_btn(t, 'ag-btn ag-btn--primary', 'ag-btn__in', 1)
    t = wrap_btn(t, 'ag-btn ag-btn--ghost', 'ag-btn__in', 1)
    ropes = ('<!-- Канаты ринга: декор, реагирует на указатель и касание (скрипт ниже). Без JS — прямые линии. -->'
             ' <div class="ag-bh__ropes" data-ag-ui-ropes-band aria-hidden="true">'
             '<svg class="ag-bh__rsvg" viewBox="0 0 1200 48" preserveAspectRatio="none" focusable="false">'
             '<path class="ag-bh__rope ag-bh__rope--hot" data-y="10" d="M0 10Q600 10 1200 10"/>'
             '<path class="ag-bh__rope" data-y="24" d="M0 24Q600 24 1200 24"/>'
             '<path class="ag-bh__rope" data-y="38" d="M0 38Q600 38 1200 38"/></svg></div> ')
    t = rep(t, '<!-- Планка P14: только подтверждённые факты', ropes + '<!-- Планка P14: только подтверждённые факты')
    t = focus3(t, R)
    css = press_css(R, [('ag-btn', 'ag-btn__in')])
    css += '''  /* «Канаты ринга»: полоса на всю ширину экрана между первым экраном и планкой фактов */
  #ag-cl01-01 .ag-bh__ropes{position:relative;z-index:1;height:48px;width:100vw;margin:clamp(14px,2vw,26px) calc(50% - 50vw) 0;touch-action:pan-y;}
  #ag-cl01-01 .ag-bh__rsvg{display:block;width:100%;height:100%;overflow:visible;}
  #ag-cl01-01 .ag-bh__rope{fill:none;stroke:rgba(244,244,245,.34);stroke-width:2;stroke-linecap:round;vector-effect:non-scaling-stroke;}
  #ag-cl01-01 .ag-bh__rope--hot{stroke:rgba(255,196,0,.85);stroke-width:2.5;}
  #ag-cl01-01 .ag-bh__ropes + .ag-bh__facts{margin-top:clamp(8px,1.2vw,16px);}
  @media (forced-colors:active){#ag-cl01-01 .ag-bh__rope,#ag-cl01-01 .ag-bh__rope--hot{stroke:CanvasText;}}
  @media print{#ag-cl01-01 .ag-bh__ropes{display:none;}}
  @media (max-width:599px){
    #ag-cl01-01 .ag-bh__ropes{height:44px;margin-top:10px;}
    #ag-cl01-01 .ag-bh__ropes + .ag-bh__facts{margin-top:6px;}
    #ag-cl01-01 .ag-bh__facts > li{padding:12px 14px 13px;}
    #ag-cl01-01 .ag-bh__facts b{font-size:28px;}
    #ag-cl01-01 .ag-bh__facts li > span{margin-top:6px;font-size:13px;line-height:1.35;}
  }
'''
    t = add_css(t, css)
    t = touch(t)
    i = t.index('<!-- Движок движения')
    t = t[:i] + ROPES_JS.lstrip('\n') + '\n  ' + t[i:]
    save(1, t)

# ---------------------------------------------------------------- CL01-02
BAG_JS = r'''
  <script>
  /* «Мешок качается»: кадр «Мешки вдоль стены» висит за верхнюю кромку и раскачивается
     от движения мыши (скорость указателя) или от нажатия на кадр на сенсорном экране.
     Качается figure, у img — параллакс движка (разные узлы). До ±2,4°, затухание; rAF только
     во время взмаха. reduce — без движения и без слушателей. */
  (function () {
    "use strict";
    var W = window, D = document;
    var root = D.getElementById("ag-cl01-02");
    if (!root || root.hasAttribute("data-ag-ui-bag")) return;
    root.setAttribute("data-ag-ui-bag", "");
    var fig = root.querySelector("[data-ag-ui-bag-fig]");
    if (!fig) return;
    var mqR = W.matchMedia ? W.matchMedia("(prefers-reduced-motion: reduce)") : null;
    var a = 0, v = 0, raf = 0, last = 0, lastX = null, on = false, down = null;
    function paint() { fig.style.transform = a ? "rotate(" + a.toFixed(3) + "deg)" : ""; }
    function step(ts) {
      raf = 0;
      var dt = last ? Math.min(2, (ts - last) / 16.67) : 1; last = ts;
      v += (-0.05 * a - 0.07 * v) * dt; a += v * dt;
      if (a > 2.4) { a = 2.4; v = -Math.abs(v) * 0.5; } else if (a < -2.4) { a = -2.4; v = Math.abs(v) * 0.5; }
      if (Math.abs(a) < 0.02 && Math.abs(v) < 0.02) { a = 0; v = 0; paint(); fig.classList.remove("is-swing"); last = 0; return; }
      paint();
      if (!D.hidden) raf = W.requestAnimationFrame(step); else { a = 0; v = 0; paint(); fig.classList.remove("is-swing"); }
    }
    function push(dv) {
      v = Math.max(-0.6, Math.min(0.6, v + dv));
      fig.classList.add("is-swing");
      if (!raf) { last = 0; raf = W.requestAnimationFrame(step); }
    }
    function onMove(e) {
      if (e.pointerType !== "mouse") return;
      if (lastX !== null) push((e.clientX - lastX) * 0.006);
      lastX = e.clientX;
    }
    function onLeave() { lastX = null; }
    function onDown(e) { if (e.pointerType !== "mouse") down = { x: e.clientX, y: e.clientY }; }
    function onUp(e) {
      if (e.pointerType === "mouse" || !down) return;
      var moved = Math.abs(e.clientX - down.x) + Math.abs(e.clientY - down.y); down = null;
      if (moved > 10) return;
      var r = fig.getBoundingClientRect();
      push((e.clientX < r.left + r.width / 2 ? 1 : -1) * 0.45);
    }
    function enable() {
      if (on) return; on = true;
      fig.addEventListener("pointermove", onMove, { passive: true });
      fig.addEventListener("pointerleave", onLeave, { passive: true });
      fig.addEventListener("pointerdown", onDown, { passive: true });
      fig.addEventListener("pointerup", onUp, { passive: true });
    }
    function disable() {
      if (!on) return; on = false;
      fig.removeEventListener("pointermove", onMove); fig.removeEventListener("pointerleave", onLeave);
      fig.removeEventListener("pointerdown", onDown); fig.removeEventListener("pointerup", onUp);
      if (raf) W.cancelAnimationFrame(raf); raf = 0; a = 0; v = 0; paint(); fig.classList.remove("is-swing");
    }
    function apply() { if (mqR && mqR.matches) disable(); else enable(); }
    apply();
    if (mqR) { if (mqR.addEventListener) mqR.addEventListener("change", apply); else if (mqR.addListener) mqR.addListener(apply); }
  })();
  </script>
'''

def cl02():
    t = load(2); R = '#ag-cl01-02'
    t = bump(t, '«Мешок качается»: кадр «Мешки вдоль стены» висит за верхнюю кромку и раскачивается от\n'
                '     движения мыши или нажатия на кадр (телефон). Только действие читателя, reduce — неподвижно.\n'
                '     Зоны F04 «Ринг / Мешки» отложены до досъёмки слота CL01-02-ring: кадр ринга Zal_4 уже стоит\n'
                '     в первом экране, повторять его нельзя. Фокус 3 px. Телефон: кадр 4:3 → 3:2.')
    t = rep(t, '<figure class="ag-hl__media" data-ag-slot="CL01-02-ring"', '<figure class="ag-hl__media" data-ag-ui-bag-fig data-ag-slot="CL01-02-ring"')
    t = focus3(t, R)
    css = '''  /* «Мешок качается»: точка подвеса — верхняя кромка кадра */
  #ag-cl01-02 .ag-hl__media{transform-origin:50% 0;}
  #ag-cl01-02 .ag-hl__media.is-swing{will-change:transform;}
  @media (hover:hover) and (pointer:fine){#ag-cl01-02 .ag-hl__media{cursor:grab;}}
  @media (prefers-reduced-motion:reduce){#ag-cl01-02 .ag-hl__media{transform:none !important;cursor:auto;}}
  @media (max-width:599px){
    #ag-cl01-02 .ag-hl__media{aspect-ratio:3/2;}
  }
'''
    t = add_css(t, css)
    t = touch(t)
    i = t.index('<!-- Движок движения')
    t = t[:i] + BAG_JS.lstrip('\n') + '\n  ' + t[i:]
    save(2, t)

# ---------------------------------------------------------------- CL01-03
def cl03():
    t = load(3); R = '#ag-cl01-03'
    t = bump(t, 'Вкладки и «табло» — как есть. F23 — нажатие двух кнопок, фокус 3 px.\n'
                '     Телефон: H2 на 320 px не выходит за край (кегль ниже на ≤ 420 px, текст тот же).')
    t = wrap_btn(t, 'ag-btn ag-btn--primary', 'ag-btn__in', 1)
    t = wrap_btn(t, 'ag-btn ag-btn--ghost', 'ag-btn__in', 1)
    t = focus3(t, R)
    t = add_css(t, press_css(R, [('ag-btn', 'ag-btn__in')]))
    t = fit_title(t, R, 'ag-dr__title')
    t = touch(t)
    save(3, t)

# ---------------------------------------------------------------- CL01-04
def cl04():
    t = load(4); R = '#ag-cl01-04'
    t = bump(t, 'F23 — нажатие двух кнопок, фокус 3 px. Фильтр тренеров по направлению не ставится: он строил бы\n'
                '     утверждения на черновиках № 16, 20, 21. Телефон: строки тренеров плотнее, H2 не выходит\n'
                '     за край на 320 px.')
    t = wrap_btn(t, 'ag-btn ag-btn--primary', 'ag-btn__in', 1)
    t = wrap_btn(t, 'ag-btn ag-btn--ghost', 'ag-btn__in', 1)
    t = focus3(t, R)
    css = press_css(R, [('ag-btn', 'ag-btn__in')])
    css += '''  @media (max-width:599px){
    #ag-cl01-04 .ag-tr__card{padding:8px 0;}
    #ag-cl01-04 .ag-tr__list{margin-top:18px;}
  }
'''
    t = add_css(t, css)
    t = fit_title(t, R, 'ag-tr__title')
    t = touch(t)
    save(4, t)

# ---------------------------------------------------------------- CL01-05
DLG_JS = r'''
  <script>
  /* F07 · кадр целиком. Ссылка на файл работает и без JS; с JS кадр открывается в <dialog>
     (showModal: фон недоступен, Escape закрывает), ← → листают, фокус возвращается на ссылку.
     Подпись — номер кадра и место (кадры не сверены, I056). */
  (function () {
    "use strict";
    var W = window, D = document;
    var root = D.getElementById("ag-cl01-05");
    if (!root || root.hasAttribute("data-ag-ui-dlg")) return;
    root.setAttribute("data-ag-ui-dlg", "");
    var dlg = root.querySelector("dialog");
    if (!dlg || typeof dlg.showModal !== "function") return;
    var links = Array.prototype.slice.call(root.querySelectorAll("[data-ag-ui-open]"));
    var img = dlg.querySelector("[data-ag-ui-img]");
    var cap = dlg.querySelector("[data-ag-ui-cap]");
    var html = D.documentElement, back = null, cur = 0, keep = "";
    function show(i) {
      cur = (i + links.length) % links.length;
      var a = links[cur];
      img.setAttribute("src", a.getAttribute("href"));
      var txt = "Кадр " + (cur + 1) + " из " + links.length + " · " + (a.getAttribute("data-ag-ui-place") || "");
      if (cap.firstChild) cap.firstChild.nodeValue = txt; else cap.appendChild(D.createTextNode(txt));
    }
    links.forEach(function (a, i) {
      a.addEventListener("click", function (e) {
        if (e.metaKey || e.ctrlKey || e.shiftKey || e.button > 0) return;
        e.preventDefault();
        back = a; show(i);
        keep = html.style.overflow; html.style.overflow = "hidden";
        dlg.showModal();
      });
    });
    dlg.querySelector("[data-ag-ui-prev]").addEventListener("click", function () { show(cur - 1); });
    dlg.querySelector("[data-ag-ui-next]").addEventListener("click", function () { show(cur + 1); });
    dlg.querySelector("[data-ag-ui-close]").addEventListener("click", function () { dlg.close(); });
    dlg.addEventListener("click", function (e) { if (e.target === dlg) dlg.close(); });
    dlg.addEventListener("keydown", function (e) {
      if (e.key === "ArrowRight") { e.preventDefault(); show(cur + 1); }
      else if (e.key === "ArrowLeft") { e.preventDefault(); show(cur - 1); }
    });
    dlg.addEventListener("close", function () {
      html.style.overflow = keep;
      if (back) { try { back.focus({ preventScroll: true }); } catch (e) { back.focus(); } }
    });
  })();
  </script>
'''

def cl05():
    t = load(5); R = '#ag-cl01-05'
    t = bump(t, 'F07 «кадр целиком»: каждый кадр — ссылка на файл «Открыть кадр N из 3»; с JS кадр открывается\n'
                '     в <dialog> (стрелки, Escape, возврат фокуса, фон недоступен), без JS — файл. Подпись в окне —\n'
                '     номер кадра и место: кадры не сверены (I056), alt пустой. Фокус 3 px.\n'
                '     Телефон: H2 на 320 px не выходит за край (кегль ниже на ≤ 420 px, текст тот же).')
    imgs = re.findall(r'<img class="ag-gl__img" src="([^"]+)"', t)
    caps = re.findall(r'<figcaption class="ag-gl__cap"><span class="ag-gl__dot" aria-hidden="true"></span>([^<]+)</figcaption>', t)
    assert len(imgs) == 3 and len(caps) == 3, (imgs, caps)
    for i, (src, cap) in enumerate(zip(imgs, caps)):
        old = '<figcaption class="ag-gl__cap"><span class="ag-gl__dot" aria-hidden="true"></span>%s</figcaption>' % cap
        new = ('<a class="ag-gl__open" href="%s" data-ag-ui-open data-ag-ui-place="%s" data-ag-track="gallery_open" data-ag-params=\'{"from":"CL01-05","n":%d}\'>'
               '<span class="ag-vh">Открыть кадр %d из 3</span><svg class="ag-gl__zoom" width="20" height="20" viewBox="0 0 20 20" aria-hidden="true" focusable="false">'
               '<path d="M8.5 3.5a5 5 0 1 0 0 10 5 5 0 0 0 0-10ZM12.2 12.2 16.5 16.5M8.5 6.5v4M6.5 8.5h4" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg></a> ') % (src, cap, i + 1, i + 1)
        t = rep(t, old, new + old)
    dialog = ('<dialog class="ag-gl__dlg" aria-labelledby="ag-cl01-05-dlg-t">'
              '<div class="ag-gl__dbox">'
              '<p class="ag-gl__dt" id="ag-cl01-05-dlg-t" data-ag-ui-cap aria-live="polite">Кадр 1 из 3 · %s</p>'
              '<img class="ag-gl__dimg" data-ag-ui-img src="%s" alt="" width="1024" height="683" loading="lazy" decoding="async">'
              '<div class="ag-gl__dnav">'
              '<button class="ag-gl__dbtn" type="button" data-ag-ui-prev><svg width="20" height="20" aria-hidden="true" focusable="false"><use href="#ag-cl01-05-i-l"/></svg><span class="ag-vh">Предыдущий кадр</span></button>'
              '<button class="ag-gl__dbtn" type="button" data-ag-ui-next><svg width="20" height="20" aria-hidden="true" focusable="false"><use href="#ag-cl01-05-i-r"/></svg><span class="ag-vh">Следующий кадр</span></button>'
              '</div>'
              '<button class="ag-gl__dx" type="button" data-ag-ui-close><svg width="20" height="20" viewBox="0 0 20 20" aria-hidden="true" focusable="false"><path d="M5 5l10 10M15 5 5 15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg><span class="ag-vh">Закрыть</span></button>'
              '</div></dialog> ') % (caps[0], imgs[0])
    t = rep(t, '</div> </section>', dialog + '</div> </section>')
    t = focus3(t, R)
    css = '''  /* F07 · ссылка «открыть кадр»: весь кадр, значок лупы в углу */
  #ag-cl01-05 .ag-gl__open{position:absolute;inset:0;z-index:3;display:block;border-radius:inherit;}
  #ag-cl01-05 .ag-gl__zoom{position:absolute;right:12px;top:12px;width:40px;height:40px;padding:10px;border-radius:50%;
    background:rgba(9,9,10,.62);border:1px solid rgba(255,255,255,.22);color:var(--text);
    -webkit-backdrop-filter:blur(6px);backdrop-filter:blur(6px);transition:background-color 200ms ease,color 200ms ease;}
  #ag-cl01-05.ag-scope .ag-gl__open:focus-visible{outline:3px solid var(--accent);outline-offset:-3px;}
  @media (hover:hover){#ag-cl01-05 .ag-gl__open:hover .ag-gl__zoom{background:var(--accent);color:#09090A;}}
  /* окно просмотра */
  #ag-cl01-05 .ag-gl__dlg{width:100vw;height:100vh;max-width:none;max-height:none;margin:0;padding:0;border:0;background:transparent;color:var(--text);overscroll-behavior:contain;}
  #ag-cl01-05 .ag-gl__dlg::backdrop{background:rgba(6,6,7,.92);}
  #ag-cl01-05 .ag-gl__dbox{position:relative;display:grid;grid-template-rows:auto minmax(0,1fr) auto;gap:14px;width:100%;height:100%;padding:18px clamp(16px,4vw,48px) 22px;}
  #ag-cl01-05 .ag-gl__dt{margin:0;padding-right:56px;font-family:var(--f-display,"Oswald",sans-serif);font-size:15px;font-weight:600;letter-spacing:.08em;text-transform:uppercase;color:var(--text);min-height:44px;display:flex;align-items:center;}
  #ag-cl01-05 .ag-gl__dimg{display:block;width:100%;height:100%;max-height:calc(100dvh - 150px);object-fit:contain;}
  #ag-cl01-05 .ag-gl__dnav{display:flex;justify-content:center;gap:14px;}
  #ag-cl01-05 .ag-gl__dbtn,#ag-cl01-05 .ag-gl__dx{display:inline-flex;align-items:center;justify-content:center;width:48px;height:48px;padding:0;border-radius:50%;
    border:1px solid rgba(255,255,255,.28);background:rgba(20,20,22,.9);color:var(--text);cursor:pointer;font:inherit;}
  #ag-cl01-05 .ag-gl__dx{position:absolute;top:16px;right:clamp(16px,4vw,48px);}
  #ag-cl01-05.ag-scope .ag-gl__dlg :is(button):focus-visible{outline:3px solid var(--accent);outline-offset:3px;}
  @media (hover:hover){#ag-cl01-05 .ag-gl__dbtn:hover,#ag-cl01-05 .ag-gl__dx:hover{border-color:var(--accent);color:var(--accent);}}
  @media (forced-colors:active){#ag-cl01-05 .ag-gl__zoom,#ag-cl01-05 .ag-gl__dbtn,#ag-cl01-05 .ag-gl__dx{border:1px solid CanvasText;}}
  @media print{#ag-cl01-05 .ag-gl__zoom{display:none;}}
'''
    t = add_css(t, css)
    t = fit_title(t, R, 'ag-gl__title')
    t = touch(t)
    i = t.index('<!-- Движок движения')
    t = t[:i] + DLG_JS.lstrip('\n') + '\n  ' + t[i:]
    save(5, t)

# ---------------------------------------------------------------- CL01-06
def cl06():
    t = load(6); R = '#ag-cl01-06'
    t = bump(t, 'Таблица, жёлтая карточка и цены — как есть. F23 — нажатие тёмной кнопки, фокус чернилами 3 px.\n'
                '     Телефон: H2 на 320 px не выходит за край (кегль ниже на ≤ 420 px, текст тот же).')
    t = wrap_btn(t, 'ag-cp__btn', 'ag-cp__btnin', 1)
    t = focus3(t, R)
    t = add_css(t, press_css(R, [('ag-cp__btn', 'ag-cp__btnin')]))
    t = fit_title(t, R, 'ag-cp__title')
    t = touch(t)
    save(6, t)

# ---------------------------------------------------------------- CL01-07
ROUTE_JS = r'''  <script>
  /* Адрес: «Скопировать адрес» — везде, где браузер даёт буфер обмена; «Поделиться адресом» —
     только на сенсорном экране с Web Share. Подтверждение копирования — в aria-live.
     Уходит видимая строка адреса, без адреса сайта. */
  (function () {
    "use strict";
    var W = window, D = document;
    var root = D.getElementById("ag-cl01-07");
    if (!root || root.hasAttribute("data-ag-share-on")) return;
    root.setAttribute("data-ag-share-on", "");
    var share = root.querySelector("[data-ag-share]");
    var copy = root.querySelector("[data-ag-ui-copy]");
    var note = root.querySelector("[data-ag-ui-copied]");
    var street = root.querySelector(".ag-rt__street");
    var text = street ? street.textContent.replace(/\s+/g, " ").trim() : "Самара, улица Галактионовская, 81";
    var coarse = W.matchMedia && W.matchMedia("(pointer: coarse)").matches;
    if (share && navigator.share && coarse) {
      share.hidden = false;
      share.addEventListener("click", function () {
        try {
          var p = navigator.share({ title: "Apollo Boxing Gym", text: "Apollo Boxing Gym, " + text + ", +7 917 107-51-79" });
          if (p && p.catch) p.catch(function () {});
        } catch (e) {}
      });
    }
    function said(msg) {
      if (!note) return;
      if (note.firstChild) note.firstChild.nodeValue = msg; else note.appendChild(D.createTextNode(msg));
      W.clearTimeout(said.t);
      said.t = W.setTimeout(function () { if (note.firstChild) note.firstChild.nodeValue = ""; }, 3000);
    }
    function fallback() {
      var ta = D.createElement("textarea");
      ta.value = text; ta.setAttribute("readonly", ""); ta.style.position = "fixed"; ta.style.opacity = "0";
      D.body.appendChild(ta); ta.select();
      var ok = false;
      try { ok = D.execCommand("copy"); } catch (e) {}
      D.body.removeChild(ta);
      return ok;
    }
    var canCopy = !!(navigator.clipboard && navigator.clipboard.writeText) || (D.queryCommandSupported && D.queryCommandSupported("copy"));
    if (copy && canCopy) {
      copy.hidden = false;
      copy.addEventListener("click", function () {
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(text).then(function () { said("Адрес скопирован"); }, function () {
            if (fallback()) said("Адрес скопирован"); else copy.hidden = true;
          });
        } else if (fallback()) said("Адрес скопирован"); else copy.hidden = true;
      });
    }
  })();

  /* Карта: src ставится iframe из разметки, когда блок подходит к экрану (I176, ст. 135) —
     Яндекс не грузится вместе со страницей; узлы не вставляются. Без JS — iframe в noscript. */
  (function () {
    "use strict";
    var W = window, D = document;
    var root = D.getElementById("ag-cl01-07");
    if (!root || root.hasAttribute("data-ag-map-on")) return;
    root.setAttribute("data-ag-map-on", "");
    var box = root.querySelector("[data-ag-map]");
    var frame = box && box.querySelector("[data-ag-ui-frame]");
    if (!box || !frame) return;
    function put() {
      if (frame.getAttribute("src")) return;
      frame.addEventListener("load", function () { frame.hidden = false; }, { once: true });
      frame.setAttribute("src", box.getAttribute("data-ag-map"));
    }
    if ("IntersectionObserver" in W) {
      var io = new IntersectionObserver(function (en) {
        if (en.some(function (e) { return e.isIntersecting; })) { io.disconnect(); put(); }
      }, { rootMargin: "400px 0px" });
      io.observe(box);
    } else put();
  })();
  </script>
'''

def cl07():
    t = load(7); R = '#ag-cl01-07'
    t = bump(t, '«Скопировать адрес» (ПК и телефон, где есть буфер обмена) с подтверждением «Адрес скопирован»\n'
                '     в aria-live; «Поделиться адресом» — только на сенсорном экране. Карта: iframe в разметке\n'
                '     (hidden, без src), src по приближению блока, узлы не вставляются; noscript — как было.\n'
                '     F23 — нажатие кнопок, фокус 3 px. Телефон: карта 260 → 200 px, H2 не выходит за край на 320 px.')
    for c in ('ag-btn ag-btn--primary', 'ag-btn ag-btn--ghost'):
        t = wrap_btn(t, c, 'ag-btn__in', 1 if c.endswith('primary') else 2)
    t = rx(t, r'(<button class="ag-btn ag-btn--quiet" type="button" data-ag-share hidden>)(.*?)(</button>)',
           lambda m: m.group(1) + '<span class="ag-btn__in">' + m.group(2) + '</span>' + m.group(3))
    copybtn = ('<button class="ag-btn ag-btn--quiet" type="button" data-ag-ui-copy hidden><span class="ag-btn__in">'
               '<svg class="ag-btn__i" width="16" height="16" viewBox="0 0 16 16" aria-hidden="true" focusable="false">'
               '<rect x="5.5" y="5.5" width="8" height="8.5" rx="1.6" fill="none" stroke="currentColor" stroke-width="1.6"/>'
               '<path d="M10.5 3.5V3a1.5 1.5 0 0 0-1.5-1.5H4A1.5 1.5 0 0 0 2.5 3v6A1.5 1.5 0 0 0 4 10.5h.5" fill="none" stroke="currentColor" stroke-width="1.6"/></svg>'
               'Скопировать адрес</span></button> <span class="ag-rt__copied" data-ag-ui-copied aria-live="polite"></span>')
    t = rep(t, '</button> </div> <p class="ag-rt__hours">', '</button> ' + copybtn + ' </div> <p class="ag-rt__hours">')
    t = rep(t, '<span class="ag-rt__under-t">Галактионовская, 81</span> </div> <noscript>',
            '<span class="ag-rt__under-t">Галактионовская, 81</span> </div> '
            '<iframe class="ag-rt__frame" data-ag-ui-frame title="Apollo Boxing Gym на карте: Самара, улица Галактионовская, 81" loading="lazy" referrerpolicy="strict-origin-when-cross-origin" hidden></iframe> <noscript>')
    # старые скрипты (поделиться + вставка узла карты) заменяются одним
    t = rx(t, r'  <script>\n  /\* «Поделиться адресом»: кнопка видна.*?</script>\n', '')
    t = rx(t, r'  <script>\n  /\* Карта: iframe ставится скриптом.*?</script>\n', lambda m: ROUTE_JS)
    t = focus3(t, R)
    css = press_css(R, [('ag-btn', 'ag-btn__in')])
    css += '''  #ag-cl01-07 .ag-rt__frame[hidden]{display:none;}
  #ag-cl01-07 .ag-rt__copied{flex-basis:100%;min-height:0;font-size:14px;font-weight:600;color:var(--accent);}
  #ag-cl01-07 .ag-rt__copied:empty{display:none;}
  @media (max-width:599px){
    #ag-cl01-07 .ag-rt__map{min-height:200px;}
  }
'''
    t = add_css(t, css)
    t = fit_title(t, R, 'ag-rt__title')
    t = rep(t, 'без JS — <noscript> с тем же iframe', 'без JS — noscript с тем же iframe')
    t = rep(t, '    var root = D.getElementById("ag-cl01-07");\n    if (!root || root.hasAttribute("data-ag-share-on")) return;\n    root.setAttribute("data-ag-share-on", "");\n',
            '    var root = D.getElementById("ag-cl01-07");\n    if (!root || root.hasAttribute("data-ag-share-on")) return;\n    root.setAttribute("data-ag-share-on", "");\n' + TOUCH)
    save(7, t)

# ---------------------------------------------------------------- CL01-08
def cl08():
    t = load(8); R = '#ag-cl01-08'
    t = bump(t, 'Вопросы и ответы не менялись (FAQPage в HEAD). Фокус 3 px.\n'
                '     Телефон: H2 на 320 px не выходит за край (кегль ниже на ≤ 420 px, текст тот же).')
    t = focus3(t, R)
    t = fit_title(t, R, 'ag-fq__title')
    t = touch(t)
    save(8, t)

# ---------------------------------------------------------------- CL01-09
def cl09():
    t = load(9); R = '#ag-cl01-09'
    t = bump(t, 'Ссылки и тексты — как есть. Фокус 3 px.')
    t = focus3(t, R)
    save(9, t)

if __name__ == '__main__':
    for f in (cl01, cl02, cl03, cl04, cl05, cl06, cl07, cl08, cl09):
        f()
