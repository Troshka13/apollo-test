const {open,settle}=require('./lib');const fs=require('fs'),path=require('path');
const AFTER='file://'+path.resolve('after.html'), BEFORE='file://'+path.resolve('before.html');
const out={};const log=(g,ok,msg)=>{(out[g]=out[g]||[]).push((ok?'pass ':'FAIL ')+msg);};
const G=process.env.G||'LTCMFA';
async function txt(url){const {browser,page}=await open({reduce:true});await page.goto(url);await page.waitForTimeout(2600);
  const r=await page.evaluate(()=>{const o={};document.querySelectorAll('.ag-scope').forEach(r=>{const c=r.cloneNode(true);c.querySelectorAll('style,script,dialog,.ag-vh').forEach(x=>x.remove());o[r.id]=c.textContent.replace(/\s+/g,' ').trim();});return o;});await browser.close();return r;}
async function links(url){const {browser,page}=await open({reduce:true});await page.goto(url);await page.waitForTimeout(400);
  const r=await page.evaluate(()=>[...document.querySelectorAll('.ag-scope a[href]')].map(a=>a.closest('.ag-scope').id+' '+a.getAttribute('href')));await browser.close();return r;}
const RAF=`window.__raf=0;const __r=window.requestAnimationFrame.bind(window);window.__rafStep=0;window.requestAnimationFrame=function(f){window.__raf++;if(f&&f.name==='step')window.__rafStep++;return __r(f);};`;
(async()=>{
 if(G.includes('L')) for(const reduce of [false,true]) for(const fontsOff of [false,true]) for(const w of [320,360,390,768,1024,1440,1920]){
   const {browser,page}=await open({w,h:w<700?800:900,reduce,mobile:w<700,touch:w<700});
   if(fontsOff) await page.route('**/fonts.googleapis.com/**',r=>r.abort());
   await page.goto(AFTER);await settle(page);
   const r=await page.evaluate(()=>({ov:document.documentElement.scrollWidth>document.documentElement.clientWidth,h:document.body.scrollHeight}));
   log('L',!r.ov,`${w}px reduce=${reduce} fontsOff=${fontsOff} overflowX=${r.ov} h=${r.h}`);await browser.close();
 }
 if(G.includes('T')){const tb=await txt(BEFORE),ta=await txt(AFTER);
  for(const id of Object.keys(tb)){let a=ta[id];if(id==='ag-cl01-07')a=a.replace(' Скопировать адрес','');
   let i=0;while(i<tb[id].length&&tb[id][i]===a[i])i++;
   log('T',a===tb[id],id+(a===tb[id]?' текст совпадает':' РАЗНИЦА '+JSON.stringify(tb[id].slice(i-30,i+40))+' → '+JSON.stringify(a.slice(i-30,i+40))));}}
 if(G.includes('C')){const lb=await links(BEFORE),la=await links(AFTER);const add=la.filter(x=>!lb.includes(x)),rem=lb.filter(x=>!la.includes(x));
  log('C',rem.length===0&&add.length===3&&add.every(x=>/^ag-cl01-05 https:\/\/static\.tildacdn/.test(x)),`ссылки +${add.length} −${rem.length}: ${add.map(x=>x.split('/').pop()).join(', ')}`);}
 if(G.includes('M')){
  for(const mode of [{name:'js off',js:false},{name:'reduce',reduce:true},{name:'cdn fail',cdn:'fail'},{name:'cdn hang',cdn:'hang'}]){
   const {browser,page}=await open({w:390,h:800,mobile:true,...mode});await page.goto(AFTER,{waitUntil:'domcontentloaded'});await page.waitForTimeout(2700);
   if(mode.js!==false) for(let y=0;y<9000;y+=600){await page.evaluate(y=>scrollTo(0,y),y);await page.waitForTimeout(40);}
   const r=await page.evaluate(()=>{const bad=[];document.querySelectorAll('.ag-scope :is(p,h1,h2,h3,a,li,dt,dd,summary,td,th)').forEach(el=>{if(el.closest('[aria-hidden="true"],dialog,[hidden]'))return;let n=el,op=1;while(n&&n.nodeType===1){op*=parseFloat(getComputedStyle(n).opacity);n=n.parentElement;}if(getComputedStyle(el).display==='none')return;if(op<0.99&&el.textContent.trim())bad.push(el.textContent.trim().slice(0,30));});
     const ifr=document.querySelector('#ag-cl01-07 iframe[data-ag-ui-frame]');return {bad,m:document.documentElement.getAttribute('data-ag-motion'),map:ifr?ifr.getAttribute('src'):null,ns:!!document.querySelector('#ag-cl01-07 noscript')};});
   log('M',r.bad.length===0,`${mode.name}: motion=${r.m} скрытых текстов ${r.bad.length} ${r.bad.slice(0,3).join('|')} ${mode.js===false?'noscript карты='+r.ns:'карта src='+(r.map?'есть':'нет')}`);await browser.close();}
  const {browser,page}=await open({w:1440});await page.goto(AFTER);await settle(page);
  const r=await page.evaluate(()=>{const o={};document.querySelectorAll('.ag-scope').forEach(root=>{const all=root.querySelectorAll('[data-ag-anim]');o[root.id]=[all.length,[...all].filter(e=>!e.hasAttribute('data-ag-done')).length];});return o;});
  for(const [id,[n,left]] of Object.entries(r)) log('M',left===0,`motion on: ${id} анимаций ${n}, не отсканировано ${left}`);await browser.close();}
 if(G.includes('F')){
  // канаты, мышь
  {const {browser,page}=await open({w:1440});await page.addInitScript(RAF);await page.goto(AFTER);await settle(page);
   const band=await page.$('#ag-cl01-01 .ag-bh__ropes');const bb=await band.boundingBox();
   const d0=await page.$eval('#ag-cl01-01 .ag-bh__rope--hot',p=>p.getAttribute('d'));
   await page.mouse.move(700,bb.y-30);await page.mouse.move(720,bb.y+12,{steps:4});await page.waitForTimeout(60);
   const d1=await page.$eval('#ag-cl01-01 .ag-bh__rope--hot',p=>p.getAttribute('d'));const rs=await page.evaluate(()=>window.__rafStep);
   await page.mouse.move(740,bb.y+bb.height+60,{steps:3});await page.waitForTimeout(3500);
   const d2=await page.$eval('#ag-cl01-01 .ag-bh__rope--hot',p=>p.getAttribute('d'));
   const r1=await page.evaluate(()=>window.__rafStep);await page.waitForTimeout(1500);const r2=await page.evaluate(()=>window.__rafStep);
   const y=s=>parseFloat(s.split('Q')[1].split(' ')[1]);
   log('F',Math.abs(y(d1)-10)>2&&rs>0,`канаты: мышь оттягивает верхний канат (вершина ${y(d0).toFixed(1)} → ${y(d1).toFixed(1)}, кадров цикла ${rs})`);
   log('F',Math.abs(y(d2)-10)<0.01&&r2===r1,`канаты: успокоились (вершина ${y(d2)}), кадров цикла канатов в покое за 1,5 с: ${r2-r1}`);
   // мешок
   const fig=await page.$('#ag-cl01-02 .ag-hl__media');await fig.scrollIntoViewIfNeeded();await page.waitForTimeout(700);const fb=await fig.boundingBox();
   await page.mouse.move(fb.x+40,fb.y+fb.height/2);await page.mouse.move(fb.x+fb.width-40,fb.y+fb.height/2,{steps:6});await page.waitForTimeout(120);
   const t1=await fig.evaluate(e=>e.style.transform);await page.mouse.move(10,10);await page.waitForTimeout(6000);const t2=await fig.evaluate(e=>e.style.transform);
   log('F',/rotate/.test(t1)&&t2==='',`мешок: качается (${t1}) и останавливается ('${t2}')`);
   // диалог
   const link=await page.$('#ag-cl01-05 [data-ag-ui-open]');await link.scrollIntoViewIfNeeded();await link.click();await page.waitForTimeout(300);
   let st=await page.evaluate(()=>{const d=document.querySelector('#ag-cl01-05 dialog');return {open:d.open,cap:d.querySelector('[data-ag-ui-cap]').textContent,ov:document.documentElement.style.overflow,src:d.querySelector('img').getAttribute('src').split('/').pop()};});
   log('F',st.open&&/Кадр 1 из 3/.test(st.cap)&&st.ov==='hidden',`кадр целиком: открыт, «${st.cap}», ${st.src}, прокрутка страницы ${st.ov}`);
   await page.keyboard.press('ArrowRight');await page.waitForTimeout(100);
   st=await page.evaluate(()=>document.querySelector('#ag-cl01-05 [data-ag-ui-cap]').textContent);log('F',/Кадр 2 из 3/.test(st),`кадр целиком: → ${st}`);
   // axe в открытом диалоге
   await page.addScriptTag({content:fs.readFileSync(require.resolve('axe-core/axe.min.js'),'utf8')});
   const ax=await page.evaluate(async()=>(await axe.run(document.querySelector('#ag-cl01-05'),{resultTypes:['violations']})).violations.map(v=>v.id+':'+v.impact));
   log('A',!ax.some(v=>/serious|critical/.test(v)),`axe с открытым окном кадра: ${ax.join(', ')||'0'}`);
   await page.keyboard.press('Escape');await page.waitForTimeout(200);
   st=await page.evaluate(()=>({open:document.querySelector('#ag-cl01-05 dialog').open,f:document.activeElement.getAttribute('data-ag-ui-place'),ov:document.documentElement.style.overflow}));
   log('F',!st.open&&st.f&&st.ov==='',`кадр целиком: Escape закрыл, фокус вернулся на ссылку кадра (${st.f}), прокрутка восстановлена`);
   // копирование
   await browser.contexts()[0].grantPermissions(['clipboard-read','clipboard-write']);
   const cb=await page.$('#ag-cl01-07 [data-ag-ui-copy]');const vis=await cb.isVisible();await cb.scrollIntoViewIfNeeded();await cb.click();await page.waitForTimeout(300);
   const clip=await page.evaluate(()=>navigator.clipboard.readText().catch(e=>'ERR '+e));const note=await page.$eval('#ag-cl01-07 [data-ag-ui-copied]',e=>e.textContent);
   const share=await page.$eval('#ag-cl01-07 [data-ag-share]',e=>e.hidden);
   log('F',vis&&/Галактионовская, 81/.test(clip)&&note==='Адрес скопирован'&&share,`копирование: «${clip}», подтверждение «${note}», «Поделиться» на ПК скрыта=${share}`);
   const map=await page.evaluate(()=>{const f=document.querySelector('#ag-cl01-07 [data-ag-ui-frame]');return {src:!!f.getAttribute('src'),n:document.querySelectorAll('#ag-cl01-07 iframe').length};});
   log('F',map.src&&map.n===1,`карта: src поставлен у iframe из разметки, iframe на странице ${map.n}`);
   const mag=await page.$$eval('[data-ag-magnetic]',x=>x.length);log('F',mag===0,`магнитных кнопок: ${mag}`);
   await browser.close();}
  // телефон: касание каната, свайп над канатами прокручивает, reduce
  {const {browser,page}=await open({w:390,h:800,mobile:true,touch:true});await page.goto(AFTER);await settle(page);
   const band=await page.$('#ag-cl01-01 .ag-bh__ropes');await band.scrollIntoViewIfNeeded();await page.waitForTimeout(300);const bb=await band.boundingBox();
   await page.touchscreen.tap(bb.x+200,bb.y+11);await page.waitForTimeout(90);
   const d=await page.$eval('#ag-cl01-01 .ag-bh__rope--hot',p=>parseFloat(p.getAttribute('d').split('Q')[1].split(' ')[1]));
   log('F',Math.abs(d-10)>1,`канаты на телефоне: касание дёргает канат (вершина ${d.toFixed(1)})`);
   const cdp=await page.context().newCDPSession(page);const y0=await page.evaluate(()=>scrollY);
   {const x=Math.round(bb.x+200),y=Math.round(bb.y+20);await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x,y}]});
    for(let i=1;i<=10;i++) await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x,y:y-i*25}]});
    await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await page.waitForTimeout(500);}
   const ta=await band.evaluate(e=>getComputedStyle(e).touchAction);
   const y1=await page.evaluate(()=>scrollY);log('F',y1>y0+100,`свайп вверх над канатами прокручивает страницу (${y0} → ${y1}, touch-action: ${ta})`);
   const fig=await page.$('#ag-cl01-02 .ag-hl__media');await fig.scrollIntoViewIfNeeded();const fb=await fig.boundingBox();await page.touchscreen.tap(fb.x+30,fb.y+fb.height/2);await page.waitForTimeout(150);
   const tr=await fig.evaluate(e=>e.style.transform);log('F',/rotate/.test(tr),`мешок на телефоне: нажатие качает (${tr})`);
   await browser.close();}
  {const {browser,page}=await open({w:1440,reduce:true});await page.addInitScript(RAF);await page.goto(AFTER);await settle(page);
   const band=await page.$('#ag-cl01-01 .ag-bh__ropes');const bb=await band.boundingBox();const r0=await page.evaluate(()=>window.__rafStep);
   await page.mouse.move(700,bb.y-20);await page.mouse.move(720,bb.y+12,{steps:4});await page.waitForTimeout(200);
   const d=await page.$eval('#ag-cl01-01 .ag-bh__rope--hot',p=>p.getAttribute('d'));const r1=await page.evaluate(()=>window.__rafStep);
   log('F',/Q\S+ 10(\.00)? /.test(d)||/Q[\d.]+ 10\.00/.test(d)||d.includes(' 10.00 '),`reduce: канаты неподвижны (${d.slice(0,40)}), rAF от канатов ${r1-r0}`);
   await browser.close();}
 }
 if(G.includes('A')){const axeSrc=fs.readFileSync(require.resolve('axe-core/axe.min.js'),'utf8');
  for(const m of [{w:1440},{w:1024},{w:390,mobile:true},{w:390,mobile:true,reduce:true},{w:390,nojs:true}]){
   let o;if(m.nojs){fs.writeFileSync('after_nojs.html',fs.readFileSync('after.html','utf8').replace(/<script>[\s\S]*?<\/script>/g,'').replace(/<!--[\s\S]*?-->/g,'').replace(/<noscript>([\s\S]*?)<\/noscript>/g,'$1'));o=await open({w:390,h:900});await o.page.goto('file://'+path.resolve('after_nojs.html'));await o.page.waitForTimeout(800);}
   else {o=await open({...m,h:900});await o.page.goto(AFTER);await settle(o.page);}
   await o.page.addScriptTag({content:axeSrc});const res=await o.page.evaluate(async()=>(await axe.run(document.getElementById('allrecords'),{resultTypes:['violations']})).violations.map(v=>[v.id,v.impact,v.nodes.length,v.nodes[0].target.join(' ')]));
   const s=res.filter(v=>/serious|critical/.test(v[1]));log('A',s.length===0,`${m.w}${m.reduce?' reduce':''}${m.nojs?' без JS':''}: нарушений ${res.length} (serious/critical ${s.length}) ${res.map(v=>v.join(':')).join(' ; ').slice(0,300)}`);await o.browser.close();}}
 fs.writeFileSync('checks_b_'+G+'.json',JSON.stringify(out,null,1));
 for(const g of Object.keys(out)){console.log('## '+g);out[g].forEach(x=>console.log('  '+x));}
})();
