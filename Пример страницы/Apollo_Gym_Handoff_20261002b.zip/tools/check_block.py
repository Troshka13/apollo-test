#!/usr/bin/env python3
"""Быстрая проверка автономного блока T123 Apollo Gym без браузера (профили А и Б).
  python3 check_block.py <блок.html> [<блок2.html> ...] [--prev <прошлая версия.html>]
Проверяет: размер < 100 000 байт; движок символ в символ (tools/engine_template.html), если есть data-ag-anim;
корень div.ag-scope#ag-…; число H1; типы появления; «Подробнее»; внешние var(--ag-…); @keyframes; opacity:0;
имена «не публикуются» (по хешам); выдаёт версию из шапки, SHA-256 файла и SHA-256 кода без пробелов
(для сверки с тестом через test_audit_console.js). С --prev — сравнивает видимый текст с прошлой версией."""
import sys, os, re, hashlib, html as H
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import scan_hidden
ENGINE = open(os.path.join(HERE, 'engine_template.html'), encoding='utf-8').read()


def visible(t):
    t = re.sub(r'<!--.*?-->', ' ', t, flags=re.S)
    t = re.sub(r'<(script|style)\b.*?</\1>', ' ', t, flags=re.S | re.I)
    t = re.sub(r'<[^>]+>', ' ', t)
    return re.sub(r'\s+', ' ', H.unescape(t).replace('\xa0', ' ')).strip()


def check(path, prev=None):
    raw = open(path, 'rb').read(); t = raw.decode('utf-8')
    res = []; ok = True
    def add(cond, msg, hard=True):
        nonlocal ok
        res.append(('pass' if cond else ('FAIL' if hard else 'warn')) + '  ' + msg)
        if hard and not cond: ok = False
    ver = re.search(r'· v(\d+\.\d+\.\d+) ·', t)
    add(len(raw) < 100000, 'размер %d байт (< 100 000)' % len(raw))
    m = re.search(r'<div class="ag-scope[^"]*" id="(ag-[a-z0-9-]+)"', t)
    add(bool(m), 'корень div.ag-scope#%s' % (m.group(1) if m else '—'))
    anims = sorted(set(re.findall(r'data-ag-anim="([a-z-]+)"', t)))
    has_engine = ENGINE in t
    if anims:
        add(has_engine and t.count('<!-- Движок движения') == 1, 'движок символ в символ, один раз (типы: %s)' % ', '.join(anims))
    else:
        add(True, 'анимаций нет — движок не обязателен (%s)' % ('есть' if has_engine else 'нет'))
    appear = [a for a in anims if a in ('rise', 'fade', 'stagger', 'split', 'scale-in')]
    add(len(appear) <= 3, 'типы появления: %s (закон 8 — не больше двух на блок; сверить с прошлой версией)' % (', '.join(appear) or '—'), hard=False)
    h1 = len(re.findall(r'<h1\b', t)); add(h1 <= 1, 'H1 в блоке: %d (на страницу — один, в первом блоке)' % h1)
    add('Подробнее' not in visible(t), 'нет подписи «Подробнее»')
    add(not re.search(r'var\(--ag-', t), 'нет внешних var(--ag-…) (закон 13)', hard=False)
    add(not re.search(r'@keyframes', t), '@keyframes нет (свои ключевые кадры появления запрещены)', hard=False)
    op0 = len(re.findall(r'opacity\s*:\s*0(?![.\d])', t))
    add(op0 == 0, 'opacity:0 в CSS: %d (допустимо только у скрытых состояний — проверить глазами)' % op0, hard=False)
    add(not scan_hidden.hits(t), 'имён из записей «не публикуются» нет (по хешам)')
    add(not re.search(r'(?i)(api[_-]?key|secret|password|bearer\s)', t), 'ключей/секретов нет')
    if prev:
        a, b = visible(open(prev, encoding='utf-8').read()), visible(t)
        i = 0
        while i < min(len(a), len(b)) and a[i] == b[i]: i += 1
        add(a == b, 'видимый текст = прошлой версии' + ('' if a == b else ' — РАЗНИЦА: …%s… → …%s…' % (a[max(0, i - 40):i + 40], b[max(0, i - 40):i + 40])), hard=False)
    print('== %s · v%s' % (os.path.basename(path), ver.group(1) if ver else '?'))
    for r in res: print('  ' + r)
    print('  sha256        %s' % hashlib.sha256(raw).hexdigest())
    print('  sha256_nows   %s  (код без пробельных символов — для сверки с тестом)' % hashlib.sha256(re.sub(r'\s+', '', t).encode()).hexdigest())
    return ok


if __name__ == '__main__':
    args = sys.argv[1:]; prev = None
    if '--prev' in args:
        k = args.index('--prev'); prev = args[k + 1]; del args[k:k + 2]
    good = all([check(p, prev) for p in args])
    sys.exit(0 if good else 1)
