const HH={"salt": "apollo-gym-handoff-2026", "prefix": [[5, "00d3820adb122f9fce11"], [7, "0d01e148edab886a4c3e"], [7, "75fc1d59df800ade506f"], [8, "476d528dd3a763626f65"], [8, "d70024f53897541bef26"], [9, "1bbe0ce67c72314ea351"], [10, "794c2be903d14fb135db"], [10, "975f8e31a41b50aaba62"], [13, "8422ce46147a6e04ec61"], [15, "604be38df196d9c2b2ee"], [17, "52e6da4f731368f4d0f7"], [19, "2ef868c62dd5afcd3a1b"]], "word": ["03e98004c492006806e5", "375f9d3645f7820ec178", "d7ac910b1db6ba2ff408"]};
function sha256(ascii){/* компактная синхронная SHA-256 (UTF-8) */
 const b=new TextEncoder().encode(ascii);const K=[0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
 let h=[0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19];
 const l=b.length,n=((l+9+63)>>6)<<6,m=new Uint8Array(n);m.set(b);m[l]=0x80;const bits=l*8;const dv=new DataView(m.buffer);dv.setUint32(n-4,bits>>>0);dv.setUint32(n-8,Math.floor(bits/4294967296));
 const w=new Uint32Array(64);const r=(x,k)=>(x>>>k)|(x<<(32-k));
 for(let o=0;o<n;o+=64){for(let i=0;i<16;i++)w[i]=dv.getUint32(o+i*4);for(let i=16;i<64;i++){const s0=r(w[i-15],7)^r(w[i-15],18)^(w[i-15]>>>3),s1=r(w[i-2],17)^r(w[i-2],19)^(w[i-2]>>>10);w[i]=(w[i-16]+s0+w[i-7]+s1)>>>0;}
  let [a,bb,c,d,e,f,g,hh]=h;for(let i=0;i<64;i++){const S1=r(e,6)^r(e,11)^r(e,25),ch=(e&f)^(~e&g),t1=(hh+S1+ch+K[i]+w[i])>>>0,S0=r(a,2)^r(a,13)^r(a,22),mj=(a&bb)^(a&c)^(bb&c),t2=(S0+mj)>>>0;hh=g;g=f;f=e;e=(d+t1)>>>0;d=c;c=bb;bb=a;a=(t1+t2)>>>0;}
  h=[(h[0]+a)>>>0,(h[1]+bb)>>>0,(h[2]+c)>>>0,(h[3]+d)>>>0,(h[4]+e)>>>0,(h[5]+f)>>>0,(h[6]+g)>>>0,(h[7]+hh)>>>0];}
 return h.map(x=>x.toString(16).padStart(8,'0')).join('');}
function hiddenHits(text){/* имена «не публикуются» по хешам; логика = tools/scan_hidden.py */
 const t=text.toLowerCase().replace(/ё/g,'е');const P=HH.prefix,Wd=new Set(HH.word);const by={};P.forEach(([L,d])=>{(by[L]=by[L]||new Set()).add(d);});
 const isw=c=>/[0-9a-zа-я]/.test(c);
 for(let i=0;i<t.length;i++){if(!isw(t[i])||(i>0&&isw(t[i-1])))continue;for(const L in by){const L2=+L;if(i+L2<=t.length&&by[L].has(sha256(HH.salt+t.substr(i,L2)).slice(0,20)))return true;}}
 for(const w of t.match(/[0-9a-zа-я]+/g)||[]){if(w.length>3&&Wd.has(sha256(HH.salt+w).slice(0,20)))return true;}
 return false;}
