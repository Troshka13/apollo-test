#!/usr/bin/env python3
"""Проверка «имена из записей «не публикуются» не попали в файлы» — по хешам (tools/hidden_hashes.json).
Самих имён в паке нет. Использование:  python3 scan_hidden.py <файл|папка|zip> [...]
Код выхода 1, если найдено. Проверяются и содержимое текстовых файлов, и имена файлов, и файлы внутри zip."""
import sys, os, json, hashlib, re, zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
H = json.load(open(os.path.join(HERE, 'hidden_hashes.json'), encoding='utf-8'))
SALT = H['salt']
PREFIX = {}
for L, d in H['prefix']:
    PREFIX.setdefault(L, set()).add(d)
WORD = set(H['word'])
TEXT_EXT = ('.html', '.htm', '.md', '.txt', '.csv', '.json', '.js', '.py', '.css', '.xml', '.svg', '.sh', '.yml', '.yaml')
STARTS = re.compile(r'(?<![0-9a-zа-я])[0-9a-zа-я]')
WORDS = re.compile(r'[0-9a-zа-я]+')


def h(s):
    return hashlib.sha256((SALT + s).encode('utf-8')).hexdigest()[:20]


def hits(text):
    t = text.lower().replace('ё', 'е')
    for m in STARTS.finditer(t):
        i = m.start()
        for L, ds in PREFIX.items():
            if i + L <= len(t) and h(t[i:i + L]) in ds:
                return True
    for w in WORDS.findall(t):
        if len(w) > 3 and h(w) in WORD:
            return True
    return False


def scan_bytes(name, data, out):
    if hits(name):
        out.append(name + '  (имя файла)')
    if name.lower().endswith('.zip'):
        try:
            z = zipfile.ZipFile(__import__('io').BytesIO(data))
            for n in z.namelist():
                scan_bytes(name + '!' + n, z.read(n), out)
        except Exception:
            pass
        return
    if name.lower().endswith(TEXT_EXT):
        if hits(data.decode('utf-8', 'ignore')):
            out.append(name)


def main(paths):
    out = []
    for p in paths:
        if os.path.isdir(p):
            for root, _, files in os.walk(p):
                for f in files:
                    fp = os.path.join(root, f)
                    scan_bytes(fp, open(fp, 'rb').read(), out)
        else:
            scan_bytes(p, open(p, 'rb').read(), out)
    for o in out:
        print('НАЙДЕНО:', o)
    print('совпадений:', len(out))
    return 1 if out else 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:] or ['.']))
