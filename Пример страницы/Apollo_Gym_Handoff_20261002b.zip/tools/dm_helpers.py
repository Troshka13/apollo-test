# -*- coding: utf-8 -*-
"""Помощники сборки блоков прохода «дизайн, движение и фишка» (выдержка из сборщиков 30.09–01.10).
Принцип: блок v1.N+1 собирается из полного файла прошлой версии точечными заменами; каждая замена обязана найтись
ровно столько раз, сколько ожидается (rep/rx), иначе сборка падает. Движок не трогается; узлы скриптом не вставляются.
Пример сборщика целиком — passes/cycle-samara/build_dir07_dm.py."""
import re
EASE_OUT = 'cubic-bezier(.34,1.56,.64,1)'

def rep(t, old, new, n=1):
    c = t.count(old)
    if c != n:
        raise SystemExit('replace %d != %d: %r' % (c, n, old[:140]))
    return t.replace(old, new)

def rx(t, pat, new, n=1):
    t2, c = re.subn(pat, new, t, flags=re.S)
    if c != n:
        raise SystemExit('regex %d != %d: %r' % (c, n, pat[:140]))
    return t2

def focus3(t, root):
    return rx(t, r'(%s\.ag-scope :is\([^)]*\):focus-visible\{outline:)2px' % re.escape(root), r'\g<1>3px')

def wrap(t, tag, cls, inner, n=1):
    pat = r'(<%s class="%s"[^>]*>)(.*?)(</%s>)' % (tag, re.escape(cls), tag)
    return rx(t, pat, lambda m: m.group(1) + '<span class="%s">' % inner + m.group(2) + '</span>' + m.group(3), n)

def press_css(root, pairs):
    sel_in = ',\n  '.join('%s .%s' % (root, i) for b, i in pairs)
    sel_act = ',\n  '.join('%s .%s:active .%s' % (root, b, i) for b, i in pairs)
    red_in = ', '.join('%s .%s' % (root, i) for b, i in pairs)
    red_act = ', '.join('%s .%s:active .%s' % (root, b, i) for b, i in pairs)
    return ('''  /* F23 · нажатие: область кнопки неподвижна, сжимается подпись со значком */
  %s{display:inline-flex;align-items:center;justify-content:inherit;gap:inherit;flex:1 1 auto;min-width:0;
    transition:transform 260ms %s;}
  %s{transform:scale(.98);transition-duration:140ms;transition-timing-function:cubic-bezier(.22,.61,.36,1);}
  @media (prefers-reduced-motion:reduce){
    %s{transition:none;}
    %s{transform:none;}
  }
''' % (sel_in, EASE_OUT, sel_act, red_in, red_act))

TOUCH = '    /* iOS включает :active только при слушателе касания (F23) */\n    root.addEventListener("touchstart", function () {}, { passive: true });\n'

def touch(t):
    return rep(t, '    var tries = 0;\n', TOUCH + '    var tries = 0;\n')

def before_engine(t, js):
    i = t.index('<!-- Движок движения')
    return t[:i] + js.lstrip('\n') + '\n  ' + t[i:]

GRAIN = ("url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='180' height='180'%3E"
         "%3Cfilter id='g'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='.85' numOctaves='2' stitchTiles='stitch'/%3E"
         "%3CfeColorMatrix values='0 0 0 0 .04 0 0 0 0 .035 0 0 0 0 .03 0 0 0 .5 0'/%3E%3C/filter%3E"
         "%3Crect width='100%25' height='100%25' filter='url(%23g)'/%3E%3C/svg%3E\")")


def add_css(t, css):
    i = t.index('  </style>')
    return t[:i] + '\n  /* ===== v1.1.0 · дизайн, движение и фишка (дата) ===== */\n' + css + t[i:]


def add_js(t, js):
    """Свой скрипт — перед «Страховкой скана» (первый <script> блока)."""
    k = t.index('  /* Страховка скана')
    return t[:k] + js + '\n' + t[k:]


def grain_css(root, sec, wrap_cls):
    return '''  /* F29 · зерно бумаги (статично, только ≥ 640 px; forced-colors и печать — без зерна) */
  @media (min-width:640px){
    %(r)s .%(s)s{position:relative;}
    %(r)s .%(s)s::before{content:"";position:absolute;inset:0;z-index:0;pointer-events:none;opacity:.12;background-image:%(g)s;background-size:180px 180px;}
    %(r)s .%(w)s{position:relative;z-index:1;}
  }
  @media (forced-colors:active){%(r)s .%(s)s::before{display:none;}}
  @media print{%(r)s .%(s)s::before{display:none;}}
''' % {'r': root, 's': sec, 'w': wrap_cls, 'g': GRAIN}
