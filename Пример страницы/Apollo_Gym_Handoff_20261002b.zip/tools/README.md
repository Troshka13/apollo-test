# Инструменты

| Файл | Где работает | Что делает |
|---|---|---|
| `stand_offline.html` | любой браузер (пользователь) | вставить блок → показ на 6 ширинах, режим без JS, проверки: размер, корень, движок, H1, «Подробнее», внешние переменные, `opacity:0`, имена (по хешам), версия, SHA без пробелов |
| `test_audit_console.js` | консоль Chrome на странице теста | отчёт: запись → блок → версия → SHA кода без пробелов → имена → H1 → JSON-LD; сверять с `data/BLOCKS_STATE.csv` (`sha256_nows`) |
| `check_block.py` | Python 3 | то же, что стенд, без показа; `--prev <файл>` сравнивает видимый текст |
| `scan_hidden.py` | Python 3 | скан файлов/папок/zip на имена «не публикуются» по хешам (`hidden_hashes.json`, имён в файле нет); код выхода 1 при находке |
| `check_claims.py` | Python 3 | факты: `--blocks /страница` (видимый текст блоков из `data/BLOCKS_STATE.csv`), `--text "…" --page /…` (Description/Title) |
| `lint/07_QA/lint_copy.py --html <блок>` | Python 3 | голос и запрещённые конструкции (`lint/02_VOICE/BANNED.json`); норма — «Чисто.» |
| `engine_template.html` | — | движок, вставляется в блок символ в символ |
| `dm_helpers.py` | Python 3 | помощники сборки: `rep`/`rx` (замена ровно N раз), `wrap`, `press_css`, `touch`, `focus3`, `add_css`, `add_js`, `grain_css` |
| `stand/` | Node 18+, `npm i playwright gsap`, Chromium (`CHROMIUM_PATH` при нестандартном пути) | стенд Playwright: `page.py` собирает страницу из блоков, `measure.js` — высоты и снимки, `solo.js` — блок на пустой странице, `vcopy.js` — сверка страницы копирования; `lib.js` подменяет кадры CDN заглушками (`stand/media`), шрифты локально (`stand/fonts`, OFL) |
| `copy_page/` | Python 3 | генератор страницы копирования (образец — `/cycle-samara`; поменять список блоков, пути, Description) |
| `hidden_hashes.json`, `_shared.js` | — | общие данные хешей и SHA-256 для HTML/JS-инструментов |

Примеры:
```
python3 tools/check_block.py blocks/cycle-samara/DIR07-03_v1.1.0.html
python3 tools/scan_hidden.py .
python3 tools/check_claims.py --text "Растяжка в Самаре на Молодогвардейской, 56: …" --page /stretching-samara
python3 tools/stand/page.py after.html out/DIR08-0*_v1.1.0.html && node tools/stand/measure.js after.html after 390,1440
```
Проверки групп L/T/C/M/F/A по образцу — `passes/<страница>/checks_*.js` (пути внутри — от папки прохода).
