const fs=require('fs'),path=require('path');
const {chromium}=require('playwright');
const H=__dirname;
const media=fs.readdirSync(H+'/media');
function pickImg(url){
  const name=url.split('/').pop().split('?')[0];
  if(media.includes(name)) return H+'/media/'+name;
  const tall=/683x1024/.test(name)||/\.webp$/.test(name);
  return H+'/media/'+(tall?'sebe_1.webp':'Zal_4-1024x683.jpg');
}
async function open(opts={}){
  const browser=await chromium.launch(process.env.CHROMIUM_PATH?{executablePath:process.env.CHROMIUM_PATH}:{});
  const ctx=await browser.newContext({viewport:{width:opts.w||1440,height:opts.h||900},reducedMotion:opts.reduce?'reduce':'no-preference',javaScriptEnabled:opts.js!==false,hasTouch:!!opts.touch,isMobile:!!opts.mobile,deviceScaleFactor:1});
  const page=await ctx.newPage();
  const errs=[];page.on('pageerror',e=>errs.push(String(e)));page.on('console',m=>{if(m.type()==='error')errs.push('console:'+m.text())});
  await page.route('**/*',async r=>{
    const u=r.request().url();
    if(u.startsWith('file://')) return r.continue();
    if(u.includes('fonts.googleapis.com/css')) return r.fulfill({contentType:'text/css',body:fs.readFileSync(H+'/fonts.css','utf8').replace(/\/fonts\//g,'http://local.test/fonts/')});
    if(u.startsWith('http://local.test/fonts/')) return r.fulfill({contentType:'font/ttf',body:fs.readFileSync(H+'/fonts/'+u.split('/').pop())});
    if(u.includes('gsap.min.js')){ if(opts.cdn==='hang') return; if(opts.cdn==='fail') return r.abort(); return r.fulfill({contentType:'application/javascript',body:fs.readFileSync(require.resolve('gsap/dist/gsap.min.js'))});}
    if(u.includes('ScrollTrigger.min.js')) return r.fulfill({contentType:'application/javascript',body:fs.readFileSync(require.resolve('gsap/dist/ScrollTrigger.min.js'))});
    if(/static\.tildacdn/.test(u)&&/\.(jpe?g|png|webp)/i.test(u)){const f=pickImg(u);return r.fulfill({contentType:f.endsWith('webp')?'image/webp':'image/jpeg',body:fs.readFileSync(f)});}
    if(/\.mp4/.test(u)) return r.abort();
    if(u.includes('yandex')) return r.fulfill({contentType:'text/html',body:'<body style="margin:0;background:#2a2d33;color:#999;font:14px sans-serif;display:grid;place-items:center;height:100vh">карта (заглушка стенда)</body>'});
    return r.abort();
  });
  return {browser,page,errs};
}
async function settle(page){
  await page.waitForTimeout(400);
  const hgt=await page.evaluate(()=>document.body.scrollHeight);
  for(let y=0;y<hgt;y+=500){await page.evaluate(y=>window.scrollTo(0,y),y);await page.waitForTimeout(90);}
  await page.waitForTimeout(1500);
  await page.evaluate(()=>window.scrollTo(0,0));await page.waitForTimeout(300);
}
module.exports={open,settle,H};
