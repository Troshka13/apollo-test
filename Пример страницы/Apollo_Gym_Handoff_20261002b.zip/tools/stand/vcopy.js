const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch(process.env.CHROMIUM_PATH?{executablePath:process.env.CHROMIUM_PATH}:{});
for(const w of [1280,390]){const p=await (await b.newContext({viewport:{width:w,height:900}})).newPage();

await p.goto('file://'+require('path').resolve('copy/_wrap.html'));await p.waitForTimeout(500);
const r=await p.evaluate(async()=>{const o=[];for(const t of document.querySelectorAll('textarea')){const h=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(t.value));o.push([...new Uint8Array(h)].map(x=>x.toString(16).padStart(2,'0')).join('')===t.dataset.sha);}return {o,ov:document.documentElement.scrollWidth>document.documentElement.clientWidth};});
console.log(w,JSON.stringify(r));await p.screenshot({path:`shots/copy_${w}.png`,fullPage:false});}
await b.close();})();
