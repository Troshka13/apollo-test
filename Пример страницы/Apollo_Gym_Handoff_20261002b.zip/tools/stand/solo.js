// Каждый блок отдельно на пустой странице (группа G): node solo.js out/ПРЕФИКС-0*_vX.html
const {open,settle}=require('./lib');const {execSync}=require('child_process');const path=require('path');const fs=require('fs');
(async()=>{fs.mkdirSync('solo',{recursive:true});const res=[];for(const f of process.argv.slice(2)){const o=`solo/${path.basename(f)}`;execSync(`python3 ${__dirname}/page.py ${o} ${f}`);
 for(const w of [390,1440]){const {browser,page,errs}=await open({w,mobile:w<700,touch:w<700});await page.goto('file://'+path.resolve(o));await settle(page);
  const r=await page.evaluate(()=>{const a=[...document.querySelectorAll('[data-ag-anim]')];return {n:a.length,nd:a.filter(e=>!e.hasAttribute('data-ag-done')).length,ov:document.documentElement.scrollWidth>document.documentElement.clientWidth};});
  res.push(`${r.nd===0&&!r.ov&&errs.length===0?'pass':'FAIL'} ${path.basename(f)} ${w}: анимаций ${r.n}, не отсканировано ${r.nd}, переполнение ${r.ov}, ошибок ${errs.length}`);await browser.close();}}
 console.log(res.join('\n'));})();
