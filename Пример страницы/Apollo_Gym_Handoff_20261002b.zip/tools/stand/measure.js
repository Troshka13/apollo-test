const {open,settle}=require('./lib');
(async()=>{
  const file=process.argv[2], tag=process.argv[3]||'x', widths=(process.argv[4]||'390,1440').split(',').map(Number);
  const shots=process.env.SHOTS!=='0';
  for(const w of widths){
    const {browser,page,errs}=await open({w,h:w<700?844:900,mobile:w<700,touch:w<700});
    await page.goto('file://'+require('path').resolve(file));await settle(page);
    const res=await page.evaluate(()=>{
      const out=[];document.querySelectorAll('.ag-scope').forEach(r=>{const b=r.getBoundingClientRect();out.push([r.id,Math.round(b.height)]);});
      return {rows:out,total:document.body.scrollHeight,sw:document.documentElement.scrollWidth,cw:document.documentElement.clientWidth,motion:document.documentElement.getAttribute('data-ag-motion')};
    });
    console.log(`== ${tag} @${w}  total=${res.total} overflowX=${res.sw>res.cw} motion=${res.motion}`);
    res.rows.forEach(r=>console.log('  ',r[0].padEnd(16),r[1]));
    if(errs.length) console.log('  ERR',errs.slice(0,5));
    if(shots){require('fs').mkdirSync('shots/'+tag,{recursive:true});
      for(const [id] of res.rows){const el=await page.$('#'+id);await el.screenshot({path:`shots/${tag}/${id}_${w}.png`});}}
    await browser.close();
  }
})();
