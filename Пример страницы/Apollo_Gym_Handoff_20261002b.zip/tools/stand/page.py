import sys,os
# usage: page.py out.html file1 file2 ...
out=sys.argv[1]; files=sys.argv[2:]
parts=[]
for f in files:
    parts.append('<div class="t-rec">'+open(f).read()+'</div>')
html='''<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>stand</title><style>html,body{margin:0;padding:0;background:#111}#allrecords a{color:#ff8562}</style></head>
<body><div id="allrecords">'''+'\n'.join(parts)+'</div></body></html>'
open(out,'w').write(html)
