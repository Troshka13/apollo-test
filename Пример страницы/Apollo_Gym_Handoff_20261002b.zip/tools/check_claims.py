#!/usr/bin/env python3
"""Проверка утверждений в Title, Description, H1 и тексте блоков — против FACTS_v10 (закон 4) и законов 2–3.

    python3 work/tools/check_claims.py                     # цели phase2/DATA/SEO_TARGETS.csv (колонки *_target)
    python3 work/tools/check_claims.py --col now           # текущие значения (*_now) — находки идут в ISSUES
    python3 work/tools/check_claims.py --blocks /kids      # видимый текст последних версий блоков страницы
    python3 work/tools/check_claims.py --update-len        # пересчитать *_len в SEO_TARGETS после ручной правки

Правила — по странице: число залов у направления, «дети» там, где детские группы не подтверждены,
бесплатное занятие для детей, сайкла и растяжки, титулы тренеров, часы, «женские группы», запрещённые слова.
Числа залов и подтверждённые детские группы — FACTS_v10 §2, §6 на 29.09; после ответа владельца правятся
HALLS / KIDS_OK / FREE_NO / PAGE_RULES здесь и FACTS — в одном проходе.
В режиме --blocks часть правил только предупреждает (в тексте блоков бывают честные оговорки «не подтверждено»).
Код выхода 1, если есть нарушения (warn не считаются).
"""
import argparse, csv, html, os, re, sys

# Копия для пака передачи 02.10.2026: корень — папка пака; инвентарь — data/BLOCKS_STATE.csv (последние выданные версии).
WORK = os.environ.get('APOLLO_WORK', os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
TARGETS = os.path.join(WORK, 'data', 'phase2', 'SEO_TARGETS.csv')
INV = os.path.join(WORK, 'data', 'BLOCKS_STATE.csv')

# сколько залов у направления (FACTS §2, clubs.json)
HALLS = {'/boxing-samara': 3, '/muay-thai-samara': 3, '/kickboxing-samara': 2, '/mma-samara': 1, '/grappling-samara': 1,
         '/functional-training': 1, '/cycle-samara': 1, '/stretching-samara': 1, '/kids-boxing': 2, '/women': None, '/kids': None}
NETWORK = {'/', '/clubs', '/about', '/contacts', '/schedule', '/prices', '/directions', '/trainers', '/rules', '/page-not-found'}
# где «дети» законно: детский бокс (Галактионовская, Ново-Садовая) и страницы сети
KIDS_OK = {'/', '/boxing', '/gym', '/boxing-samara', '/kids', '/kids-boxing', '/clubs', '/about', '/prices', '/schedule',
           '/first-training', '/request', '/contacts', '/directions', '/trainers', '/camps', '/tournaments', '/rules'}
# где «бесплатно» не подтверждено: вопрос, уровень в режиме блоков
FREE_NO = {'/kids': ('№ 11', 'fail'), '/kids-boxing': ('№ 11', 'fail'), '/cycle-samara': ('5.4', 'fail'),
           '/stretching-samara': ('5.1, 5.13', 'fail'), '/nofitness': ('5.4, 5.13 — в зале сайкл и растяжка', 'warn')}
WORDS = {3: 'три', 2: 'два', 4: 'четыре', 1: 'один'}
RULES = [  # (regex, сообщение, уровень в мета, уровень в блоках)
    (r'мастер(а|ов)? спорта|\bкмс\b|чемпион|опытн\w+ тренер|действующ\w+ бойц|регали', 'титулы и опыт тренеров не подтверждены (закон 4, К2)', 'fail', 'fail'),
    (r'часы работы|работаем с|круглосуточ|\b\d{1,2}:\d\d\b', 'часы и время не подтверждены (блокеры № 2, № 3)', 'fail', 'warn'),
    (r'женск\w+ групп', 'отдельные женские группы не подтверждены (Р16, 4.5)', 'fail', 'warn'),
    (r'самооборон', 'формат самообороны не подтверждён (3.11, К14)', 'fail', 'warn'),
    (r'джиу|bjj|бжж', 'BJJ не подтверждён (3.12) — только в абзаце-определении', 'warn', 'warn'),
    (r'кроссфит', 'формат кроссфита не подтверждён (3.10)', 'fail', 'warn'),
    (r'рейтинг|\b4[,.]8\b|отзыв\w* клиент|\d+ отзыв', 'рейтинги и число отзывов не пишутся (Р14, К13)', 'fail', 'fail'),
    (r'дисциплин\w*[^.]{0,20}(характер|воспит)|характер|потенциал|лучш(ий|ая|ее|ие|их|им|ую)\b|профессиональн\w+ подход|дружн\w+ коллектив|запишитесь онлайн',
     'запрещённые слова и пустые обещания (закон 2)', 'fail', 'warn'),
    (r'!', 'восклицательный знак (закон 2)', 'fail', 'warn'),
    (r'под музыку', '«под музыку» — черновик № 5, вопрос 3.8', 'fail', 'warn'),
    (r'мешк\w*[^.]{0,40}чкалов|чкалов[^.]{0,60}мешк', 'мешки на Чкалова не подтверждены (3.4)', 'fail', 'warn'),
    (r'ков[её]р|ковре|ковра', 'название покрытия для борьбы ждёт 3.5', 'warn', 'warn'),
    (r'турбаз|детск\w+ смен', 'выезды: «турбазы» — вопрос 8.11, детские смены объявлены, но не подтверждены (8.9)', 'fail', 'warn'),
    (r'безопасн\w+ трениров|не опасно|безопасно для', 'обещание безопасности — только «решает врач» (фильтр здоровья)', 'fail', 'fail'),
    (r'\d+\s?ккал|калори\w* \d', 'калории цифрами — нет источника', 'fail', 'fail'),
]
# правила одной страницы: (страницы, regex, сообщение)
PAGE_RULES = [
    ({'/kids', '/kids-boxing'}, r'кикбоксинг|тайск|муай|мма\b|грэпплинг|функциональн|офп', 'детские группы кроме бокса не подтверждены (7.3, 7.4)'),
    ({'/kids', '/kids-boxing'}, r'по возрасту|\b\d{1,2}\s?(–|-|до)\s?\d{1,2} лет|с \d{1,2} лет', 'возраст групп не подтверждён (4.3)'),
    ({'/tournaments'}, r'по боксу|бокс,', 'дисциплины турнира — черновик № 3 (8.3)'),
    ({'/prices', '/'}, r'персональн\w+[^.]{0,30}2 ?800', 'персональная цена — только рядом с именами (Р17)'),
]


def check(page, text, where, blocks=False):
    out = []
    t = text.lower().replace('ё', 'е')
    for rx, msg, lvl_meta, lvl_blk in RULES:
        if re.search(rx.replace('ё', 'е'), t):
            out.append((lvl_blk if blocks else lvl_meta, f'{page} · {where}: {msg}'))
    for pages, rx, msg in PAGE_RULES:
        if page in pages and re.search(rx, t):
            out.append(('warn' if blocks else 'fail', f'{page} · {where}: {msg}'))
    n = HALLS.get(page)
    if re.search(r'\b(4|четыре|четырех)\s+(зал|клуб)', t) and page not in NETWORK:
        if (n is not None and n != 4) or page in ('/women', '/kids'):
            out.append(('fail', f'{page} · {where}: «4 зала» — у страницы {n or "не все"} зал(а) (FACTS §2)'))
    for sent in re.split(r'(?<=[.!?])\s+', t):  # детская группа другого направления в одной фразе
        if re.search(r'дет(ей|и|ск)|ребен', sent) and re.search(r'кикбоксинг|тайск|муай|\bмма\b|грэпплинг|функциональн|растяжк|сайкл', sent) \
                and not re.search(r'по боксу|детск\w* бокс|бокс для детей', sent):
            out.append(('warn' if blocks else 'fail', f'{page} · {where}: дети рядом с направлением, где детские группы не подтверждены (7.3, 7.4, 7.10) — «{sent[:70]}»'))
            break
    kids = re.search(r'дет(ей|и|ск)|ребен|ребенк', t)
    if page not in KIDS_OK and kids:
        out.append(('warn' if blocks else 'fail', f'{page} · {where}: детские группы не подтверждены (7.3, 7.4)'))
    free = re.search(r'бесплатн|(?<![\d ])0 ₽', t)
    if page in FREE_NO and free:
        q, lvl = FREE_NO[page]
        out.append((lvl if blocks else 'fail', f'{page} · {where}: бесплатное занятие не подтверждено ({q})'))
    elif not blocks and free and kids and not re.search(r'для взрослых|взрослым', t):
        out.append(('fail', f'{page} · {where}: «дети» и «бесплатно» рядом без «для взрослых» (№ 11)'))
    return out


def length(field, v):
    n = len(v)
    if field == 'title' and not 45 <= n <= 70:
        return f'длина Title {n} (ориентир 50–70, SEO_RULES)'
    if field == 'description' and not 110 <= n <= 165:
        return f'длина Description {n} (ориентир 120–160, SEO_RULES)'
    return ''


def visible(s):
    s = re.sub(r'<!--.*?-->', ' ', s, flags=re.S)
    s = re.sub(r'<(style|script)[^>]*>.*?</\1>', ' ', s, flags=re.S)
    return re.sub(r'\s+', ' ', html.unescape(re.sub(r'<[^>]+>', ' ', s)).replace('\xa0', ' '))


def update_len():
    rows = list(csv.DictReader(open(TARGETS, encoding='utf-8')))
    cols = list(rows[0].keys())
    for r in rows:
        for f in ('title', 'description', 'h1'):
            r[f'{f}_len'] = len(r.get(f'{f}_target', '') or '')
    with open(TARGETS, 'w', encoding='utf-8', newline='') as fh:
        w = csv.DictWriter(fh, fieldnames=cols)
        w.writeheader()
        w.writerows(rows)
    print(f'длины пересчитаны: {len(rows)} страниц')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--col', default='target', choices=['target', 'now', 'research'])
    ap.add_argument('--blocks')
    ap.add_argument('--update-len', action='store_true')
    ap.add_argument('--text', help='проверить одну строку (Description/Title) для --page')
    ap.add_argument('--page')
    a = ap.parse_args()
    if a.update_len:
        return update_len()
    if a.text:
        r = check(a.page or '/', a.text, 'text')
        for lvl, msg in r: print(lvl, msg)
        print('символов:', len(a.text), '| нарушений:', sum(1 for l, _ in r if l == 'fail'))
        return 1 if any(l == 'fail' for l, _ in r) else 0
    res = []
    if a.blocks:
        latest = {}
        for r in csv.DictReader(open(INV, encoding='utf-8')):
            if r['page'] == a.blocks:
                latest[r['block']] = r  # инвентарь хранит последнюю версию блока
        for b, r in latest.items():
            p = os.path.join(WORK, r['file'])
            if os.path.exists(p):
                res += check(a.blocks, visible(open(p, encoding='utf-8').read()), b, blocks=True)
    else:
        for r in csv.DictReader(open(TARGETS, encoding='utf-8')):
            for f in ('title', 'description', 'h1'):
                v = r.get(f'{f}_{a.col}', '')
                if v:
                    res += check(r['url'], v, f'{f}_{a.col}')
                    if a.col == 'target' and length(f, v):
                        res.append(('warn', f"{r['url']} · {f}_target: {length(f, v)}"))
    for lvl, m in res:
        print(f'{lvl:4}  {m}')
    fails = sum(1 for l, _ in res if l == 'fail')
    print(f'нарушений: {fails}, предупреждений: {len(res) - fails}')
    sys.exit(1 if fails else 0)


if __name__ == '__main__':
    main()
