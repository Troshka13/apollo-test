# Технический справочник · движок, приёмы, грабли

Код ниже — **выдержки из выданных блоков** (не переписывать «по памяти»). Эталоны целиком:
| Приём | Эталонный блок |
|---|---|
| F04 «Зоны зала» — вкладки меняют кадр и подпись | `blocks/functional-training/DIR06-04_v1.1.0.html` |
| F10 плашка вкладок (столбец ПК / сетка 2×2 телефон) | `blocks/cycle-samara/DIR07-04_v1.1.0.html`, `blocks/grappling-samara/DIR05-04_v1.1.0.html` |
| F14 + F30 «Педаль по кругу» (маршрут, WAAPI по точкам) | `blocks/cycle-samara/DIR07-03_v1.1.0.html` |
| F14 текущий шаг по прокрутке (IntersectionObserver), вертикальный профиль | `blocks/grappling-samara/DIR05-02_v1.1.0.html` |
| F14 «Живые пиктограммы» шагов | `blocks/boxing-samara/DIR01-02_v1.2.0.html` |
| F08 сравнение колонок с подсветкой отличий | `blocks/kickboxing-samara/DIR03-02_v1.1.0.html` |
| Предметная физика: «Канаты ринга», «Мешок качается» | `blocks/boxing/CL01-01_v1.2.0.html`, `CL01-02` |
| «Тяжёлый мешок» (маятник по удару) | `blocks/gym/CL03-01_v1.1.0.html` |
| «Живая сетка клетки» (canvas с первого наведения) | `blocks/mma/CL02-01_v1.1.0.html` |
| «Ручка программы» (поворот жестом) | `blocks/nofitness/CL04-04_v1.1.0.html` |
| «Ценники на канате» (инерция прокрутки) | `blocks/prices/PRICES-01_v1.2.0.html` |
| «Билет-табло», «лампа» по `?days=` | `blocks/schedule/SCHEDULE-02_v1.1.0.html`, `SCHEDULE-04` |
| «Деталь на чертеже» (термин в тексте ↔ деталь схемы, только мышь) | `blocks/cycle-samara/DIR07-02_v1.1.0.html` |
| F22 FAQ плавно + «Раскрыть все» | `blocks/cycle-samara/DIR07-07_v1.1.0.html` |

## 1. Движок
- Шаблон — `tools/engine_template.html`, вставляется последним в блоке **символ в символ**. GSAP 3.13.0 + ScrollTrigger с cdnjs; без них и при reduce — `data-ag-motion="off"`, весь текст виден.
- Типы: `rise`, `fade`, `stagger` (`data-ag-children`), `split`, `draw` (путь SVG через `stroke-dash*`), `scale-in`, `parallax` (`data-ag-parallax` ≤ 0,08), `count`, `marquee`; `data-ag-delay`, `data-ag-dur`, `data-ag-distance`, `data-ag-start`.
- Движок пишет inline `opacity:1` и `transform` у своих узлов → свой эффект на них строится через `stroke-opacity`, `stroke-width`, `color`, `background`, классы — **не** через `opacity`/`transform`.
- MutationObserver движка (`childList`) пересканирует блок через 220 мс после вставки узлов → **скрипт блока не вставляет узлы**, всё нужное — заранее в разметке (`hidden`, `aria-hidden`), JS меняет атрибуты и классы.
- «Страховка скана» — маленький скрипт перед движком: ждёт `ApolloMotion.ready` и сканирует блок, если GSAP уже грузит другой блок.
- Готовность `draw` проверять по вычисленному `stroke-dashoffset` (≈ 0) или `data-ag-motion="off"`.

## 2. F23 — нажатие кнопки (область неподвижна, сжимается подпись)
Внутрь кнопки — обёртка `<span class="ag-btn__in">…</span>` (`dm_helpers.wrap`), iOS-слушатель `touchstart` (`dm_helpers.touch`, вставляется перед `var tries = 0;`; где его нет — после `btn.hidden = false;`).
```css
  /* F23 · нажатие: область кнопки неподвижна, сжимается подпись со значком */
  #ag-dir07-08 .ag-btn__in{display:inline-flex;align-items:center;justify-content:inherit;gap:inherit;flex:1 1 auto;min-width:0;
    transition:transform 260ms cubic-bezier(.34,1.56,.64,1);}
  #ag-dir07-08 .ag-btn:active .ag-btn__in{transform:scale(.98);transition-duration:140ms;transition-timing-function:cubic-bezier(.22,.61,.36,1);}
  @media (prefers-reduced-motion:reduce){
    #ag-dir07-08 .ag-btn__in{transition:none;}
    #ag-dir07-08 .ag-btn:active .ag-btn__in{transform:none;}
  }
```

## 3. F10 — плашка выбранной вкладки (замер `offset*`, без проезда при первой установке и resize)
```js
    /* v1.1.0 · F10: плашка выбранной вкладки — ::before у списка по --px/--py/--pw/--ph */
    var placed = false, jumpT = 0;
    function place(jump) {
      var t = tabs[current()];
      if (!t) return;
      if (jump) { W.clearTimeout(jumpT); list.classList.add("is-jump"); }
      list.style.setProperty("--px", t.offsetLeft + "px");
      list.style.setProperty("--py", t.offsetTop + "px");
      list.style.setProperty("--pw", t.offsetWidth + "px");
      list.style.setProperty("--ph", t.offsetHeight + "px");
      list.classList.add("is-plate");
      if (jump) jumpT = W.setTimeout(function () { list.classList.remove("is-jump"); }, 60);
    }
    if (W.ResizeObserver) new W.ResizeObserver(function () { place(true); }).observe(list);
    else W.addEventListener("resize", function () { place(true); });
    function current() {
      for (var k = 0; k < tabs.length; k++) if (tabs[k].getAttribute("aria-selected") === "true") return k;
      return 0;
    }
    function select(i, focus) {
      var was = current();
      tabs.forEach(function (t, k) {
        var on = k === i;
        t.setAttribute("aria-selected", on ? "true" : "false");
        t.setAttribute("tabindex", on ? "0" : "-1");
        panels[k].classList.toggle("is-on", on);
      });
      if (focus) tabs[i].focus();
      place(!placed);
      placed = true;
      if (was !== i && !reduce && panels[i].animate) {
        panels[i].animate([{ opacity: 0.001, transform: "translateY(6px)" }, { opacity: 1, transform: "none" }], { duration: 250, easing: "ease-out" });
      }
    }
```
```css
  /* F10 · плашка выбранной вкладки едет; линия к панели — после неё */
  #ag-dir07-04 .ag-xw__tabs{position:relative;isolation:isolate;}
  #ag-dir07-04 .ag-xw__tabs::before{
    content:"";position:absolute;left:0;top:0;z-index:-1;width:var(--pw,0px);height:var(--ph,0px);
    transform:translate(var(--px,0px),var(--py,0px));background:var(--tab-on);pointer-events:none;opacity:0;
    transition:transform .32s cubic-bezier(.22,.61,.36,1),width .32s cubic-bezier(.22,.61,.36,1),height .32s cubic-bezier(.22,.61,.36,1);
  }
  #ag-dir07-04 .ag-xw__tabs.is-plate::before{opacity:1;}
  #ag-dir07-04 .ag-xw__tabs.is-jump::before{transition:none;}
  #ag-dir07-04 .ag-xw__tabs.is-plate .ag-xw__tab[aria-selected="true"]{background:transparent;}
  #ag-dir07-04 .ag-xw__tab[aria-selected="true"]::before{transition-delay:.22s;}
  #ag-dir07-04 .ag-xw__tab[aria-selected="true"]::after{transition-delay:.4s;}
  @media (max-width:1023px){
    #ag-dir07-04 .ag-xw__tabs::before{border:1px solid rgba(255,196,0,.5);border-radius:12px;}
    #ag-dir07-04 .ag-xw__tabs.is-plate .ag-xw__tab[aria-selected="true"]{border-color:transparent;}
  }
```

## 4. F22 — FAQ раскрывается плавно, «Раскрыть все» без перехода
```css
  /* F22 · плавное раскрытие ответа (Chromium 131+); иначе — мгновенно, как было */
  @supports (interpolate-size:allow-keywords) and selector(::details-content){
    #ag-dir07-07 .ag-xq__list{interpolate-size:allow-keywords;}
    #ag-dir07-07 .ag-xq__item::details-content{
      height:0;overflow:clip;overflow-clip-margin:8px;
      transition:height .32s cubic-bezier(.22,.61,.36,1),content-visibility .32s allow-discrete;
    }
    #ag-dir07-07 .ag-xq__item[open]::details-content{height:auto;}
    #ag-dir07-07.is-bulk .ag-xq__item::details-content{transition:none;}
    @media (prefers-reduced-motion:reduce){
      #ag-dir07-07 .ag-xq__item::details-content{transition:none;}
    }
  }
  @media print{
    #ag-dir07-07 .ag-xq__item::details-content{height:auto !important;content-visibility:visible !important;}
    #ag-dir07-07 .ag-xq__a{display:block !important;}
  }
```
```js
    btn.addEventListener("click", function () {
      var open = btn.getAttribute("aria-expanded") !== "true";
      busy = true;
      root.classList.add("is-bulk");
      items.forEach(function (d) { d.open = open; });
      W.setTimeout(function () { busy = false; root.classList.remove("is-bulk"); }, 80);
      sync();
      refresh();
    });
    items.forEach(function (d) {
      d.addEventListener("toggle", function () { if (!busy) { sync(); refresh(); } });
    });
    /* v1.1.0: высота ответа меняется переходом — пересчитать позиции анимаций ниже по окончании */
    root.addEventListener("transitionend", function (e) {
      if (e.propertyName === "height" && e.pseudoElement === "::details-content") refresh();
    });
```
Флаг `busy` снимается **таймером 80 мс**: событие `toggle` приходит асинхронно, иначе «Раскрыть все» запускает 10 переходов.

## 5. F29 — зерно бумаги (только ≥ 640 px)
```css
  /* F29 · зерно бумаги (статично, только ≥ 640 px; forced-colors и печать — без зерна) */
  @media (min-width:640px){
    #ag-dir07-06 .ag-xp{position:relative;}
    #ag-dir07-06 .ag-xp::before{content:"";position:absolute;inset:0;z-index:0;pointer-events:none;opacity:.12;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='180' height='180'%3E%3Cfilter id='g'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='.85' numOctaves='2' stitchTiles='stitch'/%3E%3CfeColorMatrix values='0 0 0 0 .04 0 0 0 0 .035 0 0 0 0 .03 0 0 0 .5 0'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23g)'/%3E%3C/svg%3E");background-size:180px 180px;}
    #ag-dir07-06 .ag-xp__wrap{position:relative;z-index:1;}
  }
  @media (forced-colors:active){#ag-dir07-06 .ag-xp::before{display:none;}}
  @media print{#ag-dir07-06 .ag-xp::before{display:none;}}
```

## 6. Шаблоны поведения
- **Только мышь:** `matchMedia("(min-width: 1024px) and (hover: hover) and (pointer: fine)")` + `pointerenter` с `e.pointerType === "mouse"`; при `change` медиазапроса — сброс состояний и `anim.cancel()`.
- **Текущий шаг по прокрутке (телефон):** `IntersectionObserver` с `rootMargin: "-45% 0px -50% 0px"`, шаг становится текущим через 180 мс. Один источник: на телефоне — прокрутка, на ПК — наведение.
- **WAAPI по точкам:** 24–28 ключевых кадров `transform: translate(x,y)`, `easing:"linear"`, плавность закладывается в выборку точек; перебивание — с текущей точки (`anim.currentTime / dur`), одна анимация, без очереди.
- **reduce на лету:** проверять `matchMedia("(prefers-reduced-motion: reduce)").matches` в момент события, а не один раз.
- **Смена раскладки 1023/1024:** класс `is-jump` (без перехода) при первой установке, `ResizeObserver`, смене медиазапроса.
- **forced-colors:** подложки скрыть, выбранное — `outline`/`Highlight`, остальное `GrayText`.
- **Печать:** ответы FAQ раскрыты, декоративное скрыто.
- **Таймеры вместо rAF** там, где стандарт проекта этого требует (подгонка подписей, снятие флагов).

## 7. Грабли, на которых уже спотыкались
| Что | Как избежать |
|---|---|
| Педаль/маркер оставался невидимым после быстрых наведений (состояние «гаснет» не сбрасывалось) | пока элемент гаснет, переход считать «не по ходу» и начинать заново; проверять серию быстрых действий |
| Уходящая панель вкладок 180 мс оставалась в Tab | `tabindex="0"` только у выбранной панели |
| Неразрывный пробел «для&nbsp;взрослых» давал +43 px на 320 | неразрывный пробел — только перед тире |
| Подпись вкладки переносилась на 390 | `nowrap` от 375 px, на 320–374 — перенос с `text-wrap:balance` |
| Пунктирный кружок читался как «загрузка» | сплошной контур |
| Тон дорожек на телефоне не различался | разница яркости ≥ 1,3 (#141417 → #222226) |
| Тест: `endsWith(', 0)')` совпадал с `rgb(0, 0, 0)` | проверять альфу `rgba(…, 0)` |
| Тест: `hover()` Playwright ждёт стабилизации и ломает проверку анимации | `mouse.move` |
| Тест: касание мимо элемента ниже экрана | `scrollIntoView({block:'center'})` перед касанием |
| Тест: клик сразу после `emulateMedia(reduce)` терялся | пауза 120 мс |
| Тест FAQPage по номеру вопроса | сверять по названию вопроса (в HEAD бывает не весь FAQ) |
| HEAD-генератор фазы 1 смотрит на v1.0.0 | генераторы проходов `passes/*/gen_head_*_v11.py` |
| Блок вставлен не на ту страницу (CL04 на `/cycle-samara`) / дубль вместо другого блока (`/mma`) | в странице копирования — «сейчас там» и контрольный заголовок; сверка теста после установки |

## 8. Проверочные пороги
- `getAnimations({subtree:true})` = 0 через 0,6–1,3 с после серии быстрых действий.
- Контраст текста ≥ 4,5 (жёлтый текст на бумаге — нельзя).
- Высота: по каждому блоку на 390 и 1440 «до/после», плюс 320/360/599/600/768/1023/1024.

## 9. Профиль В — без кода
- **Движок:** скопировать целиком из `engine_template.html` комплекта (или из конца любого блока v1.0.x — он такой же) и вставить последним, ничего не меняя. Пользователь проверяет `stand_offline.html` («Движок символ в символ: да»).
- **iOS-нажатие (F23):** в первый скрипт блока, после строки `var root = …closest(".ag-scope");` и проверки `if (!root) return;`:
```js
    /* iOS включает :active только при слушателе касания (F23) */
    root.addEventListener("touchstart", function () {}, { passive: true });
```
- **Обёртка подписи кнопки:** `<a class="ag-btn ag-btn--primary" …><span class="ag-btn__in">Текст<svg…></svg></span></a>` + CSS из раздела 2.
- **Фокус 3 px:** в правиле `#ag-…-NN.ag-scope :is(a,button):focus-visible{outline:2px …}` заменить `2px` на `3px` (и в особых правилах блока).
- **Магнит:** удалить атрибут `data-ag-magnetic="…"`.
- **Пример отчёта `test_audit_console.js`** (что прислать ассистенту):
```
URL: https://apolloboxing.tilda.ws/cycle-samara
Title: Сайкл и сайклинг в Самаре — студия Apollo NoFitness
Description: Сайкл (сайклинг) в Самаре на Молодогвардейской, 56: …
JSON-LD (sha256 без пробелов): 402a1d78…

rec | type | root | block | ver | sha256_nows | hidden | h1
rec4002221001 | 1370 | ag-dir07-01 | DIR07-01 | 1.1.0 | d2c86a5a714fd3a3… | нет | 1
rec4002337501 | 1370 | ag-dir07-02 | DIR07-02 | 1.1.0 | b08a4425d898810a… | нет | 0
```
Сверка: `sha256_nows` = колонке `sha256_nows` в `data/BLOCKS_STATE.csv` (или в README комплекта) → «стоит»; иначе — другая версия; `hidden: ДА` → блок заменить срочно.
