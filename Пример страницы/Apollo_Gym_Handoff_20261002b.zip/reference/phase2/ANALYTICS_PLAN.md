# План аналитики · Метрика, трекер `data-ag-track`, согласие

**Состояние на 29.09.** В блоках 1 362 атрибута `data-ag-track` с `data-ag-params`, 41 имя цели (CODE_AUDIT, раздел «Цели»). Обработчика нет, в Метрику ничего не уходит (I165).

**Решение Ф5:**
- сайтовый трекер в HEAD сайта, один на сайт;
- 12 целей, остальные имена — параметрами;
- до согласия ничего не отправляется;
- цель заявки не задваивается.

Черновик трекера — `work/build/site_tracker.html` v1.0.0. Он проверен стендом `harness/t_tracker.js`: 5/5 pass, на тест не установлен.

## 1. Подключение Метрики

1. Счётчик создаёт владелец или пользователь в Метрике. Номер вводится **только** в Tilda: «Настройки сайта → Аналитика → Яндекс Метрика». В документах и коде — плейсхолдер, трекер находит номер сам (`window.yaCounterNNN`).
2. Вебвизор — по решению. Если включён, поля имени и телефона формы несут класс `ym-disable-keys`, их блоки — `ym-hide-content`. Это патч REQUEST-02. Посетителей нужно информировать в политике.
3. Плашка cookie Tilda (T972) — решение К11 (вопрос 2.11). Когда она стоит, Метрика из настроек не грузится до согласия. Трекер тогда копит события до 60 с и сбрасывает, если Метрика так и не появилась. Отправки до согласия нет.
4. Автоцели Метрики — клик по телефону, отправка формы, мессенджеры — создаются сами. Для отчётов берём наши цели, автоцели не удаляем.

## 2. Двенадцать целей

| Цель Метрики | Что значит | Имена `data-ag-track` | Ключевые параметры |
|---|---|---|---|
| `request_success` | заявка ушла — **главная конверсия** | событие формы `tildaform:aftersuccess`; страховка — приход на `/request-sent` со свежей меткой | `page`, `src` |
| `request_start` | пошёл к записи | `request_start`, `request_open` | `club`, `direction`, `trainer`, `who`, `from`, `intent` |
| `phone_click` | звонок или сохранение номера | `phone_click`, `request_call`, `phone_copy`, `contact_save` | `from`, `page`, `src` |
| `route_click` | построить маршрут | `route_click`, `route_open` | `club`, `map`, `from` |
| `schedule_view` | смотрел расписание | `schedule_open`, `schedule_view`, `schedule_filter` | `club`, `direction`, `from` |
| `price_view` | смотрел цены | `price_view`, `prices_open`, `price_jump`, `price_pick`, `personal_view` | `direction`, `from`, `to` |
| `club_select` | выбрал зал | `club_select`, `club_pick`, `map_select_club` | `club`, `from` |
| `direction_select` | выбрал направление | `direction_select`, `direction_view`, `kids_view`, `fitbox_open`, `directions_open` | `direction`, `club`, `from` |
| `trainer_view` | открыл тренера | `trainer_open`, `trainer_view` | `trainer`, `from` |
| `faq_open` | открыл ответ | `faq_open`, `faq_jump`, `faq_filter` | `q`, `role`, `from` |
| `outbound_click` | ушёл на внешний сайт или событие | `outbound_click`, `events_open`, `camp_view`, `tournament_view` | `target`, `event`, `from` |
| `feature_use` | пользовался фишкой страницы | `technique_pair`, `compare_vs`, `home_select_goal`, `first_training_guide` | `pair`, `vs`, `goal`, `from` |
| — (только параметры визита) | навигация внутри сайта | `nav_click`, `nav_open`, `page_jump`, `request_submit` | `to`, `tab`, `from` |

**Составная цель** в интерфейсе Метрики: `request_start` → `request_success`. Это воронка записи.

**Цель Tilda для формы.** Если Tilda шлёт виртуальную страницу `/tilda/formXXX/submitted/`, в Метрике не заводить по ней вторую цель: конверсия — `request_success`. Проверить на тесте, приходит ли она (I051).

**Параметры** — только ключи белого списка:

`club direction trainer who days from to tab q goal map target event role pair vs intent page action src`

Строка обрезается до 80 знаков. Имя, телефон и комментарий не передаются никогда — проверено тестом.

## 3. Правила для новых блоков

- Имя цели — из столбца «Имена» таблицы выше. Новое имя — только добавлением в карту `MAP` трекера (новая версия) и в эту таблицу.
- Вариант — параметром, а не новым именем: `from` (откуда), `club`, `direction`.
- `data-ag-params` — корректный JSON в одинарных кавычках атрибута. Аудит проверяет: сейчас 0 ошибок.
- Слияния, которые стоит сделать в проходах страниц (новые имена не нужны): `route_open` → `route_click`, `nav_open` → `nav_click`, `schedule_view` → `schedule_open`, `prices_open` → `price_view`, `club_pick` / `map_select_club` → `club_select`. Трекер уже сводит их в одну цель, так что это чистка, не срочно.

## 4. Установка трекера — когда пользователь скажет

1. Проверить, что Метрика подключена в «Настройки сайта → Аналитика».
2. Код `build/site_tracker.html` целиком → «Настройки сайта → Ещё → HTML-код для вставки внутрь head» → Сохранить → опубликовать все страницы. Код в HEAD сайта применяется только после публикации.
3. В Метрике завести 12 целей типа «JavaScript-событие» с идентификаторами из таблицы и составную цель.
4. Проверка на тесте:
   - открыть страницу с `?_ym_debug=2`, кликнуть «Записаться», телефон, маршрут — в консоли видны `reachGoal`;
   - отправить тестовую заявку — `request_success` один раз;
   - через 1–2 часа цели видны в отчёте «Конверсии».
5. Если стоит плашка cookie — без согласия в консоли пусто, после согласия события уходят.

## 5. Отчёты, которые нужны владельцу

| Вопрос | Отчёт |
|---|---|
| Сколько заявок и откуда | цель `request_success` × источники трафика; параметры `club`, `direction` |
| Какой зал выбирают | `club_select`, `request_start.club` |
| Что смотрят перед записью | воронка `price_view` / `schedule_view` → `request_start` → `request_success` |
| Звонят или пишут | `phone_click` против `request_success` |
| Работают ли фишки страниц | `feature_use` по `from` |
| Какие вопросы открывают | `faq_open.q` — кандидаты в текст страницы |

## 6. Хвосты

- I051 — дубль цели формы Tilda: проверить после установки.
- I101 — цели `phone_copy`, `contact_save`, `map_select_club`, `page_jump`, `outbound_click` не было в таблице BLOCK_PATTERNS. Закрывается этим планом.
- I142 — `replaceState` на `/schedule`: не считает ли Метрика смену адреса новым просмотром. Проверить в Вебвизоре или «Посещаемости» после установки.
- [?] Сохраняются ли параметры `ym(…,'params')` для навигации без цели — проверить в «Параметрах визитов».
