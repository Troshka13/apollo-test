# Стенд Playwright · как пользоваться в фазе 2

Стенд лежит в `work/harness/` архива. Он собирает страницу, похожую на Tilda (обёртка `t-rec`, T123, шапка и подвал v9), подменяет сеть и гоняет проверки в Chromium. tildacdn, Яндекс и Google Fonts из среды недоступны, поэтому:
- шрифты берутся локально из `@fontsource`;
- GSAP — из `node_modules`;
- кадры — из `harness/media`;
- карта — заглушка.

## 1. Установка

```
bash /home/claude/work/tools/bootstrap.sh      # npm install, playwright, проверка chromium, дымовой прогон
```

- Chromium уже стоит в `/opt/pw-browsers`. `playwright install` не запускать.
- Путь к Chromium в `launch()` задан явно (`/opt/pw-browsers/chromium-1194/…`); если его нет — Playwright берёт браузер из `PLAYWRIGHT_BROWSERS_PATH`.
- Playwright ищется так: сначала локально (`require.resolve('playwright')`), потом глобально (`/home/claude/.npm-global/lib/node_modules/playwright`). bootstrap ставит его локально, если нет нигде.
- `APOLLO_WORK` — корень `work/`. По умолчанию это папка над `harness/`.

## 2. Файлы

| Файл | Роль |
|---|---|
| `h<page>.js` (`hcl01.js` … `hwomen.js`, `hreq.js`, `hsent.js`) | сборщик страницы: список блоков, записи, адрес, подмена кадров `STAND` |
| `hpage.js` | общий сборщик по префиксу `PAGE=…` (TR, PRIVACY, CONSENT, NOTFOUND, любой другой). Берёт **последнюю версию** каждого блока (фаза 2) |
| `h.js`, `hf*.js`, `hh.js` | сборщики шапки, подвала и главной (история фазы 1) |
| `tcommon.js` | общие проверки: `scrollThrough`, `hiddenText`, `layoutIssues`, `smallTargets`, `axe`, `contrast`, ширины |
| `t_<page>.js` | тест страницы: группы L/T/A/M/F/G/H/S/J |
| `t_trainer.js` (`PAGE=TR03`), `t_docs.js` (`PAGE=PRIVACY\|CONSENT\|NOTFOUND`) | тесты генерируемых страниц |
| `t_cdn_hang.js` | **фаза 2:** висящий cdnjs — `PAGE=CL01 [HANG=8000] node t_cdn_hang.js` |
| `t_tracker.js` | **фаза 2:** сайтовый трекер целей — `PAGE=CL01 node t_tracker.js` |
| `shot_<page>_full.js` + `crop_<page>.py` / `crop_each_<page>.py` | снимки fullPage 1440 и 390 и обрезка по блокам |
| `media/` | подменные кадры: `clubs/` (по залам), `dirs/`, `clip.webm` |
| `out_<page>/` | снимки и журналы; в архив не входят |

## 3. Группы проверок

| Группа | Что проверяет |
|---|---|
| L | 320–1920 px × 3 шрифта (Oswald/Manrope, Arial, широкий системный): нет горизонтальной прокрутки, ничего за краем, слова не рвутся; высоты блоков; бюджет 390 px |
| T / A | цели ≥ 44×44 (ссылка в предложении ответа — исключение); axe WCAG 2.2 AA на 1440 / 1024 / 390 / 390 reduce, после взаимодействий, без JS (ст. 160) |
| M | GSAP грузится один раз; все `data-ag-anim` отсканированы; без JS, при reduce и при заблокированном cdnjs весь текст виден |
| F | функции страницы: вкладки, стрелки, свайп, карта, якоря и старые хэши, «Раскрыть все», подгонка H1 на 320 px |
| G | каждый блок один на пустой странице: фон, Oswald, акцент, движение (закон 13) |
| H | с шапкой и подвалом: один H1, id не повторяются, ссылки только на живые страницы, `/request` и `/schedule` с ключом зала |
| S | размер < 100 000 байт, движок символ в символ; нет `var(--ag-`, `:where(`, `:has(`, `opacity:0`, `@keyframes`, своих rAF; селекторы от корня; запреты текста, имена «не публикуются» |
| J | JSON-LD: типы, адрес, вопросы FAQ слово в слово с блоком; нет `openingHours`, отзывов, `geo`, `Person`. Есть не во всех тестах — раздел 9 |
| C | (фаза 2) висящий CDN — `t_cdn_hang.js` |

Запуск:

```
cd /home/claude/work/harness
timeout 1800 node t_cl03.js > run1.txt 2>&1        # все группы; tail -40 run1.txt
ONLY=L,A node t_cl03.js                             # часть групп
PAGE=TR03 node t_trainer.js
PAGE=CL03 node t_cdn_hang.js
```

Полный прогон страницы — 10–25 минут. Группы L и A самые долгие.

## 4. Новая версия блока в фазе 2

Сборщики страниц фазы 1 знают версии блоков. Пример — `hcl03.js`:

```js
const VER = process.env.CLVER || 'v1.0.0';
const DEF = { 3: 'v1.0.2', 4: 'v1.0.1' };            // версии по умолчанию
const BLK = [1..9].map((n) => `${WORK}/CL03-0${n}_${(process.env['CLVER'+n] || DEF[n] || VER)}.html`);
```

Новая версия блока:
- разово — `CLVER5=v1.1.0 node t_cl03.js`;
- навсегда — добавить в `DEF`.

В сборщиках других страниц имена переменных свои: смотреть первые 20 строк `h<page>.js`. `hpage.js` берёт последнюю версию сам.

Тест `t_<page>.js` сверяет фишки и тексты фазы 1 (группа F, списки запретов S). Если проход меняет текст или функцию, тест правится в той же сессии. Проверка, которая стала неверной, не удаляется молча — в ответе пишется, что изменено и почему.

## 5. Новая страница или новый блок

1. Простой путь — `hpage.js`: `PAGE=<префикс> node t_trainer.js`, или свой короткий тест по образцу `t_docs.js`.
2. Страница со своими функциями — скопировать `hcl03.js` → `h<page>.js`: файлы блоков, id записей, адрес `https://apollo.test/<slug>`, таблица `STAND`. Затем `t_cl03.js` → `t_<page>.js`: `IDS`, `NOENGINE`, `BUDGET`, проверки F, списки S.

## 6. Настоящие кадры на стенде

Кадры владельца и новые кадры фазы 2 кладутся в `harness/media/<страница>/` (WebP после `media_prep.py`). В `h<page>.js` таблица `STAND` сопоставляет имя файла на tildacdn и локальный файл:

```js
const STAND = { 'Zal_4-1024x683.jpg': 'media/clubs/c1_1.webp', … };
```

- Адреса `static.tildacdn.pub/…` подменяются в `route`. `static.tildacdn.com/…` — тоже нужно добавить, если кадр загружен туда.
- Без записи в `STAND` кадр становится пикселем-заглушкой. Раскладка при этом проверяется, вид — нет.

После подмены: прогон L, бюджет 390 px, снимки.

## 7. Снимки

```
node shot_cl03_full.js            # fullPage 1440 и 390 + границы блоков → out_cl03/
python3 crop_cl03.py              # группы по три блока до ~3100 px
```

Снимок отдельного элемента сдвигается, поэтому только обрезка fullPage (ст. 64). Каждый снимок посмотреть глазами (Read) до отправки. Отдавать показом: `SendUserFile`, `display: render`.

## 8. Частые ловушки

- `page.goto` висит: страница ждёт `load`, а GSAP задержан. Нужен `waitUntil: 'domcontentloaded'` (опция `newPage`).
- axe «без JS» — только страница с вырезанными `<script>` (`stripScripts`), не `javaScriptEnabled:false` (ст. 160).
- Ховер мерить после 320 мс (ст. 21); высоты колонок — с reduce (ст. 26); раскладку — по `offset*`, не `getBoundingClientRect` (ст. 83).
- MutationObserver для журнала атрибутов ставится на `document` в init-скрипте (ст. 160).
- Бейдж и ленты: `padding-top`, не `margin-top` (ст. 155).
- Отладочные скрипты `_*.js` и `m*.js` — черновики фазы 1. `_*.js` в архив не входят.

## 9. Покрытие стенда по страницам (29.09)

| Страница | Сборщик | Тест | Группа J | Снимки fullPage | Обрезка | Генератор JSON-LD |
|---|---|---|---|---|---|---|
| `/` | `hh.js` + `hf*.js` (история) | **нет**: старые `t_hero`, `t_fork`, `t_start`, `t_events*` ссылаются на заменённые версии блоков — для истории; первый проход главной начинается с `t_home.js` по образцу `t_cl03.js` | нет | нет | нет | **нет** |
| `/boxing` | `hcl01.js` | `t_cl01.js` | **нет** | частично (`shot_cl01.js`, без границ блоков) | нет | **нет** |
| `/boxing-samara` | `hdir01.js` | `t_dir01.js` | **нет** | частично (`shot_dir01.js`) | нет | да |
| `/prices` | `hprices.js` | `t_prices.js` | **нет** | частично (`shot_prices.js`) | нет | да |
| `/schedule` | `hschedule.js` | `t_schedule.js` | да | частично (`shot_schedule.js`) | нет | да |
| `/kids` | `hkids.js` | `t_kids.js` | **нет** | да | да | да |
| `/request` | `hreq.js` | `t_req.js`, `t_req_days.js` | — (графа нет) | нет | нет | не нужен |
| `/request-sent` | `hsent.js` | `t_sent.js` | — (графа нет) | частично (`shot_sent.js`) | нет | не нужен |
| `/trainer-…` | `hpage.js` | `t_trainer.js` (`PAGE=TRnn`) | в тесте — JSON-LD после открытия | через `hpage.js` | `crop_page.py` | `gen_trainers.py` |
| `/privacy-policy`, `/consent`, `/page-not-found` | `hpage.js` | `t_docs.js` | — | через `hpage.js` | `crop_page.py` | не нужен |
| остальные 23 страницы (CL02–04, DIR02–08, KIDSBOX, WOMEN, FIRST, PERSONAL, TOURNAMENTS, CAMPS, TRAINERS, CLUBS, DIRECTIONS, ABOUT, CONTACTS, RULES, REVIEWS) | `h<page>.js` | `t_<page>.js` | да | да | да | да |

Чего нет — дописывается в первом проходе страницы:
- группа J — по образцу `t_cl03.js`;
- `shot_<page>_full.js` — копия `shot_cl03_full.js` с другим сборщиком;
- обрезка — `crop_page.py`;
- генератор графа — по образцу `gen_cl03_jsonld.py`: воспроизвести текущий граф, `diff` пустой, потом правки.
