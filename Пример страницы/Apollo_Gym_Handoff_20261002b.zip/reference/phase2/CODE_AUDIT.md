# Аудит кода блоков · 29.09.2026

Метод: 316 блоков из DATA/BLOCKS_INVENTORY.csv (54 страницы + шапка и подвал), 29 `XX_head_jsonld.html`, 20 `TRnn_head.html`. Python 3, `html.parser`: комментарии, `<script>`, `<style>` не считаются разметкой и текстом, элементы из JS не видны. Скрипт — `work/tools/code_audit.py`: без аргументов — сводка, `--md файл` — разделы 1–10 и «Цели» (ниже — его вывод). «Главное» — вручную.

## Главное

1. **Высокий · цели не уходят в Метрику.** `data-ag-track` — 1 362 атрибута, 41 цель, 303 блока из 316. `ym(` / `reachGoal` / `dataLayer` — 0 блоков; кода, который читает атрибуты и шлёт цель, нет. Сделать: один общий обработчик кликов (track + params → `reachGoal`). Мнение: слить близкие имена — route_click/route_open, nav_click/nav_open, schedule_open/schedule_view, price_view/prices_open, club_select/club_pick/map_select_club.
2. **Высокий · страницы без входящих ссылок.** На /about, /rules, /reviews не ведёт ни одна ссылка, на /privacy-policy — только с неё самой. /directions, /clubs, /contacts — с 1–3 второстепенных страниц (/page-not-found, /about, /reviews, TR02). Шапка и подвал не ведут ни на одну из семи. Сделать: добавить в подвал к публикации (HOME-01 откладывает ссылку на /clubs до публикации). 20 тренерских — тоже без ссылок, но под `noindex, follow`.
3. **Высокий · «бесплатно» на каждой странице.** 138 блоков, 146 вхождений; шапка (3) и подвал (1) дают «Первое групповое занятие — бесплатно.» на всех 54 страницах, в том числе на /kids, /kids-boxing, /cycle-samara, где своих вхождений нет. Для детей и сайкла условие не подтверждено (OWNER_QUESTIONS.md 7.1, ISSUES_REGISTER.csv I017). Сделать: закрыть вопросы до публикации; мнение: при ответе «нет» править 4 места в шапке и подвале.
4. **Высокий (скорость) · 295 копий движка.** Код один, 10,4 КБ; всего 3 071 КБ — 34 % кода блоков. Работает одна копия на страницу, лишних 242 (2 520 КБ); на главной 11 лишних, 114,5 КБ из 465,6. Мнение: вынести движок в общий код сайта, в блоках оставить `ApolloMotion.scan`. Это против правила автономных блоков — решать вам.
5. **Средний · вес HTML.** Главная: 465,6 КБ + 112,5 КБ шапки и подвала = 578 КБ; клубы и направления — 220–279 КБ + 112,5. По сайту: движок 34 %, `<style>` 30 %, комментарии 8 % (729 КБ). Мнение: вырезать комментарии при сборке к публикации — минус 8 % без риска.
6. **Средний · шапка — 89 % лимита T123** (88 585 байт: CSS 31,5 КБ, JS 18 КБ, комментарии 1,7 КБ, остальное — меню). Следующий — TRAINERS-03, 77 %. Мнение: новые пункты меню — после деления шапки на два T123 или ужатия CSS.
7. **Средний · картинки.** 148 `<img>`, srcset — 0; jpg/jpeg 138, webp 7, png 2. 31 картинка главной (HOME-03 — 25, HOME-04 — 6): в `src` gif 1×1, адрес в `data-ag-src` — без JS виден только gif. Мнение: эти 31 — на обычный `src` + `loading="lazy"`, как у 92 других; для srcset проверить, какие размеры отдаёт CDN Tilda.
8. **Средний · JSON-LD.** 29 графов, ошибок 0. Нигде нет geo, openingHours(Specification), aggregateRating, Person, Event, ExerciseGym. `description` узла `/boxing#club` в CL01 расходится с пятью другими графами; /mma, /gym, /nofitness везде одинаковы. Сделать: один description на @id. Мнение: geo и часы залов — первыми, когда данные подтверждены.
9. **Исправлено 29.09 · /consent.** В первой версии CSV блоки CONSENT-01…03 стояли на /privacy-policy, отсюда «2 H1». Страница /consent заведена в BLOCKS_INVENTORY.csv, таблицы ниже пересчитаны: у каждой страницы один H1.
10. **Низкий · первый экран.** fetchpriority="high" — 22 кадра, все в первых блоках, без lazy; у 30 страниц в первом блоке нет `<img>`. У 4 LCP-кадров alt="" (WOMEN-01, FIRST-01, PERSONAL-01, REQUEST-01) — мнение: дать alt. H1 анимирован на 53 из 53 (rise 51, split 2): после загрузки GSAP видимый H1 уходит в opacity 0 и появляется заново — мнение: проверить влияние на LCP в PageSpeed.
11. **Низкий · сторонние домены.** GSAP — cdnjs.cloudflare.com (295 блоков), шрифты — fonts.googleapis.com и gstatic (316 блоков, один URL, 8 начертаний). CSS ничего не прячет до GSAP, при сбое движок выключается через 2 с. Мнение: GSAP — на CDN Tilda, начертания — сократить.
12. **Низкий · видео и карты.** HOME-02: 4 `<video>`, у 3 пустой источник, poster — 0, preload="none". Карты — iframe yandex.ru в 8 блоках; 7 грузят их через JS с запасным `<noscript>`, CL01-07 — src сразу. Мнение: poster ролику, CL01-07 — по схеме CL02–CL04-07.

Без замечаний: пропусков уровней заголовков 0, «Подробнее» 0, `<img>` без alt 0, превышений T123 0. 12 картинок без размеров — фоновые копии в CL03-06 в рамке с aspect-ratio в CSS.

## Таблица по страницам

Порядок и «первый блок» — по CSV. `<link>` — css2 Google Fonts без preconnect. В скобках — доля лимита T123. Без размеров — нет width+height и aspect-ratio в style. LCP «да» — в первом блоке `<img fetchpriority="high">`, «нет img» — в первом блоке нет `<img>`. Тренеры — кодом TRnn.

| страница | блоков | с движком | `<link>` шрифтов | вес КБ | самый тяжёлый блок | h1 | img | img без размеров | LCP с fetchpriority |
|---|---:|---:|---:|---:|---|---:|---:|---:|---|
| все страницы | 2 | 0 | 2 | 112.5 | GLOBAL-HEADER (89%) | — | 2 | 0 | — |
| / | 12 | 12 | 12 | 465.6 | HOME-04 (53%) | 1 | 61 | 0 | да |
| /boxing | 9 | 7 | 9 | 229.7 | CL01-01 (36%) | 1 | 5 | 0 | да |
| /mma | 9 | 7 | 9 | 233.0 | CL02-04 (41%) | 1 | 7 | 0 | да |
| /gym | 9 | 7 | 9 | 234.1 | CL03-04 (36%) | 1 | 20 | 12 | да |
| /boxing-samara | 9 | 9 | 9 | 278.5 | DIR01-07 (40%) | 1 | 4 | 0 | да |
| /prices | 6 | 6 | 6 | 197.3 | PRICES-04 (41%) | 1 | 0 | 0 | нет img |
| /schedule | 4 | 4 | 4 | 175.3 | SCHEDULE-02 (71%) | 1 | 5 | 0 | да |
| /nofitness | 9 | 7 | 9 | 235.4 | CL04-04 (40%) | 1 | 5 | 0 | да |
| /muay-thai-samara | 8 | 8 | 8 | 237.2 | DIR02-02 (35%) | 1 | 4 | 0 | да |
| /kickboxing-samara | 8 | 8 | 8 | 252.0 | DIR03-02 (42%) | 1 | 1 | 0 | да |
| /mma-samara | 9 | 9 | 9 | 260.3 | DIR04-03 (34%) | 1 | 3 | 0 | да |
| /grappling-samara | 8 | 8 | 8 | 220.1 | DIR05-04 (34%) | 1 | 2 | 0 | да |
| /functional-training | 8 | 7 | 8 | 226.6 | DIR06-03 (36%) | 1 | 2 | 0 | да |
| /cycle-samara | 8 | 7 | 8 | 222.6 | DIR07-04 (36%) | 1 | 1 | 0 | да |
| /stretching-samara | 8 | 7 | 8 | 234.5 | DIR08-02 (35%) | 1 | 1 | 0 | да |
| /kids | 8 | 7 | 8 | 216.3 | KIDS-01 (35%) | 1 | 5 | 0 | да |
| /kids-boxing | 7 | 6 | 7 | 181.2 | KIDSBOX-01 (34%) | 1 | 3 | 0 | да |
| /women | 8 | 7 | 8 | 228.7 | WOMEN-02 (52%) | 1 | 2 | 0 | да |
| /first-training | 6 | 5 | 6 | 165.0 | FIRST-02 (33%) | 1 | 1 | 0 | да |
| /personal-training | 6 | 5 | 6 | 168.2 | PERSONAL-02 (36%) | 1 | 1 | 0 | да |
| /tournaments | 6 | 5 | 6 | 155.6 | TOURNAMENTS-02 (35%) | 1 | 1 | 0 | да |
| /camps | 6 | 5 | 6 | 162.6 | CAMPS-01 (33%) | 1 | 0 | 0 | нет img |
| /trainers | 5 | 5 | 5 | 188.7 | TRAINERS-03 (77%) | 1 | 0 | 0 | нет img |
| /clubs | 6 | 6 | 6 | 186.0 | CLUBS-02 (38%) | 1 | 4 | 0 | да |
| /directions | 6 | 6 | 6 | 168.4 | DIRECTIONS-02 (40%) | 1 | 0 | 0 | нет img |
| /about | 6 | 6 | 6 | 142.3 | ABOUT-02 (30%) | 1 | 2 | 0 | нет img |
| /contacts | 3 | 3 | 3 | 116.2 | CONTACTS-02 (53%) | 1 | 4 | 0 | нет img |
| /rules | 3 | 2 | 3 | 68.4 | RULES-02 (32%) | 1 | 0 | 0 | нет img |
| /reviews | 3 | 3 | 3 | 91.4 | REVIEWS-01 (45%) | 1 | 0 | 0 | нет img |
| /privacy-policy | 3 | 3 | 3 | 66.4 | PRIVACY-01 (25%) | 1 | 0 | 0 | нет img |
| /consent | 3 | 3 | 3 | 67.0 | CONSENT-01 (25%) | 1 | 0 | 0 | нет img |
| /page-not-found | 2 | 2 | 2 | 47.5 | NOTFOUND-01 (26%) | 1 | 0 | 0 | нет img |
| /request | 2 | 2 | 2 | 102.7 | REQUEST-02 (70%) | 1 | 1 | 0 | да |
| /request-sent | 3 | 3 | 3 | 93.4 | SENT-01 (41%) | 1 | 1 | 0 | нет |
| TR01 | 4 | 4 | 4 | 105.8 | TR01-01 (36%) | 1 | 0 | 0 | нет img |
| TR02 | 4 | 4 | 4 | 108.2 | TR02-01 (36%) | 1 | 0 | 0 | нет img |
| TR03 | 5 | 5 | 5 | 133.5 | TR03-01 (36%) | 1 | 0 | 0 | нет img |
| TR04 | 5 | 5 | 5 | 133.6 | TR04-01 (36%) | 1 | 0 | 0 | нет img |
| TR05 | 5 | 5 | 5 | 130.6 | TR05-01 (36%) | 1 | 0 | 0 | нет img |
| TR08 | 5 | 5 | 5 | 133.5 | TR08-01 (36%) | 1 | 0 | 0 | нет img |
| TR09 | 5 | 5 | 5 | 133.4 | TR09-01 (36%) | 1 | 0 | 0 | нет img |
| TR10 | 5 | 5 | 5 | 133.7 | TR10-01 (36%) | 1 | 0 | 0 | нет img |
| TR11 | 5 | 5 | 5 | 133.6 | TR11-01 (36%) | 1 | 0 | 0 | нет img |
| TR12 | 5 | 5 | 5 | 133.6 | TR12-01 (36%) | 1 | 0 | 0 | нет img |
| TR13 | 5 | 5 | 5 | 133.0 | TR13-01 (36%) | 1 | 0 | 0 | нет img |
| TR14 | 5 | 5 | 5 | 133.1 | TR14-01 (36%) | 1 | 0 | 0 | нет img |
| TR15 | 5 | 5 | 5 | 133.0 | TR15-01 (36%) | 1 | 0 | 0 | нет img |
| TR16 | 5 | 5 | 5 | 133.3 | TR16-01 (36%) | 1 | 0 | 0 | нет img |
| TR17 | 5 | 5 | 5 | 133.0 | TR17-01 (36%) | 1 | 0 | 0 | нет img |
| TR19 | 5 | 5 | 5 | 130.6 | TR19-01 (36%) | 1 | 0 | 0 | нет img |
| TR20 | 5 | 5 | 5 | 130.9 | TR20-01 (36%) | 1 | 0 | 0 | нет img |
| TR22 | 5 | 5 | 5 | 131.1 | TR22-01 (37%) | 1 | 0 | 0 | нет img |
| TR23 | 5 | 5 | 5 | 131.7 | TR23-01 (37%) | 1 | 0 | 0 | нет img |
| TR24 | 5 | 5 | 5 | 130.8 | TR24-01 (36%) | 1 | 0 | 0 | нет img |
| **итого** | 316 | 295 | 316 | 9031.0 | | 54 | 148 | 12 | |

## 1. Вес, движок, шрифты

- Всего 9031.0 КБ в 316 файлах: комментарии 729.1 КБ (8%), `<script>` 3760.6 КБ, из них копии движка 3071.3 КБ (34%), `<style>` 2686.8 КБ (30%).
- Лимит T123: превышений 0; в зоне 80–100% — GLOBAL-HEADER 89%. Самые тяжёлые: GLOBAL-HEADER 86.5 КБ, TRAINERS-03 75.3 КБ, SCHEDULE-02 69.6 КБ, REQUEST-02 68.4 КБ.
- Движок (`window.ApolloMotion`): в 295 блоках из 316, код один (295 из 295 совпадают с engine_template.html без учёта пробелов). Без движка: GLOBAL-HEADER, GLOBAL-FOOTER, CL01-07, CL01-09, CL02-07, CL02-09, CL03-07, CL03-09, CL04-07, CL04-09, DIR06-07, DIR07-07, DIR08-07, KIDS-07, KIDSBOX-06, WOMEN-07, FIRST-05, PERSONAL-05, TOURNAMENTS-05, CAMPS-05, RULES-03.
- Лишние копии движка (остальные видят `window.ApolloMotion` и выходят) — 241 шт. на 54 страницах, 2509.1 КБ; больше всего на /: 11 шт., 114.5 КБ.
- Google Fonts: `<link rel="stylesheet">` в 316 блоках, URL один на все: `…family=Oswald:wght@500;600;700&family=Manrope:wght@400;500;600;700;800&display=swap`. preconnect к fonts.*: 632 в 316 блоках.

## 2. Заголовки

- Ровно один H1 и он в первом блоке: 54 из 54 страниц.
- Шапка и подвал: GLOBAL-HEADER — заголовков нет; GLOBAL-FOOTER — заголовков нет.
- Пропуски уровней внутри блока: 0. На стыке блоков по порядку CSV: 0.
- H1 первого блока с анимацией `data-ag-anim`: rise — 51, split — 3 (из 54).

| страница | H1 |
|---|---|
| / | Бокс и единоборства в Самаре |
| /boxing | Зал бокса с рингом на Галактионовской, 81 |
| /mma | Зал ММА и грэпплинга на Чкалова, 72 |
| /gym | Бокс и тайский бокс на Ново-Садовой, 106Б |
| /boxing-samara | Бокс в Самаре |
| /prices | Цены на бокс и единоборства в Самаре |
| /schedule | Расписание тренировок Apollo Gym в Самаре |
| /nofitness | Сайкл и функциональные тренировки на Молодогвардейской, 56 |
| /muay-thai-samara | Тайский бокс в Самаре |
| /kickboxing-samara | Кикбоксинг в Самаре |
| /mma-samara | ММА в Самаре |
| /grappling-samara | Грэпплинг в Самаре |
| /functional-training | Функциональные тренировки в Самаре |
| /cycle-samara | Сайкл в Самаре |
| /stretching-samara | Растяжка в Самаре |
| /kids | Единоборства для детей в Самаре |
| /kids-boxing | Детский бокс в Самаре |
| /women | Бокс и единоборства для девушек в Самаре |
| /first-training | Первая тренировка по боксу и единоборствам в Самаре |
| /personal-training | Персональные тренировки по боксу в Самаре |
| /tournaments | Турниры Apollo по единоборствам в Самаре |
| /camps | Сборы и выезды Apollo |
| /trainers | Тренеры Apollo Gym в Самаре |
| /clubs | Четыре зала Apollo Gym в Самаре |
| /directions | Направления Apollo в Самаре: единоборства и тренировки для формы |
| /about | Что такое Apollo Gym в Самаре |
| /contacts | Контакты Apollo Gym в Самаре |
| /rules | Правила клубов Apollo в Самаре |
| /reviews | Отзывы об Apollo Gym в Самаре |
| /privacy-policy | Политика обработки персональных данных |
| /consent | Согласие на обработку персональных данных |
| /page-not-found | Такой страницы нет |
| /request | Записаться на тренировку в Самаре |
| /request-sent | Заявка ушла, администратор перезвонит |

Тренеры: TR01 — Влад Агафонов; TR02 — Герман Корниенко; TR03 — Макар Панин; TR04 — Илья Миренков; TR05 — Дмитрий Смирнов; TR08 — Владислав Гуров; TR09 — Артур Котенков; TR10 — Никита Журавлёв; TR11 — Илья Долгих; TR12 — Софья Теплова; TR13 — Дмитрий Шкатов; TR14 — Евгений Пьянзин; TR15 — Марк Туманов; TR16 — Алексей Дудочкин; TR17 — Илона Тронь; TR19 — Алексей Узяков; TR20 — Андрей Махота; TR22 — Елизавета Гурылева; TR23 — Никита Скорняков; TR24 — Иван Моисеев.

## 3. Изображения

| `<img>` | без размеров | lazy | fetchpriority=high | alt="" | alt непустой | без alt | srcset | data-ag-src | в noscript |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 148 | 12 | 123 | 22 | 43 | 105 | 0 | 0 | 31 | 0 |

- `<img>` в 51 блоках. Адреса (у отложенных — из data-ag-src): static.tildacdn.* — 147; пустой src — 1 (SENT-01). Форматы на CDN: jpg — 105, jpeg — 33, webp — 7, png — 2.
- Отложенные (`src` — gif 1×1, адрес в `data-ag-src`, подставляет JS): HOME-03 — 25, HOME-04 — 6.
- Без размеров: CL03-06 — 12.
- alt="" по блокам: HOME-04 — 16, CL03-06 — 12, HOME-02 — 4, HOME-06 — 4, GLOBAL-HEADER — 1, GLOBAL-FOOTER — 1, WOMEN-01 — 1, FIRST-01 — 1, PERSONAL-01 — 1, REQUEST-01 — 1, SENT-01 — 1.
- fetchpriority="high": 22, все в первых блоках — да, вместе с lazy — нет. С alt="": FIRST-01, PERSONAL-01, REQUEST-01, WOMEN-01. С `data-ag-anim`: parallax — 15 (из них прячут opacity на старте: 0).
- Страниц без fetchpriority="high" в первом блоке: 32; первый блок с `<img>` — /request-sent; без `<img>` — 31.
- lazy в первом блоке: CLUBS-01. Фон через CSS `url(`: REQUEST-02 — `data:image/svg+xml,%3Csvg xmln…`.

## 4. Видео и iframe

| блок | `<video>` | источник | poster | preload | muted | playsinline | autoplay |
|---|---:|---|---|---|---|---|---|
| HOME-02 | 3 | адрес пуст | нет | none | да | да | нет |
| HOME-02 | 1 | static.tildacdn.com | нет | none | да | да | нет |

| блок | `<iframe>`: что | основной | в noscript | loading |
|---|---|---|---:|---|
| CONTACTS-02_v12.1.0 | yandex.ru/map-widget/v1/ | создаёт JS | 1 | lazy |
| CL01-07 | yandex.ru/map-widget/v1/ | src сразу | 0 | lazy |
| CL02-07 | yandex.ru/map-widget/v1/ | data-src → JS | 1 | lazy |
| CL03-07 | yandex.ru/map-widget/v1/ | data-src → JS | 1 | lazy |
| SCHEDULE-03 | yandex.ru/map-widget/v1/ | data-src → JS | 1 | lazy |
| CL04-07 | yandex.ru/map-widget/v1/ | data-src → JS | 1 | lazy |
| CLUBS-03 | yandex.ru/map-widget/v1/ | data-src → JS | 1 | lazy |
| CONTACTS-02_v12.2.0 | yandex.ru/map-widget/v1/ | data-src → JS | 1 | lazy |

## 5. Внутренние ссылки

- `href="/…"`: 879, уникальных путей 29; в `<noscript>` — 18; с `#` или `?` — 209.
- Пути не из списка страниц CSV: нет.
- Ссылки с текстом «Подробнее»: 0.
- Страницы CSV без входящих ссылок с других страниц и из шапки/подвала: /about, /rules, /reviews, /page-not-found, /request-sent, все страницы тренеров (20).

| путь | ссылок | с других страниц | шапка/подвал |
|---|---:|---:|---|
| /request | 231 | 49 | ✓ |
| /trainers | 70 | 41 | ✓ |
| / | 54 | 52 | ✓ |
| /prices | 52 | 40 | ✓ |
| /boxing | 50 | 28 | ✓ |
| /mma | 49 | 29 | ✓ |
| /boxing-samara | 45 | 26 | ✓ |
| /gym | 39 | 24 | ✓ |
| /nofitness | 36 | 21 | ✓ |
| /muay-thai-samara | 28 | 18 | ✓ |
| /kids | 25 | 14 | ✓ |
| /kickboxing-samara | 24 | 16 | ✓ |
| /mma-samara | 19 | 11 | ✓ |
| /functional-training | 19 | 11 | ✓ |
| /grappling-samara | 16 | 8 | ✓ |
| /personal-training | 16 | 11 | ✓ |
| /cycle-samara | 15 | 7 | ✓ |
| /stretching-samara | 15 | 7 | ✓ |
| /schedule | 15 | 8 | ✓ |
| /first-training | 13 | 8 | ✓ |
| /women | 10 | 7 | ✓ |
| /kids-boxing | 9 | 4 | ✓ |
| /tournaments | 8 | 4 | ✓ |
| /camps | 8 | 3 | ✓ |
| /contacts | 5 | 4 |  |
| /clubs | 4 | 3 |  |
| /privacy-policy | 2 | 1 |  |
| /directions | 1 | 1 |  |
| /consent | 1 | 1 |  |

## 6. Аналитика

- `data-ag-track` в разметке: 1362 в 303 блоках; `data-ag-params`: 1362; уникальных целей: 41; params, не читаемых как JSON: 0.
- JS дописывает (setAttribute) data-ag-params: CONTACTS-02_v12.1.0, SCHEDULE-03, WOMEN-02, WOMEN-08, CONTACTS-02_v12.2.0, REVIEWS-01, SENT-03; data-ag-track: SENT-01.
- getAttribute/`[data-ag-track]` в JS: WOMEN-08. `ym(` / `reachGoal` / `dataLayer`: нет ни в одном блоке.

## 7. JSON-LD

Файлов `XX_head_jsonld.html` без `_test`: 29, ошибок разбора: 0. «Вложенные» — типы из списка проверки ниже верхнего уровня; «pO» — `parentOrganization`.

| страницы | @type верхнего уровня | вложенные | pO |
|---|---|---|---|
| / | SportsOrganization, WebSite, SportsActivityLocation×4, WebPage, ItemList, FAQPage |  | ✓ |
| /boxing, /mma, /gym, /nofitness | SportsActivityLocation, WebPage, BreadcrumbList, FAQPage |  | ✓ |
| /boxing-samara, /muay-thai-samara, /kickboxing-samara, /mma-samara, /grappling-samara, /functional-training, /stretching-samara, /women | Service, WebPage, BreadcrumbList, FAQPage | Offer |  |
| /prices | WebPage, BreadcrumbList, OfferCatalog, Offer×4, FAQPage |  |  |
| /schedule | SportsOrganization, WebSite, SportsActivityLocation×4, WebPage, BreadcrumbList, ItemList |  | ✓ |
| /cycle-samara, /kids, /kids-boxing, /personal-training | Service, WebPage, BreadcrumbList, FAQPage |  |  |
| /first-training | HowTo, WebPage, BreadcrumbList, FAQPage |  |  |
| /tournaments | WebPage, BreadcrumbList, HowTo, FAQPage |  |  |
| /camps, /rules | WebPage, BreadcrumbList, FAQPage |  |  |
| /trainers | CollectionPage, BreadcrumbList |  |  |
| /clubs | CollectionPage, ItemList, SportsActivityLocation×4, BreadcrumbList, FAQPage |  | ✓ |
| /directions | CollectionPage, ItemList, BreadcrumbList, FAQPage |  |  |
| /about | AboutPage, SportsOrganization, SportsActivityLocation×4, BreadcrumbList |  | ✓ |
| /contacts | ContactPage, SportsOrganization, SportsActivityLocation×4, ItemList, BreadcrumbList, FAQPage |  | ✓ |
| /reviews | BreadcrumbList |  |  |

- Страниц с типом: FAQPage — 25, HowTo — 2, BreadcrumbList — 28, SportsActivityLocation — 9, Offer — 9; `parentOrganization` — 9.
- Нет ни на одной странице: ExerciseGym, Organization, LocalBusiness, Person, Event, openingHours, openingHoursSpecification, geo, aggregateRating.
- Без файла JSON-LD: /privacy-policy, /consent, /page-not-found, /request, /request-sent, страницы тренеров (20).
- `description` узла `{{PRODUCTION_ORIGIN}}/boxing#club`: **не совпадают**.
  - /boxing (CL01_head_jsonld.html): «Зал бокса с рингом на Галактионовской, 81 в Самаре: бокс, тайский бокс, кикбоксинг и ФитБокс, взрослые и детские группы.»
  - главная (HOME_head_jsonld.html): «Зал с рингом на Галактионовской. Здесь проходят взрослые и детские занятия по единоборствам.»
- Узлы с одним `@id` в нескольких графах (id · графов · вариантов description · вариантов узла): `/boxing#club` · 6 · 2 · 2; `/mma#club` · 6 · 1 · 1; `/gym#club` · 6 · 1 · 1; `/nofitness#club` · 6 · 1 · 1; `/#organization` · 4 · 1 · 1; `/#website` · 2 · 1 · 1.

## 8. robots в HEAD тренеров

- TRnn_head.html: 20 файлов, `noindex, follow` — 20. JSON-LD в них: 0.

## 9. Внешние домены

Ресурс — src, `<link href>`, data-src, data-ag-src, data-ag-clip, CSS `url(`; переход — `<a href>`; JS — адрес в строке скрипта. Число — блоков. `fetch(`: нет.

| домен | блоков | ресурс | переход | JS |
|---|---:|---:|---:|---:|
| **fonts.googleapis.com** | 316 | 316 | 0 | 0 |
| **fonts.gstatic.com** | 316 | 316 | 0 | 0 |
| **cdnjs.cloudflare.com** | 295 | 0 | 0 | 295 |
| **static.tildacdn.*** | 51 | 50 | 0 | 1 |
| yandex.ru | 12 | 8 | 11 | 6 |
| 2gis.ru | 10 | 0 | 9 | 2 |
| apollocamp.pro | 5 | 0 | 5 | 0 |

- Не встречается: api-maps.yandex.ru.

## 10. «бесплатн» в видимом тексте

- Блоков: 138, страниц (по своим блокам): 47, вхождений: 146. Шапка и подвал: GLOBAL-HEADER×3, GLOBAL-FOOTER — то есть фраза есть на каждой странице.
- Блоков со словом по страницам: / 5, /boxing 2, /mma 2, /gym 2, /boxing-samara 3, /prices 6, /schedule 1, /nofitness 2, /muay-thai-samara 1, /kickboxing-samara 3, /mma-samara 3, /grappling-samara 3, /functional-training 2, /stretching-samara 3, /women 3, /first-training 3, /personal-training 3, /tournaments 1, /trainers 1, /clubs 2, /directions 1, /about 1, /contacts 1, /reviews 1, /privacy-policy 1, /consent 1, /request 1; страницы тренеров — 20 из 20, блоков 78.
- Своих вхождений нет: /cycle-samara, /kids, /kids-boxing, /camps, /rules, /page-not-found, /request-sent.

## Цели data-ag-track

Число — атрибутов в разметке. «шапка/подвал» — на всех страницах. Если цель стоит больше чем на половине обычных страниц, выписаны исключения. TR — тренеры. Ключи — из JSON в data-ag-params.

| имя цели | число | страницы | ключи params |
|---|---:|---|---|
| `request_start` | 229 | шапка/подвал, 28 из 34, кроме /rules, /privacy-policy, /consent, /page-not-found, /request, /request-sent, TR ×20 | club, direction, from, intent, trainer, who |
| `phone_click` | 183 | шапка/подвал, 32 из 34, кроме /request, /request-sent, TR ×20 | from, page |
| `direction_select` | 162 | шапка/подвал, /, /boxing, /mma, /gym, /nofitness, /muay-thai-samara, /kickboxing-samara, /mma-samara, /grappling-samara, /functional-training, /cycle-samara, /stretching-samara, /kids, /kids-boxing, /tournaments, /trainers, /directions, TR ×19 (без TR01) | direction, from |
| `club_select` | 160 | шапка/подвал, 23 из 34, кроме /prices, /women, /first-training, /tournaments, /camps, /directions, /rules, /privacy-policy, /consent, /request, /request-sent, TR ×19 (без TR01) | club, from |
| `nav_click` | 157 | 22 из 34, кроме /, /boxing, /boxing-samara, /prices, /tournaments, /camps, /clubs, /directions, /about, /contacts, /request, /request-sent, TR ×20 | from, to |
| `faq_open` | 147 | /, /camps, /clubs, /directions, TR ×20 | from, q |
| `route_click` | 65 | шапка/подвал, /, /boxing, /mma, /gym, /schedule, /nofitness, /clubs, /contacts, /reviews | club, from, map |
| `page_jump` | 55 | 20 из 34, кроме /, /boxing, /boxing-samara, /prices, /schedule, /trainers, /about, /rules, /reviews, /privacy-policy, /consent, /page-not-found, /request, /request-sent | from, tab, to |
| `trainer_open` | 44 | /trainers | from, trainer |
| `price_view` | 27 | шапка/подвал, /, /boxing, /boxing-samara, /nofitness, TR ×20 | from |
| `map_select_club` | 17 | /, /schedule, /clubs, /contacts | club, from |
| `schedule_filter` | 15 | /schedule | direction |
| `schedule_open` | 14 | шапка/подвал, /, /boxing, /schedule | club, from |
| `home_select_goal` | 10 | /, /boxing-samara, /directions | from, goal |
| `faq_jump` | 7 | /kids-boxing, /first-training, /camps | from, q |
| `trainer_view` | 7 | /, /boxing, /boxing-samara, /nofitness, /muay-thai-samara, /kickboxing-samara, /about | from, trainer |
| `request_call` | 6 | /request, /request-sent | from |
| `technique_pair` | 5 | /muay-thai-samara | pair |
| `club_pick` | 4 | /women | club, from |
| `faq_filter` | 4 | /tournaments | role |
| `nav_open` | 4 | /request-sent | from, to |
| `outbound_click` | 4 | /, /camps, /about | from, target |
| `route_open` | 4 | /boxing, /mma, /gym, /nofitness | club, from |
| `personal_view` | 3 | /boxing-samara, /prices | from |
| `price_jump` | 3 | /prices | from, to |
| `camp_view` | 2 | /about | event, from |
| `compare_vs` | 2 | /kickboxing-samara | vs |
| `direction_view` | 2 | /boxing-samara | direction, from |
| `events_open` | 2 | / | from, target |
| `fitbox_open` | 2 | /boxing-samara | from |
| `kids_view` | 2 | /boxing-samara | direction, from |
| `price_pick` | 2 | /muay-thai-samara, /kickboxing-samara | direction, from |
| `prices_open` | 2 | /request, /request-sent | from |
| `schedule_view` | 2 | / | from |
| `tournament_view` | 2 | /about, /rules | event, from |
| `contact_save` | 1 | /contacts | from, page |
| `directions_open` | 1 | /boxing | club, from |
| `first_training_guide` | 1 | / | from |
| `phone_copy` | 1 | /contacts | from, page |
| `request_open` | 1 | /request | from |
| `request_submit` | 1 | /request | from |
