# SEO-брифы страниц · индекс · собрано `tools/build_briefs.py`

Не править руками: ручные решения — в `DATA/seo_brief_notes.json`, мета — в `DATA/SEO_TARGETS.csv`, затем пересборка. Бриф страницы — `REFERENCE/briefs/<страница>.md`, 13 пунктов; в проход берётся только бриф своей страницы. Бриф — предложение к проходу: каждая правка проходит законы 1–13, FACTS и check_claims; спорные ключи — список Ф11 (DECISIONS). «К проходу» ставится в Tilda только в проходе страницы, вместе с H1 (Ф2 снимается фразой «Раскладка ключей утверждена»).

Страниц: 30. Устаревших брифов (блоки менялись после заметок): 0 — `build_briefs.py --stale`.

| Страница | Бриф | Title к проходу | H2 правок | FAQ: в графе / предложений | Гейты | Спорная |
|---|---|---|---|---|---|---|
| / | [briefs/home.md](briefs/home.md) | Бокс и единоборства в Самаре — четыре клуба Apollo Gym | 4 | 6 / 5 | № 11; К12 | да |
| /boxing | [briefs/boxing.md](briefs/boxing.md) | Зал бокса на Галактионовской, 81 — Apollo Boxing Gym Самара | 1 | 6 / 1 | № 11 |  |
| /mma | [briefs/mma.md](briefs/mma.md) | ММА клуб на Чкалова, 72 — Apollo MMA Gym, зал с клеткой | 1 | 6 / 1 | 3.4, 3.5 | да |
| /gym | [briefs/gym.md](briefs/gym.md) | = сейчас | 0 | 6 / 1 | № 11 |  |
| /nofitness | [briefs/nofitness.md](briefs/nofitness.md) | = сейчас | 0 | 7 / 1 | 5.4; 5.1; 5.13 |  |
| /boxing-samara | [briefs/boxing-samara.md](briefs/boxing-samara.md) | Бокс в Самаре — секция для взрослых и начинающих \| Apollo Gym | 4 | 9 / 5 | — | да |
| /prices | [briefs/prices.md](briefs/prices.md) | Цены на бокс и единоборства в Самаре — абонементы \| Apollo Gym | 1 | 8 / 2 | 5.5 |  |
| /muay-thai-samara | [briefs/muay-thai-samara.md](briefs/muay-thai-samara.md) | = сейчас | 1 | 8 / 4 | 7.4 |  |
| /kickboxing-samara | [briefs/kickboxing-samara.md](briefs/kickboxing-samara.md) | Кикбоксинг в Самаре — секция для взрослых и начинающих \| Apollo | 2 | 8 / 4 | 7.4 |  |
| /mma-samara | [briefs/mma-samara.md](briefs/mma-samara.md) | ММА в Самаре — секция смешанных единоборств \| Apollo Gym | 3 | 8 / 3 | 3.4 |  |
| /grappling-samara | [briefs/grappling-samara.md](briefs/grappling-samara.md) | = сейчас | 1 | 10 / 4 | 3.12; 3.5 |  |
| /functional-training | [briefs/functional-training.md](briefs/functional-training.md) | Функциональные тренировки в Самаре — ОФП и круговые \| Apollo | 2 | 10 / 3 | 3.6 |  |
| /cycle-samara | [briefs/cycle-samara.md](briefs/cycle-samara.md) | Сайкл в Самаре — тренировки на велотренажёрах \| Apollo NoFitness | 0 | 10 / 3 | 5.4; 3.8 |  |
| /stretching-samara | [briefs/stretching-samara.md](briefs/stretching-samara.md) | Растяжка в Самаре — стретчинг для начинающих \| Apollo NoFitness | 2 | 10 / 3 | 6.8; 5.1; 5.13 |  |
| /kids | [briefs/kids.md](briefs/kids.md) | Спортивные секции для детей в Самаре — единоборства \| Apollo Gym | 1 | 9 / 4 | 7.3; 7.4; № 11; 4.3 |  |
| /kids-boxing | [briefs/kids-boxing.md](briefs/kids-boxing.md) | Бокс для детей в Самаре — детская секция бокса \| Apollo Gym | 0 | 8 / 3 | № 11; 4.3; 6.x (I144) |  |
| /women | [briefs/women.md](briefs/women.md) | Бокс для девушек в Самаре — ФитБокс, кикбоксинг, тайский \| Apollo | 1 | 9 / 3 | 3.11; 4.5 |  |
| /first-training | [briefs/first-training.md](briefs/first-training.md) | Пробная тренировка в Самаре — первое групповое бесплатно \| Apollo | 1 | 9 / 1 | К7; № 11 |  |
| /personal-training | [briefs/personal-training.md](briefs/personal-training.md) | Персональный тренер по боксу в Самаре \| Apollo Gym | 1 | 10 / 1 | 5.5; 5.8 | да |
| /tournaments | [briefs/tournaments.md](briefs/tournaments.md) | Турниры по единоборствам в Самаре — открытые турниры Apollo | 0 | 3 / 1 | № 3 (8.3); 8.5 |  |
| /camps | [briefs/camps.md](briefs/camps.md) | Спортивные сборы Apollo — выезды команды и Apollo Camp на Пхукете | 0 | 6 / 2 | 8.9; 8.11; 8.14 |  |
| /trainers | [briefs/trainers.md](briefs/trainers.md) | Тренеры по боксу и единоборствам в Самаре \| Apollo Gym | 1 | 0 / 1 | 6.1 | да |
| /clubs | [briefs/clubs.md](briefs/clubs.md) | Клубы единоборств в Самаре — 4 адреса Apollo Gym | 1 | 6 / 1 | 3.1; 3.2 | да |
| /schedule | [briefs/schedule.md](briefs/schedule.md) | Расписание тренировок по боксу и единоборствам \| Apollo Gym Самара | 0 | 0 / 1 | № 2; № 3; 4.1 |  |
| /request | [briefs/request.md](briefs/request.md) | = сейчас | 0 | 0 / 0 | — |  |
| /directions | [briefs/directions.md](briefs/directions.md) | = сейчас | 0 | 9 / 1 | — |  |
| /about | [briefs/about.md](briefs/about.md) | = сейчас | 0 | 0 / 0 | 3.5 |  |
| /contacts | [briefs/contacts.md](briefs/contacts.md) | = сейчас | 0 | 4 / 1 | — |  |
| /rules | [briefs/rules.md](briefs/rules.md) | = сейчас | 0 | 2 / 0 | — |  |
| /self-defense-samara | [briefs/self-defense-samara.md](briefs/self-defense-samara.md) | = сейчас | 0 | 0 / 0 | 3.11; К14 |  |

## Спорные места Ф11 — решение по умолчанию применено

Правка — строкой журнала DECISIONS, затем `keywords_rules.json` → `core_import.py` → `build_briefs.py`. Этап 2 закрывается фразой «Раскладка ключей утверждена».

| Запрос | Частота, Самара | Владелец | Почему |
|---|---|---|---|
| клуб единоборств самара | 404 | / | Главная — «клуб единоборств», /clubs — «клубы». Если Яндекс склеит — владелец /clubs. |
| бокс самара | 3687 | /boxing-samara | Владелец — направление (запрос услуги). Главная держит «Бокс» в Title и H1: по запросу в топ-3 старый сайт. Через месяц после переезда — какой URL показывает Яндекс (исследование, 3.2). |
| тренер по боксу самара | 91 | /personal-training | Единственное число — персональный интент. /trainers — «тренеры по боксу самара». |
| тренеры по боксу самара | 91 | /trainers |  |
| клубы единоборств самара | 404 | /clubs | На главной — H2 «Четыре клуба единоборств в Самаре» с анкором на /clubs. |
| мма клуб самара | 56 | /mma | «Клуб» — интент места: зал на Чкалова. /mma-samara берёт «мма самара», «секция мма», «тренировки мма». |
| фитбокс | 56 | /boxing-samara | К16: ФитБокс идёт в боксёрских залах (Галактионовская, Ново-Садовая), не на Молодогвардейской. Владелец — /boxing-samara#fitbox, текст — /women. |
| фитбокс самара | 25 | /boxing-samara | К16: ФитБокс идёт в боксёрских залах (Галактионовская, Ново-Садовая), не на Молодогвардейской. Владелец — /boxing-samara#fitbox, текст — /women. |
| фитнес бокс | 11 | /boxing-samara | К16: ФитБокс идёт в боксёрских залах (Галактионовская, Ново-Садовая), не на Молодогвардейской. Владелец — /boxing-samara#fitbox, текст — /women. |
| apollo gym | 97 | / | Бренд сети. /gym («Apollo Gym на Ново-Садовой») — текст и Title с адресом. |
