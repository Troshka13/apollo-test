#!/usr/bin/env python3
"""Offline integrity checks. Python 3; optional Node.js for JS syntax. No installs/network."""
from pathlib import Path
from html.parser import HTMLParser
import json, re, subprocess, shutil, sys

root = Path(__file__).resolve().parents[1]
checks = []
def check(name, condition, detail=''):
    checks.append({'name': name, 'status': 'pass' if condition else 'fail', 'detail': detail})
def readjson(name):
    return json.loads((root / name).read_text(encoding='utf-8'))

features = readjson('data/features.json')
pages = readjson('data/page_designs.json')
coverage = readjson('data/page_coverage.json')
overlays = readjson('data/block_overlays.json')
demos = readjson('data/demo_registry.json')
feature_ids = {f['id'] for f in features}
check('30 feature specifications', len(features) == 30 and len(feature_ids) == 30)
check('33 page briefs and one trainer template', len(pages) == 34 and 'TR_TEMPLATE' in pages)
check('215 baseline block proposals', len(overlays) == 215)
check('Six standalone demos and six T123 fragments', len(demos) == 6)
check('Coverage equals page brief index', {p['id'] for p in coverage} == set(pages))
for f in features:
    check(f"Feature file {f['id']}", (root / f"features/{f['id']}.md").is_file())
for p in coverage:
    check(f"Page and source {p['id']}", all((root / p[k]).is_file() for k in ('brief', 'baseline_copy')) and (root / f"prompts/pages/{p['id']}.md").is_file())
    check(f"Block count {p['id']}", sum(x['page_id'] == p['id'] for x in overlays) == p['block_count'])
check('Every overlay refers to a known page and feature',all(x['page_id'] in pages and (x['feature_id'] is None or x['feature_id'] in feature_ids) for x in overlays))
check('Unique baseline block IDs',len({x['block_id'] for x in overlays})==215)

missing_links=[]
for file in root.rglob('*.md'):
    if 'baseline_refs' in file.parts or 'external' in file.parts:
        continue # Original snapshots: untouched, may contain references to their full original package.
    for link in re.findall(r'\[[^\]]*\]\(([^)]+)\)', file.read_text(encoding='utf-8')):
        if re.match(r'^[a-zA-Z]+:|^#',link): continue
        target=link.split('#')[0]
        if target and not (file.parent / target).exists(): missing_links.append(f'{file.relative_to(root)}: {target}')
check('Addon Markdown relative links', not missing_links, '; '.join(missing_links))

class Doc(HTMLParser):
    def __init__(self):
        super().__init__(); self.ids=[]; self.scripts=[]; self.styles=[]; self.collect=None; self.buf=[]; self.external_js=[]; self.tags=[]; self.links=[]
    def handle_starttag(self,tag,attrs):
        d=dict(attrs); self.tags.append((tag,d))
        if 'id' in d: self.ids.append(d['id'])
        if tag in ('script','style'): self.collect=tag; self.buf=[]
        if tag=='script' and d.get('src'): self.external_js.append(d['src'])
        if tag=='a' and d.get('href'): self.links.append(d['href'])
    def handle_data(self,data):
        if self.collect: self.buf.append(data)
    def handle_endtag(self,tag):
        if tag==self.collect:
            getattr(self,'scripts' if tag=='script' else 'styles').append(''.join(self.buf)); self.collect=None; self.buf=[]

scripts=[]
for file in [root/'preview.html']+[root/d[k] for d in demos for k in ('path','fragment')]:
    doc=Doc(); doc.feed(file.read_text(encoding='utf-8'))
    rel=str(file.relative_to(root))
    check(f'{rel}: unique IDs',len(doc.ids)==len(set(doc.ids)))
    check(f'{rel}: no external JS',not doc.external_js)
    for link in doc.links:
        if not re.match(r'^[a-zA-Z]+:|^#',link):
            check(f'{rel}: link {link}',(file.parent / link.split('#')[0]).exists())
    scripts.extend({'file':rel,'code':s} for s in doc.scripts)
    if '/examples/' in str(file):
        check(f'{rel}: no standalone document tags',not any(t in ('html','head','body','meta','title') for t,d in doc.tags))
        check(f'{rel}: scoped CSS roots',all(not re.search(r'(?:^|[{}])\s*(?:body|html|:root)\b',s) and 'ROOT' not in s for s in doc.styles))
        check(f'{rel}: no form submission mock',not any(t=='form' for t,d in doc.tags))
        check(f'{rel}: reduced-motion rule',any('prefers-reduced-motion:reduce' in s for s in doc.styles))

node=shutil.which('node')
if node:
    code="const vm=require('vm');let s='';process.stdin.on('data',x=>s+=x);process.stdin.on('end',()=>{const bad=[];for(const item of JSON.parse(s)){try{new vm.Script(item.code,{filename:item.file})}catch(e){bad.push(String(e))}}console.log(JSON.stringify(bad));process.exitCode=bad.length?1:0});"
    res=subprocess.run([node,'-e',code],input=json.dumps(scripts),text=True,capture_output=True)
    check('Inline JavaScript parses in Node',res.returncode==0,res.stdout.strip()+res.stderr.strip())
else: checks.append({'name':'Inline JavaScript syntax','status':'not_tested','detail':'Node not installed; no installation required by this integrity checker.'})

for name in ('Oswald.ttf','Manrope.ttf','Oswald_OFL.txt','Manrope_OFL.txt'):
    check(f'Local font/license {name}',(root/'assets/fonts'/name).is_file())
prices=readjson('baseline_refs/04_DATA/prices.json')
check('Source prices preserve admin-unconfirmed status',prices['confirmed_by_admin_on'] is None)
check('NoFitness unread-source status retained',next(p for p in coverage if p['id']=='CL04')['source_status']=='Текущий HTML не прочитан; проект по v8.2')
check('Original external reference and license',all((root/'sources/external'/f).is_file() for f in ('NIKE_DESIGN.md','VOLTAGENT_LICENSE.txt')))

output={'checker':'Static integrity + syntax; not browser/runtime testing','date':'2026-09-30','results':checks}
(root/'qa/static_results.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
failed=[c for c in checks if c['status']=='fail']
print(json.dumps({'checks':len(checks),'passed':sum(c['status']=='pass' for c in checks),'failed':failed},ensure_ascii=False,indent=2))
sys.exit(bool(failed))
