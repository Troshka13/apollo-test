# Каталог 30 приёмов

Все параметры — предложения Apollo. Источники объясняют принцип, а не установленный код.

| ID | Приём | Где полезен | Сложность |
|---|---|---|---|
| [F01](features/F01.md) | Рамка ринга в первом экране | HOME, CL01 | medium |
| [F02](features/F02.md) | Заголовок как спортивная афиша | HOME, TOURNAMENTS, CAMPS | low |
| [F03](features/F03.md) | Мягкое приближение фотографии | HOME, CL01, CL02, CL03, CAMPS | low |
| [F04](features/F04.md) | Зоны зала | CL01, CL02, CL03, CL04, HOME | medium |
| [F05](features/F05.md) | Наклон медиа | CL01, CL02, TRAINERS, TOURNAMENTS | medium |
| [F06](features/F06.md) | Галерея с нативным свайпом | CL01, CL02, CL03, CL04, CAMPS, TOURNAMENTS | medium |
| [F07](features/F07.md) | Полноразмерный просмотр | CL01, CL02, CL03, CL04, CAMPS, TOURNAMENTS | medium |
| [F08](features/F08.md) | Сравнение по одинаковым строкам | CLUBS, DIR03, DIR04, DIR08, WOMEN, PERSONAL | low |
| [F09](features/F09.md) | Подбор направления | HOME, DIRECTIONS, KIDS, FIRST | medium |
| [F10](features/F10.md) | Плавный индикатор вкладок | HOME, SCHEDULE, PRICES, DIR04, CL04 | low |
| [F11](features/F11.md) | Фильтры с явным состоянием | TRAINERS, SCHEDULE, CLUBS, REVIEWS | low |
| [F12](features/F12.md) | Тренер в двух кадрах | TRAINERS, CL01, CL02, CL03, CL04, TR_TEMPLATE | medium |
| [F13](features/F13.md) | Состав тренеров без скачков | TRAINERS, PERSONAL, WOMEN | medium |
| [F14](features/F14.md) | Маршрут первого занятия | HOME, FIRST, KIDSBOX, TOURNAMENTS | low |
| [F15](features/F15.md) | Что взять с собой | FIRST, KIDS, KIDSBOX | low |
| [F16](features/F16.md) | Цена выбранного пакета | PRICES, HOME, CL01, CL02, CL03, PERSONAL | low |
| [F17](features/F17.md) | Разница с разовыми посещениями | PRICES | low |
| [F18](features/F18.md) | Контекстная запись | HOME, CL01, CL02, CL03, CL04, DIR01, REQUEST | low |
| [F19](features/F19.md) | Навигация по длинной странице | CL01, CL02, CL03, CL04, PRICES, TR_TEMPLATE | low |
| [F20](features/F20.md) | Клуб и маршрут | HOME, CLUBS, CONTACTS | medium |
| [F21](features/F21.md) | Вход с улицы | CL01, CL02, CL03, CL04, CONTACTS | low |
| [F22](features/F22.md) | FAQ с аккуратным раскрытием | HOME, FIRST, KIDS, PRICES, CL01, DIR01 | low |
| [F23](features/F23.md) | Кнопка с мягким нажатием | GLOBAL, REQUEST, PRICES | low |
| [F24](features/F24.md) | Полоса фактов | HOME | low |
| [F25](features/F25.md) | Афиша турнира | TOURNAMENTS, HOME | low |
| [F26](features/F26.md) | Архив событий | TOURNAMENTS, CAMPS | medium |
| [F27](features/F27.md) | История выезда | CAMPS, HOME | medium |
| [F28](features/F28.md) | Состояния настоящей заявки | REQUEST, SCHEDULE, TRAINERS | medium |
| [F29](features/F29.md) | Бумажная поверхность | PRICES, FIRST, KIDS, KIDSBOX | low |
| [F30](features/F30.md) | Графика из оборудования зала | DIR01, DIR04, DIR05, DIR07, CL01, CL02 | low |
