# Движение: контракт и справочник атрибутов

## Что изменилось в v8.2 (21.09.2026)

v8 требовал `G04_MOTION.html` (BODY) и `G00_FOUNDATION.html` (HEAD) как общие файлы сайта, а блок — только атрибуты `data-ag-*`, без своего `<script src>`. На практике это дважды привело к одному и тому же: блок GLOBAL-HEADER (19.09) и блок HOME-10 (20.09) показывались нестилизованными/неподвижными, потому что общие файлы не были фактически подключены на сайте. 21.09 закреплено окончательно: **общих файлов больше нет вообще**. `G00_FOUNDATION.html`/`G04_MOTION.html` не ставятся, не предполагаются, не упоминаются как источник истины ни для одного блока.

Справочник атрибутов ниже (типы появления, модификаторы, правила вкуса, проверка) остаётся действующим стандартом того, **как должно выглядеть** движение — он не привязан к тому, откуда берётся движок. Меняется только механизм:

1. **Блок без движения** ничего не подключает и не использует `data-ag-anim` — это нормально и предпочтительно, если движение не даёт блоку ничего существенного (см. «Правила вкуса»).
2. **Блок с движением** несёт свою копию движка — целиком, самостоятельно, в собственном `<script>` в конце блока. Шаблон движка — в конце этого файла, раздел «Встраиваемый движок». Копируется без изменений в логике, меняется только то, что вставляется по месту (ничего — движок сам находит свой корень через `document.currentScript`).
3. **Несколько блоков с движением на одной странице не мешают друг другу и не плодят вторых копий GSAP.** Первый такой блок на странице подгружает GSAP 3.13 + ScrollTrigger с cdnjs и создаёт `window.ApolloMotion`. Каждый следующий блок с движением обнаруживает, что `window.ApolloMotion` уже есть, не грузит GSAP повторно и просто просит его отсканировать свой собственный корень. Если из двух таких блоков один удалить — второй по-прежнему работает без изменений: это и есть автономность, не «отсутствие общего кода на странице любой ценой».
4. **Блок читается без движка.** Класс `html.ag-motion` вешается только после фактической загрузки GSAP. Нет JS, упал CDN, `prefers-reduced-motion`, таймаут 2 с — контент виден целиком, ничего не спрятано. Это не изменилось.
5. **`data-ag-track`/`data-ag-params`** (аналитика, не движение) — отдельный вопрос, эта пара атрибутов не требует движка и в данном документе не описывается.

---

## Справочник атрибутов

Все атрибуты ставятся на **элемент блока**, не на корень `.ag-scope`.

### `data-ag-anim` — тип появления

| Значение | Что делает | Где уместно |
|---|---|---|
| `rise` | Сдвиг + проявление. По умолчанию снизу на 32 px. | Карточка, изображение, группа текста |
| `fade` | Только прозрачность | Фон, декоративный слой |
| `stagger` | Каскад по детям контейнера | Сетка карточек, список направлений, колода |
| `split` | Заголовок выезжает по словам из-под маски | H1 и H2, **не больше одного на экран** |
| `count` | Число крутится до целевого | Планка доказательств |
| `parallax` | Смещение при скролле | Крупное фото, фон hero |
| `draw` | Отрисовка линии (SVG `path`/`line` или `scaleX`) | Таймлайн первого визита, разделители |
| `scale-in` | Фото наезжает из 1.07 в 1.0 | Кадр в рамке, слот фото |
| `marquee` | Синхронизирует скорость бегущей строки | Полоса доказательств |

### Модификаторы

| Атрибут | По умолчанию | Смысл |
|---|---|---|
| `data-ag-from` | `up` | `up` · `down` · `left` · `right` · `none` |
| `data-ag-distance` | `32` | Дистанция сдвига, px |
| `data-ag-dur` | `700` | Длительность, мс |
| `data-ag-delay` | `0` | Задержка, мс |
| `data-ag-stagger` | `80` | Шаг каскада, мс |
| `data-ag-children` | дети контейнера | CSS-селектор элементов каскада |
| `data-ag-start` | `top 86%` | Точка старта ScrollTrigger |
| `data-ag-repeat` | нет | Присутствует — повторять при каждом проходе |
| `data-ag-split` | `words` | `words` · `chars` |
| `data-ag-count-to` | из текста | Целевое число |
| `data-ag-count-dec` | `0` | Знаков после запятой |
| `data-ag-count-prefix` / `-suffix` | — | Например `от ` и ` ₽` |
| `data-ag-parallax` | `0.12` | Сила, 0.05–0.25 |
| `data-ag-parallax-scope` | — | Ставится на родителя, относительно которого считать |
| `data-ag-magnetic` | `0.28` | Кнопка тянется к курсору. Только на десктопе |
| `data-ag-deck` + `data-ag-dots="<id колоды>"` | — | Точки-индикаторы свайп-колоды |
| `data-ag-speed` | `48` | Секунд на круг бегущей строки |

### Примеры

```html
<!-- Заголовок по словам, один на экран -->
<h2 class="ag-h2" data-ag-anim="split">Четыре зала в Самаре</h2>

<!-- Каскад карточек -->
<ul class="ag-grid" data-ag-anim="stagger" data-ag-children="li" data-ag-stagger="70">…</ul>

<!-- Счётчик -->
<b data-ag-anim="count" data-ag-count-to="900" data-ag-count-suffix=" ₽">900 ₽</b>

<!-- Фото с параллаксом -->
<div class="ag-ph" data-ratio="4:5" data-ag-anim="parallax" data-ag-parallax="0.1">…</div>

<!-- Кнопка -->
<a class="ag-btn ag-btn--primary" href="/request" data-ag-magnetic>Записаться на тренировку</a>
```

---

## Правила вкуса

**Одно движение — одна мысль.** Лимит считает только **типы появления**: `rise`, `fade`, `stagger`, `split`, `scale-in`. Их в блоке не больше двух.

`count`, `parallax`, `marquee` и `draw` — не появления, а поведение отдельного элемента, и в лимит не входят. Поэтому hero эталона (`split` + `rise` как появления, плюс `scale-in` на фото, `count` на планке, `parallax` на фоне и `marquee` на строке) правило не нарушает: появлений в нём два основных плюс одно на медиа.

Практический ориентир: до трёх появлений на блок, из них одно ведущее.

**`split` — только на один заголовок в пределах экрана.** Обычно это H1 hero и один H2 на странице. Остальные заголовки едут вместе с блоком через `rise`.

**Параллакс — только на фото, никогда на тексте.** Сила до 0.15. Текст в параллаксе нечитаем на телефоне.

**Каскад не длиннее 8 элементов.** Девятая карточка появится через 0,7 с после первой — человек уже отвёл взгляд. Для длинных списков ставим `data-ag-stagger="45"` или делим на группы.

**Ничего не появляется дважды.** `once: true` по умолчанию. `data-ag-repeat` — только для бесконечной бегущей строки.

**Первый экран не анимируем в ноль.** H1 и первая кнопка hero получают `data-ag-anim="rise"` с `data-ag-delay` не больше 150 мс. Пользователь не должен ждать.

**Счётчик — только на подтверждённых числах.** Крутить «29 турниров», пока цифра не подтверждена, нельзя.

**Скролл не перехватываем.** Никакого smooth-scroll поверх нативного, никакого горизонтального повествования, никакого pin на главной.

**Элемент без анимации просто не получает атрибут.** Значения `none` не существует. Неизвестное значение `data-ag-anim` молча отрабатывает как `rise` — опечатка не упадёт с ошибкой, а даст неожиданное движение, поэтому значения сверяем по таблице выше.

**Каскад по строкам таблицы:** `data-ag-children="tbody tr"`. Селектор может быть списком через запятую — он уходит в `querySelectorAll`. Трансформы на `<tr>` поддерживаются неровно, поэтому для таблиц ограничиваемся `data-ag-from="none"` (только прозрачность).

---

## Что запрещено в блоке

- **свой** `<script src="…gsap…">` разрешён и обязателен, если блок использует `data-ag-anim` — но ровно один экземпляр шаблона ниже, без правок логики;
- вторая инициализация GSAP/ScrollTrigger **в обход** проверки `window.ApolloMotion` (нельзя писать параллельный движок «на свой лад» — только шаблон ниже);
- `opacity: 0` в CSS блока на контенте — контент прячет только сам движок в рантайме, и только после успешной загрузки; в разметке и в CSS блока по умолчанию всё видимо;
- свои `@keyframes` для появления — для этого есть `data-ag-anim`;
- анимация `filter` и `box-shadow` покадрово;
- `will-change` навсегда — рантайм ставит и снимает его сам;
- бесконечная анимация чего-либо, кроме бегущей строки.

---

## Проверка движения перед сдачей

1. Отключите JS в devtools → весь текст, цены и ссылки видны.
2. Включите «Reduce motion» в системе → ничего не движется, ничего не спрятано.
3. Заблокируйте `cdnjs.cloudflare.com` в devtools → через 2 с страница видна полностью.
4. Откройте блок в редакторе Tilda и переключитесь между режимами → анимация не запускается второй раз, слушатели не дублируются.
5. Прокрутите блок в обе стороны → элементы не мигают и не появляются повторно.
6. Телефон 360 px → параллакс не создаёт горизонтальной прокрутки.
7. Если на странице два и более блока с движением — удалите один (или временно спрячьте) и убедитесь, что второй по-прежнему анимируется как раньше.

---

## Встраиваемый движок (копировать в блок целиком, если нужен `data-ag-anim`)

Логика — точная копия того, что раньше жило в `G04_MOTION.html`, только со сканом, заново привязанным к своему блоку через `document.currentScript`, а не к `document` целиком, и с проверкой `window.ApolloMotion` перед повторной загрузкой GSAP. Обработчики типов появления (`rise/fade/stagger/split/count/parallax/draw/scale-in/marquee`), магнитные кнопки и точки-индикаторы колоды не менялись — таблица атрибутов выше описывает именно это поведение.

```html
<script>
(function () {
  "use strict";
  var BLOCK = document.currentScript.closest(".ag-scope");
  if (!BLOCK || BLOCK.hasAttribute("data-ag-mounted")) return;
  BLOCK.setAttribute("data-ag-mounted", "");

  if (window.ApolloMotion && window.ApolloMotion.ready) { window.ApolloMotion.scan(BLOCK); return; }
  if (window.ApolloMotion && !window.ApolloMotion.ready) { return; } // грузится/деградировал по другому блоку — не дублируем попытку

  var GSAP_CORE = "https://cdnjs.cloudflare.com/ajax/libs/gsap/3.13.0/gsap.min.js";
  var GSAP_ST   = "https://cdnjs.cloudflare.com/ajax/libs/gsap/3.13.0/ScrollTrigger.min.js";
  var BOOT_TIMEOUT = 2000;
  var html = document.documentElement;
  var reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var bailed = false;

  var API = { ready: false, reduced: reduced, scan: function () {} };
  window.ApolloMotion = API;

  function standDown(reason) {
    bailed = true;
    html.classList.remove("ag-motion");
    html.setAttribute("data-ag-motion", "off");
    API.ready = false;
    if (window.console && reason) console.info("[ApolloMotion] off:", reason);
  }

  if (reduced) { standDown("prefers-reduced-motion"); return; }

  var bootTimer = setTimeout(function () { standDown("timeout"); }, BOOT_TIMEOUT);
  function loadScript(src) {
    return new Promise(function (res, rej) {
      var s = document.createElement("script");
      s.src = src; s.async = true;
      s.onload = res;
      s.onerror = function () { rej(new Error("load fail " + src)); };
      document.head.appendChild(s);
    });
  }

  html.classList.add("ag-motion");

  loadScript(GSAP_CORE)
    .then(function () { return loadScript(GSAP_ST); })
    .then(function () {
      clearTimeout(bootTimer);
      if (bailed) return;
      if (!window.gsap || !window.ScrollTrigger) { standDown("gsap missing"); return; }
      init();
    })
    .catch(function (e) { clearTimeout(bootTimer); standDown(e && e.message); });

  function init() {
    var gsap = window.gsap, ST = window.ScrollTrigger;
    gsap.registerPlugin(ST);
    gsap.defaults({ ease: "power3.out", duration: 0.7 });
    ST.config({ ignoreMobileResize: true });
    html.setAttribute("data-ag-motion", "on");
    API.ready = true; API.gsap = gsap; API.ScrollTrigger = ST;

    var num = function (el, attr, dflt) { var v = parseFloat(el.getAttribute(attr)); return isNaN(v) ? dflt : v; };
    var done = function (el) { el.setAttribute("data-ag-done", ""); };
    var fresh = function (root, sel) {
      return Array.prototype.slice.call((root || document).querySelectorAll(sel))
        .filter(function (el) { return !el.hasAttribute("data-ag-done"); });
    };

    function splitText(el, mode) {
      if (el.__agSplit) return el.__agSplit;
      var text = el.textContent;
      el.setAttribute("aria-label", text);
      var parts = mode === "chars" ? text.split("") : text.split(/(\s+)/);
      var frag = document.createDocumentFragment(); var nodes = [];
      parts.forEach(function (p) {
        if (/^\s+$/.test(p)) { frag.appendChild(document.createTextNode(p)); return; }
        if (p === "") return;
        var span = document.createElement("span");
        span.className = "ag-split__i"; span.setAttribute("aria-hidden", "true");
        span.style.display = "inline-block"; span.style.willChange = "transform,opacity";
        span.textContent = p; frag.appendChild(span); nodes.push(span);
      });
      el.textContent = ""; el.appendChild(frag); el.__agSplit = nodes; return nodes;
    }

    function fromVars(el) {
      var dir = el.getAttribute("data-ag-from") || "up";
      var d = num(el, "data-ag-distance", 32);
      var v = { opacity: 0 };
      if (dir === "up") v.y = d; else if (dir === "down") v.y = -d;
      else if (dir === "left") v.x = d; else if (dir === "right") v.x = -d;
      return v;
    }

    var handlers = {
      rise: function (el) {
        gsap.fromTo(el, fromVars(el), {
          opacity: 1, x: 0, y: 0,
          duration: num(el, "data-ag-dur", 700) / 1000,
          delay: num(el, "data-ag-delay", 0) / 1000,
          scrollTrigger: trig(el),
          onStart: function () { el.style.willChange = "transform,opacity"; },
          onComplete: function () { el.style.willChange = ""; }
        });
        done(el);
      },
      fade: function (el) {
        gsap.fromTo(el, { opacity: 0 }, {
          opacity: 1, duration: num(el, "data-ag-dur", 800) / 1000,
          delay: num(el, "data-ag-delay", 0) / 1000, scrollTrigger: trig(el)
        });
        done(el);
      },
      stagger: function (el) {
        var sel = el.getAttribute("data-ag-children");
        var kids = sel ? el.querySelectorAll(sel) : el.children;
        if (!kids.length) { handlers.rise(el); return; }
        gsap.set(el, { opacity: 1 });
        gsap.fromTo(kids, fromVars(el), {
          opacity: 1, x: 0, y: 0,
          duration: num(el, "data-ag-dur", 650) / 1000,
          delay: num(el, "data-ag-delay", 0) / 1000,
          stagger: num(el, "data-ag-stagger", 80) / 1000,
          scrollTrigger: trig(el)
        });
        done(el);
      },
      split: function (el) {
        var mode = el.getAttribute("data-ag-split") || "words";
        var nodes = splitText(el, mode);
        gsap.set(el, { opacity: 1 });
        gsap.fromTo(nodes, { yPercent: 108, opacity: 0 }, {
          yPercent: 0, opacity: 1,
          duration: num(el, "data-ag-dur", 800) / 1000,
          delay: num(el, "data-ag-delay", 0) / 1000,
          stagger: num(el, "data-ag-stagger", mode === "chars" ? 18 : 55) / 1000,
          ease: "power4.out", scrollTrigger: trig(el),
          onComplete: function () { nodes.forEach(function (n) { n.style.willChange = ""; }); }
        });
        done(el);
      },
      count: function (el) {
        var to = num(el, "data-ag-count-to", parseFloat(el.textContent) || 0);
        var dec = num(el, "data-ag-count-dec", 0);
        var prefix = el.getAttribute("data-ag-count-prefix") || "";
        var suffix = el.getAttribute("data-ag-count-suffix") || "";
        var o = { v: 0 };
        gsap.set(el, { opacity: 1 });
        gsap.to(o, {
          v: to, duration: num(el, "data-ag-dur", 1400) / 1000, ease: "power2.out",
          scrollTrigger: trig(el, "top 88%"),
          onUpdate: function () {
            el.textContent = prefix + o.v.toFixed(dec).replace(/\B(?=(\d{3})+(?!\d))/g, " ") + suffix;
          }
        });
        done(el);
      },
      parallax: function (el) {
        var s = num(el, "data-ag-parallax", 0.12);
        gsap.set(el, { opacity: 1, willChange: "transform" });
        gsap.fromTo(el, { yPercent: -s * 50 }, {
          yPercent: s * 50, ease: "none",
          scrollTrigger: {
            trigger: el.closest("[data-ag-parallax-scope]") || el.parentElement || el,
            start: "top bottom", end: "bottom top", scrub: true
          }
        });
        done(el);
      },
      draw: function (el) {
        var isPath = el.tagName.toLowerCase() === "path" || el.tagName.toLowerCase() === "line";
        gsap.set(el, { opacity: 1 });
        if (isPath && el.getTotalLength) {
          var len = el.getTotalLength();
          gsap.fromTo(el, { strokeDasharray: len, strokeDashoffset: len },
            { strokeDashoffset: 0, duration: num(el, "data-ag-dur", 1200) / 1000,
              ease: "power2.inOut", scrollTrigger: trig(el) });
        } else {
          gsap.fromTo(el, { scaleX: 0, transformOrigin: "left center" },
            { scaleX: 1, duration: num(el, "data-ag-dur", 900) / 1000, scrollTrigger: trig(el) });
        }
        done(el);
      },
      "scale-in": function (el) {
        gsap.fromTo(el, { opacity: 0, scale: 1.07 }, {
          opacity: 1, scale: 1, duration: num(el, "data-ag-dur", 1000) / 1000,
          delay: num(el, "data-ag-delay", 0) / 1000, ease: "power2.out", scrollTrigger: trig(el)
        });
        done(el);
      },
      marquee: function (el) {
        var track = el.querySelector(".ag-marquee__track") || el.firstElementChild;
        if (!track) { done(el); return; }
        track.style.animationDuration = num(el, "data-ag-speed", 48) + "s";
        done(el);
      }
    };

    function trig(el, dflt) {
      return {
        trigger: el, start: el.getAttribute("data-ag-start") || dflt || "top 86%",
        once: el.getAttribute("data-ag-repeat") === null,
        toggleActions: "play none none none"
      };
    }

    function magnetic(el) {
      if (window.matchMedia("(hover: none)").matches) { done(el); return; }
      var str = num(el, "data-ag-magnetic", 0.28);
      var qx = gsap.quickTo(el, "x", { duration: 0.4, ease: "power3.out" });
      var qy = gsap.quickTo(el, "y", { duration: 0.4, ease: "power3.out" });
      el.addEventListener("pointermove", function (e) {
        var r = el.getBoundingClientRect();
        qx((e.clientX - r.left - r.width / 2) * str); qy((e.clientY - r.top - r.height / 2) * str);
      });
      el.addEventListener("pointerleave", function () { qx(0); qy(0); });
      done(el);
    }

    function deckDots(deck) {
      var dots = document.querySelectorAll('[data-ag-dots="' + deck.id + '"] .ag-deck__dot');
      if (!dots.length) { done(deck); return; }
      Array.prototype.forEach.call(deck.children, function (item, i) {
        ST.create({
          trigger: item, horizontal: true, scroller: deck,
          start: "left center", end: "right center",
          onToggle: function (self) {
            if (self.isActive && dots[i]) {
              Array.prototype.forEach.call(dots, function (d) { d.removeAttribute("data-ag-active"); });
              dots[i].setAttribute("data-ag-active", "");
            }
          }
        });
      });
      done(deck);
    }

    function scan(root) {
      fresh(root, "[data-ag-anim]").forEach(function (el) {
        var kind = el.getAttribute("data-ag-anim");
        (handlers[kind] || handlers.rise)(el);
      });
      fresh(root, "[data-ag-magnetic]").forEach(magnetic);
      fresh(root, "[data-ag-deck]").forEach(deckDots);
      ST.refresh();
    }
    API.scan = scan;
    scan(BLOCK);

    window.addEventListener("load", function () { ST.refresh(); });
    document.addEventListener("lazyloaded", function () { ST.refresh(); });

    var pending = null;
    new MutationObserver(function (muts) {
      var add = muts.some(function (m) { return m.addedNodes && m.addedNodes.length; });
      if (!add) return;
      clearTimeout(pending);
      pending = setTimeout(function () { scan(BLOCK); }, 220);
    }).observe(BLOCK, { childList: true, subtree: true });
  }
})();
</script>
```

Перед сдачей блока, который несёт этот шаблон: пройти весь чек-лист «Проверка движения перед сдачей» выше, включая пункт 7 (второй такой же блок на странице не ломается и не дублирует GSAP). Блок без `data-ag-anim` этот шаблон не несёт вообще — лишний движок в блоке без анимации сам по себе нарушает автономность (лишний вес и лишняя точка отказа без пользы).
