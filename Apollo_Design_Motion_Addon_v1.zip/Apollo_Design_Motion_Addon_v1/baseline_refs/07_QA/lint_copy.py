#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Apollo Gym · проверка текста по 02_VOICE/BANNED.json
Запуск из корня пака:   python3 07_QA/lint_copy.py
Проверить один файл:    python3 07_QA/lint_copy.py 03_COPY/pages/HOME.md
Проверить готовый блок: python3 07_QA/lint_copy.py --html путь/к/блоку.html

Ненулевой код возврата = есть замечания. Блок с замечаниями не сдаётся.
"""
import re, sys, json, glob, os, html

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BAN = json.load(open(os.path.join(ROOT, "02_VOICE", "BANNED.json"), encoding="utf-8"))

# Строки .md, которые адресованы агенту, а не посетителю.
SERVICE_PREFIX = re.compile(
    r"^\s*\*\*(Нельзя|Проверить|Данные|Движение|Фото|Слоты|Композиц|Сборка|Поверхность|Интерфейс|Включение|Разметка|Как блок меняется)", re.I)
SERVICE_SECTION = re.compile(r"^##\s+(SEO|Роль страницы|Перелинковка|Новые черновые факты|Что подтвердить)", re.I)
HEADING_LINE = re.compile(r"^\s*(#{1,6}\s|\*\*(H1|H2|H3|Кикер|Кнопк))", re.I)


def visible_text_md(raw):
    """Оставляет только то, что увидит посетитель."""
    out, skip = [], False
    for line in raw.split("\n"):
        s = line.strip()
        if SERVICE_SECTION.match(s):
            skip = True
            continue
        if s.startswith("## ") or s.startswith("### "):
            skip = False
        if skip or SERVICE_PREFIX.match(s):
            continue
        if s.startswith("*") and s.endswith("*") and not s.startswith("**"):
            continue           # курсивная ремарка агенту
        if s.startswith("> "):
            continue           # цитата-сноска агенту
        out.append(line)
    return "\n".join(out)


def visible_text_html(raw):
    raw = re.sub(r"<!--.*?-->", " ", raw, flags=re.S)
    raw = re.sub(r"<(script|style)\b.*?</\1>", " ", raw, flags=re.S | re.I)
    raw = re.sub(r"<[^>]+>", " ", raw)
    return html.unescape(raw)


def check(text, name, is_html=False):
    found = []
    low = text.lower()

    for p in BAN["hard_ban_phrases"]:
        # по границам слов, чтобы «жми» не ловилось внутри «нажмите»
        if re.search(r"(?<![а-яёa-z])" + re.escape(p.lower()) + r"(?![а-яёa-z])", low):
            found.append(("ЗАПРЕЩЁННАЯ ФРАЗА", p))

    for w in BAN["weak_words"]["list"]:
        n = len(re.findall(r"(?<![а-яёa-z])" + re.escape(w.lower()) + r"(?![а-яёa-z])", low))
        if n:
            found.append(("СЛАБОЕ СЛОВО", f"{w} ×{n}"))

    if re.search(r"(?i)\bне\s+[а-яё]+\s*[—–-]\s*а\b", text):
        found.append(("АНТИТЕЗА", "не X — а Y"))
    if re.search(r"(?i)\b(бокс|тренировка|спорт|единоборства|зал)\s+[—–]\s+это\b", text):
        found.append(("ТИРЕ-АФОРИЗМ", "X — это Y"))
    if "!" in text:
        found.append(("ВОСКЛИЦАНИЕ", "! в тексте"))
    EMOJI = "[" + chr(0x1F300) + "-" + chr(0x1FAFF) + chr(0x2600) + "-" + chr(0x27BF) + chr(0xFE0F) + "]"
    if re.search(EMOJI, text):
        found.append(("ЭМОДЗИ", "символ в тексте"))
    if re.search(r"(?<![А-ЯЁ])[А-ЯЁ]{4,}\s+[А-ЯЁ]{4,}(?![А-ЯЁ])", text):
        found.append(("КАПС", "капс в теле текста — задавайте через CSS"))

    for m in re.finditer(r"(?:(?<=^)|(?<=[.!?]\s))((?:[А-ЯЁ][^.!?\n]{1,22}\.\s*){3})", text):
        found.append(("СТАККАТО-ТРИАДА", m.group(1).strip()[:70]))

    we = len(re.findall(r"(?i)(?<![а-яё])(мы|нас|нам|наши|наша|наше|нашего|нашей|нашу)(?![а-яё])", text))
    if we > 3:
        found.append(("«МЫ»", f"{we} раз на файл — сайт про читателя"))

    return found


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    as_html = "--html" in sys.argv
    targets = args or glob.glob(os.path.join(ROOT, "03_COPY", "pages", "*.md"))

    total = 0
    for f in sorted(targets):
        raw = open(f, encoding="utf-8").read()
        text = visible_text_html(raw) if (as_html or f.endswith((".html", ".htm"))) else visible_text_md(raw)
        issues = check(text, f)
        if issues:
            total += len(issues)
            print(f"\n─── {os.path.relpath(f, ROOT)}")
            for kind, detail in issues:
                print(f"    [{kind}] {detail}")

    print(f"\nПроверено файлов: {len(targets)} · замечаний: {total}")
    if total == 0:
        print("Чисто.")
    sys.exit(1 if total else 0)


if __name__ == "__main__":
    main()
