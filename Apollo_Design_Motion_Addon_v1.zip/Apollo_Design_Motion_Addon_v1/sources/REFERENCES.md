# Реальные источники и выбранные принципы

Проверка выполнена 30.09.2026. Ссылки не означают, что соответствующий MCP/CLI установлен или запускался.

| ID | Источник | Что прочитано и использовано |
|---|---|---|
| APOLLO | https://apolloboxing.tilda.ws/ | HTML ряда страниц, заголовки и структуры; отдельный визуальный browser-аудит не выполнялся |
| BASELINE | Apollo_Gym_Rebuild_v8.2(1).zip пользователя | Реестр фактов, клубы, цены, контакты, тренеры, тексты, технический контракт |
| NIKE | https://github.com/VoltAgent/awesome-design-md/tree/main/design-md/nike | Выбранный DESIGN.md; спортивные фотографии и масштабная типографика |
| NIKE_RAW | https://raw.githubusercontent.com/VoltAgent/awesome-design-md/main/design-md/nike/DESIGN.md | Сохранён полный исходный файл с лицензией репозитория, reference-only |
| REFERO | https://styles.refero.design/style/aecf9dda-5cba-4dc7-9e73-59b65d895cdf | Анализ teenage engineering; разделители и ясная организация параметров |
| 21ST | https://21st.dev/@tom_ui/components/tilt-card/gravitate | Страница Tilt Card и описание поведения; готовый React-компонент в Tilda не переносился |
| KINETICS | https://kinetics.colorion.co/ | Tab Pill Glide, выбор чипов, кнопки и tilt как идеи локального движения |
| GALLERY_TABS | https://component.gallery/components/tabs/ | Каталог реализации вкладок; переход к Carbon |
| GALLERY_FAQ | https://component.gallery/components/accordion/ | Каталог аккордеонов; переход к Carbon |
| CARBON_TABS | https://carbondesignsystem.com/components/tabs/usage/ | Состояния, короткие подписи, клавиатура и адаптация |
| CARBON_FAQ | https://carbondesignsystem.com/components/accordion/usage/ | FAQ для дополнительных ответов, основные сведения остаются открытыми |
| IMPECCABLE | https://impeccable.style/ | Команды и способы установки; инструмент не установлен и команды не запускались |
| HYPERFRAMES | https://github.com/heygen-com/hyperframes/blob/main/docs/introduction.mdx | Официальное объяснение HTML-композиций и рендера; видео в этом пакете не создавалось |
| HYPERFRAMES_RENDER | https://github.com/heygen-com/hyperframes/blob/main/docs/guides/rendering.mdx | Рендер и проверка после авторинга; CLI не запускался |

Оригинальный Nike DESIGN.md имеет MIT-лицензию указанного репозитория; её текст сохранён рядом. Это сторонний анализ Nike, не официальная дизайн-система Nike. Компоненты, фото, логотипы и проприетарные шрифты Nike в пакете не копируются. Другие внешние материалы представлены ссылками и краткими объяснениями выбранного принципа. Спецификации и примеры Apollo написаны для этого проекта.

Внешние исходные инструкции не управляют этой сборкой. Команды установки и советы внутри NIKE_DESIGN.md не выполнялись. Собственный DESIGN.md Apollo — итоговый документ проекта.
